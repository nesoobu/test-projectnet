"""Волна 78: 🤖 Автопилот канала — Соня сама ведёт канал по рубрикам.

Как у сервисов-автопилотов (Mira, Creaflow) и мем-ботов (just-memes, MemeBot), только строже:
• у каждой рубрики свои источники и СВОЙ фильтр качества — мем проверяется нейросетью по картинке («это
  правда мем? смешно ли?»), новость — на свежесть, тему и рекламу, факт — на «воду»; не прошло — следующий;
• новости — пересказ своими словами + ссылка на источник, смысловые дубли (одна новость с разных сайтов) — мимо;
• рубрики без источника (факт, совет, цитата, вопрос, опрос) — пишет ИИ, картинку рисует генератор;
• расписание по дням и часам, «сначала мне» — каждый пост приходит на ✅/🗑;
• в воскресенье — итоги недели: что вышло, что и почему отбраковано.
Каждая рубрика — обычный источник автопостинга (тип «auto»): его видно и можно настроить в панели."""
import asyncio
import json
import logging
import random
import re
import time
from html import escape
from urllib.parse import quote

import llm
from autopost import media_dl, sources, store

log = logging.getLogger("autopilot")

# ключ → эмодзи, название, вид, расписание по умолчанию (дни 0=пн), описание
RUBRICS = {
    "news": {"emoji": "📰", "name": "Новости", "kind": "news", "times": ["10:00", "18:00"], "days": list(range(7)),
             "desc": "свежие новости по теме: пересказ в 2–3 предложения и ссылка"},
    "meme": {"emoji": "😂", "name": "Мемы", "kind": "meme", "times": ["13:00", "21:00"], "days": list(range(7)),
             "desc": "только настоящие смешные мемы — каждый проверяю по картинке"},
    "art": {"emoji": "🎨", "name": "Картинки в тему", "kind": "art", "times": ["16:00"], "days": list(range(7)),
            "desc": "красивые картинки по теме канала с живой подписью"},
    "fact": {"emoji": "🧠", "name": "Факт", "kind": "ai", "times": ["11:00"], "days": [0, 2, 4],
             "desc": "интересный факт по теме + картинка"},
    "tip": {"emoji": "💡", "name": "Совет", "kind": "ai", "times": ["12:00"], "days": [1, 3],
            "desc": "полезный практичный совет + картинка"},
    "quote": {"emoji": "💬", "name": "Цитата", "kind": "ai", "times": ["09:30"], "days": [6],
              "desc": "цитата со смыслом и коротким комментарием"},
    "question": {"emoji": "❓", "name": "Вопрос подписчикам", "kind": "ai", "times": ["20:00"], "days": [3],
                 "desc": "вопрос для обсуждения в комментариях"},
    "poll": {"emoji": "📊", "name": "Опрос", "kind": "poll", "times": ["19:00"], "days": [1, 5],
             "desc": "настоящий опрос Telegram по теме"},
    "video": {"emoji": "🎬", "name": "Видео", "kind": "video", "times": ["17:00"], "days": [2, 5],
              "desc": "видео из твоих источников (YouTube, VK, ТГ-каналы)"},
}
DEFAULT_ON = ["news", "meme", "fact", "poll", "art"]
AI_PROMPTS = {
    "fact": "Один удивительный, НО ДОСТОВЕРНЫЙ факт по теме «{theme}». Без выдумок: если не уверена в цифре — "
            "не пиши цифру. Первая строка — цепляющий заголовок, дальше 2–4 предложения простым языком.",
    "tip": "Один практичный совет по теме «{theme}», который можно применить сегодня. Заголовок, потом 3–5 "
           "коротких пунктов или предложений. Без банальностей вроде «пейте воду».",
    "quote": "Короткая известная цитата, подходящая каналу о «{theme}», с автором (только реальная, без выдуманных "
             "авторов), и 1–2 предложения от себя — почему она откликается.",
    "question": "Вопрос подписчикам канала о «{theme}», на который хочется ответить в комментариях. 1–2 "
                "предложения контекста и сам вопрос. Без «а вы знали».",
}
STATE_KEY = "apl:{cid}"


# ================= профиль автопилота =================
async def profile(cid: int) -> dict:
    import db
    try:
        return json.loads(await db.kv_get(STATE_KEY.format(cid=cid)) or "{}")
    except ValueError:
        return {}


async def save(cid: int, p: dict):
    import db
    await db.kv_set(STATE_KEY.format(cid=cid), json.dumps(p, ensure_ascii=False))


def new_profile(theme: str) -> dict:
    return {"theme": theme, "lang": "ru", "mode": "moderate", "active": False, "on": list(DEFAULT_ON),
            "sources": {}, "rules": {}, "created": int(time.time())}


async def guess_theme(cid: int, owner: int) -> str:
    """Тема канала из названия и последних постов — ИИ одной строкой."""
    import db
    c = await store.channel(cid) or {}
    recent = await db.q_all("SELECT p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                            "WHERE s.chat_id=? AND s.status='sent' ORDER BY s.sent_at DESC LIMIT 12", cid)
    bits = [re.sub(r"<[^>]+>", "", r.get("text") or "")[:80] for r in recent]
    try:
        out = await llm.ask([{"role": "system", "content": "По названию и постам Telegram-канала опиши его тему "
                              "3–8 словами по-русски, без кавычек. Только тема."},
                             {"role": "user", "content": f"Канал: {c.get('title', '')}\nПосты: " + " | ".join(b for b in bits if b)}],
                            max_tokens=60, temperature=0.3)
        out = out.strip().strip("«»\"'.").split("\n")[0][:80]
        if len(out) >= 3:
            return out
    except Exception as e:
        log.info("тема: %s", e)
    return (c.get("title") or "жизнь и интересное")[:60]


# ================= источники =================
def default_sources(key: str, theme: str) -> list[list[str]]:
    """Источники по умолчанию для рубрики (дополняются своими)."""
    if key == "news":
        return [["rss", f"https://news.google.com/rss/search?q={quote(theme)}&hl=ru&gl=RU&ceid=RU:ru"]]
    if key == "meme":
        return [["pinterest", "q:смешные мемы"], ["pinterest", f"q:мемы {theme}"], ["reddit", "memes"]]
    if key == "art":
        return [["pinterest", f"q:{theme} эстетика"]]
    return []


def detect_source(raw: str) -> tuple[str, str] | None:
    """Ссылка → (тип, источник) для автопостинга."""
    raw = raw.strip()
    low = raw.lower()
    try:
        if "t.me/" in low or raw.startswith("@"):
            return "tg", sources.normalize("tg", raw)[0]
        if "vk.com/" in low or "vk.ru/" in low:
            if "video" in low or "clip" in low:
                return "video", raw
            return "vk", sources.normalize("vk", raw)[0]
        if "reddit.com/r/" in low:
            return "reddit", sources.normalize("reddit", raw)[0]
        if "pinterest." in low:
            return "pinterest", sources.normalize("pinterest", raw)[0]
        if any(h in low for h in ("youtube.com", "youtu.be", "rutube.ru", "tiktok.com", "dzen.ru/video")):
            return "video", raw
        if low.startswith(("http://", "https://")) or re.match(r"^[\w-]+(\.[\w-]+)+(/.*)?$", low):
            return "rss", raw if low.startswith("http") else "https://" + raw
    except sources.SourceError:
        return None
    return None


async def find_feed(url: str) -> str:
    """Сайт → его RSS (как браузеры: <link rel=alternate type=rss>). Уже лента — она и есть."""
    st, body = await sources._get(url)
    if st != 200:
        raise sources.SourceError(f"сайт ответил {st}")
    head = body[:4000].lower()
    if b"<rss" in head or b"<feed" in head or b"<rdf" in head:
        return url
    page = body.decode("utf-8", "ignore")
    for m in re.finditer(r"<link[^>]+>", page, re.I):
        tag = m.group(0)
        if re.search(r"application/(rss|atom)\+xml", tag, re.I):
            h = re.search(r'href=["\']([^"\']+)', tag)
            if h:
                return sources._web(h.group(1), url) or h.group(1)
    for guess in ("/feed", "/rss", "/rss.xml", "/feed.xml"):
        u = re.sub(r"(https?://[^/]+).*", r"\1", url) + guess
        try:
            st, b = await sources._get(u)
            if st == 200 and (b"<rss" in b[:4000].lower() or b"<feed" in b[:4000].lower()):
                return u
        except sources.SourceError:
            continue
    raise sources.SourceError("не нашла RSS на сайте — пришли ссылку на ленту или другой сайт")


def all_sources(cfg: dict) -> list[list[str]]:
    return [list(x[:2]) for x in (cfg.get("sources") or [])]


async def candidates(rule: dict, cfg: dict, seen: set, want: int) -> list[dict]:
    key = cfg.get("rubric") or rule["source"]
    kind = RUBRICS.get(key, {}).get("kind", "ai")
    if kind in ("ai", "poll"):
        return [{"key": f"ai:{time.time()}:{i}", "_ai": True} for i in range(want)]
    items, errs = [], []
    for t, src in all_sources(cfg):
        try:
            got = await sources.fetch(t, src, 30)
        except Exception as e:   # один сайт упал — остальные работают
            errs.append(f"{t}: {e}")
            continue
        for it in got:
            it["_src"] = t
            it["key"] = f"{t}|{it['key']}"
        items += got
    if not items and errs:
        raise sources.SourceError("; ".join(errs)[:200])
    fresh = [i for i in items if i["key"] not in seen]
    if kind == "news":   # свежие первыми
        fresh.sort(key=lambda i: i.get("ts") or 0, reverse=True)
    else:
        random.shuffle(fresh)
        fresh.sort(key=lambda i: -(i.get("views") or 0))   # популярное (просмотры ТГ) — вперёд
    return fresh[:max(want * 8, 12)]


# ================= фильтры качества =================
class Reject(Exception):
    pass


def _json(out: str) -> dict:
    m = re.search(r"\{.*\}", out or "", re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(0))
    except ValueError:
        return {}


MEME_JUDGE = (
    "Ты строгий редактор мем-канала. Посмотри на картинку и ответь ТОЛЬКО JSON: "
    '{"meme": true|false, "funny": 0-10, "lang": "ru"|"en"|"other"|"none", "why": "3-6 слов"}. '
    "meme=true — только если это мем: шутка, смешная подпись/диалог, абсурдная или жизненная ситуация, реакция, "
    "шаблон мема, смешной кадр. meme=false: пейзаж, закат, просто красивое фото, арт без шутки, реклама, "
    "скриншот длинного текста, мотивационная цитата, новость. funny — насколько реально смешно обычному человеку "
    "(7+ — засмеялся бы). lang — язык текста на картинке (none — текста нет).")
NEWS_JUDGE = (
    "Ты редактор новостного канала на тему «{theme}». Оцени запись и ответь ТОЛЬКО JSON: "
    '{"news": true|false, "relevant": 0-10, "ad": true|false, "why": "3-6 слов"}. '
    "news=true — это сообщение о событии/факте (не реклама, не вакансия, не гороскоп, не подборка «10 лучших»). "
    "relevant — насколько это про тему канала. ad=true — реклама/промо/партнёрский материал.")
ART_JUDGE = (
    "Ты редактор эстетичного канала на тему «{theme}». Ответь ТОЛЬКО JSON: "
    '{"relevant": 0-10, "quality": 0-10, "junk": true|false, "why": "3-6 слов"}. '
    "junk=true — реклама, водяные знаки магазинов, скриншот, коллаж с ценами, мем, текст вместо картинки.")
TEXT_JUDGE = ("Ты редактор Telegram-канала. Оцени пост и ответь ТОЛЬКО JSON: "
              '{"score": 0-10, "why": "3-6 слов"}. 7+ — интересно и по делу; ниже — вода, банальность, '
              "выдумка, канцелярит, «как ИИ», ошибки.")
MEME_MIN_FUNNY = 6


def _first_image(item: dict, media: list) -> str | None:
    for m in media:
        if m.get("type") == "photo" and str(m.get("src", "")).startswith("http"):
            return m["src"]
    img = item.get("image")
    return img if img and str(img).startswith("http") else None


async def judge_meme(item: dict, media: list, lang: str = "ru") -> dict:
    img = _first_image(item, media)
    if not img:
        raise Reject("нет картинки — нечем проверить, что это мем")
    try:
        out = await llm.ask_vision(MEME_JUDGE, "Это мем? Насколько смешно?", img, max_tokens=120)
    except Exception as e:
        raise Reject(f"не смогла посмотреть картинку ({str(e)[:40]}) — без проверки мемы не выкладываю")
    j = _json(out)
    if not j.get("meme"):
        raise Reject(f"не мем: {j.get('why') or 'обычная картинка'}")
    if int(j.get("funny") or 0) < MEME_MIN_FUNNY:
        raise Reject(f"не смешно ({j.get('funny')}/10): {j.get('why') or ''}".strip())
    if lang == "ru" and j.get("lang") == "other":
        raise Reject("текст на непонятном языке")
    return j


def _words(s: str) -> set:
    return {w for w in re.findall(r"[а-яёa-z0-9]{4,}", (s or "").lower())}


def is_dup_title(title: str, recent: list[str], thr: float = 0.5) -> bool:
    """Одна и та же новость с разных сайтов: много общих слов в заголовке."""
    a = _words(title)
    if len(a) < 3:
        return False
    for r in recent:
        b = _words(r)
        if b and len(a & b) / max(1, min(len(a), len(b))) >= thr:
            return True
    return False


async def judge_news(item: dict, theme: str, recent: list[str], max_age_h: int = 36) -> dict:
    ts = item.get("ts") or 0
    if ts and time.time() - ts > max_age_h * 3600:
        raise Reject(f"старая новость ({int((time.time() - ts) / 3600)} ч)")
    if is_dup_title(item.get("title", ""), recent):
        raise Reject("эта новость уже была (с другого сайта)")
    out = await llm.ask([{"role": "system", "content": NEWS_JUDGE.replace("{theme}", theme)},
                         {"role": "user", "content": f"{item.get('title', '')}\n{item.get('text', '')[:600]}"}],
                        max_tokens=120, temperature=0)
    j = _json(out)
    if j and (not j.get("news") or j.get("ad")):
        raise Reject("реклама" if j.get("ad") else f"не новость: {j.get('why') or ''}")
    if j and int(j.get("relevant") or 0) < 5:
        raise Reject(f"не по теме ({j.get('relevant')}/10)")
    return j


async def judge_art(item: dict, media: list, theme: str) -> dict:
    img = _first_image(item, media)
    if not img:
        return {}
    try:
        out = await llm.ask_vision(ART_JUDGE.replace("{theme}", theme), "Оцени картинку для канала.", img, max_tokens=100)
    except Exception:
        return {}   # vision упал — картинки и так с доски/поиска по теме
    j = _json(out)
    if j.get("junk"):
        raise Reject(f"мусор: {j.get('why') or ''}")
    if j and (int(j.get("relevant") or 0) < 5 or int(j.get("quality") or 0) < 5):
        raise Reject(f"не в тему/некрасиво ({j.get('relevant')}/{j.get('quality')})")
    return j


async def judge_text(text: str) -> int:
    try:
        out = await llm.ask([{"role": "system", "content": TEXT_JUDGE}, {"role": "user", "content": text[:1500]}],
                            max_tokens=80, temperature=0)
        return int(_json(out).get("score") or 7)
    except Exception:
        return 7


# ================= сборка поста =================
async def _picture(prompt_ru: str) -> dict | None:
    """Картинка к посту генератором (как /draw). Не вышло — пост без картинки."""
    from handlers import tools
    try:
        en = await llm.ask([{"role": "system", "content": "Write a short vivid English prompt (max 40 words) for an "
                             "illustration to this Telegram post. No text, no letters on the image. Only the prompt."},
                            {"role": "user", "content": prompt_ru[:800]}], max_tokens=120, temperature=0.7)
        url = (f"https://image.pollinations.ai/prompt/{quote((en or prompt_ru)[:300])}?width=1024&height=1024"
               f"&nologo=true&seed={random.randint(1, 10 ** 6)}&model=flux")
        data = await tools.fetch_image(url)
        path = str(media_dl._dir() / f"apl_{int(time.time() * 1000)}.jpg")
        with open(path, "wb") as f:
            f.write(data)
        return {"type": "photo", "src": path, "path": path}
    except Exception as e:
        log.info("картинка не нарисовалась: %s", e)
        return None


def _clean_ai(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = re.sub(r"(?m)^#{1,4}\s*", "", s)
    return s


def _headed(text: str) -> str:
    """Первая строка — жирный заголовок."""
    lines = text.strip().split("\n", 1)
    head = escape(lines[0].strip().strip("«»\"'"))
    body = escape(lines[1].strip()) if len(lines) > 1 else ""
    return f"<b>{head}</b>" + (f"\n\n{body}" if body else "")


async def _bump(rule: dict, cfg: dict, ok: bool, why: str = ""):
    st = cfg.get("apl_stats") or {}
    wk = time.strftime("%G-%V")
    if st.get("wk") != wk:
        st = {"wk": wk, "ok": 0, "rej": 0, "why": {}}
    if ok:
        st["ok"] += 1
    else:
        st["rej"] += 1
        w = re.sub(r"\(.*?\)|:.*$", "", why).strip()[:40] or "другое"
        st["why"][w] = st["why"].get(w, 0) + 1
    cfg["apl_stats"] = st
    await store.set_cfg(rule["id"], apl_stats=st)


async def materialize(rule: dict, cfg: dict, item: dict) -> dict:
    """Пост рубрики. Не прошёл фильтр качества → rules.SkipItem (берём следующую запись)."""
    from autopost import publisher, rules
    key = cfg.get("rubric") or rule["source"]
    rb = RUBRICS.get(key, RUBRICS["fact"])
    theme = cfg.get("theme") or "интересное"
    reacts = publisher.REACTION_SETS[cfg.get("reacts", 0) % len(publisher.REACTION_SETS)]
    opts = {"silent": bool(cfg.get("silent")), "link_preview": False}
    footer = ("\n\n" + escape(rule["footer"])) if rule.get("footer") else ""
    try:
        if rb["kind"] == "ai":
            recent = cfg.get("recent") or []
            sys_p = (AI_PROMPTS[key].format(theme=theme) + " Пиши по-русски, живо, как человек в своём канале, "
                     "300–700 символов, без хэштегов, без markdown, без «Конечно». Только текст поста.")
            if recent:
                sys_p += " Не повторяй прошлые темы: " + " | ".join(recent[-10:])
            text = ""
            for attempt in range(2):
                out = _clean_ai(await llm.ask([{"role": "system", "content": sys_p},
                                               {"role": "user", "content": "Новый пост."}],
                                              max_tokens=800, temperature=0.95))
                if out and await judge_text(out) >= 6:
                    text = out
                    break
                log.info("автопилот %s: текст слабый, переписываю", key)
            if not text:
                raise Reject("ИИ дважды написал слабо")
            await store.set_cfg(rule["id"], recent=(recent + [text.split("\n")[0][:60]])[-12:])
            pic = await _picture(text) if key != "question" else None
            body = _headed(text) if key in ("fact", "tip") else escape(text)
            await _bump(rule, cfg, True)
            return {"text": body + footer, "media": [pic] if pic else [], "buttons": [], "reactions": reacts,
                    "opts": opts}

        if rb["kind"] == "poll":
            recent = cfg.get("recent") or []
            out = await llm.ask([{"role": "system", "content":
                                  f"Придумай живой опрос для Telegram-канала о «{theme}». Ответ — ТОЛЬКО JSON: "
                                  '{"q": "вопрос до 200 символов", "options": ["2–6 вариантов, каждый до 80 символов"]}. '
                                  "Варианты смешные или жизненные, не «да/нет». Без повторов: " + " | ".join(recent[-8:])},
                                 {"role": "user", "content": "Новый опрос."}], max_tokens=400, temperature=1.0)
            j = _json(out)
            q = str(j.get("q") or "").strip()[:290]
            opts_l = [str(o).strip()[:95] for o in (j.get("options") or []) if str(o).strip()][:10]
            if not q or len(opts_l) < 2:
                raise Reject("ИИ не собрал опрос")
            await store.set_cfg(rule["id"], recent=(recent + [q[:60]])[-12:])
            await _bump(rule, cfg, True)
            return {"text": "", "media": [], "buttons": [], "reactions": [],
                    "opts": {**opts, "poll": {"q": q, "options": opts_l}}}

        if rb["kind"] == "news":
            recent = cfg.get("news_recent") or []
            await judge_news(item, theme, recent)
            out = _clean_ai(await llm.ask([{"role": "system", "content":
                                            "Перескажи новость для Telegram-канала по-русски: первая строка — короткий "
                                            "заголовок без кавычек, потом 2–3 предложения сути своими словами. "
                                            "Только факты из текста, ничего не добавляй. Без хэштегов и markdown."},
                                           {"role": "user", "content": f"{item.get('title', '')}\n{item.get('text', '')[:1500]}"}],
                                          max_tokens=500, temperature=0.4))
            if not out:
                raise Reject("ИИ не пересказал")
            await store.set_cfg(rule["id"], news_recent=(recent + [item.get("title", "")])[-60:])
            media = []
            if item.get("image"):
                media = [{"type": "photo", "src": item["image"]}]
            link = f'\n\n<a href="{escape(item.get("link", ""), quote=True)}">источник</a>' if item.get("link") else ""
            await _bump(rule, cfg, True)
            return {"text": _headed(out) + link + footer, "media": media, "buttons": [], "reactions": reacts,
                    "opts": opts}

        # meme / art / video — медиа из источника
        fake = {**rule, "type": item.get("_src") or "rss", "with_media": 1}
        kind = rb["kind"]
        media = await rules.resolve_media(fake, {**cfg, "media_kind": "video" if kind == "video" else "all"}, item)
        if not media:
            raise Reject("в записи нет картинки/видео")
        if kind == "meme":
            if not all(m["type"] in ("photo", "animation", "video") for m in media):
                raise Reject("не картинка")
            await judge_meme(item, media, cfg.get("lang", "ru"))
            text = ""
        elif kind == "art":
            await judge_art(item, media, theme)
            from autopost import captions
            text = ""
            try:
                text = escape(await captions.live_caption({"type": "pinterest", "source": theme},
                                                          {**cfg, "caption": cfg.get("caption") if cfg.get("caption", "none") != "none" else "vibe"},
                                                          item, media))
            except Exception as e:
                log.info("подпись: %s", e)
        else:
            text = escape(item.get("title") or "")[:200]
        await _bump(rule, cfg, True)
        return {"text": (text + footer).strip(), "media": media, "buttons": [], "reactions": reacts, "opts": opts}
    except Reject as e:
        await _bump(rule, cfg, False, str(e))
        raise rules.SkipItem(str(e))


# ================= включение / выключение =================
async def apply(owner: int, cid: int, p: dict) -> list[int]:
    """Профиль → источники «auto» (по одному на включённую рубрику). Выключенные — на паузу."""
    from autopost import rules as R
    made = []
    ch = await store.channel(cid)
    for key, rb in RUBRICS.items():
        rid = (p.get("rules") or {}).get(key)
        r = await store.rule(rid) if rid else None
        on = p.get("active") and key in p.get("on", [])
        srcs = (p.get("sources") or {}).get(key, []) + default_sources(key, p["theme"])
        if on and rb["kind"] in ("news", "meme", "art", "video") and not srcs:
            on = False   # видео без своих источников не включаю
        if not on:
            if r and r.get("active"):
                await store.set_rule(rid, active=0)
            continue
        cfg = {"rubric": key, "theme": p["theme"], "lang": p.get("lang", "ru"), "sources": srcs,
               "sched": "times", "times": (p.get("times") or {}).get(key) or rb["times"],
               "days": (p.get("days") or {}).get(key) or rb["days"], "autopilot": cid,
               "caption": "none", "tags": "none", "link_style": "none"}
        title = f"🤖 {rb['emoji']} {rb['name']}"
        if not r:
            rid = await store.add_rule(owner, cid, "auto", key, title)
            p.setdefault("rules", {})[key] = rid
            r = await store.rule(rid)
        await store.set_rule(rid, active=1, moderation=1 if p.get("mode", "moderate") == "moderate" else 0, title=title)
        await store.set_cfg(rid, **cfg)
        r = await store.rule(rid)
        await store.set_rule(rid, next_run=R.next_run(r, store.cfg_of(r), ch))
        made.append(rid)
    return made


async def report(cid: int) -> str:
    p = await profile(cid)
    lines = []
    wk = time.strftime("%G-%V")
    for key, rid in (p.get("rules") or {}).items():
        r = await store.rule(rid)
        if not r:
            continue
        st = store.cfg_of(r).get("apl_stats") or {}
        if st.get("wk") != wk:
            st = {"ok": 0, "rej": 0, "why": {}}
        rb = RUBRICS.get(key, {})
        why = ", ".join(f"{k} — {v}" for k, v in sorted(st.get("why", {}).items(), key=lambda x: -x[1])[:3])
        lines.append(f"{rb.get('emoji', '•')} <b>{rb.get('name', key)}</b>: вышло {st.get('ok', 0)}"
                     + (f" · отсеяла {st['rej']} ({escape(why)})" if st.get("rej") else ""))
    return "\n".join(lines) or "пока ничего не выходило"


async def report_loop(bot):
    """По воскресеньям в 20:00 МСК — итоги недели владельцу каждого канала на автопилоте."""
    import db
    from datetime import datetime, timedelta, timezone
    msk = timezone(timedelta(hours=3))
    while True:
        await asyncio.sleep(600)
        try:
            now = datetime.now(msk)
            if now.weekday() != 6 or now.hour < 20:
                continue
            rows = await db.q_all("SELECT k, v FROM kv WHERE k LIKE 'apl:%' AND k NOT LIKE 'apl:rep:%'")
            for row in rows:
                try:
                    cid = int(row["k"].split(":")[1])
                    p = json.loads(row["v"])
                except (ValueError, IndexError):
                    continue
                if not p.get("active"):
                    continue
                mark = f"apl:rep:{cid}:{time.strftime('%G-%V')}"
                if await db.kv_get(mark):
                    continue
                await db.kv_set(mark, "1")
                ch = await store.channel(cid) or {}
                owner = ch.get("owner_id")
                if owner:
                    await bot.send_message(owner, f"📈 <b>итоги недели · {escape(ch.get('title', ''))}</b>\n\n"
                                           + await report(cid))
        except Exception as e:
            log.warning("итоги автопилота: %s", e)
