"""Волна 38: капча, отсев ботов, бусты, подтверждение победы, видео/GIF, свой текст кнопки."""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMessage, SendVideo, SendDocument, AnswerCallbackQuery
from aiogram.types import Update, CallbackQuery, Message, Chat, User, Video, MessageOriginChannel


def cbu(data, uid, chat_id=None):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name=f"U{uid}"),
        message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=chat_id or uid, type="private"))))


def acq():
    return H.sent(AnswerCallbackQuery)


async def new_gw(dp, bot, opts, n=1, media=None):
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:text", 1, 1))
    await dp.feed_update(bot, msg("приз", 1, 1))
    await dp.feed_update(bot, cbq(f"gw:w:{n}", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    for o in opts:
        await dp.feed_update(bot, cbq(f"gw:o:{o}", 1, 1))
        if o == "btn":
            await dp.feed_update(bot, msg("🔥 Хочу приз", 1, 1))
        if o == "ph":
            await dp.feed_update(bot, msg(None, 1, 1, video=media))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    return await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import giveaway as G
    G.ANIM_PAUSE = 0
    H.ADMINS.add(1)
    await dp.feed_update(bot, msg("/start", 1, 1))
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, msg("пост", 1, 1, forward_origin=MessageOriginChannel(
        type="channel", date=datetime.now(), chat=Chat(id=-100777, type="channel", title="City_N"), message_id=5)))
    await dp.feed_update(bot, cbq("gw:cancelnew", 1, 1))
    sus = {50}
    async def fake_sus(bot_, user): return user.id in sus
    boosted = {60}
    async def fake_boost(bot_, chat, uid): return 1 if uid in boosted else 0
    G._suspicious, G.boosts_of = fake_sus, fake_boost
    # ---------- видео, свой текст кнопки, капча, бусты ----------
    v = Video(file_id="VID", file_unique_id="v", width=1, height=1, duration=5)
    SENT.clear()
    g = await new_gw(dp, bot, ["cap", "bst", "btn", "ph"], media=v)
    sv = H.sent(SendVideo)
    check(f"[{P}] пост с видео и своей кнопкой", sv and sv[-1].video == "VID" and "🔥 Хочу приз" in str(sv[-1].reply_markup)
          and "проверку" in sv[-1].caption and "забусти" in sv[-1].caption and "боты" in sv[-1].caption)
    check(f"[{P}] отсев ботов включён по умолчанию", g["antibot"] == 1 and g["captcha"] == 1 and g["boost_bonus"] == 3)
    SENT.clear()
    await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", 60))
    check(f"[{P}] капча: кнопка ведёт в бота на проверку", any(f"gwcap_{g['id']}" in (a.url or "") for a in acq()))
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwcap_{g['id']}", 60, 60))
    right = G._cap[(60, g["id"])][0]
    kb = H.sent(SendMessage)[-1].reply_markup
    wrong = next(b.callback_data for row in kb.inline_keyboard for b in row if not b.callback_data.endswith(right))
    await dp.feed_update(bot, cbu(wrong, 60))
    check(f"[{P}] капча: мимо — ещё попытка", not await db.q_one("SELECT 1 FROM giveaway_users WHERE uid=60")
          and (60, g["id"]) in G._cap)
    right = G._cap[(60, g["id"])][0]
    await dp.feed_update(bot, cbu(f"gw:cap:{g['id']}:0:{right}", 60))
    row = await db.q_one("SELECT * FROM giveaway_users WHERE gid=? AND uid=60", g["id"])
    check(f"[{P}] капча пройдена → в игре, с бустом 1+3 билета", row and row["tickets"] == 4 and row["boosts"] == 1)
    # ---------- отсев ботов на итогах ----------
    g2 = await new_gw(dp, bot, [], n=1)
    for u in (50, 51):
        await dp.feed_update(bot, cbu(f"gw:j:{g2['id']}", u))
    check(f"[{P}] подозрительный помечен", (await db.q_one("SELECT flags FROM giveaway_users WHERE uid=50 AND gid=?",
                                                           g2["id"]))["flags"] == "sus")
    SENT.clear()
    await G.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g2["id"]))
    r = (await db.q_one("SELECT result FROM giveaways WHERE id=?", g2["id"]))["result"]
    check(f"[{P}] 🤖 бот не выиграл", r == "51")
    csv = H.sent(SendDocument)[-1]
    check(f"[{P}] CSV: время входа и пометка", csv.document.filename.endswith(".csv"))
    # ---------- подтверждение победы ----------
    g3 = await new_gw(dp, bot, ["cf"], n=1)
    for u in (70, 71, 72):
        await dp.feed_update(bot, cbu(f"gw:j:{g3['id']}", u))
    SENT.clear()
    await G.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g3["id"]))
    w1 = int((await db.q_one("SELECT result FROM giveaways WHERE id=?", g3["id"]))["result"])
    dm = [m for m in H.sent(SendMessage) if m.chat_id == w1]
    from aiogram.methods import EditMessageText as _E   # волна 56: итоги приходят правкой «барабана»
    ch = [m for m in SENT if isinstance(m, (SendMessage, _E)) and m.chat_id == -100777 and m.reply_markup]
    check(f"[{P}] ⏰ победителю — «подтверди», в канале — кнопка", dm and f"gw:cf:{g3['id']}" in str(dm[-1].reply_markup)
          and ch and f"gwcf_{g3['id']}" in str(ch[-1].reply_markup))
    await db.q_run("UPDATE gw_wins SET ts=? WHERE gid=?", int(time.time()) - 25 * 3600, g3["id"])
    SENT.clear()
    await G.expire_confirms(bot)
    w2 = int((await db.q_one("SELECT result FROM giveaways WHERE id=?", g3["id"]))["result"])
    check(f"[{P}] не подтвердил за 24 ч — перевыбор", w2 != w1 and any("не подтвердил" in t for t in texts()))
    SENT.clear()
    await dp.feed_update(bot, cbu(f"gw:cf:{g3['id']}", w2))
    st = (await db.q_one("SELECT status FROM gw_wins WHERE gid=? AND uid=?", g3["id"], w2))["status"]
    check(f"[{P}] новый подтвердил — владелец узнал", st == "ok" and any("подтвердил" in t for t in texts()))
    await dp.feed_update(bot, cbu(f"gw:cf:{g3['id']}", w1))
    check(f"[{P}] старый уже не может подтвердить", any("время вышло" in (a.text or "") for a in acq()))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
