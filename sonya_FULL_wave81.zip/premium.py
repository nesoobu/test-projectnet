"""✨ Монетизация: мягкие суточные лимиты на «дорогие» функции, пробная Соня+, приглашение купить.
Бесплатное не отнимаем — лимиты только на то, что жрёт сервер и нейросети.
Волна 44: Соня+ одна на всех ботов — покупается в основной Соне, помощники читают её базу."""
import time

import config
import db

# что сколько раз в день бесплатно (0 — только с Соней+)
DAILY = {"fx": 3, "vtxt": 3, "hd": 0, "long": 0, "stt": 20, "stk_video": 3, "stk_cut": 10, "stk_copy": 0, "stk_emojiver": 0,
         "ai_mod": 0, "chat_gender": 0}
# сколько штук можно иметь бесплатно (0 — без лимита; каналы и источники — из .env)
COUNT = {"subs": 3, "stk_packs": 1, "stk_items": 30}
TRIAL_DAYS = 3
NAMES = {
    "fx": "эффекты (slowed, 8D, бас…)", "vtxt": "текст из видео", "hd": "видео 1080p и выше",
    "subs": "подписки на артистов", "ap_channels": "каналы в автопостинге", "ap_rules": "автоисточники",
    "long": "видео длиннее 30 минут", "stt": "расшифровка голосовых", "stk_video": "видео-стикеры из GIF, видео и кружков",
    "stk_cut": "умное вырезание фона", "stk_copy": "весь чужой пак себе",
    "stk_emojiver": "эмодзи-версия пака",
    "stk_packs": "паки", "stk_items": "стикеров в паке", "ai_mod": "ИИ-антиспам и итоги дня",
    "chat_gender": "поиск по полу в анонимном чате",
}
MAIN_LINK_ARG = "plus"   # t.me/<Соня>?start=plus — экран Сони+


def plus(uid: int) -> bool:
    from handlers import extra
    return extra.active(uid)


async def chat_plus(bot, chat) -> bool:
    """Соня+ для чата: в личке — у человека, в группе — у любого её админа."""
    if chat.type == "private":
        return plus(chat.id)
    from handlers import groupmod
    try:
        return any(plus(a) for a in await groupmod.admins_of(bot, chat.id))
    except Exception:
        return False


def main_url() -> str:
    return f"https://t.me/{config.MAIN_BOT}?start={MAIN_LINK_ARG}"


async def used(uid: int, feat: str) -> int:
    r = await db.q_one("SELECT n FROM feat_usage WHERE uid=? AND day=? AND feat=?", uid, db._day(), feat)
    return r["n"] if r else 0


async def allow(uid: int, feat: str, is_plus: bool | None = None) -> bool:
    """Списать одно использование. False — бесплатное на сегодня кончилось.
    uid — чей счётчик (для групп — id чата); is_plus — уже посчитанный плюс (для групп)."""
    if plus(uid) if is_plus is None else is_plus:
        return True
    if await used(uid, feat) >= DAILY.get(feat, 0):
        return False
    await db.q_run("INSERT INTO feat_usage VALUES(?,?,?,1) ON CONFLICT(uid, day, feat) DO UPDATE SET n=n+1",
                   uid, db._day(), feat)
    return True


def limit_of(feat: str) -> int:
    if feat == "ap_rules":
        return config.FREE_SOURCES
    if feat == "ap_channels":
        return config.FREE_CHANNELS
    return COUNT.get(feat, 0)


def can_have(uid: int, feat: str, have: int) -> bool:
    lim = limit_of(feat)
    return plus(uid) or not lim or have < lim


async def trial_used(uid: int) -> bool:
    u = await db.get_user(uid) or {}
    return bool(u.get("plus_trial"))


async def upsell_kb(uid: int):
    from handlers.ap_common import kb_rows
    if config.PROFILE != "full":   # помощник: Соню+ покупают у основной Сони — заодно знакомятся с ней
        return kb_rows([(f"✨ Соня+ — у @{config.MAIN_BOT}", main_url())])
    rows = [[("✨ Соня+ от 29 ⭐", "m:plus")]]
    if not await trial_used(uid):
        rows.insert(0, [(f"🎁 {TRIAL_DAYS} дня бесплатно", "plus:trial")])
    return kb_rows(*rows)


async def upsell_text(uid: int, feat: str) -> str:
    import ui
    if feat in DAILY and DAILY[feat]:
        head = f"⏳ <b>{NAMES[feat]}</b>: {DAILY[feat]} в день бесплатно — на сегодня всё"
    elif limit_of(feat):
        head = f"🔒 <b>{NAMES[feat]}</b>: бесплатно до {limit_of(feat)}"
    else:
        head = f"💎 <b>{NAMES[feat]}</b> — только с Соней+"
    tail = "с ✨ Соней+ — без лимитов, плюс приоритет в очереди и HD"
    if config.PROFILE != "full":
        tail = f"✨ Соня+ — одна на все боты Сони: купил у @{config.MAIN_BOT} — работает и здесь"
    if feat in DAILY and DAILY[feat]:
        tail += ". завтра лимит обновится"
    return head + "\n" + ui.hint(tail)


async def upsell(m, uid: int, feat: str):
    """m — Message, куда ответить."""
    await m.answer(await upsell_text(uid, feat), reply_markup=await upsell_kb(uid))


async def start_trial(uid: int) -> int | None:
    from handlers import extra
    # волна 62: одной командой — двойной тап раньше давал пробу дважды (6 дней вместо 3)
    if not await db.q_change("UPDATE users SET plus_trial=? WHERE id=? AND COALESCE(plus_trial,0)=0",
                             int(time.time()), uid):
        return None
    return await extra.grant_plus(uid, TRIAL_DAYS)
