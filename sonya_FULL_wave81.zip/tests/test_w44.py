"""Волна 44: общая Соня+, 🛡 помощник для групп, 🧩 стикеры. Профиль: аргумент 2 (full|dl|grp|stk).
python test_w44.py ../sonya grp"""
import asyncio
import io
import os
import sqlite3
import sys
import time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "grp"
from aiogram.methods import (SendMessage, AnswerCallbackQuery, CreateNewStickerSet, AddStickerToSet,
                             DeleteStickerFromSet, EditMessageText)
from aiogram.types import PhotoSize, Voice, Sticker

PLUS_UID, FREE_UID = 77, 78


def main_db():
    """База «основной Сони» для помощников: у 77 есть Соня+, у 78 — нет."""
    path = os.path.join(H.TMP, "main.db")
    c = sqlite3.connect(path)
    c.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, plus_until INTEGER)")
    c.execute("INSERT OR REPLACE INTO users VALUES(?,?)", (PLUS_UID, int(time.time()) + 86400))
    c.execute("INSERT OR REPLACE INTO users VALUES(?,?)", (FREE_UID, 0))
    c.commit()
    c.close()
    config.MAIN_DB_PATH = path


def all_text():
    out = []
    for m in SENT:
        for a in ("text", "caption"):
            v = getattr(m, a, None)
            if isinstance(v, str):
                out.append(v)
    return "\n".join(out)


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    P = config.PROFILE
    if P != "full":
        main_db()
    M, bot, dp = await setup()
    import premium
    from handlers import extra

    if P == "full":
        await extra.grant_plus(PLUS_UID, 3)
        check("full: плюс по своей базе", premium.plus(PLUS_UID) and not premium.plus(FREE_UID))
        SENT.clear()
        await dp.feed_update(bot, msg("/start plus", 60, 60))
        check("full: /start plus — экран Сони+ (ссылка из помощников)", "plus:buy" in kbs())
        check("full: в Соне+ сказано, что она на все боты", "на все мои боты" in extra.PLUS_TEXT)
        kb = str(await premium.upsell_kb(FREE_UID))
        check("full: покупка внутри Сони", "m:plus" in kb)
        SENT.clear()
        await dp.feed_update(bot, msg("/bots", 60, 60))
        check("full: /bots отвечает", "боты" in all_text())
        from handlers import menu
        import fleet
        fleet.helpers = lambda: [{"profile": "stk", "name": "🧩 стикеры", "token": "1:x", "db": "", "service": ""}]
        menu._bot_names["1:x"] = "SonyaStickerBot"
        SENT.clear()
        await dp.feed_update(bot, msg("/bots", 60, 60))
        check("full: /bots — ссылки на помощников", "t.me/SonyaStickerBot" in kbs() and "стикеры" in all_text())
        # длинное видео — только с Соней+
        from handlers import media
        tok = media._token("https://youtu.be/x", "youtube", "YouTube")
        media._long_tok.add(tok)
        SENT.clear()
        await dp.feed_update(bot, cbq(f"dl:v:{tok}", FREE_UID, FREE_UID))
        check("full: видео > 30 мин без плюса — предложение Сони+", "30 минут" in all_text())
        # розыгрыш без подписи бота у плюса
        from handlers import giveaway
        check("full: розыгрыш с Соней+ — без «через @бот»",
              giveaway._via("bot", {"owner_id": PLUS_UID}) == "" and giveaway._via("bot", {"owner_id": FREE_UID}) == "bot")

    if P == "dl":
        check("dl: Соня+ читается из базы Сони", premium.plus(PLUS_UID) and not premium.plus(FREE_UID))
        check("dl: владелец всегда с плюсом", premium.plus(config.OWNER_ID))
        kb = str(await premium.upsell_kb(FREE_UID))
        check("dl: покупка — ссылкой на Соню", f"t.me/{config.MAIN_BOT}?start=plus" in kb and "m:plus" not in kb)
        check("dl: лимиты теперь работают и в помощнике",
              await premium.allow(FREE_UID, "fx") and await premium.allow(FREE_UID, "fx")
              and await premium.allow(FREE_UID, "fx") and not await premium.allow(FREE_UID, "fx")
              and await premium.allow(PLUS_UID, "fx"))
        t = await premium.upsell_text(FREE_UID, "fx")
        check("dl: в предложении — «одна Соня+ на все боты»", "одна на все боты" in t)

    if P == "grp":
        from handlers import media, grp
        SENT.clear()
        await M.setup_commands(bot)
        from aiogram.methods import SetMyCommands
        cmds = {c.command for m in SENT if isinstance(m, SetMyCommands) for c in m.commands}
        check("grp: свои команды", {"settings", "text", "summary", "warn"} <= cmds and "draw" not in cmds)
        SENT.clear()
        await dp.feed_update(bot, msg("/start", 60, 60))
        check("grp: старт — «добавить в группу» с правами админа", "startgroup=grp" in kbs() and "admin=" in kbs()
              and "Помощник для групп" in all_text())
        # настройки: ИИ-функции — только с плюсом у админа
        H.ADMINS.clear()
        H.ADMINS.add(FREE_UID)   # владелец (1) — всегда с плюсом, в этих группах его нет
        from handlers import groupmod
        groupmod._admins.clear()
        await db.add_chat(-900, "Чат")
        SENT.clear()
        await dp.feed_update(bot, msg("/settings", -900, FREE_UID))
        check("grp: /settings — свои переключатели", "Помощник в этой группе" in all_text() and "gs:auto_voice" in kbs()
              and "gs:auto_dl" not in kbs())
        SENT.clear()
        await dp.feed_update(bot, cbq("gs:antispam", -900, FREE_UID))
        alerts = [m for m in SENT if isinstance(m, AnswerCallbackQuery) and m.show_alert]
        check("grp: ИИ-антиспам без плюса не включается", alerts and "Соней+" in alerts[-1].text
              and not await db.chat_flag(-900, "antispam"))
        SENT.clear()
        await dp.feed_update(bot, cbq("gs:captcha", -900, FREE_UID))
        check("grp: капча включается бесплатно", await db.chat_flag(-900, "captcha"))
        await db.set_chat_flag(-900, "captcha", False)
        H.ADMINS.add(PLUS_UID)
        groupmod._admins.clear()
        SENT.clear()
        await dp.feed_update(bot, cbq("gs:antispam", -900, FREE_UID))
        check("grp: плюс у любого админа — ИИ-антиспам включается", await db.chat_flag(-900, "antispam"))
        check("grp: ИИ разрешён в чате с плюсом", await grp.ai_allowed(bot, -900))
        # голосовые: лимит на чат
        calls = []

        async def fake_tr(m, bot, target, quiet=False):
            calls.append(target.message_id)
            return "текст"
        media.transcribe_message = fake_tr
        H.ADMINS.discard(PLUS_UID)
        groupmod._admins.clear()
        await db.add_chat(-901, "Чат2")
        v = lambda d: Voice(file_id="v", file_unique_id="v", duration=d)  # noqa: E731
        for _ in range(premium.DAILY["stt"]):
            await dp.feed_update(bot, msg(None, -901, 61, voice=v(10)))
        check("grp: 20 голосовых в день бесплатно", len(calls) == premium.DAILY["stt"])
        SENT.clear()
        await dp.feed_update(bot, msg(None, -901, 61, voice=v(10)))
        await dp.feed_update(bot, msg(None, -901, 61, voice=v(10)))
        ups = [t for t in H.texts() if "расшифровок в день" in t]
        check("grp: 21-е — без расшифровки, Соня+ предложена один раз", len(calls) == premium.DAILY["stt"] and len(ups) == 1)
        check("grp: кнопка Сони+ ведёт к основной Соне", f"t.me/{config.MAIN_BOT}?start=plus" in kbs())
        await db.add_chat(-902, "Чат3")
        SENT.clear()
        await dp.feed_update(bot, msg(None, -902, 61, voice=v(6 * 60)))
        check("grp: голосовое > 5 мин без плюса — не расшифровываю", len(calls) == premium.DAILY["stt"]
              and "до 5 мин" in all_text())
        H.ADMINS.add(PLUS_UID)
        groupmod._admins.clear()
        await dp.feed_update(bot, msg(None, -902, 61, voice=v(6 * 60)))
        check("grp: с плюсом у админа — длинное расшифровано", len(calls) == premium.DAILY["stt"] + 1)
        await db.set_chat_flag(-902, "auto_voice", False)
        await dp.feed_update(bot, msg(None, -902, 61, voice=v(10)))
        check("grp: авторасшифровку можно выключить", len(calls) == premium.DAILY["stt"] + 1)
        # приветствие без ИИ
        from aiogram.types import User
        await db.set_chat_flag(-902, "greet", True)
        SENT.clear()
        await dp.feed_update(bot, msg(None, -902, 62, new_chat_members=[User(id=63, is_bot=False, first_name="Аня")]))
        check("grp: приветствие новичка", "Аня" in all_text() and "добро пожаловать" in all_text())

    if P == "stk":
        from handlers import stickers
        from PIL import Image
        img = io.BytesIO()
        Image.new("RGB", (300, 200), "red").save(img, "PNG")
        st = Image.open(io.BytesIO(stickers.to_png(img.getvalue(), "sticker")))
        em = Image.open(io.BytesIO(stickers.to_png(img.getvalue(), "emoji")))
        check("stk: стикер — сторона 512", max(st.size) == 512 and st.size == (512, 341))
        check("stk: эмодзи — ровно 100×100", em.size == (100, 100))
        check("stk: эмодзи из подписи", stickers.pick_emoji("котик 😺") == "😺" and stickers.pick_emoji("") == "✨")

        async def fake_build(bot, m, kind):
            from aiogram.types import InputSticker, BufferedInputFile
            return InputSticker(sticker=BufferedInputFile(b"x", "s.png"), format="static", emoji_list=["✨"])
        stickers.build = fake_build
        photo = [PhotoSize(file_id="p", file_unique_id="p", width=10, height=10)]
        SENT.clear()
        await dp.feed_update(bot, msg("/start", FREE_UID, FREE_UID))
        check("stk: старт — новый пак эмодзи/стикеров", "stk:new:emoji" in kbs() and "Стикеры и эмодзи" in all_text())
        SENT.clear()
        await dp.feed_update(bot, msg(None, FREE_UID, FREE_UID, photo=photo))
        check("stk: первая картинка — спрашиваю тип пака", "stk:new:sticker" in kbs())
        SENT.clear()
        await dp.feed_update(bot, cbq("stk:new:sticker", FREE_UID, FREE_UID))
        await dp.feed_update(bot, cbq("stk:wr", FREE_UID, FREE_UID))   # волна 52: мастер — всё случайно
        mk = [m for m in SENT if isinstance(m, CreateNewStickerSet)]
        check("stk: пак создан из ожидавшей картинки", mk and mk[0].sticker_type == "regular"
              and mk[0].name.endswith("_by_Sonya_rubot") and mk[0].user_id == FREE_UID)
        check("stk: без плюса — подпись бота в названии", mk and mk[0].title.endswith("· @Sonya_rubot"))
        p = (await stickers.packs_of(FREE_UID))[0]
        check("stk: пак в базе и текущий", p["n"] == 1 and (await stickers.current(FREE_UID))["id"] == p["id"])
        SENT.clear()
        await dp.feed_update(bot, msg(None, FREE_UID, FREE_UID, photo=photo))
        check("stk: следующая картинка — в тот же пак", [m for m in SENT if isinstance(m, AddStickerToSet)]
              and (await stickers.current(FREE_UID))["n"] == 2)
        await db.q_run("UPDATE sticker_packs SET n=? WHERE id=?", premium.COUNT["stk_items"], p["id"])
        SENT.clear()
        await dp.feed_update(bot, msg(None, FREE_UID, FREE_UID, photo=photo))
        check("stk: 30 штук без плюса — предел", not [m for m in SENT if isinstance(m, AddStickerToSet)]
              and "стикеров в паке" in all_text())
        SENT.clear()
        await dp.feed_update(bot, cbq("stk:new:emoji", FREE_UID, FREE_UID))
        await dp.feed_update(bot, cbq("stk:wr", FREE_UID, FREE_UID))   # волна 52: мастер — всё случайно
        check("stk: второй пак без плюса — Соня+", "паки" in all_text() and f"start=plus" in kbs())
        from aiogram.types import Animation
        await db.q_run("UPDATE sticker_packs SET n=1 WHERE id=?", p["id"])   # волна 51: видео — 3 в день бесплатно
        await db.q_run("INSERT INTO feat_usage VALUES(?,?,?,?)", FREE_UID, db._day(), "stk_video", premium.DAILY["stk_video"])
        SENT.clear()
        await dp.feed_update(bot, msg(None, FREE_UID, FREE_UID,
                                      animation=Animation(file_id="a", file_unique_id="a", width=1, height=1, duration=1)))
        check("stk: GIF сверх дневного лимита — Соня+", "видео-стикеры" in all_text())
        # с плюсом: второй пак, эмодзи, без подписи
        SENT.clear()
        await dp.feed_update(bot, msg(None, PLUS_UID, PLUS_UID, photo=photo))
        await dp.feed_update(bot, cbq("stk:new:emoji", PLUS_UID, PLUS_UID))
        await dp.feed_update(bot, cbq("stk:wr", PLUS_UID, PLUS_UID))   # волна 52: мастер — всё случайно
        await dp.feed_update(bot, cbq("stk:new:sticker", PLUS_UID, PLUS_UID))
        await dp.feed_update(bot, cbq("stk:wr", PLUS_UID, PLUS_UID))   # волна 52: мастер — всё случайно
        await dp.feed_update(bot, msg(None, PLUS_UID, PLUS_UID, photo=photo))
        mk = [m for m in SENT if isinstance(m, CreateNewStickerSet)]
        check("stk: с плюсом — два пака, эмодзи-пак, чистое название",
              len(mk) == 2 and mk[0].sticker_type == "custom_emoji" and "@Sonya_rubot" not in mk[0].title)
        # переименование
        SENT.clear()
        await dp.feed_update(bot, cbq(f"stk:ren:{p['id']}", FREE_UID, FREE_UID))
        await dp.feed_update(bot, msg("Котики", FREE_UID, FREE_UID))
        from aiogram.methods import SetStickerSetTitle
        ren = [m for m in SENT if isinstance(m, SetStickerSetTitle)]
        check("stk: переименование", ren and ren[0].title.startswith("Котики")
              and (await db.q_one("SELECT title FROM sticker_packs WHERE id=?", p["id"]))["title"] == "Котики")
        # свой стикер — удалить
        SENT.clear()
        own = Sticker(file_id="own1", file_unique_id="o", type="regular", width=512, height=512, is_animated=False,
                      is_video=False, set_name=p["name"])
        await dp.feed_update(bot, msg(None, FREE_UID, FREE_UID, sticker=own))
        tok = (await db.q_one("SELECT k FROM kv WHERE k LIKE 'stk:card:%' ORDER BY rowid DESC"))["k"].split(":")[2]
        await dp.feed_update(bot, cbq(f"stk:c:rm:{tok}", FREE_UID, FREE_UID))
        dl = [m for m in SENT if isinstance(m, DeleteStickerFromSet)]
        check("stk: свой стикер — удаляется из пака", dl and dl[0].sticker == "own1")
        SENT.clear()
        await dp.feed_update(bot, msg("/packs", FREE_UID, FREE_UID))
        check("stk: /packs — ссылки на паки", "addstickers/" in kbs())

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
