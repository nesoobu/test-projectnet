"""Волна 62: розыгрыши — капча картинкой (3 вида + случайная, пауза после 3 промахов), фильтр новых аккаунтов,
двойные нажатия (отмена, подтверждение, выбор подарка, итоги, вход, буст) больше не срабатывают дважды.
python test_w62.py ../sonya full   (и gw)"""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMessage, SendPhoto, AnswerCallbackQuery
from aiogram.types import Update, CallbackQuery, Message, Chat, User, MessageOriginChannel


def cbu(data, uid):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name=f"U{uid}"),
        message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=uid, type="private"))))


def alerts():
    return [a.text or "" for a in H.sent(AnswerCallbackQuery)]


async def new_gw(dp, bot, opts):
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:text", 1, 1))
    await dp.feed_update(bot, msg("приз", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:1", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    for o in opts:
        await dp.feed_update(bot, cbq(f"gw:o:{o}", 1, 1))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    return await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import giveaway as G, gifts
    import gwcaptcha
    G.ANIM_PAUSE = 0
    H.ADMINS.add(1)
    await dp.feed_update(bot, msg("/start", 1, 1))
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, msg("пост", 1, 1, forward_origin=MessageOriginChannel(
        type="channel", date=datetime.now(), chat=Chat(id=-100777, type="channel", title="City_N"), message_id=5)))
    await dp.feed_update(bot, cbq("gw:cancelnew", 1, 1))

    async def no_sus(bot_, user): return False
    G._suspicious = no_sus

    # ---------- картинки капчи ----------
    ok = True
    for k in (1, 2, 3, 4):
        for _ in range(5):
            png, q, opts, right = gwcaptcha.make(k)
            ok &= png[:8] == b"\x89PNG\r\n\x1a\n" and 0 <= right < len(opts) and opts[right] not in q \
                and len(set(opts)) == len(opts)
    check(f"[{P}] капча: 4 вида рисуются, ответа нет в вопросе, варианты разные", ok)

    # ---------- выбор вида кнопкой по кругу ----------
    g = await new_gw(dp, bot, ["cap", "cap"])
    check(f"[{P}] «🛡 Капча» по кругу: два нажатия → «Число»", g["captcha"] == 2)

    # ---------- капча в боте: картинка, ответ не в тексте и не в кнопках ----------
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwcap_{g['id']}", 60, 60))
    ph = H.sent(SendPhoto)
    right = G._cap[(60, g["id"])][0]
    datas = [b.callback_data for row in ph[-1].reply_markup.inline_keyboard for b in row] if ph else []
    check(f"[{P}] капча пришла картинкой, в кнопках только номера вариантов",
          ph and all(d.rsplit(":", 1)[1].isdigit() for d in datas) and len(datas) == 4)
    wrong = [d for d in datas if not d.endswith(f":{right}")]
    for i in range(3):
        await dp.feed_update(bot, cbu(wrong[0], 60))
        if (60, g["id"]) in G._cap:
            wrong = [d.replace(d.rsplit(":", 1)[1], "x") for d in []] or [
                f"gw:cap:{g['id']}:0:{(G._cap[(60, g['id'])][0] + 1) % 4}"]
    check(f"[{P}] 3 промаха → пауза, в розыгрыш не пустило",
          not await db.q_one("SELECT 1 FROM giveaway_users WHERE uid=60")
          and float(await db.kv_get(f"gw:capban:{g['id']}:60") or 0) > time.time())
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwcap_{g['id']}", 60, 60))
    check(f"[{P}] на паузе новую капчу не даю (перебор не работает)",
          not H.sent(SendPhoto) and any("промахов" in t for t in H.texts()))
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwcap_{g['id']}", 61, 61))
    await dp.feed_update(bot, cbu(f"gw:cap:{g['id']}:0:{G._cap[(61, g['id'])][0]}", 61))
    check(f"[{P}] верный ответ → в игре", await db.q_one("SELECT 1 FROM giveaway_users WHERE uid=61 AND gid=?", g["id"]))

    # ---------- аккаунт моложе 90 дней ----------
    await db.q_run("INSERT OR REPLACE INTO users(id, name, joined, last_seen) VALUES(?,?,?,?)",
                   100000, "старожил", int(time.time()) - 200 * 86400, int(time.time()))
    G._age_cache.clear()
    g2 = await new_gw(dp, bot, ["age"])
    check(f"[{P}] условие в посте: аккаунту больше 90 дней", g2["min_age"] == 90 and "90 дней" in G.post_text(g2, 0))
    SENT.clear()
    await dp.feed_update(bot, cbu(f"gw:j:{g2['id']}", 7_000_000_001))
    await dp.feed_update(bot, cbu(f"gw:j:{g2['id']}", 70))
    check(f"[{P}] id выше всех «старожилов» — не пускаю, старый — пускаю",
          not await db.q_one("SELECT 1 FROM giveaway_users WHERE uid=? AND gid=?", 7_000_000_001, g2["id"])
          and await db.q_one("SELECT 1 FROM giveaway_users WHERE uid=70 AND gid=?", g2["id"])
          and any("меньше 90 дней" in t for t in alerts()))

    # ---------- двойные нажатия ----------
    g3 = await new_gw(dp, bot, ["ref", "bst"])
    await dp.feed_update(bot, cbu(f"gw:j:{g3['id']}", 80))
    await asyncio.gather(dp.feed_update(bot, cbu(f"gw:jb:{g3['id']}:80", 81)),
                         dp.feed_update(bot, cbu(f"gw:jb:{g3['id']}:80", 81)))
    t80 = (await db.q_one("SELECT tickets FROM giveaway_users WHERE gid=? AND uid=80", g3["id"]))["tickets"]
    check(f"[{P}] двойной вход по ссылке — другу +1 билет, а не +2", t80 == 2)

    async def boosted(bot_, chat, uid):
        await asyncio.sleep(0.01)
        return 1
    G.boosts_of = boosted
    await asyncio.gather(dp.feed_update(bot, cbu(f"gw:bst:{g3['id']}", 81)),
                         dp.feed_update(bot, cbu(f"gw:bst:{g3['id']}", 81)))
    t81 = (await db.q_one("SELECT tickets FROM giveaway_users WHERE gid=? AND uid=81", g3["id"]))["tickets"]
    check(f"[{P}] двойной «я забустил» — +3 билета один раз", t81 == 4)

    # отмена с возвратом звёзд
    await db.q_run("UPDATE giveaways SET gift_kind='stars', gift_stars=10 WHERE id=?", g3["id"])
    before = await gifts.balance(1)
    await asyncio.gather(dp.feed_update(bot, cbq(f"gw:cx:{g3['id']}", 1, 1)),
                         dp.feed_update(bot, cbq(f"gw:cx:{g3['id']}", 1, 1)))
    check(f"[{P}] двойная отмена — звёзды вернулись один раз", await gifts.balance(1) - before == 10)

    # итоги: таймер + «итоги сейчас»
    g4 = await new_gw(dp, bot, [])
    await dp.feed_update(bot, cbu(f"gw:j:{g4['id']}", 90))
    ann = []
    real_ann = G._announce

    async def count_ann(*a, **k):
        ann.append(1)
        await asyncio.sleep(0.01)
        return await real_ann(*a, **k)
    G._announce = count_ann
    g4 = await db.q_one("SELECT * FROM giveaways WHERE id=?", g4["id"])
    await asyncio.gather(G.finish(bot, g4), G.finish(bot, g4), dp.feed_update(bot, cbq(f"gw:end:{g4['id']}", 1, 1)))
    G._announce = real_ann
    check(f"[{P}] итоги подводятся один раз", len(ann) == 1)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:cx:{g4['id']}", 1, 1))
    check(f"[{P}] завершённый не отменить", (await db.q_one("SELECT status FROM giveaways WHERE id=?", g4["id"]))["status"] == "done")

    # подтверждение победы
    await db.q_run("UPDATE giveaways SET gift_kind='exact', gift_id='g1' WHERE id=?", g4["id"])
    await db.q_run("INSERT OR REPLACE INTO gw_wins VALUES(?,?,'wait',?)", g4["id"], 90, int(time.time()))
    deliv = []

    async def fake_deliver(bot_, gw, winners):
        deliv.append(1)
        await asyncio.sleep(0.01)
        return 0
    real_deliver = gifts.deliver_wins
    gifts.deliver_wins = fake_deliver
    await asyncio.gather(dp.feed_update(bot, cbu(f"gw:cf:{g4['id']}", 90)),
                         dp.feed_update(bot, cbu(f"gw:cf:{g4['id']}", 90)))
    gifts.deliver_wins = real_deliver
    check(f"[{P}] двойное «забираю приз» — подарок один раз", len(deliv) == 1)

    # выбор подарка
    wid = await db.q_run("INSERT INTO gift_wins(gid, uid, stars, gift_id, title, status, ts) VALUES(?,?,?,?,?,?,?)",
                         g4["id"], 91, 15, "", "приз", "pending", int(time.time()))
    sent_gifts = []

    async def fp(bot_, stars):
        await asyncio.sleep(0.01)
        return [{"id": "g15"}]

    async def snd(bot_, uid, gid, text):
        sent_gifts.append(uid)
        return True
    real_fp, real_send = gifts.for_price, gifts.send
    gifts.for_price, gifts.send = fp, snd
    await asyncio.gather(dp.feed_update(bot, cbu(f"gwc:{wid}:g15", 91)), dp.feed_update(bot, cbu(f"gwc:{wid}:g15", 91)))
    check(f"[{P}] двойной выбор подарка — дарю один", sent_gifts == [91])
    # авто-вручение не трогает приз, который сейчас вручается
    wid2 = await db.q_run("INSERT INTO gift_wins(gid, uid, stars, gift_id, title, status, ts) VALUES(?,?,?,?,?,?,?)",
                          g4["id"], 92, 15, "", "приз", "sending", 0)
    sent_gifts.clear()
    await gifts.auto_claim(bot)
    check(f"[{P}] авто-вручение: «sending» не дарю второй раз", 92 not in sent_gifts)
    gifts.for_price, gifts.send = real_fp, real_send

    # фонд: два одновременных списания не уводят в минус
    await db.q_run("UPDATE users SET gift_stars=10 WHERE id=1")
    r = await asyncio.gather(gifts.change(1, -10, "a"), gifts.change(1, -10, "b"))
    check(f"[{P}] фонд: из 10 ⭐ два списания по 10 — прошло одно", sorted(r) == [False, True]
          and await gifts.balance(1) == 0)

    # ---------- монеты, колесо, проба, блэкджек ----------
    await dp.feed_update(bot, msg("/start", 300, 300))
    c0 = (await db.get_user(300))["coins"]
    r = await asyncio.gather(db.claim_bonus(300), db.claim_bonus(300), db.claim_bonus(300))
    got = sum(x[0] for x in r)
    check(f"[{P}] тройной /bonus — монеты один раз", got > 0 and (await db.get_user(300))["coins"] - c0 == got
          and sum(1 for x in r if x[0]) == 1)
    check(f"[{P}] списать минус 100 = начислить — нельзя", not await db.take_coins(300, -100))

    if P == "full":   # колесо — только в Соне
        from handlers import luck
        luck.SPIN = ["🎡"]
        spins = []
        real_spin = luck.spin

        async def cnt_spin(uid):
            spins.append(uid)
            return await real_spin(uid)
        luck.spin = cnt_spin
        await asyncio.gather(*(dp.feed_update(bot, msg("/wheel", 300, 300)) for _ in range(5)))
        luck.spin = real_spin
        check(f"[{P}] пять /wheel разом — один прокрут", len(spins) == 1)

    import premium
    await dp.feed_update(bot, msg("/start", 301, 301))
    r = await asyncio.gather(premium.start_trial(301), premium.start_trial(301))
    check(f"[{P}] двойная «пробная Соня+» — один раз", sum(1 for x in r if x) == 1)

    if P == "full":   # блэкджек — только в Соне
        await db.add_coins(300, 1000)
        SENT.clear()
        await dp.feed_update(bot, cbu("bj:new:100", 300))
        gid = next(iter(luck._bj), None)
        fins = []
        real_fin = luck.bj_finish

        async def cnt_fin(gg):
            fins.append(1)
            await asyncio.sleep(0.01)
            return "🏆 ты выиграл(а)! +100 🪙"
        luck.bj_finish = cnt_fin
        if gid:
            await asyncio.gather(dp.feed_update(bot, cbu(f"bj:s:{gid}", 300)), dp.feed_update(bot, cbu(f"bj:s:{gid}", 300)))
        luck.bj_finish = real_fin
        check(f"[{P}] блэкджек: двойной «хватит» — расчёт один раз", gid and len(fins) == 1)

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
