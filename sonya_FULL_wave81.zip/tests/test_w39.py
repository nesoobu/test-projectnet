"""Волна 39: хэш итогов заранее, /check, призы по местам, отложенный старт, повтор, прирост, «через @бот», рассылка."""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMessage, EditMessageText
from aiogram.types import Update, CallbackQuery, Message, Chat, User, MessageOriginChannel


def cbu(data, uid):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name=f"U{uid}"),
        message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=uid, type="private"))))


async def connect(dp, bot, uid, cid):
    H.ADMINS.add(uid)
    await dp.feed_update(bot, msg("/start", uid, uid))
    await dp.feed_update(bot, msg("/giveaway", uid, uid))
    await dp.feed_update(bot, msg("пост", uid, uid, forward_origin=MessageOriginChannel(
        type="channel", date=datetime.now(), chat=Chat(id=cid, type="channel", title="Канал"), message_id=5)))


async def create(dp, bot, uid, prize, n, opts=(), later=None, fresh=True):
    if fresh:
        await dp.feed_update(bot, msg("/giveaway", uid, uid))
    await dp.feed_update(bot, cbq("gw:pt:text", uid, uid))
    await dp.feed_update(bot, msg(prize, uid, uid))
    await dp.feed_update(bot, cbq(f"gw:w:{n}", uid, uid))
    await dp.feed_update(bot, cbq("gw:d:3600", uid, uid))
    for o in opts:
        await dp.feed_update(bot, cbq(f"gw:o:{o}", uid, uid))
    if later:
        await dp.feed_update(bot, cbq("gw:o:later", uid, uid))
        await dp.feed_update(bot, msg(later, uid, uid))
    await dp.feed_update(bot, cbq("gw:go", uid, uid))
    return await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import giveaway as G
    G.ANIM_PAUSE = 0
    # ---------- чужой админ: подпись «через @бот», хэш заранее ----------
    await connect(dp, bot, 5, -100500)
    SENT.clear()
    g = await create(dp, bot, 5, "🎧 Наушники\n🎮 Геймпад\n🍫 Шоколадка", 3, opts=("ntf",), fresh=False)
    post = [m for m in H.sent(SendMessage) if m.chat_id == -100500][-1].text
    check(f"[{P}] в посте хэш итогов и «через @бот»", G.commit(g["secret"]) in post and "через @Sonya_rubot" in post)
    check(f"[{P}] призы по местам распознаны", G.places(g) == ["🎧 Наушники", "🎮 Геймпад", "🍫 Шоколадка"])
    for u in (31, 32, 33, 34):
        await dp.feed_update(bot, msg("/start", u, u))
        await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", u))
    await db.q_run("UPDATE giveaway_users SET ref_by=31 WHERE uid=32 AND gid=?", g["id"])
    SENT.clear()
    await G.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"]))
    await asyncio.sleep(0.4)
    gd = await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"])
    check(f"[{P}] seed итогов = секрет со старта", gd["seed"] == g["secret"])
    from aiogram.methods import EditMessageText as _E   # волна 56: итоги приходят правкой «барабана»
    res = [m for m in SENT if isinstance(m, (SendMessage, _E)) and m.chat_id == -100500 and "итоги" in m.text][-1].text
    check(f"[{P}] итоги: 🥇🥈🥉 с призами по местам", "🥇" in res and "— 🎧 Наушники" in res and "— 🍫 Шоколадка" in res)
    rep = [m for m in H.sent(SendMessage) if m.chat_id == 5 and "завершён" in m.text][-1].text
    check(f"[{P}] отчёт: приглашённые", "по приглашениям пришло: <b>1</b>" in rep)
    losers = {m.chat_id for m in H.sent(SendMessage) if "не повезло" in (m.text or "")}
    won = {int(x) for x in gd["result"].split(",")}
    check(f"[{P}] 📣 проигравшим пришли итоги", losers == {31, 32, 33, 34} - won and len(losers) == 1)
    SENT.clear()
    await dp.feed_update(bot, msg(f"/check {g['id']}", 77, 77))
    t = texts()[-1]
    check(f"[{P}] /check: хэш совпадает с seed", "✅ sha256(seed) совпадает" in t and G.commit(g["secret"]) in t)
    # ---------- отложенный старт ----------
    SENT.clear()
    g2 = await create(dp, bot, 5, "Стикерпак", 1, later="через 2ч")
    check(f"[{P}] 📅 отложенный: в канал пока не вышел", g2["status"] == "scheduled"
          and not [m for m in H.sent(SendMessage) if m.chat_id == -100500])
    check(f"[{P}] срок сдвинут от старта", g2["ends"] - g2["starts"] > 3500)
    await db.q_run("UPDATE giveaways SET starts=? WHERE id=?", int(time.time()) - 1, g2["id"])
    await G.tick(bot)
    g2b = await db.q_one("SELECT * FROM giveaways WHERE id=?", g2["id"])
    check(f"[{P}] пришло время — опубликован", g2b["status"] == "active" and g2b["msg_id"])
    # ---------- повтор ----------
    await dp.feed_update(bot, cbq(f"gw:rp:{g['id']}", 5, 5))
    await dp.feed_update(bot, cbq("gw:d:3600", 5, 5))
    await dp.feed_update(bot, cbq("gw:go", 5, 5))
    g3 = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    check(f"[{P}] 🔁 повтор с теми же условиями", g3["id"] != g["id"] and g3["prize"] == g["prize"] and g3["notify"] == 1
          and g3["winners"] == 3 and g3["secret"] != g["secret"])
    # ---------- владелец бота — без подписи ----------
    await connect(dp, bot, 1, -100600)
    SENT.clear()
    await create(dp, bot, 1, "Приз", 1, fresh=False)
    post = [m for m in H.sent(SendMessage) if m.chat_id == -100600][-1].text
    check(f"[{P}] у владельца бота подписи «через» нет", "через @" not in post)
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
