"""Волна 81: расписание — интервалы 15 мин…сутки, своё «3:10», разброс с правилом ⅓, лента картинкой.
python test_w81.py ../sonya"""
import asyncio, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
config.BANNERS = True
from aiogram.methods import SendPhoto, EditMessageMedia

CID, UID = -100888, 1


async def main():
    M, bot, dp = await setup()
    import uikit
    from autopost import store, rules as R, timeparse as T
    bot.session.middleware(uikit.UiMiddleware())
    await store.add_channel(CID, UID, "H9", "h9")
    rid = await store.add_rule(UID, CID, "rss", "https://x.ru/feed", "лента")

    check("своё время понимаю как на часах", T.parse_duration("3:10") == 190 and T.parse_duration("3.10") == 190
          and T.parse_duration("3ч10м") == 190 and T.parse_duration("1д 2ч") == 1560 and T.parse_duration("95") == 95
          and T.parse_duration("2 часа 15 минут") == 135 and T.parse_duration("ерунда") is None)
    check("правило разброса: не больше ⅓ интервала (3 ч → до ±1 ч, ±3 ч нельзя)",
          T.max_spread(180) == 60 and 180 not in T.spread_options(180) and 60 in T.spread_options(180))

    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:rip:{rid}", UID, UID))
    kb = str([getattr(x, "reply_markup", "") for x in SENT])
    check("выбор интервала: 15 мин, 30, 45, 1 ч … сутки + «своё»", all(f"ap:riv:{m}:{rid}" in kb for m in (15, 30, 45, 60, 120, 180, 360, 1440))
          and f"ap:rinx:{rid}" in kb)
    await dp.feed_update(bot, cbq(f"ap:rinx:{rid}", UID, UID))
    await dp.feed_update(bot, msg("3:10", UID, UID))
    r = await store.rule(rid)
    check("своё «3:10» → каждые 3 ч 10 мин", r["every_min"] == 190 and R.sched_label(r, store.cfg_of(r)).startswith("каждые 3 ч 10 мин"))
    await dp.feed_update(bot, cbq(f"ap:riv:180:{rid}", UID, UID))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:rsv:180:{rid}", UID, UID))
    alerts = [getattr(x, "text", "") or "" for x in SENT]
    check("разброс ±3 ч при интервале 3 ч — не даю, объясняю почему", any("⅓" in a for a in alerts)
          and not store.cfg_of(await store.rule(rid)).get("spread"))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:rsv:60:{rid}", UID, UID))
    r = await store.rule(rid)
    c = store.cfg_of(r)
    now = int(time.time())
    gaps = [(R.next_run(r, c, None, now) - now) / 3600 for _ in range(400)]
    check("3 ч ± 1 ч → следующий пост в окне 2–4 ч (случайно)", c["spread"] == 60 and min(gaps) >= 2 and max(gaps) <= 4
          and max(gaps) - min(gaps) > 1.5)
    txt = "\n".join(H.texts())
    ph = H.sent(SendPhoto) + H.sent(EditMessageMedia)
    check("экран расписания: «каждые 3 ч ± 1 ч», окно 2–4 ч, лента суток картинкой",
          "± 1 ч" in R.sched_label(r, c) and "2 ч – 4 ч" in txt and ph)
    await dp.feed_update(bot, cbq(f"ap:riv:60:{rid}", UID, UID))
    c = store.cfg_of(await store.rule(rid))
    check("интервал уменьшили до 1 ч — разброс сам ужался до ±20 мин", c["spread"] == 20)
    await store.set_cfg(rid, sched="times", times=["10:00", "18:00"], spread=30)
    r = await store.rule(rid)
    c = store.cfg_of(r)
    ts = [R.next_run(r, c, None, now) for _ in range(200)]
    from datetime import datetime
    mins = {(datetime.fromtimestamp(t, T.MSK).hour * 60 + datetime.fromtimestamp(t, T.MSK).minute) for t in ts}
    check("своё время + разброс: каждый пост в пределах ±30 мин от своего времени",
          all(any(abs(mm - base) <= 30 for base in (600, 1080)) for mm in mins) and len(mins) > 5)
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
