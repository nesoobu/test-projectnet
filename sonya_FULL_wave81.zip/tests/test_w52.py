"""Волна 52: редакторы пака — мастер (название/ссылка), перенос ссылки, архив, эмодзи-версия, соавторы.
python test_w52.py ../sonya stk"""
import asyncio
import io
import sys
import zipfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "stk"
from aiogram.methods import (CreateNewStickerSet, AddStickerToSet, DeleteStickerSet, SendDocument, SendMessage)
from aiogram.types import PhotoSize, Sticker, StickerSet

U, P, C = 400, 401, 402   # обычный, с Соней+, соавтор


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


def stk(fid, uq, video=False):
    return Sticker(file_id=fid, file_unique_id=uq, type="regular", width=512, height=512, is_animated=False,
                   is_video=video, emoji="😺")


def png():
    from PIL import Image
    b = io.BytesIO()
    Image.new("RGBA", (300, 200), (255, 0, 0, 255)).save(b, "PNG")
    return b.getvalue()


async def main():
    M, bot, dp = await setup()
    from handlers import stickers, stkedit
    import premium
    premium.plus = lambda uid: uid == P

    async def fake_download(file_id, destination=None, **kw):
        destination.write(png()) if hasattr(destination, "write") else open(destination, "wb").write(png())
    bot.download = fake_download
    stickers._last_sticker = lambda b, n: asyncio.sleep(0, None)
    taken = set()

    async def fake_set(b, name):
        return StickerSet(name=name, title="Мой пак", sticker_type="regular",
                          stickers=[stk(f"s{i}", f"s{i}") for i in range(3)]) if name in taken else None
    stickers._set_of = fake_set
    photo = [PhotoSize(file_id="p", file_unique_id="p", width=10, height=10)]

    # ---- ссылки ----
    tail = "_by_Sonya_rubot"
    check("ссылка: кириллица → латиница, мусор вон", stkedit.clean_slug("Мои котики!!", tail) == "moi_kotiki")
    check("ссылка: с буквы и без «__»", stkedit.clean_slug("123__cats  2", tail) == "cats_2")
    check("ссылка: длина с хвостом ≤ 64", len(stkedit.clean_slug("a" * 100, tail) + tail) <= 64)
    check("случайное название — с именем", "Тим" in stkedit.rand_title("Тим"))
    import re
    rs = stkedit.rand_slug("Тим", tail)
    check("случайная ссылка — по правилам", re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*", rs) and "__" not in rs
          and rs.startswith("tim_"))

    # ---- мастер: своё название и своя ссылка ----
    SENT.clear()
    await dp.feed_update(bot, cbq("stk:new:sticker", U, U))
    check("мастер: шаг 1 — название, 🎲 и ⚡", "шаг 1" in all_text() and "stk:wt" in kbs() and "stk:wr" in kbs())
    await dp.feed_update(bot, msg(None, U, U, photo=photo))
    check("картинка во время мастера — придержана", "запомнила" in all_text() and not H.sent(CreateNewStickerSet))
    SENT.clear()
    await dp.feed_update(bot, msg("Котики Тима", U, U))
    check("мастер: шаг 2 — ссылка", "шаг 2" in all_text() and "stk:wok" in kbs())
    taken.add("busy_cats" + tail)
    SENT.clear()
    await dp.feed_update(bot, msg("busy cats", U, U))
    check("занятая ссылка — прошу другую", "занята" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("тимкотики", U, U))
    check("своя ссылка свободна", "свободна" in all_text() and "timkotiki" + tail in all_text())
    SENT.clear()
    await dp.feed_update(bot, cbq("stk:wok", U, U))
    mk = H.sent(CreateNewStickerSet)
    check("пак создан с моим названием и ссылкой, из придержанной картинки",
          mk and mk[0].name == "timkotiki" + tail and mk[0].title.startswith("Котики Тима"))
    p = await stickers.current(U)
    check("в базе — название без подписи бота", p and p["title"] == "Котики Тима")
    check("текст в мастере не стал цитатой", not [m for m in SENT if "стикер-цитату" in (getattr(m, "text", "") or "")])

    # ---- 🎲 и отмена ----
    await db.q_run("DELETE FROM sticker_packs WHERE uid=?", U)
    await dp.feed_update(bot, cbq("stk:new:emoji", U, U))
    SENT.clear()
    await dp.feed_update(bot, cbq("stk:wt", U, U))
    w = await stkedit.wiz_get(U)
    check("🎲 название с именем и сразу ссылка", w["t"] and "Тим" in w["t"] and w["s"] and "шаг 2" in all_text())
    await dp.feed_update(bot, cbq("stk:home", U, U))
    check("ушёл с мастера — сброшен", not await stkedit.wiz_get(U))
    SENT.clear()
    await dp.feed_update(bot, msg("просто текст", U, U))
    check("после отмены текст — снова цитата", "стикер-цитату" in all_text())

    # ---- инструменты (владелец, с плюсом) ----
    await dp.feed_update(bot, cbq("stk:new:sticker", P, P))
    await dp.feed_update(bot, cbq("stk:wr", P, P))
    await dp.feed_update(bot, msg(None, P, P, photo=photo))
    p = await stickers.current(P)
    taken.add(p["name"])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:p:{p['id']}", P, P))
    check("экран пака: 🛠 инструменты у хозяина", f"stk:t:{p['id']}" in kbs())
    await dp.feed_update(bot, cbq(f"stk:t:{p['id']}", P, P))
    check("инструменты: ссылка, архив, эмодзи-версия, соавторы",
          all(f"stk:{k}:{p['id']}" in kbs() for k in ("mv", "zip", "ev", "co")))
    # архив
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:zip:{p['id']}", P, P))
    doc = H.sent(SendDocument)
    check("📥 архив отправлен", bool(doc))
    # перенос ссылки
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:mv:{p['id']}", P, P))
    check("🔗 перенос: предупреждаю и спрашиваю", "пропадёт" in all_text() and f"stk:mvy:{p['id']}" in kbs())
    await dp.feed_update(bot, msg("new cool", P, P))
    old = p["name"]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:mvy:{p['id']}", P, P))
    mk = H.sent(CreateNewStickerSet)
    dl = H.sent(DeleteStickerSet)
    p2 = await stickers.pack(P, p["id"])
    check("перенос: новый пак по file_id, старый удалён, в базе новая ссылка",
          mk and mk[0].name == "new_cool" + tail and mk[0].stickers[0].sticker == "s0" and dl and dl[0].name == old
          and p2["name"] == "new_cool" + tail)
    taken.add(p2["name"])
    # эмодзи-версия
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:ev:{p['id']}", P, P))
    mk = H.sent(CreateNewStickerSet)
    check("🧩 эмодзи-версия (Соня+)", mk and mk[0].sticker_type == "custom_emoji" and len(mk[0].stickers) == 3)

    # ---- соавторы ----
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:co:{p['id']}", P, P))
    code = await db.kv_get(f"stk:inv:{p['id']}")
    check("👥 приглашение: ссылка со start=stkj_", f"stkj_{p['id']}_{code}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start stkj_{p['id']}_wrong", C, C, name="Аня"))
    check("чужой код не пускает", "устарело" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start stkj_{p['id']}_{code}", C, C, name="Аня"))
    check("соавтор принят, хозяину сообщили", "ты соавтор" in all_text()
          and any(getattr(m, "chat_id", 0) == P and "соавтор" in m.text for m in H.sent(SendMessage)))
    SENT.clear()
    await dp.feed_update(bot, msg(None, C, C, photo=photo))
    ad = H.sent(AddStickerToSet)
    check("соавтор добавляет в пак хозяина (user_id хозяина)", ad and ad[0].user_id == P and ad[0].name == p2["name"])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:p:{p['id']}", C, C))
    check("соавтор: без удаления и инструментов", f"stk:pd:{p['id']}" not in kbs() and f"stk:t:{p['id']}" not in kbs()
          and f"stk:leave:{p['id']}" in kbs())
    await dp.feed_update(bot, cbq(f"stk:pdy:{p['id']}", C, C))
    check("соавтор не может удалить пак", await stickers.pack(P, p["id"]))
    await dp.feed_update(bot, cbq("stk:list", C, C))
    check("в «моих паках» у соавтора — 👥", "👥" in all_text() or "👥" in kbs())
    await dp.feed_update(bot, cbq(f"stk:cox:{p['id']}", P, P))
    check("хозяин убрал всех — доступа нет", not await stickers.pack(C, p["id"]))
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
