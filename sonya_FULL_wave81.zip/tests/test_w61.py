"""Волна 61: безопасность. Ссылки не во внутреннюю сеть (SSRF), чтение с потолком, антифлуд во всех ботах,
локальные пути из чужой RSS-ленты, бэкап с паролем.
python test_w61.py ../sonya full"""
import asyncio, io, os, subprocess, sys, zipfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendDocument, EditMessageText, SendMessage


class FakeContent:
    def __init__(self, chunks):
        self.chunks, self.read = chunks, 0

    async def iter_chunked(self, n):
        for c in self.chunks:
            self.read += 1
            yield c


class FakeResp:
    def __init__(self, chunks, headers=None):
        self.headers, self.content = headers or {}, FakeContent(chunks)


async def main():
    M, bot, dp = await setup()
    import netguard
    from downloader import links as L, core
    from autopost import media_dl, sources

    # ---------- ссылки: шаблон площадки — только в адресе сайта ----------
    good = ["https://youtu.be/abc", "https://m.youtube.com/shorts/x", "https://vm.tiktok.com/ZMabc123/",
            "https://ru.pinterest.com/pin/1/", "https://pin.it/abc", "https://music.yandex.ru/album/1/track/2",
            "https://www.threads.net/@u/post/abc", "youtube.com/watch?v=1", "https://x.com/u/status/1"]
    bad = ["http://127.0.0.1:8080/?youtu.be/x", "http://169.254.169.254/latest?youtube.com/watch",
           "https://pinterest.evil.com/pin/1/", "https://youtube.com.evil.com/watch?v=1", "https://evil.com/youtu.be/x",
           "http://localhost/?x.com/u/status/1", "https://dropbox.com/u/status/1", "http://[::1]/youtu.be/x",
           "https://pinterest.127.0.0.1.nip.io/pin/1/", "https://youtube.com:8443/watch?v=1"]
    check("ссылки: обычные площадки узнаю", all(L.classify(u) for u in good))
    check("ссылки: «youtu.be» в хвосте чужого адреса — не YouTube", not any(L.classify(u) for u in bad))
    check("ссылки: в тексте внутренний адрес не находится",
          [x.url for x in L.find_links("вот https://youtu.be/abc и http://127.0.0.1/?youtu.be/x")] == ["https://youtu.be/abc"])

    # ---------- netguard.check ----------
    async def blocked(u):
        try:
            await netguard.check(u)
            return False
        except netguard.Blocked:
            return True
    inner = ["http://127.0.0.1/", "http://169.254.169.254/latest/meta-data", "http://localhost:8081/",
             "http://[::1]/", "http://10.0.0.5/", "http://192.168.1.1/", "http://100.64.0.1/", "http://0.0.0.0/",
             "file:///etc/passwd", "ftp://example.com/x", "http://[::ffff:127.0.0.1]/"]
    check("сеть: внутренние адреса и не-http — блок", all([await blocked(u) for u in inner]))
    check("сеть: публичный адрес — можно", not await blocked("http://8.8.8.8/x"))

    calls = []
    old_dl = core._dl_sync
    core._dl_sync = lambda *a, **k: calls.append(a) or {"path": "/tmp/x"}
    try:
        await core.download("http://127.0.0.1:8081/bot/getMe", "video")
        ok = False
    except media_dl.DLError:
        ok = True
    core._dl_sync = old_dl
    check("скачивание: внутренний адрес — отказ, yt-dlp даже не зовём", ok and not calls)
    core._dl_sync = lambda *a, **k: calls.append(a[0]) or {"path": "/tmp/x"}
    await core.download("ytsearch1:Земфира - Хочешь audio", "audio")
    try:
        await core.download("127.0.0.1:8081/x", "video")
        ok = False
    except media_dl.DLError:
        ok = True
    core._dl_sync = old_dl
    check("скачивание: поиск ytsearch1: идёт, «127.0.0.1/x» без http — отказ",
          calls == ["ytsearch1:Земфира - Хочешь audio"] and ok)
    for fn in (lambda: media_dl.ytdlp_download("http://169.254.169.254/latest", "video"),
               lambda: media_dl.ytdlp_list("http://127.0.0.1/list", 5),
               lambda: core.probe("http://localhost/x")):
        try:
            await fn()
            ok = False
        except media_dl.DLError:
            ok = True
        if not ok:
            break
    check("автоисточник видео/музыки и проба: внутренний адрес — отказ", ok)
    try:
        await sources.fetch("rss", "http://127.0.0.1:9/feed.xml")
        ok = False
    except sources.SourceError:
        ok = True
    check("RSS: внутренний адрес — отказ", ok)

    # ---------- редиректы проверяем на каждом шаге ----------
    from aiohttp import web, ClientSession
    hits = []

    async def h_redir_in(r):
        hits.append("in")
        raise web.HTTPFound("http://127.0.0.2:%d/secret" % port)

    async def h_redir_ok(r):
        raise web.HTTPFound("/ok")

    async def h_ok(r):
        return web.Response(text="ok")

    async def h_big(r):
        resp = web.StreamResponse()
        await resp.prepare(r)
        for _ in range(40):
            await resp.write(b"x" * 65536)
        return resp
    app = web.Application()
    app.router.add_get("/r", h_redir_in)
    app.router.add_get("/r2", h_redir_ok)
    app.router.add_get("/ok", h_ok)
    app.router.add_get("/big", h_big)
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "127.0.0.1", 0)
    await site.start()
    port = site._server.sockets[0].getsockname()[1]
    real_ok = netguard._ip_ok
    netguard._ip_ok = lambda ip: ip == "127.0.0.1" or real_ok(ip)   # «публичный» для теста — только 127.0.0.1
    try:
        async with ClientSession() as s:
            try:
                async with netguard.get(s, f"http://127.0.0.1:{port}/r") as r:
                    ok = False
            except netguard.Blocked:
                ok = True
            check("редирект во внутреннюю сеть — блок на втором шаге", ok and hits == ["in"])
            async with netguard.get(s, f"http://127.0.0.1:{port}/r2") as r:
                body = await r.text()
            check("обычный редирект — проходит", body == "ok")
        try:
            await core.fetch_bytes(f"http://127.0.0.1:{port}/big", limit=1024 * 1024)
            ok = False
        except media_dl.DLError as e:
            ok = "больш" in str(e)
        check("fetch_bytes: 2.5 МБ при лимите 1 МБ — обрыв, а не всё в память", ok)
        check("fetch_bytes: в лимит — отдаёт", await core.fetch_bytes(f"http://127.0.0.1:{port}/ok") == b"ok")
        check("resolve_redirect: конечный адрес", (await core.resolve_redirect(f"http://127.0.0.1:{port}/r2")).endswith("/ok"))
    finally:
        netguard._ip_ok = real_ok
        await runner.cleanup()

    # ---------- чтение с потолком ----------
    fr = FakeResp([b"a" * 1000] * 50)
    try:
        await netguard.read_limited(fr, 5000)
        ok = False
    except netguard.Blocked:
        ok = True
    check("read_limited: рвёт сразу за лимитом, хвост не читает", ok and fr.content.read == 6)
    try:
        await netguard.read_limited(FakeResp([b"a"], {"Content-Length": "999999999"}), 5000)
        ok = False
    except netguard.Blocked:
        ok = True
    check("read_limited: огромный Content-Length — отказ до чтения", ok)
    p = os.path.join(H.TMP, "save.bin")
    check("save_limited: пишет в файл", await netguard.save_limited(FakeResp([b"ab", b"cd"]), p, 10) == 4
          and open(p, "rb").read() == b"abcd")

    # ---------- RSS не может подсунуть локальный файл сервера ----------
    feed = b"""<?xml version="1.0"?><rss version="2.0"><channel><title>t</title>
    <item><title>a</title><link>https://site.ru/post/1</link><guid>1</guid>
      <description>&lt;img src="/home/sonya/sonya/.env"&gt; text</description></item>
    <item><title>b</title><guid>2</guid><enclosure url="/home/sonya/sonya/data/sonya.db" type="image/jpeg"/>
      <enclosure url="file:///etc/passwd" type="audio/mpeg"/></item>
    <item><title>c</title><link>https://site.ru/p/3</link><guid>3</guid>
      <enclosure url="//cdn.site.ru/a.jpg" type="image/jpeg"/></item>
    </channel></rss>"""
    old_get = sources._get

    async def fake_get(url):
        return 200, feed
    sources._get = fake_get
    items = await sources.fetch("rss", "https://site.ru/rss")
    sources._get = old_get
    imgs = [i.get("image") for i in items]
    check("RSS: путь «/home/…» не становится локальным файлом",
          not any(str(x or "").startswith("/") for i in items for x in (i.get("image"), i.get("audio"), i.get("video"))))
    check("RSS: относительная картинка → от адреса статьи, //cdn → https, без адреса — выкинута",
          imgs == ["https://site.ru/home/sonya/sonya/.env", None, "https://cdn.site.ru/a.jpg"]
          and items[1].get("audio") is None)

    # ---------- антифлуд ----------
    import middlewares
    src = open(os.path.join(H.W, "main.py"), encoding="utf-8").read()
    line = next(x for x in src.splitlines() if "dp.message.outer_middleware(middlewares.Throttle())" in x)
    check("антифлуд: включён во всех профилях (не под NEW_BOTS)", line.startswith("    dp.") and not line.startswith("        "))
    th = middlewares.Throttle()
    got = []

    async def h(e, d):
        got.append(1)
    for _ in range(12):
        await th(h, msg("я хозяин", 1, 1).message, {})
    check("антифлуд: владельца не режу", len(got) == 12)
    got.clear()
    for i in range(10):
        await th(h, msg("фото", 90, 90, media_group_id="alb1").message, {})
    for i in range(8):
        await th(h, msg("ещё", 90, 90).message, {})
    check("антифлуд: альбом из 10 — как одно сообщение (10 + 7 прошли, 18-е режу)", len(got) == 17)
    got.clear()
    for i in range(3):
        await th(h, msg("фото", 90, 90, media_group_id="alb2").message, {})
    check("антифлуд: альбом поверх лимита — режу целиком, не кусками", not got)

    class St:
        def __init__(self, v):
            self.v = v

        async def get_state(self):
            return self.v
    th2 = middlewares.Throttle()
    got.clear()
    for _ in range(30):
        await th2(h, msg("пост в копилку", 91, 91).message, {"state": St("AP:pool_add")})
    check("антифлуд: в открытом мастере (копилка — пачка пересланных постов) не режу", len(got) == 30)
    got.clear()
    for _ in range(12):
        await th2(h, msg("просто так", 92, 92).message, {"state": St(None)})
    check("антифлуд: без мастера — режу как раньше", len(got) == middlewares.Throttle.LIMIT)

    # настоящий диспетчер: копилка автопостинга получает все 20 пересланных постов
    dp.message.outer_middleware(middlewares.Throttle())
    from handlers.ap_common import AP
    ctx = dp.fsm.get_context(bot, chat_id=93, user_id=93)
    await ctx.set_state(AP.pool_add)
    await ctx.update_data(rid=0)
    seen = []
    from handlers import ap_rules
    old_pool = ap_rules.store.rule

    async def fake_rule(rid, uid):
        seen.append(1)
        return None
    ap_rules.store.rule = fake_rule
    for i in range(20):
        await dp.feed_update(bot, msg(f"пост {i}", 93, 93))
        await ctx.set_state(AP.pool_add)   # fake_rule → state.clear(); возвращаем мастер
        await ctx.update_data(rid=0)
    ap_rules.store.rule = old_pool
    check("антифлуд в диспетчере: все 20 постов дошли до копилки", len(seen) == 20)

    # ---------- флаг чата: не assert ----------
    try:
        await db.chat_flag(-100, "id=1; DROP TABLE users; --")
        ok = False
    except ValueError:
        ok = True
    check("флаг чата: чужое имя колонки — ValueError (а не assert, который -O выключает)", ok)

    # ---------- бэкап с паролем ----------
    import system, fleet
    config.BACKUP_PASS = "тест-пароль 123"
    raw = b"secret anon db " * 500
    enc, sealed = system.seal(raw)
    dec = subprocess.run(system.DECRYPT.split() + ["-pass", "env:P"], input=enc, capture_output=True,
                         env={**os.environ, "P": config.BACKUP_PASS}).stdout
    check("бэкап: шифруется и расшифровывается командой из подсказки", sealed and raw not in enc and dec == raw)
    wrong = subprocess.run(system.DECRYPT.split() + ["-pass", "pass:не тот"], input=enc, capture_output=True)
    check("бэкап: чужой пароль не подходит", wrong.returncode != 0 or wrong.stdout != raw)
    SENT.clear()
    check("бэкап базы: уходит .enc с 🔐", await system.send_backup(bot) == "ok"
          and H.sent(SendDocument)[-1].document.filename.endswith(".db.gz.enc")
          and "🔐" in H.sent(SendDocument)[-1].caption)
    SENT.clear()
    if await fleet.send_backup_all(bot) == "ok":
        d = H.sent(SendDocument)[-1]
        data = d.document.data
        z = subprocess.run(system.DECRYPT.split() + ["-pass", "env:P"], input=data, capture_output=True,
                           env={**os.environ, "P": config.BACKUP_PASS}).stdout
        check("бэкап всех ботов: .zip.enc, внутри настоящий zip",
              d.document.filename.endswith(".zip.enc") and zipfile.is_zipfile(io.BytesIO(z)) and "openssl" in d.caption)
    config.BACKUP_PASS = ""
    SENT.clear()
    await system.send_backup(bot)
    check("бэкап без пароля: как раньше + подсказка 🔓",
          H.sent(SendDocument)[-1].document.filename.endswith(".db.gz") and "🔓" in H.sent(SendDocument)[-1].caption)
    SENT.clear()
    await dp.feed_update(bot, cbq("adm:srv", 1, 1))
    srv = "\n".join(m.text for m in SENT if isinstance(m, (EditMessageText, SendMessage)))
    check("«🗂 Сервер»: строка про бэкап", "бэкап: <b>🔓 без пароля" in srv)
    import ui
    check("/help владельцу: BACKUP_PASS", "BACKUP_PASS" in ui.HELP_SECTIONS["owner"][1]
          and all(len(b) <= 4096 for _t, b in ui.HELP_SECTIONS.values()))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
