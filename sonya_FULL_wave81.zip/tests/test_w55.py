"""Волна 55: карточка длинного видео в скачивалке. python test_w55.py ../sonya dl"""
import asyncio
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "dl"
from aiogram.methods import SendPhoto, SendMessage, SendVideo


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


def caps():
    return "\n".join((getattr(m, "caption", "") or getattr(m, "text", "") or "") for m in SENT)


async def main():
    M, bot, dp = await setup()
    from downloader import core
    from handlers import media, vtools
    from autopost import media_dl
    import premium
    premium.plus = lambda uid: uid == 1
    MB = 1048576
    lim = media_dl.MAX_BYTES
    check("битрейт звука под лимит: 79 мин → ≤ 64k, 3 мин → 192k",
          core.fit_kbps(79 * 60) <= 64 and core.fit_kbps(180) == 192 and 79 * 60 * core.fit_kbps(79 * 60) * 1000 / 8 < lim)

    big = {"title": "История TSMC", "uploader": "Канал", "duration": 79 * 60, "views": 1_200_000,
           "thumbnail": "https://i.ytimg.com/x.jpg", "qualities": [(360, 300 * MB), (720, 900 * MB)]}
    text, kb = media.card_view(big, "tok1", False)
    check("не влезает — честно: «от 300 МБ», звук и фрагмент", "от 300 МБ" in text and "dl:a:tok1" in str(kb)
          and "vt:cut:tok1" in str(kb) and "vt:qh:" not in str(kb))
    check("мета: автор, длина 1:19:00, просмотры", "Канал" in text and "1:19:00" in text and "1.2 млн" in text)
    small = dict(big, duration=15 * 60, qualities=[(360, 20 * MB), (480, 35 * MB), (720, 60 * MB)])
    text, kb = media.card_view(small, "tok2", False)
    check("влезает — кнопки качеств с весом, без того, что не влезет",
          "vt:qh:360:tok2" in str(kb) and "vt:qh:480:tok2" in str(kb) and "vt:qh:720" not in str(kb) and "35 МБ" in str(kb))

    async def fake_probe(url):
        core.DURS[url] = big["duration"]
        return dict(big, collection=False, is_live=False, audio_only=False)
    core.probe = fake_probe
    SENT.clear()
    await dp.feed_update(bot, msg("https://youtu.be/JhjPPRZ6W3I", 50, 50))
    ph = H.sent(SendPhoto)
    check("длинное видео — карточка с обложкой", ph and "История TSMC" in ph[0].caption and "dl:a:" in str(ph[0].reply_markup))
    tok = media._token("https://youtu.be/JhjPPRZ6W3I", "youtube", "YouTube")
    check("> 30 мин помечено для Сони+", tok in media._long_tok)

    calls = []

    async def fake_dl(url, kind="video", max_h=None, progress=None, priority=False, section=None):
        calls.append((kind, section))
        import tempfile
        p = tempfile.mktemp(suffix=".mp4")
        open(p, "wb").write(b"x")
        return {"path": p, "title": "t", "duration": 10}
    core.download = fake_dl
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:cut:{tok}", 50, 50))
    await dp.feed_update(bot, msg("12:30-13:00", 50, 50))
    check("✂️ фрагмент длинного — качаю только кусок", calls and calls[-1] == ("video", (750, 780))
          and H.sent(SendVideo))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:qh:360:{tok}", 50, 50))
    check("видео > 30 мин без Сони+ — предложение плюса", not H.sent(SendVideo) and "start=plus" in kbs())
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
