"""Волна 73: автопостинг из Pinterest — видео вместо обложки (HLS как у yt-dlp/gallery-dl), карусели альбомом,
запасной путь через страницу пина; подписи без «описания картинки» и случайных эмодзи.
python test_w73.py ../sonya"""
import asyncio, json, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"


async def main():
    await db.init()
    from autopost import media_dl as md, rules, captions

    # ---------- HLS ----------
    h = "https://v1.pinimg.com/videos/iht/hls/ab/cd/ef/abcdef0123456789abcdef0123456789.m3u8"
    g = md.hls_to_mp4_guess(h)
    check("HLS → тот же ролик 720p.mp4", g and g[0] == "https://v1.pinimg.com/videos/iht/720p/ab/cd/ef/abcdef0123456789abcdef0123456789.mp4")
    pin_hls = {"id": "1", "images": {"736x": {"url": "https://i.pinimg.com/736x/a.jpg"}},
               "videos": {"video_list": {"V_HLSV4": {"url": h, "width": 720, "duration": 9000}}}}

    async def pin_ok(url): return pin_hls
    md.pinterest_pin = pin_ok
    tried = []

    async def dd_720(url, suffix=".mp4"):
        tried.append(url)
        if "/720p/" in url:
            return "/tmp/v720.mp4"
        raise md.DLError("404")
    md.download_direct = dd_720
    f = await md.pinterest_video("https://www.pinterest.com/pin/1/")
    check("только HLS → качаю 720p.mp4 (раньше — сдавался и слал обложку)", f["path"] == "/tmp/v720.mp4" and f["duration"] == 9)

    async def dd_404(url, suffix=".mp4"):
        raise md.DLError("404")

    async def ff(url): return "/tmp/hls.mp4"
    md.download_direct, md._ffmpeg_hls = dd_404, ff
    f = await md.pinterest_video("https://www.pinterest.com/pin/1/")
    check("mp4 нет совсем → HLS через ffmpeg", f["path"] == "/tmp/hls.mp4")

    async def ff_bad(url): raise md.DLError("HLS: 403")
    md._ffmpeg_hls = ff_bad
    try:
        await md.pinterest_video("https://www.pinterest.com/pin/1/")
        ok = False
    except md.DLError as e:
        ok = "не скачалось" in str(e)
    check("ничего не вышло — «не скачалось», а не «не видео»", ok)

    # ---------- данные пина: API упал → страница ----------
    import importlib
    importlib.reload(md)
    from autopost import media_dl as md

    async def api_bad(pid): raise md.DLError("pinterest api: detailed: 403")
    page_pin = {"id": "7", "images": {"orig": {"url": "x"}}}

    async def html_ok(pid): return page_pin
    md._pin_api, md._pin_html = api_bad, html_ok
    p = await md.pinterest_pin("https://www.pinterest.com/pin/7/")
    check("API не отдал → беру страницу пина", p is page_pin)

    page = ('<html><meta property="og:image" content="https://i.pinimg.com/736x/og.jpg">'
            '<script type="application/json">{"props":{"x":{"id":"55","videos":null,"title":"t"}}}</script>'
            '<script>var a="https:\\/\\/v1.pinimg.com\\/videos\\/iht\\/hls\\/aa\\/bb\\/cc\\/hash.m3u8";</script></html>')
    pp = md.parse_pin_page(page, "55")
    check("страница: видео найдено даже без JSON (по ссылке на v1.pinimg)", md.pin_is_video(pp)
          and "hash.m3u8" in json.dumps(pp))
    page2 = ('<script type="application/json">' + json.dumps({"a": [{"id": "9", "images": {"736x": {"url": "u"}},
             "carousel_data": {"carousel_slots": [{"images": {"236x": {"url": f"https://i.pinimg.com/236x/{i}.jpg"}}}
                                                   for i in range(3)]}}]}) + '</script>')
    pp = md.parse_pin_page(page2, "9")
    check("страница: карусель из JSON → 3 картинки", len(md.pinterest_images(pp)) == 3)
    sig = "0123456789abcdef0123456789abcdef"
    story = {"story_pin_data": {"pages": [{"blocks": [{"image_signature": sig}]},
                                          {"blocks": [{"image_signature": sig.replace("0", "f")}]}]}}
    ims = md.pinterest_images(story)
    check("идея-пин без ссылок, только image_signature → originals (как gallery-dl)",
          len(ims) == 2 and ims[0] == f"https://i.pinimg.com/originals/01/23/45/{sig}.jpg")
    try:
        await md._ffmpeg_hls("https://evil.example/x.m3u8")
        ok = False
    except md.DLError:
        ok = True
    check("ffmpeg ходит только на pinimg", ok)

    # ---------- видео не скачалось → не шлём обложку ----------
    async def pv_fail(url): raise md.DLError("видео пина не скачалось: 403")

    async def yt_fail(url, kind): raise md.DLError("yt-dlp: 403")
    md.pinterest_video, md.ytdlp_download = pv_fail, yt_fail
    rules.media_dl = md
    rule = {"with_media": 1, "type": "pinterest", "source": "q:rain"}
    item = {"key": "pin:1", "image": "https://i.pinimg.com/736x/a.jpg", "video_page": "https://www.pinterest.com/pin/1/"}
    try:
        await rules.resolve_media(rule, {"media_kind": "all"}, dict(item))
        ok = False
    except rules.SkipItem:
        ok = True
    check("видео-пин не скачался → пропуск, а не картинка-обложка", ok)

    async def pv_photo(url): raise md.DLError("это не видео-пин")

    async def pin_car(url):
        return {"id": "1", "carousel_data": {"carousel_slots": [{"images": {"736x": {"url": f"https://i.pinimg.com/736x/{i}.jpg"}}}
                                                               for i in range(4)]}}
    md.pinterest_video, md.pinterest_pin = pv_photo, pin_car
    media = await rules.resolve_media(rule, {"media_kind": "all"}, dict(item))
    check("карусель → альбом из 4 фото", len(media) == 4 and all(m["type"] == "photo" for m in media))

    async def pin_down(url): raise md.DLError("pinterest page: 403")
    md.pinterest_pin = pin_down

    async def pv_unknown(url): raise md.DLError("pinterest page: 403")
    md.pinterest_video = pv_unknown
    media = await rules.resolve_media(rule, {"media_kind": "all"}, dict(item))
    check("Pinterest совсем не ответил и тип неизвестен — шлю картинку (лучше, чем ничего)", len(media) == 1)

    # ---------- подписи ----------
    check("«стоит в дожде с рисунком 📱» — бракую как описание, 📱 убираю",
          captions.polish("стоит в дожде с рисунком 📱") == "стоит в дожде с рисунком"
          and captions.too_poetic("стоит в дожде с рисунком"))
    check("живые подписи проходят, настроенческий эмодзи остаётся",
          not captions.too_poetic("я бы сейчас туда") and captions.polish("я бы сейчас туда 🌧") == "я бы сейчас туда 🌧")
    seen = []

    async def vision(system, prompt, img):
        seen.append(prompt)
        return "девушка сидит у окна 📱" if len(seen) == 1 else "хочу так же, без телефона"

    async def ask(msgs, **k): return "ДА"
    captions.llm.ask_vision, captions.llm.ask = vision, ask
    cap = await captions.live_caption({"type": "pinterest", "source": "q:rain"}, {"caption": "vibe"},
                                      {"image": "https://i.pinimg.com/736x/a.jpg"}, [])
    check("vision: просим реакцию, а не описание; описание отбраковано → вторая попытка",
          "НЕ описывай" in seen[0] and cap == "хочу так же, без телефона")

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
