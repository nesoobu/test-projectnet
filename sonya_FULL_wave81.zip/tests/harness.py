"""Общая обвязка тестов: временная база, мок-сессия aiogram, сборка диспетчера как в main."""
import os
import sys
import tempfile
from datetime import datetime

W = sys.argv[1]
sys.path.insert(0, W)
os.chdir(W)
TMP = tempfile.mkdtemp()

import config  # noqa: E402
config.DB_PATH = os.path.join(TMP, "t.db")
config.OWNER_ID = 1
config.LLM_KEY = "k"
import db  # noqa: E402
db.DB_PATH = config.DB_PATH

from aiogram import Bot, Dispatcher  # noqa: E402
from aiogram.client.session.base import BaseSession  # noqa: E402
from aiogram.methods import (GetMe, SendMessage, EditMessageText, SendDice, SendPhoto, SendVideoNote,  # noqa: E402
                             SendAnimation, SendAudio, SendDocument, SendVoice, GetChatAdministrators,
                             GetChatMember, GetFile, GetChat)
from aiogram.types import (Message, Chat, User, Update, CallbackQuery, Dice, ChatMemberAdministrator,  # noqa: E402
                           ChatMemberMember, File, PhotoSize)

SENT = []
DICE = [3]
ADMINS = {1}
LEFT = set()   # кто «не подписан» на каналы


class Mock(BaseSession):
    async def make_request(self, bot, method, timeout=None):
        res = await self._make(bot, method)
        return res.as_(bot) if hasattr(res, "as_") else res   # как в настоящей сессии: объект знает своего бота

    async def _make(self, bot, method):
        SENT.append(method)
        now = datetime.now()
        if isinstance(method, GetMe):
            return User(id=999, is_bot=True, first_name="Соня", username="Sonya_rubot")
        if isinstance(method, GetChatAdministrators):
            return [ChatMemberAdministrator.model_construct(user=User(id=a, is_bot=False, first_name="A"),
                                                            status="administrator", can_restrict_members=True,
                                                            can_delete_messages=True) for a in ADMINS]
        if isinstance(method, GetChatMember):
            if method.user_id in LEFT:
                from aiogram.types import ChatMemberLeft
                return ChatMemberLeft(user=User(id=method.user_id, is_bot=False, first_name="U"))
            if method.user_id in ADMINS:
                return (await self._make(bot, GetChatAdministrators(chat_id=method.chat_id)))[0]
            return ChatMemberMember(user=User(id=method.user_id, is_bot=False, first_name="U"))
        if isinstance(method, GetChat):
            from aiogram.types import ChatFullInfo, ChatPermissions
            return ChatFullInfo(id=method.chat_id, type="supergroup", accent_color_id=0, max_reaction_count=11,
                                accepted_gift_types={"unlimited_gifts": False, "limited_gifts": False,
                                                     "unique_gifts": False, "premium_subscription": False,
                                                     "gifts_from_channels": False},
                                permissions=ChatPermissions(can_send_messages=True, can_send_photos=False))
        if isinstance(method, GetFile):
            return File(file_id=method.file_id, file_unique_id="u", file_path="x/file")
        cid = getattr(method, "chat_id", None)
        if cid is not None:
            chat = Chat(id=cid, type="private" if int(cid) > 0 else "supergroup")
            if isinstance(method, SendDice):
                v = DICE.pop(0) if len(DICE) > 1 else DICE[0]
                return Message(message_id=len(SENT) + 100, date=now, chat=chat, dice=Dice(emoji="🎲", value=v))
            if isinstance(method, (SendMessage, EditMessageText)):
                return Message(message_id=len(SENT) + 100, date=now, chat=chat, text=method.text)
            from aiogram.methods import SendVideo, SendPoll
            if isinstance(method, SendPoll):   # волна 78: опросы автопилота
                return Message(message_id=len(SENT) + 100, date=now, chat=chat)
            if isinstance(method, SendVideo):
                from aiogram.types import Video
                return Message(message_id=len(SENT) + 100, date=now, chat=chat,
                               video=Video(file_id="VID" + str(len(SENT)), file_unique_id="u", width=1, height=1,
                                           duration=1))
            if isinstance(method, (SendPhoto, SendVideoNote, SendAnimation, SendAudio, SendDocument, SendVoice)):
                return Message(message_id=len(SENT) + 100, date=now, chat=chat,
                               photo=[PhotoSize(file_id="f", file_unique_id="u", width=1, height=1)])
        return True

    async def close(self):
        pass

    async def stream_content(self, *a, **k):
        yield b""


def texts():
    out = []
    for m in SENT:
        t = getattr(m, "text", None) or getattr(m, "caption", None)
        if isinstance(t, str):
            out.append(t)
    return out


def sent(cls, chat_id=None):
    return [m for m in SENT if isinstance(m, cls) and (chat_id is None or m.chat_id == chat_id)]


FAILS = []


def check(name, cond):
    print(("✅" if cond else "❌"), name)
    if not cond:
        FAILS.append(name)


_uid = [0]


def msg(text, chat_id=50, user_id=50, name="Тим", reply=None, **kw):
    _uid[0] += 1
    return Update(update_id=_uid[0], message=Message(
        message_id=_uid[0], date=datetime.now(), text=text,
        chat=Chat(id=chat_id, type="private" if chat_id > 0 else "supergroup", title="Чат"),
        from_user=User(id=user_id, is_bot=False, first_name=name), reply_to_message=reply, **kw))


def reply_to(user_id, name="Друг", chat_id=-100, text="хай", **kw):
    return Message(message_id=99999, date=datetime.now(), text=text,
                   chat=Chat(id=chat_id, type="private" if chat_id > 0 else "supergroup"),
                   from_user=User(id=user_id, is_bot=False, first_name=name), **kw)


def cbq(data, chat_id=50, user_id=50, mid=1, name="Тим"):
    _uid[0] += 1
    return Update(update_id=_uid[0], callback_query=CallbackQuery(
        id=str(_uid[0]), chat_instance="x", data=data, from_user=User(id=user_id, is_bot=False, first_name=name),
        message=Message(message_id=mid, date=datetime.now(), text="x",
                        chat=Chat(id=chat_id, type="private" if chat_id > 0 else "supergroup"))))


async def setup():
    """База + диспетчер в том же порядке роутеров и middleware, что и main.main()."""
    await db.init()
    from autopost import store as ap_store
    await ap_store.init()
    import main as M
    bot = Bot("123:abc", session=Mock())
    dp = Dispatcher()
    from middlewares import UserMiddleware
    dp.message.outer_middleware(UserMiddleware())
    dp.callback_query.outer_middleware(UserMiddleware())
    try:
        from handlers import gate
        dp.message.outer_middleware(gate.SubGate())
        dp.callback_query.outer_middleware(gate.SubGate())
    except ImportError:
        pass
    if hasattr(M, "routers_for"):
        dp.include_routers(*M.routers_for(config.PROFILE))
    else:
        src = open(os.path.join(W, "main.py"), encoding="utf-8").read()
        start = src.index("dp.include_routers(") + len("dp.include_routers(")
        names = [n.strip() for n in src[start:src.index(")", start)].replace("\n", " ").split(",") if n.strip()]
        dp.include_routers(*[M.groups if n == "groups" else getattr(M, n.split(".")[0]).router for n in names])
    from handlers import groupmod
    try:
        from handlers import community
        if config.PROFILE in ("full", "grp"):
            dp.message.outer_middleware(community.AntiSpam())
    except ImportError:
        pass
    dp.message.outer_middleware(groupmod.GroupGuard())
    return M, bot, dp
