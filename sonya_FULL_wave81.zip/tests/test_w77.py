"""Волна 77: Pinterest-доска целиком через API (было: RSS → только ~25 последних, без видео и каруселей).
python test_w77.py ../sonya"""
import asyncio, json, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"


def pin(i, video=False, carousel=False):
    p = {"id": str(1000 + i), "type": "pin", "title": f"пин {i}", "description": "",
         "images": {"736x": {"url": f"https://i.pinimg.com/736x/aa/bb/{i}.jpg"}}}
    if video:
        p["videos"] = {"video_list": {"V_HLSV3_MOBILE": {"url": f"https://v1.pinimg.com/videos/mc/hls/aa/bb/cc/v{i}.m3u8",
                                                         "width": 720, "duration": 11000}}}
    if carousel:
        p["carousel_data"] = {"carousel_slots": [{"images": {"736x": {"url": f"https://i.pinimg.com/736x/c/{i}_{k}.jpg"}}}
                                                 for k in range(4)]}
    return p


async def main():
    await db.init()
    from autopost import sources, rules, media_dl as md, store
    await store.init()
    calls = []

    async def api(resource, options):
        calls.append((resource, options.get("bookmarks")))
        if resource == "Board":
            assert options["username"] == "Nesoobu" and options["slug"] == "h9"
            return {"resource_response": {"data": {"id": "777"}}}
        if not options.get("bookmarks"):
            pins = [pin(i, video=(i == 3), carousel=(i == 5)) for i in range(25)]
            return {"resource_response": {"data": pins, "bookmark": "PAGE2"}}
        if options["bookmarks"] == ["PAGE2"]:
            return {"resource_response": {"data": [pin(i) for i in range(25, 50)], "bookmark": "PAGE3"}}
        return {"resource_response": {"data": [pin(i) for i in range(50, 278)], "bookmark": "-end-"}}
    sources._pin_api = api
    items = await sources.fetch("pinterest", "Nesoobu/h9", 15)
    check(f"доска целиком: {len(items)} из 278 пинов (RSS давал ~25)", len(items) == 278
          and [c[0] for c in calls] == ["Board", "BoardFeed", "BoardFeed", "BoardFeed"])
    v = next(i for i in items if i["key"] == "pin:1003")
    c = next(i for i in items if i["key"] == "pin:1005")
    check("видео-пин распознан сразу, ссылки на видео уже есть", v["is_video"] and "V_HLSV3_MOBILE" in v["video_list"])
    check("карусель — 4 картинки", len(c.get("images") or []) == 4)
    n0 = len(calls)
    await sources.fetch("pinterest", "Nesoobu/h9", 15)
    check("повторно за 20 минут — из кэша, Pinterest не дёргаю", len(calls) == n0)

    # ---------- уже выложенные (ключи RSS) не повторяю ----------
    rid = await store.add_rule(1, -100, "pinterest", "Nesoobu/h9", "h9") if hasattr(store, "add_rule") else None
    rule = {"id": rid or 1, "type": "pinterest", "source": "Nesoobu/h9"}
    for k in range(25):   # RSS-ключи старых публикаций — ссылки на пины
        await store.mark_seen(rule["id"], f"https://www.pinterest.com/pin/{1000 + k}/")
    cands = await rules.candidates(rule, {"order": "random", "loop": 1}, 5)
    check("RSS-ключи старых постов узнаю по id пина: свежие — только из невыложенных",
          len(cands) == 253 and all(int(x["key"][4:]) >= 1025 for x in cands))

    # ---------- видео и карусель при публикации ----------
    got = []

    async def dd(url, suffix=".mp4"):
        got.append(url)
        if "/720p/" in url:
            return "/tmp/v.mp4"
        raise md.DLError("404")
    md.download_direct = dd
    media = await rules.resolve_media({"with_media": 1, "type": "pinterest"}, {"media_kind": "all"}, dict(v))
    check("видео-пин → ВИДЕО (по ссылкам из доски, HLS → 720p.mp4), не картинка",
          len(media) == 1 and media[0]["type"] == "video" and media[0]["path"] == "/tmp/v.mp4")
    media = await rules.resolve_media({"with_media": 1, "type": "pinterest"}, {"media_kind": "all"}, dict(c))
    check("карусель → альбом из 4", len(media) == 4 and all(m["type"] == "photo" for m in media))

    # ---------- API не пустил → RSS ----------
    sources._board_cache.clear()

    async def api_bad(resource, options):
        raise sources.SourceError("pinterest ответил 403")
    sources._pin_api = api_bad
    rss = []

    async def get(url, *a, **k):
        rss.append(url)
        return 200, b"<rss><channel></channel></rss>"
    sources._get = get
    try:
        await sources.fetch("pinterest", "Nesoobu/h9", 15)
    except sources.SourceError:
        pass
    check("API не пустил — запасной путь через RSS", rss and rss[0].endswith("Nesoobu/h9.rss"))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
