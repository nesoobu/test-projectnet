"""Волна 51: «богатый» стикер-бот. python test_w51.py ../sonya stk"""
import asyncio
import io
import os
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "stk"
from aiogram.methods import (CreateNewStickerSet, AddStickerToSet, SetStickerEmojiList, SetStickerPositionInSet,
                             SetStickerSetThumbnail, DeleteStickerFromSet, DeleteStickerSet, SendSticker,
                             ReplaceStickerInSet, SetCustomEmojiStickerSetThumbnail, EditMessageText, SendPhoto)
from aiogram.types import PhotoSize, Sticker, StickerSet

U, P = 300, 301   # обычный и с Соней+


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


def stk(fid, uq, set_name="", video=False, emoji="✨", ce=None, typ="regular"):
    return Sticker(file_id=fid, file_unique_id=uq, type=typ, width=512, height=512, is_animated=False,
                   is_video=video, set_name=set_name, emoji=emoji, custom_emoji_id=ce)


def png(color="red", size=(400, 300)):
    from PIL import Image, ImageDraw
    im = Image.new("RGB", size, (245, 245, 240))
    ImageDraw.Draw(im).ellipse((100, 50, 300, 250), fill=color)
    b = io.BytesIO()
    im.save(b, "PNG")
    return b.getvalue()


async def main():
    M, bot, dp = await setup()
    from handlers import stickers
    import premium
    from PIL import Image
    premium.plus = lambda uid: uid == P
    stickers.ALBUM_WAIT = 0.1

    async def fake_download(file_id, destination=None, **kw):
        destination.write(png()) if hasattr(destination, "write") else open(destination, "wb").write(png())
    bot.download = fake_download

    # ---- картинки ----
    check("подпись: эмодзи отдельно, текст отдельно", stickers.caption_text("когда пятница 🎉😎") == "когда пятница"
          and stickers.pick_emoji("когда пятница 🎉") == "🎉")
    kw = stickers.keywords_of("когда пятница наконец пришла и все рады очень сильно сегодня вечером ура")
    check("ключевые слова: до 64 символов", kw and sum(map(len, kw)) <= 64 and "пятница" in kw)
    st = Image.open(io.BytesIO(stickers.to_png(png(), "sticker", text="когда пятница")))
    check("надпись на стикере: 512 и прозрачный фон под надписью", max(st.size) == 512 and st.mode == "RGBA")
    cut = Image.open(io.BytesIO(stickers.to_png(png(), "sticker", cut=True)))
    check("вырезка + обводка: углы прозрачные, по контуру белое",
          cut.getpixel((1, 1))[3] == 0 and any(cut.getpixel((x, cut.height // 2))[:3] == (255, 255, 255)
                                               and cut.getpixel((x, cut.height // 2))[3] > 200 for x in range(cut.width // 3)))
    # маска «от нейросети»: рисуем вручную
    from PIL import ImageDraw
    m = Image.new("RGBA", (400, 300), (0, 0, 0, 0))
    ImageDraw.Draw(m).rectangle((50, 50, 350, 250), fill=(0, 0, 0, 255))
    b = io.BytesIO()
    m.save(b, "PNG")
    sm = Image.open(io.BytesIO(stickers.to_png(png(), "sticker", cut=True, smart=b.getvalue())))
    check("умный фон: применяю маску нейросети", sm.mode == "RGBA" and sm.getpixel((1, 1))[3] == 0)
    bad = Image.new("RGBA", (400, 300), (0, 0, 0, 255))
    b2 = io.BytesIO()
    bad.save(b2, "PNG")
    check("умный фон: маска «всё» — не применяю", stickers.apply_smart(Image.open(io.BytesIO(png())), b2.getvalue()) is None)
    check("умный фон без модели — выключен, бот не падает", stickers.smart_ready() in (True, False))
    vs = Image.open(io.BytesIO(stickers.showcase("Котики", [png()] * 6, "6 шт · @bot")))
    check("витрина: картинка 1080 в ширину", vs.size[0] == 1080)

    # ---- видео: кружок и ускорение ----
    import shutil
    if shutil.which("ffmpeg"):
        import subprocess
        import tempfile
        src = tempfile.mktemp(suffix=".mp4")
        subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=240x240:rate=30",
                        "-t", "6", src], check=True)
        data = await stickers.to_webm(src, "sticker", round_=True, dur=6)
        tmp = tempfile.mktemp(suffix=".webm")
        open(tmp, "wb").write(data)
        pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=width:stream_tags=alpha_mode",
                             "-of", "default=nw=1", tmp], capture_output=True, text=True).stdout
        check("кружок: круглый видео-стикер с прозрачностью, 512, ≤256 КБ",
              len(data) <= 256 * 1024 and "width=512" in pr and "alpha_mode=1" in pr)
        dur = float(next((x.split("=")[1] for x in pr.split() if x.startswith("duration=")), "9"))
        check("видео 6 с ускорено до 3 с", dur <= 3.1)

    # ---- карточка после добавления ----
    photo = [PhotoSize(file_id="p1", file_unique_id="p1", width=10, height=10)]
    new_stk = stk("NEW1", "nu1")

    async def fake_last(bot_, name):
        return new_stk
    stickers._last_sticker = fake_last
    await dp.feed_update(bot, cbq("stk:new:sticker", U, U))
    await dp.feed_update(bot, cbq("stk:wr", U, U))   # волна 52: мастер — всё случайно
    SENT.clear()
    await dp.feed_update(bot, msg(None, U, U, photo=photo, caption="когда пятница 🎉"))
    mk = H.sent(CreateNewStickerSet)
    check("подпись → эмодзи и ключевые слова", mk and mk[0].stickers[0].emoji_list == ["🎉"]
          and "пятница" in (mk[0].stickers[0].keywords or []))
    p = await stickers.current(U)
    SENT.clear()
    await dp.feed_update(bot, msg(None, U, U, photo=photo))
    ss = H.sent(SendSticker)
    check("после добавления — присылаю сам стикер с карточкой", ss and ss[0].sticker == "NEW1"
          and "stk:c:em:" in str(ss[0].reply_markup) and "stk:c:bg:" in str(ss[0].reply_markup))
    tok = (await db.q_one("SELECT k FROM kv WHERE k LIKE 'stk:card:%' ORDER BY rowid DESC"))["k"].split(":")[2]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:em:{tok}", U, U))
    check("😀: выбор эмодзи", f"stk:c:e0:{tok}" in kbs())
    await dp.feed_update(bot, cbq(f"stk:c:e9:{tok}", U, U))
    se = H.sent(SetStickerEmojiList)
    check("эмодзи привязан", se and se[0].emoji_list == ["🔥"] and se[0].sticker == "NEW1")
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:ew:{tok}", U, U))
    await dp.feed_update(bot, msg("😺🐱", U, U))
    se = H.sent(SetStickerEmojiList)
    check("✍️ свои эмодзи — несколько", se and se[0].emoji_list == ["😺", "🐱"])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:up:{tok}", U, U))
    check("⬅️ первым", H.sent(SetStickerPositionInSet) and H.sent(SetStickerPositionInSet)[0].position == 0)
    await dp.feed_update(bot, cbq(f"stk:c:cv:{tok}", U, U))
    th = H.sent(SetStickerSetThumbnail)
    check("🖼 обложка пака", th and th[0].name == p["name"] and th[0].format == "static")

    async def fake_set(bot_, name):
        return StickerSet(name=name, title="t", sticker_type="regular", stickers=[stk("x", "x0"), new_stk])
    stickers._set_of = fake_set
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:bg:{tok}", U, U))
    rp = H.sent(ReplaceStickerInSet)
    check("✂️ без фона: стикер заменён на месте", rp and rp[0].old_sticker == "NEW1"
          and rp[0].sticker.emoji_list == ["😺"])
    check("…и новая карточка «↩️ С фоном»", "С фоном" in kbs())
    # 🗑 из карточки
    tok = (await db.q_one("SELECT k FROM kv WHERE k LIKE 'stk:card:%' ORDER BY rowid DESC"))["k"].split(":")[2]
    n0 = (await stickers.pack(U, p["id"]))["n"]
    check("карточка хранится в базе", await db.q_one("SELECT k FROM kv WHERE k LIKE 'stk:card:%'"))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:rm:{tok}", U, U))
    check("🗑 удалено, счётчик меньше", H.sent(DeleteStickerFromSet) and (await stickers.pack(U, p["id"]))["n"] == n0 - 1)

    # ---- альбом ----
    SENT.clear()
    n0 = (await stickers.pack(U, p["id"]))["n"]
    for i in range(4):
        await dp.feed_update(bot, msg(None, U, U, photo=[PhotoSize(file_id=f"a{i}", file_unique_id=f"a{i}",
                                                                    width=10, height=10)], media_group_id="g1"))
    await asyncio.sleep(0.3)
    check("альбом: 4 картинки — 4 стикера", len(H.sent(AddStickerToSet)) == 4
          and (await stickers.pack(U, p["id"]))["n"] == n0 + 4)
    check("альбом: одно сообщение-прогресс, без спама", len(H.sent(SendMessage)) == 1 and "добавила 4" in all_text())

    # ---- экран пака, витрина, удаление ----
    SENT.clear()
    await dp.feed_update(bot, cbq("stk:list", U, U))
    check("мои паки: пак → экран", f"stk:p:{p['id']}" in kbs() and "addstickers/" in kbs())
    await dp.feed_update(bot, cbq(f"stk:p:{p['id']}", U, U))
    check("экран пака: прогресс, витрина, удалить", "▰" in all_text() and f"stk:v:{p['id']}" in kbs()
          and f"stk:pd:{p['id']}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:v:{p['id']}", U, U))
    check("👀 витрина — фото с кнопкой «Добавить пак»", H.sent(SendPhoto) and "addstickers/" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:pd:{p['id']}", U, U))
    check("удалить пак — сначала спрашиваю", not H.sent(DeleteStickerSet) and f"stk:pdy:{p['id']}" in kbs())
    await dp.feed_update(bot, cbq(f"stk:pdy:{p['id']}", U, U))
    check("пак удалён в Telegram и у меня", H.sent(DeleteStickerSet) and not await stickers.pack(U, p["id"])
          and not await stickers.current(U))

    # ---- свой стикер и чужой пак ----
    foreign = stk("f1", "f1", set_name="cats_by_x")
    SENT.clear()
    await dp.feed_update(bot, msg(None, U, U, sticker=foreign))
    tok = [k for k in stickers._msgs][-1]
    check("чужой стикер: «весь пак себе»", f"stk:cp:{tok}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:cp:{tok}", U, U))
    check("весь пак — с Соней+", not H.sent(CreateNewStickerSet) and "чужой пак" in all_text())

    async def big_set(bot_, name):
        return StickerSet(name=name, title="Котики", sticker_type="regular",
                          stickers=[stk(f"c{i}", f"c{i}", video=i % 2 == 0) for i in range(60)])
    stickers._set_of = big_set
    await dp.feed_update(bot, msg(None, P, P, sticker=foreign))
    tok = [k for k in stickers._msgs][-1]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:cp:{tok}", P, P))
    mk = H.sent(CreateNewStickerSet)
    check("копия: 50 сразу + остальные, форматы сохранены", mk and len(mk[0].stickers) == 50
          and mk[0].stickers[0].format == "video" and mk[0].stickers[1].format == "static"
          and len(H.sent(AddStickerToSet)) == 10)
    cp = await stickers.current(P)
    check("копия: в базе, 60 шт, название как у оригинала", cp and cp["n"] == 60 and cp["title"] == "Котики")
    SENT.clear()
    await dp.feed_update(bot, msg(None, P, P, sticker=stk("c1", "c1", set_name=cp["name"])))
    check("свой стикер — карточка действий", "stk:c:up:" in kbs() and "stk:c:rm:" in kbs())

    # ---- эмодзи-пак: обложка через custom_emoji ----
    stickers._set_of = lambda b, n: asyncio.sleep(0, None)
    await dp.feed_update(bot, cbq("stk:new:emoji", P, P))
    await dp.feed_update(bot, cbq("stk:wr", P, P))   # волна 52: мастер — всё случайно
    stickers._last_sticker = lambda b, n: asyncio.sleep(0, stk("E1", "e1", ce="555", typ="custom_emoji"))
    await dp.feed_update(bot, msg(None, P, P, photo=photo))
    await dp.feed_update(bot, msg(None, P, P, photo=photo))
    tok = (await db.q_one("SELECT k FROM kv WHERE k LIKE 'stk:card:%' ORDER BY rowid DESC"))["k"].split(":")[2]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"stk:c:cv:{tok}", P, P))
    ce = H.sent(SetCustomEmojiStickerSetThumbnail)
    check("эмодзи-пак: обложка из эмодзи", ce and ce[0].custom_emoji_id == "555")

    # ---- главная ----
    SENT.clear()
    await dp.feed_update(bot, msg("/start", P, P))
    check("главная: текущий пак, прогресс, статистика", "добавляю в" in all_text() and "паков:" in all_text())
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
