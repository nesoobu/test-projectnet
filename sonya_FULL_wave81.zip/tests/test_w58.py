"""Волна 58: Соня-ассистент в личных чатах (Telegram Business). python test_w58.py ../sonya full"""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.methods import SendMessage
from aiogram.types import (Update, Message, Chat, User, BusinessConnection, BusinessBotRights,
                           Voice, MessageOriginUser)

OWNER = 1
_u = [1000]


def biz_conn(enabled=True, can_reply=True):
    _u[0] += 1
    return Update(update_id=_u[0], business_connection=BusinessConnection(
        id="BC1", user=User(id=OWNER, is_bot=False, first_name="Тим"), user_chat_id=OWNER,
        date=datetime.now(), is_enabled=enabled,
        rights=BusinessBotRights(can_reply=can_reply, can_read_messages=True)))


def biz_msg(text, from_id, chat_id, name="Аня", voice=False):
    _u[0] += 1
    kw = {}
    if voice:
        kw["voice"] = Voice(file_id="v", file_unique_id="v", duration=5)
    return Update(update_id=_u[0], business_message=Message(
        message_id=_u[0], date=datetime.now(), business_connection_id="BC1",
        chat=Chat(id=chat_id, type="private"),
        from_user=User(id=from_id, is_bot=False, first_name=name), text=text if not voice else None, **kw))


def to_chat(cid):
    return [m for m in H.sent(SendMessage) if m.chat_id == cid]


def biz_sent(cid):
    return [m for m in H.sent(SendMessage) if m.chat_id == cid and getattr(m, "business_connection_id", None) == "BC1"]


async def main():
    M, bot, dp = await setup()
    from handlers import business as B

    # нет обработчика удалённых сообщений — принципиально
    check("шпиона нет: deleted_business_messages не слушаем",
          not getattr(dp.deleted_business_messages, "handlers", []))

    # подключение
    SENT.clear()
    await dp.feed_update(bot, biz_conn())
    conn = await B.conn_of(OWNER)
    check("подключение сохранено, владельцу — настройки", conn and conn["can_reply"] == 1
          and to_chat(OWNER) and "подключена" in to_chat(OWNER)[0].text)

    # автоответ выключен по умолчанию
    SENT.clear()
    await dp.feed_update(bot, biz_msg("привет", 50, 50))
    check("по умолчанию автоответ молчит", not biz_sent(50))

    # включаем, режим «всем»
    c = await B.cfg_of(OWNER)
    c["on"], c["mode"] = 1, "all"
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("ещё раз", 50, 50))
    check("mode=all: отвечаю, через business-соединение", biz_sent(50) and B.DEF_TEXT in biz_sent(50)[0].text)

    # кулдаун — второй раз сразу молчу
    SENT.clear()
    await dp.feed_update(bot, biz_msg("ау", 50, 50))
    check("кулдаун: второй раз сразу — молчу", not biz_sent(50))

    # владелец сам написал — 30 мин молчу
    await db.q_run("UPDATE biz_seen SET replied=0 WHERE uid=? AND chat_id=?", OWNER, 50)
    await dp.feed_update(bot, biz_msg("я сам отвечу", OWNER, 50))   # исходящее владельца
    SENT.clear()
    await dp.feed_update(bot, biz_msg("а?", 50, 50))
    check("владелец недавно писал — автоответ молчит", not biz_sent(50))

    # режим «только новым»
    c = await B.cfg_of(OWNER)
    c["mode"] = "new"
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("новый человек", 60, 60))
    check("mode=new: новому отвечаю", biz_sent(60))
    await db.q_run("UPDATE biz_seen SET replied=0, last_out=0 WHERE uid=? AND chat_id=?", OWNER, 50)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("я уже писал раньше", 50, 50))
    check("mode=new: знакомому не отвечаю", not biz_sent(50))

    # чёрный список
    c = await B.cfg_of(OWNER)
    c["mode"], c["bl"] = "all", [70]
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("спам", 70, 70))
    check("чёрный список: не отвечаю", not biz_sent(70))

    # пауза
    c = await B.cfg_of(OWNER)
    c["paused"] = 1
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("эй", 80, 80))
    check("пауза: молчу везде", not biz_sent(80))
    c = await B.cfg_of(OWNER)
    c["paused"] = 0
    await B.save_cfg(OWNER, c)

    # расшифровка голосовых → владельцу
    async def fake_dl(file_id, destination=None, **kw):
        open(destination, "wb").write(b"x")
    bot.download = fake_dl
    import stt
    stt.transcribe = lambda p: asyncio.sleep(0, "привет как дела")
    c = await B.cfg_of(OWNER)
    c["stt"], c["on"] = 1, 0   # автоответ выключим, чтобы проверить именно расшифровку
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg(None, 90, 90, name="Петя", voice=True))
    await asyncio.sleep(0.05)
    dm = [m for m in to_chat(OWNER) if "Петя" in m.text]
    check("🎙 расшифровка входящего голосового — владельцу в ЛС", dm and "как дела" in dm[0].text)
    check("голосовое собеседнику НЕ пересылаю", not biz_sent(90))

    # ИИ-черновик
    import llm
    llm.ask = lambda *a, **k: asyncio.sleep(0, "Привет! Давай завтра созвонимся.")
    c = await B.cfg_of(OWNER)
    c["draft"], c["on"] = 1, 0
    await B.save_cfg(OWNER, c)
    SENT.clear()
    await dp.feed_update(bot, biz_msg("созвон?", 95, 95, name="Макс"))
    await asyncio.sleep(0.05)
    draft = [m for m in to_chat(OWNER) if "черновик" in m.text]
    check("🤖 черновик ответа — владельцу с кнопкой «отправить»", draft and "созвонимся" in draft[0].text
          and "biz:snd:" in str(draft[0].reply_markup))
    tok = list(B._drafts)[-1]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"biz:snd:{tok}", OWNER, OWNER))
    check("черновик отправляется собеседнику от имени владельца", biz_sent(95) and "созвонимся" in biz_sent(95)[0].text)

    # настройки: тумблеры и текст
    SENT.clear()
    await dp.feed_update(bot, msg("/assistant", OWNER, OWNER))
    check("/assistant: экран настроек", "Соня-ассистент" in "\n".join(H.texts()) and "biz:on" in
          "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT))
    await dp.feed_update(bot, cbq("biz:on", OWNER, OWNER))
    check("тумблер автоответа сохраняется", (await B.cfg_of(OWNER))["on"] == 1)
    await dp.feed_update(bot, cbq("biz:text", OWNER, OWNER))
    await dp.feed_update(bot, msg("Я на встрече, наберу позже", OWNER, OWNER))
    check("свой текст автоответа", (await B.cfg_of(OWNER))["text"] == "Я на встрече, наберу позже")

    # не подключённый — инструкция
    SENT.clear()
    await dp.feed_update(bot, msg("/assistant", 500, 500))
    check("не подключён — показываю, как подключить", "Telegram для бизнеса" in "\n".join(H.texts()))

    # сводка: кому не ответил больше суток
    await db.q_run("UPDATE biz_seen SET last_in=?, last_out=0, name='Долг' WHERE uid=? AND chat_id=?",
                   int(time.time()) - 2 * 86400, OWNER, 60)
    rows = await db.q_all("SELECT name FROM biz_seen WHERE uid=? AND last_in>last_out AND last_in<?",
                          OWNER, int(time.time()) - 86400)
    check("сводка видит забытых собеседников", any(r["name"] == "Долг" for r in rows))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
