"""Волна 56: розыгрыши — барабан вживую, проверка честности, экран розыгрыша, напоминание, продление, карточка.
python test_w56.py ../sonya gw"""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "gw"
from aiogram.methods import SendMessage, EditMessageText, SendDocument, SendPhoto
from aiogram.types import Update, CallbackQuery, Message, Chat, User, MessageOriginChannel


def cbu(data, uid):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name=f"U{uid}"),
        message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=uid, type="private"))))


async def connect(dp, bot, uid, cid):
    H.ADMINS.add(uid)
    await dp.feed_update(bot, msg("/start", uid, uid))
    await dp.feed_update(bot, msg("/giveaway", uid, uid))
    await dp.feed_update(bot, msg("пост", uid, uid, forward_origin=MessageOriginChannel(
        type="channel", date=datetime.now(), chat=Chat(id=cid, type="channel", title="Канал"), message_id=5)))


async def create(dp, bot, uid, prize, n, opts=(), later=None, fresh=True):
    if fresh:
        await dp.feed_update(bot, msg("/giveaway", uid, uid))
    await dp.feed_update(bot, cbq("gw:pt:text", uid, uid))
    await dp.feed_update(bot, msg(prize, uid, uid))
    await dp.feed_update(bot, cbq(f"gw:w:{n}", uid, uid))
    await dp.feed_update(bot, cbq("gw:d:3600", uid, uid))
    for o in opts:
        await dp.feed_update(bot, cbq(f"gw:o:{o}", uid, uid))
    if later:
        await dp.feed_update(bot, cbq("gw:o:later", uid, uid))
        await dp.feed_update(bot, msg(later, uid, uid))
    await dp.feed_update(bot, cbq("gw:go", uid, uid))
    return await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")




def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import giveaway as G
    G.ANIM_PAUSE = 0
    await connect(dp, bot, 7, -100900)
    g = await create(dp, bot, 7, "🎧 Наушники", 1, fresh=False)
    for u in (41, 42, 43, 44):
        await dp.feed_update(bot, msg("/start", u, u))
        await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", u))
    # экран розыгрыша
    SENT.clear()
    await dp.feed_update(bot, cbq("gw:list", 7, 7))
    check(f"[{P}] список: розыгрыш — кнопка на экран", f"gw:g:{g['id']}" in kbs())
    await dp.feed_update(bot, cbq(f"gw:g:{g['id']}", 7, 7))
    t = "\n".join(H.texts())
    check(f"[{P}] экран: участники, билеты, до итогов, кнопки", "участников" in t and "до итогов" in t
          and all(f"gw:{k}:{g['id']}" in kbs() for k in ("end", "rm", "csv", "cx")) and f"gw:ex:{g['id']}:86400" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:g:{g['id']}", 8, 8))
    check(f"[{P}] чужой экран не открывается", not [m for m in SENT if isinstance(m, EditMessageText)])
    # продление
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:ex:{g['id']}:86400", 7, 7))
    g2 = await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"])
    check(f"[{P}] ⏰ +1 день — время сдвинуто, пост обновлён", g2["ends"] == g["ends"] + 86400
          and any(isinstance(m, EditMessageText) and m.chat_id == -100900 for m in SENT))
    # напоминание
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:rm:{g['id']}", 7, 7))
    rm = [m for m in H.sent(SendMessage) if m.chat_id == -100900]
    check(f"[{P}] 📣 напоминание в канале ответом на пост", rm and "успевай" in rm[0].text and rm[0].reply_to_message_id)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:rm:{g['id']}", 7, 7))
    check(f"[{P}] второе напоминание сразу — нельзя", not [m for m in H.sent(SendMessage) if m.chat_id == -100900])
    # csv
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:csv:{g['id']}", 7, 7))
    check(f"[{P}] 📄 участники файлом до итогов", H.sent(SendDocument))
    # итоги: барабан
    SENT.clear()
    await G.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"]))
    ch_send = [m for m in H.sent(SendMessage) if m.chat_id == -100900]
    ch_edit = [m for m in SENT if isinstance(m, EditMessageText) and m.chat_id == -100900 and m.message_id != g["msg_id"]]
    check(f"[{P}] 🎰 барабан: «крутим», кадры, итоги правкой", ch_send and "крутим барабан" in ch_send[0].text
          and len(ch_edit) >= 4 and "итоги розыгрыша" in ch_edit[-1].text)
    check(f"[{P}] под итогами — «🔍 Проверить честность»", f"gwv_{g['id']}" in str(ch_edit[-1].reply_markup))
    # проверка честности по ссылке
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwv_{g['id']}", 50, 50))
    t = "\n".join(H.texts())
    check(f"[{P}] проверка: seed, хэш ✅, победитель, как выбирали", "seed" in t and "✅" in t and "🏆" in t
          and "random.Random" in t and f"gw:pl:{g['id']}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:pl:{g['id']}", 50, 50))
    doc = H.sent(SendDocument)
    check(f"[{P}] публичный список — файлом", bool(doc))
    check(f"[{P}] имена в нём скрыты", G._mask("Анастасия") == "Ан***" and G._mask("Я") == "***")
    # карточка
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:card:{g['id']}", 7, 7))
    check(f"[{P}] 🖼 карточка итогов", H.sent(SendPhoto))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:g:{g['id']}", 7, 7))
    check(f"[{P}] экран после итогов: победитель, карточка, повтор", "🏆" in "\n".join(H.texts())
          and f"gw:card:{g['id']}" in kbs() and f"gw:rp:{g['id']}" in kbs())
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
