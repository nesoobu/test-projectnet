"""Волна 63: 🎲 розыгрыш кубиком в комментариях и в чате (/roll), учёт стажа и активности (members.py),
фильтры «старожилы» и «только с бустом» в обычных розыгрышах.
python test_w63.py ../sonya full   (и gw, grp)"""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMessage, SendDice, EditMessageText, AnswerCallbackQuery
from aiogram.types import (Update, CallbackQuery, Message, Chat, User, ChatMemberUpdated, ChatMemberMember,
                           ChatMemberLeft, MessageOriginChannel)

G_ID, CH_ID = -100, -100555


def gmsg(text, uid, **kw):
    return msg(text, G_ID, uid, name=f"U{uid}", **kw)


def member_upd(chat_id, uid, join=True):
    H._uid[0] += 1
    u = User(id=uid, is_bot=False, first_name=f"U{uid}")
    old = ChatMemberLeft(user=u) if join else ChatMemberMember(user=u)
    new = ChatMemberMember(user=u) if join else ChatMemberLeft(user=u)
    return Update(update_id=H._uid[0], chat_member=ChatMemberUpdated(
        chat=Chat(id=chat_id, type="channel" if chat_id == CH_ID else "supergroup"),
        from_user=u, date=datetime.now(), old_chat_member=old, new_chat_member=new))


def all_text():
    out = []
    for m in SENT:
        t = getattr(m, "text", None) or getattr(m, "caption", None)
        if isinstance(t, str):
            out.append(t)
    return "\n".join(out)


async def panel_mid():
    r = await db.q_one("SELECT k FROM kv WHERE k LIKE ? ORDER BY rowid DESC LIMIT 1", f"roll:{G_ID}:%")
    return int(r["k"].rsplit(":", 1)[1]) if r else 0


def alerts():
    return [a.text or "" for a in H.sent(AnswerCallbackQuery)]


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    import members
    from handlers import roll, giveaway as G
    roll.DICE_PAUSE = 0
    H.ADMINS.clear()
    H.ADMINS.add(1)

    async def linked(bot_, chat_id):
        return CH_ID if chat_id == G_ID else 0
    roll._linked = linked

    # ---------- учёт: комментарии, вступления ----------
    for u in (201, 202, 203, 204, 205):
        await dp.feed_update(bot, gmsg(f"коммент {u}", u, message_thread_id=777))
    await dp.feed_update(bot, gmsg("ещё", 201, message_thread_id=777))
    check(f"[{P}] ветка: 5 комментаторов по порядку, без повторов",
          await members.thread_people(G_ID, 777) == [201, 202, 203, 204, 205])
    check(f"[{P}] активность: 201 написал 2 раза", await members.msgs(G_ID, 201) == 2)
    await dp.feed_update(bot, gmsg(None, 206, new_chat_members=[User(id=206, is_bot=False, first_name="Новичок")]))
    check(f"[{P}] вступил при боте → стаж 0 дн, не старожил", not await members.old_enough(G_ID, 206, 3))
    check(f"[{P}] писал, а вступления не видели → был до бота → старожил", await members.old_enough(G_ID, 201, 90))
    await dp.feed_update(bot, member_upd(CH_ID, 205, join=True))
    check(f"[{P}] подписка на канал при боте (chat_member) → стаж с этого момента",
          (await members.days_in(CH_ID, 205)) is not None and not await members.old_enough(CH_ID, 205, 3))
    await dp.feed_update(bot, member_upd(CH_ID, 205, join=False))
    check(f"[{P}] отписался — запись стёрта", await members.days_in(CH_ID, 205) is None)
    await dp.feed_update(bot, member_upd(CH_ID, 205, join=True))

    # ---------- /roll: права и панель ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/roll", 50, 50))
    check(f"[{P}] /roll в личке — объясняю, как пользоваться", "в комментариях к посту" in all_text())
    SENT.clear()
    await dp.feed_update(bot, gmsg("/roll", 202, message_thread_id=777))
    check(f"[{P}] не админ — нельзя", "только админы" in all_text() and not await panel_mid())
    SENT.clear()
    await dp.feed_update(bot, gmsg("/roll", 1, message_thread_id=777))
    mid = await panel_mid()
    check(f"[{P}] панель в комментах: «комментировал пост», 6 человек (с админом)",
          mid and "комментировал пост" in all_text() and "<b>6</b>" in all_text())
    SENT.clear()
    await dp.feed_update(bot, cbq("rl:w+", G_ID, 202, mid))
    check(f"[{P}] чужие нажатия на панель — нельзя", any("панель админа" in a for a in alerts()))
    for a in ("rl:w+", "rl:days"):
        await dp.feed_update(bot, cbq(a, G_ID, 1, mid))
    st = json.loads(await db.kv_get(f"roll:{G_ID}:{mid}"))
    check(f"[{P}] кнопки: 2 победителя, старожилы ≥3 дн", st["winners"] == 2 and st["days"] == 3
          and "в канале ≥ 3 дн" in all_text())

    # ---------- бросок ----------
    H.LEFT.add(204)            # 204 отписался/вышел — не участвует; 205 подписан на канал только что; 1 — админ
    H.DICE[:] = [1, 1, 2]      # 1 → №1; снова №1 — уже выиграл, переброс; 2 → №2
    SENT.clear()
    await asyncio.gather(dp.feed_update(bot, cbq("rl:go", G_ID, 1, mid)), dp.feed_update(bot, cbq("rl:go", G_ID, 1, mid)))
    txt = all_text()
    dice = H.sent(SendDice)
    check(f"[{P}] фильтры: осталось 3 из 6 (без админа, вышедшего и новичка канала)",
          "участников: <b>3</b> (из 6" in txt and "3. U" in txt and "4. U" not in txt)
    check(f"[{P}] кубики Telegram: 3 броска, переброс при повторе", len(dice) == 3 and "уже выиграл" in txt)
    check(f"[{P}] итоги: №1 и №2 со ссылками", "итоги розыгрыша" in txt and "tg://user?id=201" in txt
          and "tg://user?id=202" in txt and txt.count("итоги розыгрыша") == 1)
    check(f"[{P}] двойной «Бросить» — розыгрыш один", txt.count("участников:") == 1)
    H.LEFT.discard(204)
    await dp.feed_update(bot, gmsg("/roll", 1, message_thread_id=777))
    mid3 = await panel_mid()
    await dp.feed_update(bot, cbq("rl:nowin", G_ID, 1, mid3))
    H.DICE[:] = [1]
    SENT.clear()
    await dp.feed_update(bot, cbq("rl:go", G_ID, 1, mid3))
    check(f"[{P}] «без прошлых победителей»: 201 и 202 не участвуют, выигрывает 203",
          "tg://user?id=203" in all_text() and "tg://user?id=201" not in all_text())

    # ---------- ответом на сообщение и «кто писал за сутки» ----------
    root = reply_to(999, chat_id=G_ID, text="кто хочет приз — отвечайте")
    for u in (301, 302):
        await dp.feed_update(bot, gmsg("я!", u, reply=root))
    SENT.clear()
    await dp.feed_update(bot, gmsg("/roll", 1, reply=root))
    check(f"[{P}] ответом на сообщение: «ответил на сообщение», 3 человека (с админом)",
          "ответил на сообщение" in all_text() and "<b>3</b>" in all_text())
    SENT.clear()
    await dp.feed_update(bot, gmsg("/roll", 1))
    mid2 = await panel_mid()
    check(f"[{P}] просто в чате: «писал в чате за сутки»", "писал в чате за сутки" in all_text())
    await dp.feed_update(bot, cbq("rl:hours", G_ID, 1, mid2))
    check(f"[{P}] период: сутки → 3 дня", "за 3 дня" in all_text())
    H.DICE[:] = [4]
    SENT.clear()
    await dp.feed_update(bot, cbq("rl:msgs", G_ID, 1, mid2))   # ≥3 сообщений — ни у кого
    await dp.feed_update(bot, cbq("rl:go", G_ID, 1, mid2))
    check(f"[{P}] никто не прошёл — честно говорю", "никто не прошёл" in all_text())

    # ---------- обычный розыгрыш: старожилы канала и буст ----------
    if P in ("full", "gw"):
        await dp.feed_update(bot, msg("/start", 1, 1))
        await dp.feed_update(bot, msg("/giveaway", 1, 1))
        await dp.feed_update(bot, msg("пост", 1, 1, forward_origin=MessageOriginChannel(
            type="channel", date=datetime.now(), chat=Chat(id=-100777, type="channel", title="City_N"), message_id=5)))
        await dp.feed_update(bot, cbq("gw:cancelnew", 1, 1))
        await dp.feed_update(bot, msg("/giveaway", 1, 1))
        await dp.feed_update(bot, cbq("gw:pt:text", 1, 1))
        await dp.feed_update(bot, msg("приз", 1, 1))
        await dp.feed_update(bot, cbq("gw:w:1", 1, 1))
        await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
        for o in ("old", "old", "nb"):
            await dp.feed_update(bot, cbq(f"gw:o:{o}", 1, 1))
        await dp.feed_update(bot, cbq("gw:go", 1, 1))
        g = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
        check(f"[{P}] розыгрыш: старожилы 30 дн + только с бустом, в условиях поста",
              g["member_days"] == 30 and g["need_boost"] == 1 and "30 дней" in G.post_text(g, 0)
              and "забустить" in G.post_text(g, 0))

        async def no_sus(bot_, user): return False
        G._suspicious = no_sus
        boosted = {401}

        async def bo(bot_, chat, uid): return 1 if uid in boosted else 0
        G.boosts_of = bo
        await dp.feed_update(bot, member_upd(-100777, 402, join=True))   # подписался только что
        boosted.add(402)
        SENT.clear()
        for u in (401, 402, 403):
            H._uid[0] += 1
            await dp.feed_update(bot, Update(update_id=H._uid[0], callback_query=CallbackQuery(
                id=str(H._uid[0]), chat_instance="x", data=f"gw:j:{g['id']}",
                from_user=User(id=u, is_bot=False, first_name=f"U{u}"),
                message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=u, type="private")))))
        ins = {r["uid"] for r in await db.q_all("SELECT uid FROM giveaway_users WHERE gid=?", g["id"])}
        a = " | ".join(alerts())
        check(f"[{P}] старожил с бустом — в игре; новичок — нет; без буста — нет",
              ins == {401} and "стажем 30+" in a and "забусти" in a)

    await db.close()
    print("итого провалов:", len(FAILS))


import json  # noqa: E402
asyncio.run(main())
sys.exit(1 if FAILS else 0)
