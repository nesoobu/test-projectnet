"""Волна 60: автоудаление сгоревших анон-веток через 2 дня + кнопка «удалить ветку».
python test_w60.py ../sonya anon"""
import asyncio, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "anon"
from aiogram.methods import SendMessage


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    from handlers import anon

    # owner 10 получает сообщения от двух анонимов → две маски
    await dp.feed_update(bot, msg("/start", 10, 10))
    mk_fresh = await anon.mask_of(10, 20)
    mk_burn = await anon.mask_of(10, 21)
    await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, qtext, mask_id, seen, answered) VALUES(?,?,?,?,?,?)",
                   10, 20, "свежее сообщение", mk_fresh["id"], 0, 0)
    await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, qtext, mask_id, seen, answered) VALUES(?,?,?,?,?,?)",
                   10, 21, "старое сгоревшее", mk_burn["id"], 1, 0)

    # маску 21 гасим и состариваем на 3 дня
    old_ts = int(time.time()) - 3 * 86400
    await db.q_run("UPDATE anon_masks2 SET active=0, last_ts=? WHERE id=?", old_ts, mk_burn["id"])

    # ---- автоочистка ----
    n = await anon.purge_burned()
    check("автоочистка: удалена 1 старая сгоревшая ветка", n == 1)
    check("сгоревшая маска стёрта", not await db.q_one("SELECT 1 FROM anon_masks2 WHERE id=?", mk_burn["id"]))
    check("её сообщения стёрты", not await db.q_one("SELECT 1 FROM anon_msgs WHERE mask_id=?", mk_burn["id"]))
    check("свежая ветка цела", await db.q_one("SELECT 1 FROM anon_masks2 WHERE id=?", mk_fresh["id"])
          and await db.q_one("SELECT 1 FROM anon_msgs WHERE mask_id=?", mk_fresh["id"]))

    # недавно сгоревшую (< 2 дней) не трогаем
    mk_recent = await anon.mask_of(10, 22)
    await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, qtext, mask_id) VALUES(?,?,?,?)", 10, 22, "вчера", mk_recent["id"])
    await db.q_run("UPDATE anon_masks2 SET active=0, last_ts=? WHERE id=?", int(time.time()) - 86400, mk_recent["id"])
    await anon.purge_burned()
    check("недавно сгоревшую (< 2 дней) не трогаем", await db.q_one("SELECT 1 FROM anon_masks2 WHERE id=?", mk_recent["id"]))

    # ---- кнопка удаления вручную ----
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:th:{mk_fresh['id']}", 10, 10))
    check("в переписке есть кнопка «удалить ветку»", f"an:thd:{mk_fresh['id']}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:thd:{mk_fresh['id']}", 10, 10))
    check("удаление спрашивает подтверждение", "удалить переписку" in "\n".join(H.texts())
          and f"an:thdy:{mk_fresh['id']}" in kbs())
    await dp.feed_update(bot, cbq(f"an:thdy:{mk_fresh['id']}", 10, 10))
    check("после подтверждения ветка и сообщения удалены",
          not await db.q_one("SELECT 1 FROM anon_masks2 WHERE id=?", mk_fresh["id"])
          and not await db.q_one("SELECT 1 FROM anon_msgs WHERE mask_id=?", mk_fresh["id"]))

    # чужую ветку удалить нельзя
    mk_other = await anon.mask_of(11, 20)
    await dp.feed_update(bot, cbq(f"an:thdy:{mk_other['id']}", 10, 10))
    check("чужую ветку удалить нельзя", await db.q_one("SELECT 1 FROM anon_masks2 WHERE id=?", mk_other["id"]))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
