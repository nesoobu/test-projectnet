"""Волна 57: обратная связь во всех ботах → владельцу в основную Соню. python test_w57.py ../sonya stk"""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "stk"
from aiogram.methods import SendMessage, EditMessageText, SendPhoto
from aiogram.types import PhotoSize


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import feedback as FB
    import os, pathlib
    config.MAIN_DB_PATH = os.path.join(H.TMP, "main_fb.db")   # общая очередь — во временной базе теста
    FB.FILES = pathlib.Path(H.TMP) / "feedback"
    import main as mainmod
    check(f"[{P}] /feedback есть в меню команд", any(c.command == "feedback" for c in mainmod.SOLO_CMDS.get(P, mainmod.PRIVATE)))
    SENT.clear()
    await dp.feed_update(bot, msg("/feedback", 60, 60, name="Аня"))
    check(f"[{P}] форма: ошибка/идея/спасибо", "fb:k:bug" in kbs() and "fb:k:idea" in kbs())
    await dp.feed_update(bot, cbq("fb:k:bug", 60, 60))
    SENT.clear()
    await dp.feed_update(bot, msg("кнопка обложки не работает", 60, 60, name="Аня"))
    r = await FB.q("SELECT * FROM feedback ORDER BY id DESC LIMIT 1")
    check(f"[{P}] отзыв в общей очереди основной Сони", r and r["profile"] == P and r["kind"] == "bug"
          and "обложки" in r["text"] and "отправила" in "\n".join(H.texts()))
    SENT.clear()
    await dp.feed_update(bot, msg("просто текст", 60, 60))
    check(f"[{P}] следующий текст — уже не отзыв", (await FB.q("SELECT COUNT(*) n FROM feedback"))["n"] == 1)
    # со скрином
    async def fake_dl(file_id, destination=None, **kw):
        open(destination, "wb").write(b"\xff\xd8jpg")
    bot.download = fake_dl
    await dp.feed_update(bot, cbq("fb:k:idea", 61, 61))
    await dp.feed_update(bot, msg(None, 61, 61, caption="вот скрин", photo=[PhotoSize(file_id="p", file_unique_id="p", width=1, height=1)]))
    r2 = await FB.q("SELECT * FROM feedback ORDER BY id DESC LIMIT 1")
    check(f"[{P}] скрин сохранён файлом", r2["file"] and (FB.FILES / r2["file"]).exists())

    # основная Соня — владельцу
    real = config.PROFILE
    config.PROFILE = "full"
    config.OWNER_ID = 1
    SENT.clear()
    await FB.pump_new(bot)
    own = [m for m in SENT if getattr(m, "chat_id", 0) == 1]
    check(f"[{P}] владельцу пришли оба: текст и фото, с ботом и кнопками",
          len(own) == 2 and any(isinstance(m, SendPhoto) for m in own) and "fb:a:" in kbs()
          and "🧩" in own[0].text + str(getattr(own[-1], "caption", "")) if P == "stk" else len(own) == 2)
    r = await FB.q("SELECT * FROM feedback WHERE id=?", r["id"])
    check(f"[{P}] второй раз не шлю", r["owner_mid"] > 0 and not (SENT.clear() or await FB.pump_new(bot)) and not SENT)
    # ответ реплаем
    from aiogram.types import Message, Chat, User
    from datetime import datetime
    rep = Message(message_id=r["owner_mid"], date=datetime.now(), chat=Chat(id=1, type="private"), text="x")
    await dp.feed_update(bot, msg("починили, спасибо!", 1, 1, reply=rep))
    r = await FB.q("SELECT * FROM feedback WHERE id=?", r["id"])
    check(f"[{P}] ответ реплаем записан, отзыв закрыт", r["answer"] == "починили, спасибо!" and r["status"] == "closed")
    # ответ кнопкой
    await dp.feed_update(bot, cbq(f"fb:a:{r2['id']}", 1, 1))
    await dp.feed_update(bot, msg("классная идея", 1, 1))
    check(f"[{P}] ответ кнопкой", (await FB.q("SELECT answer FROM feedback WHERE id=?", r2["id"]))["answer"] == "классная идея")
    # чужой не может отвечать
    await dp.feed_update(bot, cbq(f"fb:b:{r2['id']}", 99, 99))
    check(f"[{P}] не владелец не блокирует", not await FB.q("SELECT * FROM feedback_blocks"))
    # доставка ответа своим ботом
    config.PROFILE = real
    SENT.clear()
    await FB.pump_answers(bot)
    got = [m for m in H.sent(SendMessage) if m.chat_id in (60, 61)]
    check(f"[{P}] ответы доставлены пользователям через свой бот", len(got) == 2 and "починили" in got[0].text)
    SENT.clear()
    await FB.pump_answers(bot)
    check(f"[{P}] повторно не шлю", not H.sent(SendMessage))
    # блок
    config.PROFILE = "full"
    await dp.feed_update(bot, cbq(f"fb:b:{r['id']}", 1, 1))
    config.PROFILE = real
    await dp.feed_update(bot, cbq("fb:k:other", 60, 60))
    await dp.feed_update(bot, msg("спам", 60, 60))
    check(f"[{P}] заблокированный — в очередь не попадает", (await FB.q("SELECT COUNT(*) n FROM feedback WHERE uid=60"))["n"] == 1)
    # лимит
    for i in range(6):
        await dp.feed_update(bot, cbq("fb:k:other", 62, 62))
        await dp.feed_update(bot, msg(f"отзыв {i}", 62, 62))
    check(f"[{P}] лимит {FB.DAY_LIMIT} в день", (await FB.q("SELECT COUNT(*) n FROM feedback WHERE uid=62"))["n"] == FB.DAY_LIMIT)
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
