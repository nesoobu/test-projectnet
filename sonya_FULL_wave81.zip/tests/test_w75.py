"""Волна 75: эмодзи с ПОЛНОЙ анимацией (Google Noto Animated + смысловая), замена анимации в готовых паках,
помощники в админке — по названиям. python test_w75.py ../sonya"""
import asyncio, json, os, sqlite3, subprocess, sys, tempfile
from pathlib import Path
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.types import StickerSet, Sticker


async def main():
    M, bot, dp = await setup()
    import sonyamoji as SM, moji
    from handlers import admin
    fx = Path(__file__).parent / "fixtures" / "noto_1f91d.webp"
    real_webp = SM.noto_webp
    SM.noto_webp = lambda e: fx.read_bytes() if SM.norm(e) == "🤝" else None

    inv = SM.inventory()
    check("в паки идут: живые от Google (🎲 🔥 🤝), смайлики — лицо Сони (😂 нет)",
          "🤝" in inv and "🎲" in inv and "🔥" in inv and "😂" not in inv and "♠" not in inv)
    fr = SM.frames("🤝")
    check("🤝 — настоящая анимация Google: кадры разные, 100×100, ≤3 с",
          2 < len(fr) <= 90 and fr[0].size == (100, 100) and fr[0].tobytes() != fr[len(fr) // 2].tobytes())
    data = SM.webm("🤝")
    check("🤝 → WEBM ≤60 КБ", 1000 < len(data) <= 60 * 1024)
    kinds = {}
    for e in inv:
        if SM.norm(e) not in SM.NOTO:
            kinds.setdefault(SM._kind(e), e)
    moving = []
    for k, e in kinds.items():
        f = SM.frames(e)
        moving.append(len(f) == 90 and len({x.tobytes() for x in f[::9]}) >= 3)
    check(f"смысловая анимация для остальных — {len(kinds)} видов, все двигаются ({''.join(kinds.values())})",
          len(kinds) >= 10 and all(moving))
    check("флаг — «развевается», машина — «едет», туча — «дождь»",
          SM._kind("🇷🇺") == "flag" and SM._kind("🚓") == "drive" and SM._kind("🌨") == "weather")
    d = SM.webm("🇷🇺")
    check("флаг → WEBM ≤60 КБ", 1000 < len(d) <= 60 * 1024)
    gif = SM.preview_gif(["sonya", "🤝", "🇷🇺"], 3)
    check("превью с разной длиной анимаций не падает", gif[:3] == b"GIF")

    # ---------- замена анимации в уже собранных паках ----------
    SM.webm = lambda k, limit=None: b"NEW"
    packs, calls = {}, {"replace": 0, "add": 0, "create": 0}
    ids = [0]

    def nid():
        ids[0] += 1
        return f"id{ids[0]}"

    p1 = "sonya_moji1_by_Sonya_rubot"
    p0 = "sonya_emoji_by_Sonya_rubot"
    old1 = ["🖤", "⚠", "🎨", "🗑"]   # старый пак 70-й волны (статичные значки)
    packs[p1] = [(k, nid()) for k in old1]
    packs[p0] = [(k, nid()) for k in SM.SET]
    await db.kv_set(f"moji:order:{p1}", json.dumps(old1, ensure_ascii=False))
    await db.kv_set(f"moji:order:{p0}", json.dumps(list(SM.SET), ensure_ascii=False))
    await db.kv_set("moji:owner", "1")
    await db.kv_set("moji:packs", json.dumps([[p0, "Соня · эмоции"], [p1, "Соня · эмодзи 1"]], ensure_ascii=False))

    def mk(name):
        return StickerSet(name=name, title="t", sticker_type="custom_emoji", stickers=[
            Sticker(file_id=f"f_{cid}", file_unique_id=cid, type="custom_emoji", width=100, height=100,
                    is_animated=False, is_video=True, custom_emoji_id=cid) for _, cid in packs[name]])

    async def getset(name):
        if name not in packs:
            from aiogram.exceptions import TelegramBadRequest
            raise TelegramBadRequest(method=None, message="STICKERSET_INVALID")
        return mk(name)

    async def replace(user_id, name, old_sticker, sticker):
        calls["replace"] += 1
        i = [f"f_{c}" for _, c in packs[name]].index(old_sticker)
        packs[name][i] = (packs[name][i][0], nid())
        return True

    async def add(user_id, name, sticker):
        calls["add"] += 1
        packs[name].append(("?", nid()))
        return True

    async def create(user_id, name, title, stickers, sticker_type):
        calls["create"] += 1
        packs[name] = [("?", nid()) for _ in stickers]
        return True

    async def title(**kw): return True
    bot.get_sticker_set, bot.replace_sticker_in_set, bot.add_sticker_to_set = getset, replace, add
    bot.create_new_sticker_set, bot.set_sticker_set_title = create, title
    SENT.clear()
    await dp.feed_update(bot, cbq("em:home", 1, 1))
    check("админка: «✨ Обновить анимацию», пока паки старые", "Обновить анимацию" in str(SENT))
    await admin._make_pack(bot, 1, 1)
    o1 = json.loads(await db.kv_get(f"moji:order:{p1}"))
    mp = json.loads(await db.kv_get("moji:map"))
    check("старые 4 эмодзи заменены на месте (replace), лицо Сони не трогаю",
          calls["replace"] == 4 and o1[:4] == old1 and packs[p0][0][1] == "id5")
    placed = 0
    for n in packs:
        if n != p0:
            placed += len(json.loads(await db.kv_get(f"moji:order:{n}") or "[]"))
    check("раскладка стабильная: старые остались в паке 1, новые долиты", len(o1) == 200 and o1[:4] == old1
          and placed == len(inv))
    hand = json.loads(await db.kv_get("moji:ids"))
    check("🎲 в тексте — живой от Google, а не фирменный значок; 😂 — лицо Сони",
          mp["🎲"] != hand["dice"] and mp["😂"] == hand["laugh"] and mp["🖤"] == dict(packs[p1])["🖤"])
    c0 = dict(calls)
    await admin._make_pack(bot, 1, 1)
    check("повторно — ничего не перезаливаю", calls == c0)

    # ---------- лимит премиум-эмодзи в сообщении ----------
    moji.set_map({"🎮": "1"})
    check("до 90 премиум-эмодзи в сообщении (было 40 — хвост оставался обычным)", moji.html_text("🎮" * 120)[1] == 90)

    # ---------- помощники по названиям ----------
    import fleet
    dbp = config.BASE / "data" / "gw_t75.db"
    c = sqlite3.connect(dbp)
    c.execute("CREATE TABLE users(id INTEGER, joined INTEGER, last_seen INTEGER, dls INTEGER)")
    c.execute("INSERT INTO users VALUES(1, 0, 0, 0)")
    c.commit()
    c.close()
    fleet.helpers = lambda: [{"profile": "gw", "name": "🎁 розыгрыши", "token": "77:x", "db": str(dbp)}]
    await db.kv_set("botname:77", "SonyaGiveBot")
    try:
        v = await admin.helpers_view()
    finally:
        dbp.unlink(missing_ok=True)
    check("помощники — по названию и @нику, не по файлу; у розыгрышей нет «скачиваний»",
          "🎁 розыгрыши</b> · @SonyaGiveBot" in v and "gw_t75.db" not in v and "скачиваний" not in v.split("SonyaGiveBot")[1][:300])

    SM.noto_webp = real_webp
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
