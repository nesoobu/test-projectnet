"""Волна 76: /stats — картинкой-дашбордом; картинка на любом экране с шапкой, даже без кнопок.
python test_w76.py ../sonya"""
import asyncio, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
config.BANNERS = True
from aiogram.methods import SendMessage, SendPhoto

G = -100777


async def main():
    M, bot, dp = await setup()
    import uikit, gameart
    bot.session.middleware(uikit.UiMiddleware())
    for u, n in ((501, "Тими Батерман"), (502, "暗い夜"), (503, "Kostfire")):
        await dp.feed_update(bot, msg("/start", u, u, name=n))
    day = db._day()
    for u, n in ((501, 38), (502, 23), (503, 10)):
        await db.q_run("INSERT OR REPLACE INTO chat_daily VALUES(?,?,?,?)", G, u, day, n)
    for h, n in ((12, 9), (14, 12), (23, 3)):
        await db.q_run("INSERT OR REPLACE INTO chat_hours VALUES(?,?,?)", G, h, n)
    now = int(time.time())
    for t in ["смотри https://site.ru/a", "https://x.com", "https://y.com лол", "погнали играть", "погнали в кино",
              "погнали спать"]:
        await db.q_run("INSERT INTO chat_log(chat_id, name, text, ts) VALUES(?,?,?,?)", G, "x", t, now)
    SENT.clear()
    await dp.feed_update(bot, msg("/stats", G, 501))
    ph = H.sent(SendPhoto)
    check("/stats в группе — картинка-дашборд, цифры подписью", ph and "болтуны недели" in (ph[-1].caption or "")
          and not H.sent(SendMessage))
    check("слово недели — не «https» (ссылки не считаю)", "https" not in (ph[-1].caption or "") and "погнали" in ph[-1].caption)
    jpg = gameart.chat_stats("Ptz", 5, 96, 5, [("Тими", 38), ("暗い夜", 23)], [0] * 12 + [9] + [0] * 11, "погнали", 3)
    check("дашборд рисуется, иероглифы в имени не ломают (→ «участник»)", jpg[:2] == b"\xff\xd8"
          and gameart._name_ok("暗い夜") == "участник" and gameart._name_ok("Тими 🔥") == "Тими")

    SENT.clear()
    await bot.send_message(70, "📊 <b>Сводка</b>\nчто-то полезное")
    check("экран с шапкой БЕЗ кнопок — тоже с картинкой", H.sent(SendPhoto) and not H.sent(SendMessage))
    SENT.clear()
    await bot.send_message(70, "ок, запомнила")
    check("обычная фраза — без картинки", H.sent(SendMessage) and not H.sent(SendPhoto))
    SENT.clear()
    await bot.send_message(70, "😊 <b>привет</b> как дела", parse_mode=None)
    check("ответ ИИ обычным текстом — без картинки", H.sent(SendMessage) and not H.sent(SendPhoto))
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
