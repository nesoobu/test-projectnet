"""Волна 69: автопостинг 2.0 — подписи без бессмыслицы (ИИ-редактор, картинку не видно → живая фраза),
хэштеги по делу, автопауза источника после 5 сбоев с понятной причиной, 🩺 проверка канала, 🔁 упавшие посты,
🗓 неделя картинкой, строки каналов с «следующим постом».
python test_w69.py ../sonya full"""
import asyncio, json, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.methods import SendMessage, SendPhoto, EditMessageText, AnswerCallbackQuery

CID = -100777


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import captions, rules as R, store
    rule = {"id": 0, "type": "pinterest", "source": "q:осень", "title": "осень"}
    cfg = {"caption": "vibe"}

    # ---------- подписи ----------
    calls = []

    async def ask(msgs, **kw):
        sys_ = msgs[0]["content"]
        calls.append(sys_[:20])
        if sys_.startswith("Ты строгий редактор"):
            return "НЕТ" if "влажный" in msgs[1]["content"] or "бит" in msgs[1]["content"] else "ДА"
        return "влажный свет зайдёт под любой миксованный бит."

    async def vision(system, text, url, **kw):
        return "влажный свет зайдёт под любой миксованный бит." if "Прошлый" not in system else "залип на этот неон"
    llm.ask, llm.ask_vision = ask, vision
    cap = await captions.live_caption(rule, cfg, {"image": "https://i.pinimg.com/a.jpg"}, [])
    check("бессмыслицу ИИ-редактор бракует, вторая попытка — нормальная", cap == "залип на этот неон")

    async def vision_bad(*a, **k):
        raise Exception("vision model gone")
    llm.ask_vision = vision_bad
    calls.clear()
    cap = await captions.live_caption(rule, cfg, {"image": "https://i.pinimg.com/a.jpg"}, [])
    check("картинку не видно — не сочиняю «по контексту», беру живую фразу", cap in captions.FALLBACK_CAPS["vibe"]
          and not any(c.startswith("Ты ведёшь") for c in calls))

    async def ask_always_bad(msgs, **kw):
        if msgs[0]["content"].startswith("Ты строгий редактор"):
            return "НЕТ"
        return "эхо отражений души шепчет"
    llm.ask = ask_always_bad
    cap = await captions.live_caption(rule, cfg, {}, [])
    check("две попытки мимо — запасная живая фраза, а не ерунда в канал", cap in captions.FALLBACK_CAPS["vibe"])
    recent = captions.FALLBACK_CAPS["vibe"][:-1]
    check("запасные фразы не повторяются подряд", captions.fallback_caption("vibe", [c[:60] for c in recent])
          == captions.FALLBACK_CAPS["vibe"][-1])
    check("правило хэштегов: в основном русские, 3–4, без #music к картинке",
          "НА РУССКОМ" in captions.POPULAR_HINT and "3–4" in captions.POPULAR_HINT)

    # ---------- автопауза ----------
    await db.q_run("INSERT INTO ap_channels(chat_id, owner_id, title, added) VALUES(?, 1, 'H9 музыка', 0)", CID)
    rid = await db.q_run("INSERT INTO ap_rules(owner_id, chat_id, type, source, title, created, active, next_run) "
                         "VALUES(1, ?, 'rss', 'https://x.ru/rss', 'новости', 0, 1, 0)", CID)

    async def boom(rule_, cfg_, want):
        raise Exception("сайт ответил 403")
    R.candidates = boom
    SENT.clear()
    for i in range(R.FAIL_PAUSE):
        r = await store.rule(rid)
        res = await R.run_rule(bot, r)
    r = await store.rule(rid)
    msgs = [m for m in H.sent(SendMessage) if m.chat_id == 1]
    check("ошибка — человеческими словами", "не пускает сервер (403)" in res)
    check("5 сбоев подряд — источник на паузе, владельцу сообщение с «▶️ Включить» и «🩺 Проверка»",
          r["active"] == 0 and msgs and "источник на паузе" in msgs[-1].text and f"ap:ra:{rid}" in str(msgs[-1].reply_markup)
          and f"ap:hc:{CID}" in str(msgs[-1].reply_markup))
    await store.set_rule(rid, active=1)
    await store.set_cfg(rid, fails=3)

    async def empty(rule_, cfg_, want):
        return []
    R.candidates = empty
    await R.run_rule(bot, await store.rule(rid))
    check("удачный запуск обнуляет счётчик сбоев", store.cfg_of(await store.rule(rid)).get("fails") == 0)
    check("подсказки к частым ошибкам", "права" in R.human_error("Bad Request: chat not found")
          and "429" in R.human_error("HTTP 429 Too Many Requests") and "RSS" in R.human_error("это не RSS-лента"))

    # ---------- 🩺 проверка и упавшие посты ----------
    await store.set_rule(rid, last_error="сайт ответил 403")
    pid = await db.q_run("INSERT INTO ap_posts(owner_id, text, created) VALUES(1, 'пост', 0)")
    sid = await db.q_run("INSERT INTO ap_schedule(post_id, chat_id, at, status, err) VALUES(?, ?, ?, 'failed', 'net')",
                         pid, CID, int(time.time()) - 600)
    H.ADMINS.add(999)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:hc:{CID}", 1, 1))
    t = "\n".join(H.texts())
    check("🩺: права бота, источник с ошибкой по-человечески, упавшие посты", "могу публиковать" in t
          and "не пускает сервер" in t and "не вышло постов за 3 дня: <b>1</b>" in t and f"ap:hcfix:{CID}" in str(
              [getattr(m, "reply_markup", "") for m in SENT]))
    await dp.feed_update(bot, cbq(f"ap:hcfix:{CID}", 1, 1))
    s = await store.sched(sid)
    check("«🔁 Повторить упавшие» — пост снова в очереди", s["status"] == "queued" and s["at"] > time.time())
    H.ADMINS.discard(999)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:hc:{CID}", 1, 1))
    check("🩺: нет прав — так и пишу", "нет права публиковать" in "\n".join(H.texts()))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:hc:{CID}", 5, 5))
    check("чужой канал — не показываю", not any("Проверка канала" in x for x in H.texts()))

    # ---------- 🗓 неделя и главная ----------
    import uikit
    bot.session.middleware(uikit.UiMiddleware())
    config.BANNERS = True
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:wk:{CID}", 1, 1, 100))
    check("🗓 неделя — картинкой", (H.sent(SendPhoto) or [None])[-1] is not None or any(
        getattr(m, "media", None) for m in SENT))
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:home", 1, 1, 300))
    kb = str([getattr(m, "reply_markup", "") for m in SENT])
    check("главная: в строке канала ⏭ следующий пост и ⚠️ если беда", "⏭" in kb and "⚠️ H9 музыка" in kb)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:ch:{CID}", 1, 1, 301))
    t = "\n".join(H.texts())
    kb = str([getattr(m, "reply_markup", "") for m in SENT])
    check("карточка канала: предупреждение и кнопки 🩺 / 🗓", "Проверка» покажет" in t and "ap:hc:" in kb and "ap:wk:" in kb)

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
