"""Волна 74: картинка на КАЖДОМ экране с кнопками (фон раздела + заголовок экрана), длинные — страницами,
в каналах и постах — без обложек. python test_w74.py ../sonya"""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
config.BANNERS = True
from aiogram.methods import SendMessage, SendPhoto, EditMessageCaption, GetChat
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton as Bt


async def main():
    M, bot, dp = await setup()
    import uikit, banners, ui
    bot.session.middleware(uikit.UiMiddleware())

    check("шапка → раздел и заголовок", banners.auto_for_text("🧠 <b>что я о тебе помню</b>\n<i>пока ничего</i>")
          == ("home", "Что я о тебе помню", "пока ничего"))
    check("по смыслу: розыгрыши / подарки / игры / помощь",
          banners.auto_for_text("🎲 <b>Розыгрыш кубиком</b>")[0] == "giveaway"
          and banners.auto_for_text("⭐ <b>Звёзды на подарки</b>")[0] == "gifts"
          and banners.auto_for_text("💞 <b>Пара дня</b>")[0] == "games"
          and banners.auto_for_text("🛡 <b>Помощник для групп</b>")[0] == "help")
    check("без шапки — по смыслу строки (ход в игре → игры)", banners.plain_topic("ты ✊ — я ✋") == "games"
          and banners.plain_topic("🎂 когда у тебя день рождения?") == "home")
    jpg = banners.render("help", "Соня-ассистент для личных чатов", "автоответ")
    check("рисуется (длинный заголовок — в две строки)", jpg[:2] == b"\xff\xd8" and len(jpg) > 20000)

    kb = InlineKeyboardMarkup(inline_keyboard=[[Bt(text="‹ Назад", callback_data="m:home")]])
    SENT.clear()
    await bot.send_message(70, "🧠 <b>что я о тебе помню</b>\n<i>пока ничего</i>", reply_markup=kb)
    check("экран с кнопками → с картинкой", H.sent(SendPhoto) and not H.sent(SendMessage))
    SENT.clear()
    await bot.send_message(70, "просто ответ без кнопок")
    check("обычный ответ без кнопок — без картинки", H.sent(SendMessage) and not H.sent(SendPhoto))

    # длинный экран → страницы
    long = ui.head("❔", "Что я умею", "") + "\n" + "\n".join(f"строка номер {i} — " + "текст " * 8 for i in range(60))
    SENT.clear()
    await bot.send_message(70, long, reply_markup=kb)
    ph = H.sent(SendPhoto)
    nav = ph and ph[-1].reply_markup.inline_keyboard[0]
    check("длинный экран: картинка + «‹ 1/N ›», подпись ≤1024",
          ph and len(uikit.plain(ph[-1].caption)) <= 1024 and nav[1].text.startswith("1/")
          and ph[-1].reply_markup.inline_keyboard[-1][0].callback_data == "m:home")
    tok = nav[2].callback_data.split(":")[1]
    n = len(uikit.PAGES[tok]["pages"])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"uipg:{tok}:1", 70, 70))
    ed = H.sent(EditMessageCaption)
    check("листаю ›: вторая страница с той же шапкой", ed and ed[-1].caption.startswith("❔ <b>Что я умею</b>")
          and f"2/{n}" in str(ed[-1].reply_markup) and "строка номер" in ed[-1].caption)
    pages = uikit.paginate("❔ <b>X</b>\n<blockquote>" + "\n".join("a" * 50 for _ in range(30)) + "</blockquote>", True)
    check("цитату не режу посередине (разметка не ломается)", pages is None or all(p.count("<blockquote>") == p.count("</blockquote>") for p in pages))
    uikit.PAGES.clear()
    SENT.clear()
    await dp.feed_update(bot, cbq(f"uipg:{tok}:1", 70, 70))
    check("после перезапуска — «открой заново»", any("заново" in (getattr(x, "text", "") or "") for x in SENT))

    # каналы и посты
    real = H.Mock._make

    async def chan(self, b, method):
        if isinstance(method, GetChat) and method.chat_id == -1009:
            from aiogram.types import ChatFullInfo
            return ChatFullInfo(id=-1009, type="channel", accent_color_id=0, max_reaction_count=11,
                                accepted_gift_types={"unlimited_gifts": False, "limited_gifts": False,
                                                     "unique_gifts": False, "premium_subscription": False})
        return await real(self, b, method)
    H.Mock._make = chan
    SENT.clear()
    await bot.send_message(-1009, "🎁 <b>Розыгрыш</b>", reply_markup=kb)
    check("в канале — без обложки", H.sent(SendMessage) and not H.sent(SendPhoto))
    SENT.clear()
    await bot.send_message(-100500, "🎮 <b>Игры для чата</b>", reply_markup=kb)
    check("в группе — с обложкой", H.sent(SendPhoto))
    H.Mock._make = real
    tok2 = uikit.POSTING.set(True)
    SENT.clear()
    await bot.send_message(70, "📢 <b>Пост</b>", reply_markup=kb)
    uikit.POSTING.reset(tok2)
    check("пост автопостинга (и превью) — как есть, без обложки", H.sent(SendMessage) and not H.sent(SendPhoto))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
