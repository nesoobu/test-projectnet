"""Волна 66: картинки в играх — виселица, блэкджек, колесо, гороскоп, топ. Ход игры меняет ту же картинку.
python test_w66.py ../sonya full   (и games)"""
import asyncio, io, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendPhoto, EditMessageMedia, SendMessage, EditMessageText
from PIL import Image


def mid_of(method):
    return SENT.index(method) + 1 + 100   # так мок выдаёт message_id


def is_jpeg(media) -> bool:
    data = getattr(media, "data", None)
    return bool(data) and Image.open(io.BytesIO(data)).size[0] == 1280


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    import uikit, gameart
    from handlers import games, luck
    bot.session.middleware(uikit.UiMiddleware())
    config.BANNERS = True
    uid = 80
    await dp.feed_update(bot, msg("/start", uid, uid))
    await db.add_coins(uid, 5000)

    # ---------- виселица ----------
    games.WORDS[:] = ["метро"]
    SENT.clear()
    await dp.feed_update(bot, msg("/hangman", uid, uid))
    ph = H.sent(SendPhoto)
    check(f"[{P}] виселица — картинкой, буквы кнопками", ph and is_jpeg(ph[-1].photo) and "hg:" in str(ph[-1].reply_markup))
    mid = mid_of(ph[-1])
    gid = next(iter(games._hang))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"hg:{gid}:я", uid, uid, mid))
    em = H.sent(EditMessageMedia)
    check(f"[{P}] ход — та же картинка обновилась (без нового сообщения)", em and is_jpeg(em[-1].media.media)
          and not [p for p in H.sent(SendPhoto) if "достижение" not in (p.caption or "")])   # ачивка — отдельное окно
    for ch in "метро":
        await dp.feed_update(bot, cbq(f"hg:{gid}:{ch}", uid, uid, mid))
    check(f"[{P}] победа — картинка «Угадали» и кнопка «Ещё слово»", H.sent(EditMessageMedia)
          and "g:hang" in str(H.sent(EditMessageMedia)[-1].reply_markup))

    # ---------- блэкджек ----------
    SENT.clear()
    await dp.feed_update(bot, cbq("bj:new:50", uid, uid, 1))
    ph = H.sent(SendPhoto)
    check(f"[{P}] блэкджек — стол с картами", (ph and is_jpeg(ph[-1].photo)) or "блэкджек" in str(H.texts()).lower())
    if luck._bj:
        bid = next(iter(luck._bj))
        bmid = mid_of(ph[-1]) if ph else 1
        SENT.clear()
        await dp.feed_update(bot, cbq(f"bj:s:{bid}", uid, uid, bmid))
        check(f"[{P}] «хватит» — та же картинка, с итогом", H.sent(EditMessageMedia) and "Ещё раз" in str(
            H.sent(EditMessageMedia)[-1].reply_markup))

    # ---------- колесо ----------
    luck.SPIN = ["🎡"]
    SENT.clear()
    await dp.feed_update(bot, msg("/wheel", uid, uid))
    check(f"[{P}] колесо — картинка со стрелкой на выпавшем", H.sent(SendPhoto) and "выпало" in "\n".join(H.texts()))
    labels = [luck.wheel_label(w) for w in luck.WHEEL]
    check(f"[{P}] подписи секторов — без эмодзи", all(not any(ord(c) > 0x2000 for c in l) for l in labels)
          and "ДЖЕКПОТ 777" in labels)

    # ---------- гороскоп и топ ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/horo овен", uid, uid))
    check(f"[{P}] гороскоп — карточка знака", H.sent(SendPhoto) and "Гороскоп" in (H.sent(SendPhoto)[-1].caption or ""))
    if P == "full":
        SENT.clear()
        await dp.feed_update(bot, msg("/top", uid, uid))
        check(f"[{P}] топ — пьедестал", H.sent(SendPhoto) and "Топ" in (H.sent(SendPhoto)[-1].caption or ""))

    # ---------- выключено ----------
    config.BANNERS = False
    SENT.clear()
    await dp.feed_update(bot, msg("/hangman", uid, uid))
    check(f"[{P}] BANNERS=0 — игра текстом, как раньше", not H.sent(SendPhoto) and H.sent(SendMessage))
    config.BANNERS = True

    # ---------- картинки сами по себе ----------
    ok = all(Image.open(io.BytesIO(b)).size == (1280, 720) for b in (
        gameart.hangman("кот", {"к"}, {"а", "б"}), gameart.hangman("кот", set(), set("абвгде"), "lost"),
        gameart.blackjack(["10♠️", "🂠"], ["A♥️", "K♦️", "2♣️"], "", "?", 13, 10),
        gameart.wheel(labels, 3), gameart.horoscope("лев", "1 мая"), gameart.top("Топ", [("а", 1)])))
    check(f"[{P}] все рисунки 1280×720, без падений на краях (1 игрок в топе, 6 ошибок)", ok)

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
