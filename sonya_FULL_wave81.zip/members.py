"""Волна 63: кто давно в чате/канале, кто активен, кто писал под постом — для фильтров розыгрышей и /roll.
Telegram не отдаёт ботам дату вступления, поэтому считаем сами:
• вступил при боте (событие chat_member или сервисное «X вошёл») — знаем точную дату (known=1);
• не видели, как вступал, — значит был в чате ещё до того, как бот начал следить (msince) → старожил.
Сообщения в группе: счётчик msgs, последнее last_ts, ветка/ответ → thread_users (участники обсуждения)."""
import time

import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS member_seen(chat_id INTEGER, uid INTEGER, first_ts INTEGER, last_ts INTEGER DEFAULT 0,
    msgs INTEGER DEFAULT 0, known INTEGER DEFAULT 0, PRIMARY KEY(chat_id, uid));
CREATE TABLE IF NOT EXISTS thread_users(chat_id INTEGER, thread_id INTEGER, uid INTEGER, ts INTEGER,
    PRIMARY KEY(chat_id, thread_id, uid));
CREATE INDEX IF NOT EXISTS thread_users_ts ON thread_users(chat_id, thread_id, ts);
CREATE INDEX IF NOT EXISTS member_seen_last ON member_seen(chat_id, last_ts);
"""


async def init():
    c = await db.db()
    await c.executescript(SCHEMA)
    await c.commit()


_since_cache: dict[int, int] = {}


async def _since(chat_id: int, now: int) -> int:
    """С какого момента бот следит за этим чатом (первое событие). Кэш — чтобы не читать kv на каждое сообщение."""
    if chat_id in _since_cache:
        return _since_cache[chat_id]
    k = f"msince:{chat_id}"
    v = await db.kv_get(k)
    if not v:
        await db.q_change("INSERT OR IGNORE INTO kv(k, v) VALUES(?, ?)", k, str(now))
        v = await db.kv_get(k) or str(now)
    _since_cache[chat_id] = int(v)
    return int(v)


async def joined(chat_id: int, uid: int, ts: int | None = None):
    """Вступил при нас — стаж считаем с этого момента (перевступил — заново)."""
    now = ts or int(time.time())
    await _since(chat_id, now)
    await db.q_run("INSERT INTO member_seen(chat_id, uid, first_ts, last_ts, msgs, known) VALUES(?,?,?,0,0,1) "
                   "ON CONFLICT(chat_id, uid) DO UPDATE SET first_ts=excluded.first_ts, known=1, msgs=0",
                   chat_id, uid, now)


async def left(chat_id: int, uid: int):
    await db.q_run("DELETE FROM member_seen WHERE chat_id=? AND uid=?", chat_id, uid)


async def wrote(chat_id: int, uid: int, thread: int = 0):
    """Сообщение в группе. Не видели вступления — значит был тут ещё до начала слежки (known=0)."""
    now = int(time.time())
    since = await _since(chat_id, now)
    c = await db.db()
    await c.execute("INSERT INTO member_seen(chat_id, uid, first_ts, last_ts, msgs, known) VALUES(?,?,?,?,1,0) "
                    "ON CONFLICT(chat_id, uid) DO UPDATE SET last_ts=excluded.last_ts, msgs=msgs+1",
                    (chat_id, uid, since, now))
    if thread:
        await c.execute("INSERT OR IGNORE INTO thread_users VALUES(?,?,?,?)", (chat_id, thread, uid, now))
    await c.commit()


async def days_in(chat_id: int, uid: int) -> float | None:
    """Сколько дней в чате/канале. None — вступил до того, как бот начал следить (то есть старожил)."""
    r = await db.q_one("SELECT first_ts, known FROM member_seen WHERE chat_id=? AND uid=?", chat_id, uid)
    if not r or not r["known"]:
        return None
    return (time.time() - r["first_ts"]) / 86400


async def old_enough(chat_id: int, uid: int, days: int) -> bool:
    d = await days_in(chat_id, uid)
    return d is None or d >= days


async def msgs(chat_id: int, uid: int) -> int:
    r = await db.q_one("SELECT msgs FROM member_seen WHERE chat_id=? AND uid=?", chat_id, uid)
    return (r or {}).get("msgs") or 0


async def thread_people(chat_id: int, thread: int) -> list[int]:
    """Кто писал в ветке (комментарии к посту или ответы на сообщение), по порядку первого сообщения."""
    rows = await db.q_all("SELECT uid FROM thread_users WHERE chat_id=? AND thread_id=? ORDER BY ts, uid", chat_id, thread)
    return [r["uid"] for r in rows]


async def active_people(chat_id: int, hours: int) -> list[int]:
    rows = await db.q_all("SELECT uid FROM member_seen WHERE chat_id=? AND last_ts>=? ORDER BY last_ts, uid",
                          chat_id, int(time.time()) - hours * 3600)
    return [r["uid"] for r in rows]


async def cleanup():
    await db.q_run("DELETE FROM thread_users WHERE ts<?", int(time.time()) - 90 * 86400)
