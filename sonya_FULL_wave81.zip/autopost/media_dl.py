"""Скачивание медиа: yt-dlp (видео/аудио с YouTube, SoundCloud, RuTube, VK…) и Яндекс Музыка."""
import asyncio
import logging
import os
import random
import re
import shutil
import time
import uuid
from pathlib import Path

import config
import netguard

log = logging.getLogger("media_dl")
DL = config.BASE / "data" / "dl"
# лимит Bot API на отправку файла — 50 МБ; со своим сервером Bot API (BOT_API_URL) — 2 ГБ
MAX_BYTES = config.TG_SEND_MAX
LIM = config.mb(MAX_BYTES)


class DLError(Exception):
    pass


def _dir() -> Path:
    DL.mkdir(parents=True, exist_ok=True)
    return DL


def cleanup(hours: int = 72):
    if not DL.exists():
        return
    edge = time.time() - hours * 3600
    for f in DL.iterdir():
        try:
            if f.stat().st_mtime < edge:
                f.unlink()
        except OSError:
            pass


# ================= yt-dlp =================
def normalize_url(raw: str, kind: str) -> str:
    raw = raw.strip()
    if raw.startswith("@"):
        raw = f"https://www.youtube.com/{raw}"
    if not re.match(r"^https?://", raw):
        raw = "https://" + raw
    # канал ютуба без вкладки → видео (или шортсы, если просили)
    m = re.match(r"^(https?://(?:www\.|m\.)?youtube\.com/(?:@[\w.-]+|channel/[\w-]+|c/[\w.-]+))/?$", raw)
    if m:
        raw = m.group(1) + "/videos"
    m = re.match(r"^(https?://(?:www\.)?soundcloud\.com/[\w-]+)/?$", raw)
    if m and kind == "audio":
        raw = m.group(1) + "/tracks"
    return raw


def _ydl(opts: dict):
    import yt_dlp
    base = {"quiet": True, "no_warnings": True, "noplaylist": False, "socket_timeout": 30,
            "retries": 2, "ignoreerrors": False}
    base.update(opts)
    return yt_dlp.YoutubeDL(base)


def _list_sync(url: str, limit: int) -> list[dict]:
    with _ydl({"extract_flat": "in_playlist", "playlistend": limit}) as y:
        info = y.extract_info(url, download=False)
    if not info:
        raise DLError("пусто")
    entries = info.get("entries") or [info]
    out = []
    for e in entries:
        if not e:
            continue
        link = e.get("url") or e.get("webpage_url") or ""
        if link and not link.startswith("http"):
            link = f"https://www.youtube.com/watch?v={e.get('id')}"
        out.append({
            "key": str(e.get("id") or link),
            "title": e.get("title") or "",
            "text": "",
            "link": link,
            "image": None,
            "artist": e.get("uploader") or e.get("channel") or info.get("uploader") or "",
            "duration": e.get("duration"),
        })
    return out[:limit]


async def _guard(url: str):
    """Волна 61: ссылка из автоисточника во внутреннюю сеть сервера — не открываем."""
    try:
        await netguard.check_ytdlp(url)
    except netguard.Blocked as e:
        raise DLError(str(e))


async def ytdlp_list(url: str, limit: int = 15) -> list[dict]:
    await _guard(url)
    try:
        return await asyncio.to_thread(_list_sync, url, limit)
    except DLError:
        raise
    except Exception as e:
        msg = str(e).split("\n")[0]
        raise DLError(re.sub(r"^ERROR:\s*", "", msg)[:200])


def _has_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg"))


def _dl_sync(url: str, kind: str) -> dict:
    stem = str(_dir() / uuid.uuid4().hex)
    ff = _has_ffmpeg()
    if kind == "audio":
        opts = {"format": "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio/best",
                "outtmpl": stem + ".%(ext)s", "noplaylist": True, "max_filesize": MAX_BYTES}
        if ff:
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3",
                                       "preferredquality": "192"}]
    else:
        # беззвучные видео (Pinterest, гифки) — только видеодорожка, поэтому bv* без ba в запасе
        fmt = ("bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720][ext=mp4]/"
               "b[height<=720]/bv*[height<=720][ext=mp4]/bv*[height<=720]/b*"
               if ff else "b[height<=720][ext=mp4]/b[ext=mp4]/b*[ext=mp4]/b*")
        opts = {"format": fmt, "outtmpl": stem + ".%(ext)s", "noplaylist": True,
                "merge_output_format": "mp4", "max_filesize": MAX_BYTES}
    with _ydl(opts) as y:
        info = y.extract_info(url, download=True)
    files = sorted(Path(stem).parent.glob(Path(stem).name + ".*"))
    files = [f for f in files if f.suffix not in (".part", ".ytdl")]
    if not files:
        raise DLError(f"файл не скачался (возможно, больше {LIM})")
    path = files[-1]
    if path.stat().st_size > MAX_BYTES:
        path.unlink(missing_ok=True)
        raise DLError(f"файл больше {LIM} — телеграм не примет")
    return {
        "path": str(path),
        "title": info.get("track") or info.get("title") or "",
        "performer": info.get("artist") or info.get("uploader") or "",
        "duration": int(info.get("duration") or 0),
        "width": info.get("width"),
        "height": info.get("height"),
        "genre": info.get("genre") or "",
    }


async def ytdlp_download(url: str, kind: str) -> dict:
    await _guard(url)
    try:
        return await asyncio.to_thread(_dl_sync, url, kind)
    except DLError:
        raise
    except Exception as e:
        msg = str(e).split("\n")[0]
        raise DLError(re.sub(r"^ERROR:\s*", "", msg)[:200])


# ================= Яндекс Музыка =================
def ym_parse(raw: str) -> str:
    """ссылка/слово → source: likes | playlist:USER:KIND | album:ID | artist:ID | chart"""
    raw = raw.strip()
    low = raw.lower()
    if low in ("likes", "лайки", "мои лайки", "мне нравится"):
        return "likes"
    if low in ("chart", "чарт"):
        return "chart"
    m = re.search(r"/users/([^/]+)/playlists/(\d+)", raw)
    if m:
        return f"playlist:{m.group(1)}:{m.group(2)}"
    m = re.search(r"/album/(\d+)(?:/track/\d+)?", raw)
    if m:
        return f"album:{m.group(1)}"
    m = re.search(r"/artist/(\d+)", raw)
    if m:
        return f"artist:{m.group(1)}"
    raise DLError("не поняла. пришли «лайки», «чарт» или ссылку на плейлист/альбом/артиста")


def ym_title(src: str) -> str:
    kind = src.split(":")[0]
    return {"likes": "мои лайки", "chart": "чарт", "playlist": "плейлист",
            "album": "альбом", "artist": "артист"}[kind] + (f" {src.split(':')[-1]}" if ":" in src else "")


async def _ym_client(token: str):
    from yandex_music import ClientAsync
    if not token:
        raise DLError("нужен токен Яндекс Музыки (y0_…)")
    try:
        return await ClientAsync(token).init()
    except Exception as e:
        raise DLError(f"токен не подошёл: {str(e)[:100]}")


async def ym_ids(src: str, token: str) -> list[str]:
    """Список id треков источника (дёшево, без метаданных)."""
    c = await _ym_client(token)
    kind = src.split(":")[0]
    try:
        if kind == "likes":
            tl = await c.users_likes_tracks()
            return [str(t.track_id) for t in (tl.tracks if tl else [])]
        if kind == "search":   # волна 80: поиск треков по теме (автопилот)
            r = await c.search(src.split(":", 1)[1], type_="track")
            res = (r.tracks.results if r and r.tracks else []) or []
            return [f"{t.id}:{t.albums[0].id}" if t.albums else str(t.id) for t in res]
        if kind == "chart":
            ch = await c.chart("russia")
            return [str(t.track_id) for t in ch.chart.tracks] if ch and ch.chart else []
        if kind == "playlist":
            _, user, pk = src.split(":")
            pl = await c.users_playlists(int(pk), user)
            shorts = await pl.fetch_tracks_async()
            return [str(t.track_id) for t in shorts]
        if kind == "album":
            al = await c.albums_with_tracks(int(src.split(":")[1]))
            return [f"{t.id}:{al.id}" for vol in (al.volumes or []) for t in vol]
        if kind == "artist":
            out = []
            for page in range(5):
                ids = await c.artists_track_ids(int(src.split(":")[1]), page=page, page_size=100)
                if not ids:
                    break
                out += [str(i) for i in ids]
            return out
    except DLError:
        raise
    except Exception as e:
        raise DLError(f"яндекс: {str(e)[:150]}")
    raise DLError("неизвестный источник")


async def ym_meta(track_ids: list[str], token: str) -> list[dict]:
    c = await _ym_client(token)
    tracks = await c.tracks(track_ids)
    out = []
    for t in tracks:
        if not t or t.available is False:
            continue
        album = t.albums[0] if t.albums else None
        out.append({
            "key": str(t.track_id),
            "title": t.title or "",
            "text": "",
            "artist": ", ".join(t.artists_name()) if t.artists else "",
            "album": album.title if album else "",
            "genre": (album.genre or "") if album else "",
            "link": f"https://music.yandex.ru/album/{album.id}/track/{t.id}" if album else "",
            "image": None,
            "duration": int((t.duration_ms or 0) / 1000),
        })
    return out


async def ym_download(track_id: str, token: str) -> dict:
    c = await _ym_client(token)
    tracks = await c.tracks([track_id])
    if not tracks:
        raise DLError("трек не найден")
    t = tracks[0]
    stem = str(_dir() / uuid.uuid4().hex)
    try:
        await t.download_async(stem + ".mp3", codec="mp3", bitrate_in_kbps=192)
    except Exception as e:
        raise DLError(f"не скачался: {str(e)[:120]}")
    thumb = None
    try:
        await t.download_cover_async(stem + ".jpg", size="200x200")
        thumb = stem + ".jpg"
    except Exception:
        pass
    return {"path": stem + ".mp3", "title": t.title or "",
            "performer": ", ".join(t.artists_name()) if t.artists else "",
            "duration": int((t.duration_ms or 0) / 1000), "thumb": thumb}


def pick(ids: list, order: str, n: int) -> list:
    if order == "random":
        ids = ids[:]
        random.shuffle(ids)
        return ids
    if order == "old":
        return list(reversed(ids))
    return ids


# ================= прямые ссылки =================
async def download_direct(url: str, suffix: str = ".mp4") -> str:
    """Качает файл по прямой ссылке с лимитом MAX_BYTES → локальный путь."""
    import aiohttp
    path = str(_dir() / (uuid.uuid4().hex + suffix))
    ua = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/124.0 Safari/537.36"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120), headers=ua) as s:
            async with netguard.get(s, url) as r:   # волна 61: каждый редирект проверяем
                if r.status != 200:
                    raise DLError(f"файл не отдаётся ({r.status})")
                size = int(r.headers.get("Content-Length") or 0)
                if size > MAX_BYTES:
                    raise DLError(f"файл больше {LIM}")
                got = 0
                with open(path, "wb") as f:
                    async for chunk in r.content.iter_chunked(1 << 16):
                        got += len(chunk)
                        if got > MAX_BYTES:
                            raise DLError(f"файл больше {LIM}")
                        f.write(chunk)
    except DLError:
        Path(path).unlink(missing_ok=True)
        raise
    except Exception as e:
        Path(path).unlink(missing_ok=True)
        raise DLError(f"не скачался: {str(e)[:120]}")
    return path


# ================= Pinterest напрямую =================
# Волна 73: как у gallery-dl и yt-dlp. Видео у Pinterest чаще ТОЛЬКО в HLS (.m3u8) — раньше на этом сдавались
# и слали обложку. Теперь: mp4 если есть → тот же ролик в 720p.mp4 (по адресу HLS) → HLS через ffmpeg → yt-dlp.
# Данные пина: API c field_set_key «detailed» (gallery-dl), потом «unauth_react_main_pin» (yt-dlp), потом HTML-страница.
_pin_cache: dict[str, tuple[float, dict]] = {}
PIN_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36"


def _pin_ok(pin) -> bool:
    return isinstance(pin, dict) and bool(pin.get("id")) and bool(pin.get("images") or pin.get("videos")
                                                                   or pin.get("story_pin_data") or pin.get("carousel_data"))


async def _pin_api(pid: str) -> dict:
    import json as _json
    import secrets
    import aiohttp
    csrf = secrets.token_hex(16)
    hdr = {"User-Agent": PIN_UA, "Accept": "application/json, text/javascript, */*, q=0.01",
           "X-Requested-With": "XMLHttpRequest", "X-APP-VERSION": "a89153f", "X-CSRFToken": csrf,
           "X-Pinterest-PWS-Handler": "www/[username].js", "Referer": "https://www.pinterest.com/"}
    last = ""
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30), headers=hdr,
                                     cookies={"csrftoken": csrf}) as s:
        for fsk in ("detailed", "unauth_react_main_pin"):
            q = _json.dumps({"options": {"field_set_key": fsk, "id": pid}})
            try:
                async with s.get("https://www.pinterest.com/resource/PinResource/get/",
                                 params={"source_url": f"/pin/{pid}/", "data": q}) as r:
                    if r.status != 200:
                        last = f"{fsk}: {r.status}"
                        continue
                    data = await r.json(content_type=None)
            except Exception as e:
                last = f"{fsk}: {str(e)[:80]}"
                continue
            pin = ((data or {}).get("resource_response") or {}).get("data") or {}
            if _pin_ok(pin):
                return pin
            last = f"{fsk}: пусто"
    raise DLError(f"pinterest api: {last}")


def _walk_pin(node, pid: str, found: list):
    if isinstance(node, dict):
        if str(node.get("id")) == pid and (node.get("images") or node.get("videos") or node.get("story_pin_data")):
            found.append(node)
        for v in node.values():
            _walk_pin(v, pid, found)
    elif isinstance(node, list):
        for v in node:
            _walk_pin(v, pid, found)


_VID_RX = re.compile(r'https://v\d*\.pinimg\.com/videos/[^"\'\s\\]+?\.(?:mp4|m3u8)')


async def _pin_html(pid: str) -> dict:
    """Запасной путь: страница пина. Внутри — JSON с данными (как в приложении) и schema.org VideoObject."""
    import json as _json
    import aiohttp
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30),
                                         headers={"User-Agent": PIN_UA, "Accept-Language": "ru,en;q=0.8"}) as s:
            async with s.get(f"https://www.pinterest.com/pin/{pid}/") as r:
                if r.status != 200:
                    raise DLError(f"pinterest page: {r.status}")
                page = await r.text()
    except DLError:
        raise
    except Exception as e:
        raise DLError(f"pinterest page: {str(e)[:80]}")
    return parse_pin_page(page, pid)


def parse_pin_page(page: str, pid: str) -> dict:
    import json as _json
    found: list = []
    for blob in re.findall(r'<script[^>]*type="application/(?:ld\+)?json"[^>]*>(.*?)</script>', page, re.S):
        try:
            _walk_pin(_json.loads(blob), pid, found)
        except ValueError:
            continue
    pin: dict = {}
    for f in found:   # склеиваем все куски про этот пин
        for k, v in f.items():
            if v and not pin.get(k):
                pin[k] = v
    if not (pin.get("videos") or {}).get("video_list"):
        urls = list(dict.fromkeys(u.replace("\\u002F", "/") for u in _VID_RX.findall(page.replace("\\/", "/"))))
        if urls:
            pin["videos"] = {"video_list": {f"V_PAGE{i}": {"url": u} for i, u in enumerate(urls)}}
    if not pin.get("images"):
        m = re.search(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', page)
        if m:
            pin["images"] = {"orig": {"url": m.group(1)}}
    pin.setdefault("id", pid)
    if not _pin_ok(pin):
        raise DLError("pinterest page: данных пина нет")
    return pin


async def pinterest_pin(pin_url: str) -> dict:
    """Данные пина (кэш 10 минут): API → страница пина. Не вышло — DLError (это НЕ значит «не видео»)."""
    import time as _time
    m = re.search(r"/pin/(\d+)", pin_url)
    if not m:
        raise DLError("не ссылка на пин")
    pid = m.group(1)
    hit = _pin_cache.get(pid)
    if hit and _time.time() - hit[0] < 600:
        return hit[1]
    try:
        pin = await _pin_api(pid)
    except DLError as e:
        log.info("%s — читаю страницу пина", e)
        pin = await _pin_html(pid)
    if len(_pin_cache) > 500:
        _pin_cache.clear()
    _pin_cache[pid] = (_time.time(), pin)
    return pin


def _best_img(images: dict) -> str | None:
    for k in ("736x", "orig", "originals", "474x"):
        u = (images or {}).get(k)
        if isinstance(u, dict) and u.get("url"):
            return u["url"]
    for k, u in (images or {}).items():   # другой размер (у слотов карусели бывает один, любой) → берём 736x
        if isinstance(u, dict) and u.get("url"):
            return re.sub(r"/\d+x\d*/", "/736x/", u["url"], count=1)
    return None


def _video_list(pin: dict) -> dict:
    vl = (pin.get("videos") or {}).get("video_list") or {}
    if vl:
        return vl
    for page in ((pin.get("story_pin_data") or {}).get("pages") or []):
        for block in page.get("blocks") or []:
            v = ((block or {}).get("video") or {}).get("video_list")
            if v:
                return v
    return {}


def pin_is_video(pin: dict) -> bool:
    return bool(_video_list(pin))


def best_pin_image(images: dict | None) -> str | None:
    return _best_img(images or {})


def _imgs_in(node, out: list):
    """Все картинки внутри узла: {"images": {"736x": {"url": …}}} и подпись картинки идея-пина (image_signature)."""
    if isinstance(node, dict):
        u = _best_img(node.get("images")) if isinstance(node.get("images"), dict) else None
        if not u and isinstance(node.get("image"), dict):
            u = _best_img(node["image"].get("images") or {})
        sig = node.get("image_signature")
        if not u and isinstance(sig, str) and re.fullmatch(r"[0-9a-f]{32}", sig) and "video" not in node:
            u = f"https://i.pinimg.com/originals/{sig[0:2]}/{sig[2:4]}/{sig[4:6]}/{sig}.jpg"   # как в gallery-dl
        if u:
            out.append(u)
            return
        for k, v in node.items():
            if k not in ("images", "image"):
                _imgs_in(v, out)
    elif isinstance(node, list):
        for v in node:
            _imgs_in(v, out)


def pinterest_images(pin: dict) -> list[str]:
    """Все картинки пина: карусель (carousel_data.carousel_slots) или страницы идея-пина. Одна — значит не альбом.
    Смотрим только узлы карусели и story_pin_data — аватарки автора и обложки досок не цепляем."""
    urls: list[str] = []
    for k, v in pin.items():
        if "carousel" in k.lower():
            _imgs_in(v, urls)
    if len(urls) < 2:
        urls = []
        for page in ((pin.get("story_pin_data") or {}).get("pages") or []):
            _imgs_in(page.get("blocks") or [], urls)
    seen, out = set(), []
    for u in urls:
        key = re.sub(r"/(?:\d+x\d*|orig|originals)/", "/", u).rsplit(".", 1)[0]   # один кадр в разных размерах
        if key not in seen:
            seen.add(key)
            out.append(u)
    return out[:10]


def hls_to_mp4_guess(url: str) -> list[str]:
    """…/videos/<x>/hls/aa/bb/cc/<hash>.m3u8 → тот же ролик готовым mp4 (720p, 540p) — частый случай у Pinterest."""
    m = re.match(r"(https://v\d*\.pinimg\.com/videos/[^/]+/)(?:hls|hls\w*)/(.+?)(?:_\w+)?\.m3u8", url)
    if not m:
        return []
    return [f"{m.group(1)}{q}/{m.group(2)}.mp4" for q in ("720p", "expMp4", "540p")]


async def _ffmpeg_hls(url: str) -> str:
    """HLS-поток → mp4 без перекодирования (так качают yt-dlp/gallery-dl). Лимит по размеру и времени."""
    if not re.match(r"https://v\d*\.pinimg\.com/", url):   # ffmpeg ходит сам — пускаю только на CDN Pinterest
        raise DLError("HLS не с pinimg")
    if not _has_ffmpeg():
        raise DLError("нет ffmpeg для HLS")
    path = str(_dir() / (uuid.uuid4().hex + ".mp4"))
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-y", "-loglevel", "error", "-user_agent", PIN_UA, "-protocol_whitelist", "https,tls,tcp,crypto,file",
        "-i", url, "-c", "copy", "-bsf:a", "aac_adtstoasc", "-fs", str(MAX_BYTES), "-movflags", "+faststart", path,
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    try:
        _, err = await asyncio.wait_for(proc.communicate(), 180)
    except asyncio.TimeoutError:
        proc.kill()
        Path(path).unlink(missing_ok=True)
        raise DLError("HLS: слишком долго")
    if proc.returncode != 0 or not Path(path).exists() or Path(path).stat().st_size < 1000:
        Path(path).unlink(missing_ok=True)
        raise DLError(f"HLS: {(err or b'').decode('utf-8', 'ignore')[-120:]}")
    return path


async def pinterest_video(pin_url: str) -> dict:
    """Видео пина: mp4 из списка → mp4 по адресу HLS → сам HLS через ffmpeg. «это не видео-пин» — только если
    данные пина ЕСТЬ и видео в них нет (данных нет — другая ошибка, и вызывающий пробует yt-dlp, а не шлёт обложку)."""
    pin = await pinterest_pin(pin_url)
    vlist = _video_list(pin)
    if not vlist:
        raise DLError("это не видео-пин")
    return await video_from_list(vlist)


async def video_from_list(vlist: dict) -> dict:
    """Волна 77: скачать видео по готовому video_list (из данных доски — без повторного запроса пина)."""
    vids = [v for v in vlist.values() if isinstance(v, dict) and v.get("url")]
    mp4 = sorted(((v.get("width") or 0, v) for v in vids if str(v["url"]).split("?")[0].endswith(".mp4")),
                 key=lambda x: x[0])
    hls = [v for v in vids if str(v["url"]).split("?")[0].endswith(".m3u8")]
    meta = (mp4[-1][1] if mp4 else (hls[0] if hls else {}))
    out = {"duration": int((meta.get("duration") or 0) / 1000), "width": meta.get("width"), "height": meta.get("height")}
    errors = []
    good = [v for w, v in mp4 if w <= 1280] or [v for _, v in mp4[:1]]
    for v in reversed(good):
        try:
            return {**out, "path": await download_direct(v["url"], ".mp4")}
        except DLError as e:
            errors.append(str(e))
    for h in hls:
        for guess in hls_to_mp4_guess(h["url"]):
            try:
                return {**out, "path": await download_direct(guess, ".mp4")}
            except DLError:
                continue
    for h in hls:
        try:
            return {**out, "path": await _ffmpeg_hls(h["url"])}
        except DLError as e:
            errors.append(str(e))
    raise DLError("видео пина не скачалось: " + "; ".join(errors)[-200:])
