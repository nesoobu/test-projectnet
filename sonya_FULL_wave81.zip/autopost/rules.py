"""Прогон авто-источника: расписание, отбор, скачивание, оформление, публикация/модерация."""
import hashlib
import json
import logging
import re
import time
from datetime import datetime, timedelta
from html import escape

from aiogram import Bot
from aiogram.utils.keyboard import InlineKeyboardBuilder

import llm
from autopost import store, sources, publisher, timeparse, media_dl, captions, imgtools

log = logging.getLogger("rules")
MSK = timeparse.MSK

AI_MODES = {
    "none": "без ИИ",
    "sonya": "в стиле Сони",
    "short": "коротко и по делу",
    "translate": "перевод на русский",
}
AI_PROMPTS = {
    "sonya": "Перескажи это для поста в Telegram-канале от лица Сони: живо, с лёгкой иронией, "
             "2–4 предложения, без хэштегов и ссылок, на русском. Только текст поста.",
    "short": "Перепиши это как короткий пост для Telegram-канала: суть в 2–3 предложениях, "
             "нейтрально, на русском, без хэштегов и ссылок. Только текст поста.",
    "translate": "Переведи на русский естественно, сохрани смысл и тон. Только перевод.",
}
MEDIA_TYPES = {"yamusic", "music", "video"}
TEXT_TYPES = {"rss", "tg", "reddit", "youtube", "vk"}
LOOP_TYPES = {"yamusic", "pool", "music", "video", "pinterest"}
CAPTION_TYPES = {"yamusic", "music", "video", "pinterest", "pool"}
BTN_LABEL = {"yamusic": "🎧 Слушать", "music": "🎧 Слушать", "video": "▶️ Смотреть"}


# ================= расписание =================
def allowed(ts: int, cfg: dict) -> bool:
    d = datetime.fromtimestamp(ts, MSK)
    if d.weekday() not in (cfg.get("days") or list(range(7))):
        return False
    hrs = cfg.get("hours")
    if hrs:
        a, b = hrs
        h = d.hour
        return (a <= h < b) if a < b else (h >= a or h < b)
    return True


def _times_after(times: list[str], after: int, days: int = 9) -> list[int]:
    base = datetime.fromtimestamp(after, MSK).date()
    out = []
    for i in range(days):
        day = base + timedelta(days=i)
        for t in times:
            h, m = map(int, t.split(":"))
            ts = int(datetime(day.year, day.month, day.day, h, m, tzinfo=MSK).timestamp())
            if ts > after:
                out.append(ts)
    return sorted(out)


def spread_of(rule: dict, cfg: dict) -> int:
    """Разброс в минутах с правилом «не больше ⅓ интервала» (для «своего времени» — ⅓ самого короткого
    промежутка между временами, но не больше 2 ч)."""
    from autopost import timeparse
    sp = int(cfg.get("spread") or 0)
    if not sp:
        return 0
    if cfg.get("sched", "interval") == "interval":
        return min(sp, timeparse.max_spread(rule["every_min"]))
    times = sorted(cfg.get("times") or ["12:00"])
    mins = [int(t[:2]) * 60 + int(t[3:]) for t in times]
    gaps = [b - a for a, b in zip(mins, mins[1:])] + [1440 - mins[-1] + mins[0]]
    return min(sp, min(gaps) // 3, 120)


def next_run(rule: dict, cfg: dict, channel: dict | None, now: int | None = None) -> int:
    """Волна 81: + разброс. Интервал 3 ч, разброс ±1 ч → следующий пост в окне 2–4 ч после этого
    (случайно, чтобы канал не выглядел роботом); правило ⅓ не даёт постам сойтись подряд."""
    import random
    now = int(now or time.time())
    mode = cfg.get("sched", "interval")
    sp = spread_of(rule, cfg) * 60
    if mode in ("times", "slots"):
        times = cfg.get("times") if mode == "times" else json.loads((channel or {}).get("slots") or "[]")
        for ts in _times_after(times or ["12:00"], now):
            if allowed(ts, cfg):
                return max(ts + random.randint(-sp, sp), now + 60) if (sp and mode == "times") else ts
        return now + 86400
    ts = now + max(10, rule["every_min"]) * 60 + (random.randint(-sp, sp) if sp else 0)
    for _ in range(9 * 24 * 12):  # шаг 5 минут, максимум ~9 дней
        if allowed(ts, cfg):
            return ts
        ts += 300
    return ts


def sched_label(rule: dict, cfg: dict) -> str:
    mode = cfg.get("sched", "interval")
    if mode == "times":
        s = "в " + " · ".join(cfg.get("times") or [])
    elif mode == "slots":
        s = "по слотам канала"
    else:
        from autopost import timeparse
        s = "каждые " + timeparse.fmt_dur(rule["every_min"])
    sp = spread_of(rule, cfg)
    if sp:
        from autopost import timeparse
        s += f" ± {timeparse.fmt_dur(sp)}"
    days = cfg.get("days") or list(range(7))
    if len(days) < 7:
        names = "пн вт ср чт пт сб вс".split()
        s += " · " + ",".join(names[d] for d in sorted(days))
    if cfg.get("hours"):
        a, b = cfg["hours"]
        s += f" · {a:02d}–{b:02d}ч"
    return s


# ================= оформление =================
def hashtag(word: str) -> str:
    return captions.clean_tag(word, lower=False)


async def make_tags(rule: dict, cfg: dict, item: dict, caption: str = "") -> str:
    tags: list[str] = []
    if cfg["tags"] == "meta":
        tags = captions.meta_tags(rule, item)
    elif cfg["tags"] == "ai":
        # артисты — всегда точными тегами, остальное — популярное от ИИ
        artists = [t for t in captions.meta_tags(rule, {"artist": item.get("artist")})
                   if t not in captions.BASE_TAGS.get(rule["type"], [])]
        try:
            tags = artists + await captions.popular_tags(rule, item, caption)
        except Exception as e:
            log.warning("ai tags: %s", e)
            tags = captions.meta_tags(rule, item)
    for w in re.split(r"[\s,]+", cfg.get("extra_tags") or ""):
        if w:
            tags.append(captions.clean_tag(w, lower=False))
    return " ".join(captions.dedup(tags, 5))   # волна 69: 3–5 по теме, а не простыня из 8


def render_template(tpl: str, fields: dict) -> str:
    def sub(m):
        return fields.get(m.group(1), "")
    out = re.sub(r"\{(\w+)\}", sub, tpl)
    return re.sub(r"\n{3,}", "\n\n", out).strip()


async def ai_rewrite(mode: str, text: str) -> str:
    if mode not in AI_PROMPTS or not text.strip():
        return text
    out = await llm.ask([{"role": "system", "content": AI_PROMPTS[mode]},
                         {"role": "user", "content": text[:3000]}], max_tokens=600, temperature=0.7)
    return out or text


def _cut(s: str, n: int) -> str:
    if n and len(s) > n:
        return s[:n].rsplit(" ", 1)[0] + "…"
    return s


async def build(rule: dict, cfg: dict, item: dict, media: list) -> tuple[str, list]:
    """→ (html-текст, кнопки)"""
    t = rule["type"]
    title = item.get("title") or ""
    body = _cut(item.get("text") or "", cfg.get("max_len") or 0)
    link = item.get("link") or ""
    caption = ""
    if cfg.get("caption", "none") != "none" and t in CAPTION_TYPES:
        try:
            caption = await captions.live_caption(rule, cfg, item, media)
        except Exception as e:
            log.warning("caption: %s", e)
        if not caption:
            caption = captions.fallback_caption(cfg["caption"])
        if caption and rule.get("id"):
            recent = (cfg.get("recent_caps") or []) + [caption[:60]]
            await store.set_cfg(rule["id"], recent_caps=recent[-12:])
    tags = await make_tags(rule, cfg, item, caption)

    if t in TEXT_TYPES and rule["ai_mode"] != "none":
        raw = f"{title}\n\n{body}".strip() if title and body and title not in body else (body or title)
        try:
            body = await ai_rewrite(rule["ai_mode"], raw)
            title = ""
        except Exception as e:
            log.warning("ai rewrite: %s", e)

    buttons = []
    style = cfg.get("link_style", "text")
    src_link = f'<a href="{escape(link, quote=True)}">источник</a>' if link else ""
    if style == "button" and link:
        buttons = [[{"t": BTN_LABEL.get(t, "🔗 Источник"), "u": link}]]
    if style != "text":
        src_link = ""

    fields = {
        "title": escape(title), "track": escape(title), "text": escape(body),
        "link": escape(link), "src": src_link, "source": escape(rule["title"]),
        "artist": escape(item.get("artist") or ""), "album": escape(item.get("album") or ""),
        "genre": escape(item.get("genre") or ""), "tags": escape(tags),
        "caption": escape(caption),
    }
    cap = fields["caption"]
    if cfg.get("template"):
        text = render_template(cfg["template"], fields)
    elif t in ("yamusic", "music"):
        text = "\n\n".join(x for x in (cap, src_link, fields["tags"]) if x)
    elif t == "video":
        head = cap or f"<b>{fields['title']}</b>"
        text = "\n\n".join(x for x in (head, src_link if media else fields["link"], fields["tags"]) if x)
    elif t == "youtube":
        text = f"<b>{fields['title']}</b>\n\n{fields['link']}"
    elif t == "pinterest":
        text = "\n\n".join(x for x in (cap, src_link, fields["tags"]) if x)
    elif t == "ai":
        text = fields["text"] + (f"\n\n{fields['tags']}" if tags else "")
    else:
        parts = []
        if title and body.startswith(title):
            body = body[len(title):].strip()
        if title:
            parts.append(f"<b>{fields['title']}</b>")
        if body:
            parts.append(escape(body))
        if src_link:
            parts.append(src_link)
        if tags:
            parts.append(fields["tags"])
        text = "\n\n".join(parts)
    if rule.get("footer"):
        text = (text + "\n\n" if text else "") + escape(rule["footer"])
    return text, buttons


# ================= кандидаты =================
async def candidates(rule: dict, cfg: dict, want: int) -> list[dict]:
    t, src = rule["type"], rule["source"]
    seen = await store.seen_keys(rule["id"])

    if t == "pool":
        rows = await store.pool_pick(rule["id"], cfg["order"], want)
        if not rows and cfg.get("loop"):
            await store.pool_reset(rule["id"])
            rows = await store.pool_pick(rule["id"], cfg["order"], want)
        return [{"key": f"pool:{r['id']}", "_pool": r} for r in rows]

    if t == "ai":
        return [{"key": f"ai:{time.time()}:{i}", "_ai": True} for i in range(want)]

    if t == "yamusic":
        ids = await media_dl.ym_ids(src, cfg.get("token", ""))
        fresh = [i for i in ids if i not in seen]
        if not fresh and ids and cfg.get("loop"):
            await store.reset_seen(rule["id"])
            fresh = ids
        fresh = media_dl.pick(fresh, cfg["order"], want)[: want * 4]
        return await media_dl.ym_meta(fresh, cfg.get("token", "")) if fresh else []

    if t == "auto":   # волна 78: рубрика автопилота — свои источники и фильтры
        from autopost import autopilot
        return await autopilot.candidates(rule, cfg, seen, want)

    limit = 40 if cfg["order"] == "random" or t in LOOP_TYPES else 15
    try:
        items = await sources.fetch(t, src, limit)
    except sources.SourceError:
        raise
    if t == "pinterest":   # волна 77: один пин = одна запись, как бы ни назывался ключ (RSS-ссылка или pin:id)
        pid = lambda k: (re.search(r"(?:pin:|/pin/)(\d+)", k or "") or [None, k])[1]   # noqa: E731
        seen_ids = {pid(k) for k in seen}
        fresh = [i for i in items if pid(i["key"]) not in seen_ids]
    else:
        fresh = [i for i in items if i["key"] not in seen]
    if not fresh and items and cfg.get("loop") and t in LOOP_TYPES and cfg["order"] == "random":
        await store.reset_seen(rule["id"])
        fresh = items
    return media_dl.pick(fresh, cfg["order"], want)


def content_hash(item: dict) -> str:
    basis = item.get("image") or item.get("link") or (item.get("title", "") + item.get("text", "")[:200])
    return hashlib.sha1(basis.encode("utf-8", "ignore")).hexdigest()[:16]


# ================= материализация =================
async def materialize(rule: dict, cfg: dict, item: dict) -> dict:
    """Готовый словарь поста: text, media, buttons, reactions, opts."""
    t = rule["type"]
    reacts = publisher.REACTION_SETS[cfg.get("reacts", 0) % len(publisher.REACTION_SETS)]
    opts = {"silent": bool(cfg.get("silent")), "link_preview": False}

    if t == "auto":
        from autopost import autopilot
        return await autopilot.materialize(rule, cfg, item)

    if t == "pool":
        p = await store.post(item["_pool"]["post_id"])
        if not p:
            raise media_dl.DLError("запись копилки потеряна")
        text = p["text"] or ""
        if not text and cfg.get("caption", "none") != "none":
            try:
                text = escape(await captions.live_caption(rule, cfg, {"text": ""}, p["media"])
                              or captions.fallback_caption(cfg["caption"]))
            except Exception as e:
                log.warning("pool caption: %s", e)
        tags = await make_tags(rule, cfg, {"text": re.sub(r"<[^>]+>", "", text)})
        if tags and tags not in text:
            text = (text + "\n\n" if text else "") + escape(tags)
        if rule.get("footer"):
            text = (text + "\n\n" if text else "") + escape(rule["footer"])
        return {"text": text, "media": p["media"], "buttons": p["buttons"],
                "reactions": reacts or p["reactions"], "opts": {**p["opts"], **opts}}

    if t == "ai":
        recent = cfg.get("recent") or []
        prompt = (f"Ты автор Telegram-канала. Напиши один пост для рубрики: «{rule['source']}». "
                  "300–700 символов, на русском, живо, без хэштегов и без вступлений вроде «Конечно». "
                  "Только текст поста.")
        if recent:
            prompt += " Не повторяй темы прошлых постов: " + " | ".join(recent[-8:])
        out = await llm.ask([{"role": "system", "content": prompt},
                             {"role": "user", "content": "Новый пост."}], max_tokens=700, temperature=1.0)
        if not out.strip():
            raise media_dl.DLError("ИИ вернул пустоту")
        recent = (recent + [out.strip()[:60]])[-10:]
        await store.set_cfg(rule["id"], recent=recent)
        item = {**item, "text": out.strip()}
        text, buttons = await build(rule, {**cfg, "max_len": 0}, item, [])
        return {"text": text, "media": [], "buttons": buttons, "reactions": reacts, "opts": opts}

    media: list[dict] = []
    if t in MEDIA_TYPES and cfg.get("as_media") != "link":
        if t == "yamusic":
            f = await media_dl.ym_download(item["key"], cfg.get("token", ""))
            media = [{"type": "audio", "src": f["path"], "path": f["path"], "thumb": f.get("thumb"),
                      "title": f["title"], "performer": f["performer"], "duration": f["duration"]}]
        else:
            kind = "audio" if t == "music" else "video"
            f = await media_dl.ytdlp_download(item["link"], kind)
            m = {"type": kind, "src": f["path"], "path": f["path"], "duration": f["duration"]}
            if kind == "audio":
                m.update(title=f["title"], performer=f["performer"])
                item.setdefault("artist", f["performer"])
            else:
                m.update(width=f.get("width"), height=f.get("height"))
            if f.get("genre"):
                item["genre"] = f["genre"]
            media = [m]
    elif t not in MEDIA_TYPES:
        media = await resolve_media(rule, cfg, item)
    if t in ("video", "youtube") and not media:
        opts["link_preview"] = True

    text, buttons = await build(rule, cfg, item, media)
    return {"text": text, "media": media, "buttons": buttons, "reactions": reacts, "opts": opts}


class SkipItem(Exception):
    """Запись не подходит под настройки — молча берём следующую."""


MEDIA_KINDS = {"all": "фото и видео", "video": "только видео", "photo": "только фото", "none": "без медиа"}
_IMG_EXT = re.compile(r"\.(gif)(\?|$)", re.I)


async def _video_from(item: dict) -> dict | None:
    """Пробует достать настоящее видео записи: прямая ссылка → yt-dlp по странице."""
    if item.get("video"):
        try:
            path = await media_dl.download_direct(item["video"], ".mp4")
            return {"type": "video", "src": path, "path": path}
        except media_dl.DLError as e:
            log.info("direct video: %s", e)
    known_video = bool(item.get("is_video"))
    if item.get("video_list"):   # волна 77: видео-пин с доски — ссылки уже есть
        try:
            f = await media_dl.video_from_list(item["video_list"])
            return {"type": "video", "src": f["path"], "path": f["path"], "duration": f["duration"],
                    "width": f.get("width"), "height": f.get("height")}
        except media_dl.DLError as e:
            known_video = True
            log.info("pinterest video (доска): %s — пробую по странице пина", e)
    if item.get("video_page") and "pinterest." in item["video_page"]:
        try:
            f = await media_dl.pinterest_video(item["video_page"])
            return {"type": "video", "src": f["path"], "path": f["path"], "duration": f["duration"],
                    "width": f.get("width"), "height": f.get("height")}
        except media_dl.DLError as e:
            if "не видео" in str(e):
                return None
            known_video = known_video or "не скачалось" in str(e)
            log.info("pinterest video: %s — пробую yt-dlp", e)
    if item.get("video_page"):
        try:
            f = await media_dl.ytdlp_download(item["video_page"], "video")
            return {"type": "video", "src": f["path"], "path": f["path"], "duration": f["duration"],
                    "width": f.get("width"), "height": f.get("height")}
        except media_dl.DLError as e:
            log.info("page video %s: %s", item["video_page"], e)
    if known_video:   # волна 73: это точно видео, но не скачалось — НЕ шлём вместо него картинку-обложку
        item["_video_failed"] = True
    return None


async def resolve_media(rule: dict, cfg: dict, item: dict) -> list[dict]:
    kind = cfg.get("media_kind", "all")
    if not rule["with_media"] or kind == "none":
        return []
    # тип уже известен (пины из поиска/похожих) — лишнее отсеиваем сразу, без запросов
    if kind == "video" and item.get("is_video") is False:
        raise SkipItem("не видео")
    if kind == "photo" and item.get("is_video"):
        raise SkipItem("видео, а канал под фото")
    if kind != "photo" and item.get("is_video") is not False:   # волна 77: тип известен (доска) — картинку не «качаю как видео»
        v = await _video_from(item)
        if v:
            return [v]
        if item.get("_video_failed"):
            raise SkipItem("видео не скачалось — обложку вместо видео не шлю")
        if kind == "video":
            raise SkipItem("не видео")
    if not item.get("images") and "pinterest." in (item.get("video_page") or ""):
        try:   # карусель: в RSS только первая картинка, остальные — в данных пина
            pin = await media_dl.pinterest_pin(item["video_page"])
            if kind == "photo" and "is_video" not in item and media_dl.pin_is_video(pin):
                raise SkipItem("видео, а канал под фото")   # иначе ушла бы обложка видео
            many = media_dl.pinterest_images(pin)
            if len(many) > 1:
                item["images"] = many
                log.info("pinterest: в пине %s картинок — шлю альбомом", len(many))
        except media_dl.DLError as e:
            log.info("pinterest carousel: %s", e)
    images = item.get("images") or ([item["image"]] if item.get("image") else [])
    media = []
    for url in images[:10]:
        media.append({"type": "animation" if _IMG_EXT.search(url) else "photo", "src": url})
    if len(media) > 1 and any(m["type"] == "animation" for m in media):
        media = media[:1]
    if not media and item.get("audio") and kind == "all":
        try:
            path = await media_dl.download_direct(item["audio"], ".mp3")
            media = [{"type": "audio", "src": path, "path": path, "title": item.get("title", "")[:60]}]
        except media_dl.DLError as e:
            log.info("audio enclosure: %s", e)
    return media


def inbox_kb(iid: int):
    kb = InlineKeyboardBuilder()
    kb.button(text="✅ Опубликовать", callback_data=f"ib:go:{iid}")
    kb.button(text="📥 В слот", callback_data=f"ib:q:{iid}")
    kb.button(text="✏️ Править", callback_data=f"ib:ed:{iid}")
    kb.button(text="⏭ Пропустить", callback_data=f"ib:skip:{iid}")
    kb.adjust(2, 2)
    return kb.as_markup()


async def persist_media(post: dict):
    """Если локальные файлы ушли в Telegram — сохраняем file_id и чистим диск."""
    if not post.get("_changed"):
        return
    import os
    media = []
    for m in post["media"]:
        m = dict(m)
        path = m.pop("path", None)
        if path and not str(m["src"]).startswith("/"):
            for p in (path, m.get("thumb")):
                if p and str(p).startswith("/"):
                    try:
                        os.unlink(p)
                    except OSError:
                        pass
            m.pop("thumb", None)
        elif path:
            m["path"] = path
        media.append(m)
    post["media"] = media
    await store.set_post(post["id"], media=media)
    post.pop("_changed", None)


# ================= прогон =================
FAIL_PAUSE = 5   # волна 69: столько сбоев подряд — источник на паузу и сообщение владельцу


def human_error(err: str) -> str:
    """Ошибка источника — человеческими словами и с подсказкой, что делать."""
    e = (err or "").lower()
    for keys, text in (
        (("chat not found", "bot is not a member", "not enough rights", "need administrator", "kicked"),
         "меня убрали из канала или сняли права админа — верни права на публикацию"),
        (("403", "forbidden"), "сайт не пускает сервер (403) — источник мог закрыться или блокирует ботов"),
        (("404", "not found", "не существует", "закрыт"), "источник не найден или закрыт — проверь ссылку"),
        (("429", "too many"), "сайт просит реже (429) — поставь интервал побольше"),
        (("timeout", "timed out", "долго"), "сайт долго не отвечает — попробую позже"),
        (("cannot connect", "dns", "не найден", "connection"), "сайт недоступен — нет связи"),
        (("не rss", "not rss"), "по ссылке не RSS-лента — нужна ссылка на ленту"),
        (("token", "токен", "unauthorized", "401"), "ключ доступа не подходит — обнови токен"),
        (("слишком большой", "too_big", "больше"), "файлы слишком большие для Telegram"),
    ):
        if any(k in e for k in keys):
            return text
    return (err or "неизвестная ошибка")[:150]


async def _health(bot: Bot, rule: dict, ok: bool, err: str = ""):
    """Счётчик сбоев подряд. Успех — обнуляем. FAIL_PAUSE подряд — пауза источника и сообщение владельцу:
    раньше источник ломался молча, а в канал шли кривые посты или ничего."""
    cfg = store.cfg_of(rule)
    fails = 0 if ok else int(cfg.get("fails") or 0) + 1
    if fails != int(cfg.get("fails") or 0):
        await store.set_cfg(rule["id"], fails=fails)
    if fails >= FAIL_PAUSE and rule.get("active"):
        await store.set_rule(rule["id"], active=0)
        await store.set_cfg(rule["id"], fails=0)
        try:
            await bot.send_message(
                rule["owner_id"],
                f"⛔ <b>источник на паузе</b> · {escape(rule['title'])}\n"
                f"{FAIL_PAUSE} раз подряд не получилось: <i>{escape(human_error(err))}</i>\n"
                "починю сама, если это сеть, но чтобы канал не забивался ошибками — остановила. "
                "проверь и включи снова 👇",
                reply_markup=InlineKeyboardBuilder().button(text="▶️ Включить", callback_data=f"ap:ra:{rule['id']}")
                .button(text="🩺 Проверка", callback_data=f"ap:hc:{rule['chat_id']}").adjust(2).as_markup())
        except Exception as e:
            log.info("health notify: %s", e)


async def run_rule(bot: Bot, rule: dict, manual: bool = False) -> str:
    cfg = store.cfg_of(rule)
    want = max(1, min(5, int(cfg.get("per_run") or 1)))
    try:
        cands = await candidates(rule, cfg, want)
    except Exception as e:
        await store.set_rule(rule["id"], last_error=str(e)[:200])
        await _health(bot, rule, False, str(e))
        return f"ошибка: {human_error(str(e))}"

    made, errors = [], []
    channel = await store.channel(rule["chat_id"])
    for it in cands:
        if len(made) >= want or len(errors) >= 3:
            break
        if not it.get("_pool") and not it.get("_ai"):
            await store.mark_seen(rule["id"], it["key"])
            probe = {**it, "text": f"{it.get('artist', '')} {it.get('text', '')}"}
            if not sources.passes(probe, rule["include"], rule["exclude"]):
                continue
            if cfg.get("only_media") and rule["type"] in TEXT_TYPES and not it.get("image"):
                continue
            h = content_hash(it)
            if await store.hash_seen(rule["chat_id"], h, rule["id"]):
                continue
        try:
            data = await materialize(rule, cfg, it)
        except SkipItem as e:
            log.info("rule %s item %s: пропуск — %s", rule["id"], it.get("key"), e)
            continue
        except Exception as e:
            log.warning("rule %s item %s: %s", rule["id"], it.get("key"), e)
            errors.append(str(e))
            continue
        ph = None
        if not it.get("_pool") and not it.get("_ai") and (channel or {}).get("dedupe_img", 1):
            ph = await imgtools.first_photo_hash(bot, data.get("media"))
            if ph is not None and await imgtools.is_dup(rule["chat_id"], ph):
                log.info("rule %s: похожая картинка уже была — пропускаю", rule["id"])
                continue
        if it.get("_pool"):
            await store.pool_use(it["_pool"]["id"])
        elif not it.get("_ai"):
            await store.hash_add(rule["chat_id"], content_hash(it), rule["id"])
        if ph is not None:
            await imgtools.remember(rule["chat_id"], ph)
        made.append(data)

    if not made:
        err = errors[-1][:200] if errors else ""
        await store.set_rule(rule["id"], last_error=err)
        if errors:
            await _health(bot, rule, False, err)
            return f"не получилось: {human_error(err)}"
        await _health(bot, rule, True)   # «новых нет» — не сбой
        return "копилка пуста" if rule["type"] == "pool" else "новых записей нет"

    await store.set_rule(rule["id"], last_error="", posted=rule["posted"] + len(made))
    await _health(bot, rule, True)
    sent_mod = 0
    for data in made:
        pid = await store.new_post(rule["owner_id"], data["text"], data["media"], [rule["chat_id"]], data["opts"])
        await store.set_post(pid, buttons=data["buttons"], reactions=data["reactions"])
        if rule["moderation"]:
            await store.set_post(pid, status="inbox")
            iid = await store.add_inbox(rule["id"], rule["owner_id"], rule["chat_id"], pid)
            post = await store.post(pid)
            try:
                await bot.send_message(rule["owner_id"], f"📥 <b>на модерации</b> · {escape(rule['title'])}")
                await publisher.send(bot, post, rule["owner_id"], preview=True)
                await persist_media(post)
                await bot.send_message(rule["owner_id"], "что делаем?", reply_markup=inbox_kb(iid))
            except Exception as e:
                log.warning("inbox notify: %s", e)
            sent_mod += 1
        else:
            await store.set_post(pid, status="queued")
            await store.schedule(pid, rule["chat_id"], time.time() - 1)
    n = len(made)
    if sent_mod:
        return f"отправила тебе на модерацию: {n}"
    return f"публикую: {n}"
