"""Разбор времени от человека и подбор свободного слота. Всё в МСК."""
import random
import re
from datetime import datetime, timedelta, timezone

MSK = timezone(timedelta(hours=3))


def now() -> datetime:
    return datetime.now(MSK)


def fmt(ts: int) -> str:
    d = datetime.fromtimestamp(ts, MSK)
    today = now().date()
    if d.date() == today:
        day = "сегодня"
    elif d.date() == today + timedelta(days=1):
        day = "завтра"
    else:
        day = d.strftime("%d.%m")
    return f"{day} {d:%H:%M}"


REL = re.compile(r"^(?:через\s*)?\+?\s*(\d+)\s*(м|мин|минут[уы]?|ч|час|часа|часов|д|дн|день|дня|дней)$")
HM = re.compile(r"(\d{1,2})[:.](\d{2})$")


def parse(text: str) -> int | None:
    """'18:30' · 'завтра 10:00' · '25.10 18:00' · '+2ч' · 'через 30м' → unix ts (в будущем)."""
    t = text.strip().lower().replace("ё", "е")
    n = now()
    m = REL.match(t)
    if m:
        v, u = int(m.group(1)), m.group(2)
        mult = 60 if u.startswith("м") else 3600 if u.startswith("ч") else 86400
        return int(n.timestamp()) + v * mult
    base = n.date()
    m = re.match(r"^(сегодня|завтра|послезавтра)\s+(.+)$", t)
    if m:
        base = base + timedelta(days={"сегодня": 0, "завтра": 1, "послезавтра": 2}[m.group(1)])
        t = m.group(2)
        explicit_day = True
    else:
        explicit_day = False
        m = re.match(r"^(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\s+(.+)$", t)
        if m:
            y = int(m.group(3)) if m.group(3) else base.year
            if y < 100:
                y += 2000
            try:
                base = datetime(y, int(m.group(2)), int(m.group(1))).date()
            except ValueError:
                return None
            if not m.group(3) and base < n.date():
                base = base.replace(year=base.year + 1)
            t = m.group(4)
            explicit_day = True
    m = HM.fullmatch(t.strip())
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    if h > 23 or mi > 59:
        return None
    d = datetime(base.year, base.month, base.day, h, mi, tzinfo=MSK)
    if d <= n:
        if explicit_day:
            return None
        d += timedelta(days=1)
    return int(d.timestamp())


def parse_slots(text: str) -> list[str] | None:
    out = []
    for p in re.split(r"[\s,;]+", text.strip()):
        if not p:
            continue
        m = HM.fullmatch(p.replace(".", ":"))
        if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
            return None
        out.append(f"{int(m.group(1)):02d}:{m.group(2)}")
    return sorted(set(out)) or None


def next_slot(slots: list[str], busy_minutes: set[int], jitter: int = 0, days: int = 30) -> int:
    """Ближайший свободный слот канала. busy_minutes — занятые ts//60."""
    n = now()
    slots = slots or ["12:00"]
    for d in range(days):
        day = (n + timedelta(days=d)).date()
        for s in sorted(slots):
            h, mi = map(int, s.split(":"))
            dt = datetime(day.year, day.month, day.day, h, mi, tzinfo=MSK)
            if dt <= n + timedelta(minutes=1):
                continue
            ts = int(dt.timestamp())
            sm = ts // 60
            if any(abs(b - sm) <= jitter for b in busy_minutes):
                continue
            if jitter:
                ts += random.randint(-jitter, jitter) * 60
                ts = max(ts, int(n.timestamp()) + 60)
            return ts
    return int(n.timestamp()) + 3600


def is_night(ts: int | None = None) -> bool:
    h = datetime.fromtimestamp(ts, MSK).hour if ts else now().hour
    return h >= 23 or h < 8


# ================= волна 81: интервал и разброс =================
def parse_duration(text: str) -> int | None:
    """Длительность → минуты. «3:10», «3.10», «3ч10м», «3 ч 10 мин», «190», «190м», «1д 2ч», «1,5ч», «45 минут».
    «3:10» и «3.10» (две цифры после точки) — это 3 ч 10 мин, как на часах."""
    t = (text or "").strip().lower().replace("ё", "е")
    t = re.sub(r"\s+", " ", t)
    if not t:
        return None
    m = re.fullmatch(r"(\d{1,3})[:.](\d{2})", t)
    if m:
        h, mi = int(m.group(1)), int(m.group(2))
        return h * 60 + mi if mi < 60 else None
    if re.fullmatch(r"\d{1,5}", t):
        return int(t)
    total, found = 0.0, False
    for num, unit in re.findall(r"(\d+(?:[.,]\d+)?)\s*(дн|д|час|ч|h|мин|м|m)?[а-яa-z]*", t):
        if not num:
            continue
        v = float(num.replace(",", "."))
        u = unit or "м"
        total += v * (1440 if u.startswith("д") else 60 if u in ("ч", "час", "h") else 1)
        found = True
    return int(round(total)) if found and total > 0 else None


def fmt_dur(mins: int) -> str:
    """Минуты → «45 мин», «3 ч», «3 ч 10 мин», «1 д 2 ч»."""
    mins = int(mins)
    d, rest = divmod(mins, 1440)
    h, m = divmod(rest, 60)
    parts = []
    if d:
        parts.append(f"{d} д")
    if h:
        parts.append(f"{h} ч")
    if m or not parts:
        parts.append(f"{m} мин")
    return " ".join(parts)


SPREAD_SHARE = 3   # разброс не больше трети интервала


def max_spread(interval_min: int) -> int:
    """Правило разброса: не больше ⅓ интервала — тогда соседние посты всегда не ближе ⅔ интервала друг к другу
    и не дальше 1⅓ (3 ч ± 1 ч → следующий через 2–4 ч; ± 3 ч — нельзя: посты могли бы выйти подряд)."""
    return max(0, int(interval_min) // SPREAD_SHARE)


def spread_options(interval_min: int) -> list[int]:
    lim = max_spread(interval_min)
    return [s for s in (5, 10, 15, 20, 30, 45, 60, 90, 120, 180, 240, 360, 480) if s <= lim]
