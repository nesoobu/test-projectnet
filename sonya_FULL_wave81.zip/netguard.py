"""Волна 61: не ходим по чужим ссылкам во внутреннюю сеть сервера (SSRF).
Ссылку из сообщения или автоисточника проверяем: только http/https и только публичные адреса —
не 127.0.0.1, не 10.x/192.168.x, не 169.254.169.254 (метаданные облака), не localhost.
Для aiohttp — get(): редиректы проходим сами и проверяем каждый шаг. Тела ответов читаем с потолком (read_limited)."""
import asyncio
import contextlib
import ipaddress
import re
import socket
from urllib.parse import urlsplit

import aiohttp
from yarl import URL


class Blocked(Exception):
    pass


def _ip_ok(ip: str) -> bool:
    try:
        a = ipaddress.ip_address(ip.split("%", 1)[0])
    except ValueError:
        return False
    if getattr(a, "ipv4_mapped", None):
        a = a.ipv4_mapped
    return a.is_global and not a.is_multicast


async def check(url: str) -> None:
    """Бросает Blocked, если ссылка ведёт не в публичный интернет."""
    try:
        u = urlsplit(url)
        host, port = u.hostname, u.port
    except ValueError:
        raise Blocked("кривая ссылка")
    if u.scheme not in ("http", "https") or not host:
        raise Blocked("открываю только http/https")
    try:
        ipaddress.ip_address(host)
        literal = True
    except ValueError:
        literal = False
    if literal:
        if not _ip_ok(host):
            raise Blocked("это адрес внутри сети — не открываю")
        return
    try:
        infos = await asyncio.get_running_loop().getaddrinfo(host, port or 443, type=socket.SOCK_STREAM)
    except OSError:
        return   # имя не резолвится — запрос и так не уйдёт, пусть ошибку покажет сам yt-dlp/aiohttp
    if not infos or not all(_ip_ok(i[4][0]) for i in infos):
        raise Blocked("это адрес внутри сети — не открываю")


async def check_ytdlp(url: str) -> None:
    """Для yt-dlp: «ytsearch1:…» — это поиск, а не адрес; строку без схемы yt-dlp сам дополняет http:// —
    проверяем её так же."""
    if re.match(r"(?:yt|sc)search\d*:", url):
        return
    await check(url if "://" in url else "http://" + url)


@contextlib.asynccontextmanager
async def get(session: aiohttp.ClientSession, url: str, max_redirects: int = 5, **kw):
    """Как session.get, но редиректы проходим сами и проверяем каждый адрес (aiohttp сам этого не умеет).
    async with netguard.get(s, url) as r: ..."""
    for _ in range(max_redirects + 1):
        await check(url)
        r = await session.get(url, allow_redirects=False, **kw)
        kw.pop("params", None)   # параметры — только к первой ссылке
        loc = r.headers.get("Location")
        if r.status in (301, 302, 303, 307, 308) and loc:
            url = str(r.url.join(URL(loc)))
            r.release()
            continue
        try:
            yield r
        finally:
            r.release()
        return
    raise Blocked("слишком много переадресаций")


async def read_limited(r: aiohttp.ClientResponse, limit: int) -> bytes:
    """Тело ответа, но не больше limit байт — иначе Blocked (а не 300 МБ в память)."""
    if int(r.headers.get("Content-Length") or 0) > limit:
        raise Blocked("файл слишком большой")
    buf = bytearray()
    async for chunk in r.content.iter_chunked(1 << 16):
        buf += chunk
        if len(buf) > limit:
            raise Blocked("файл слишком большой")
    return bytes(buf)


async def save_limited(r: aiohttp.ClientResponse, path: str, limit: int) -> int:
    """Тело ответа сразу в файл, с потолком limit байт. Память не растёт."""
    if int(r.headers.get("Content-Length") or 0) > limit:
        raise Blocked("файл слишком большой")
    n = 0
    with open(path, "wb") as f:
        async for chunk in r.content.iter_chunked(1 << 16):
            n += len(chunk)
            if n > limit:
                raise Blocked("файл слишком большой")
            f.write(chunk)
    return n
