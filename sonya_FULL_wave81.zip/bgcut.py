"""Волна 51: умное вырезание фона нейросетью U²-Net (u2netp, 4.5 МБ, CPU).
Запускается ОТДЕЛЬНЫМ процессом на каждую картинку — onnxruntime не висит в памяти бота.
python bgcut.py <in> <out.png> [модель]  → PNG с прозрачным фоном. Код возврата 0 — ок.
Волна 53: маска дочищается (refine): тонкие линии рвутся, мелкие ошмётки и дымка убираются, дыры заливаются.
Ставится по желанию: pip install onnxruntime + файл модели data/models/u2netp.onnx (команда в HANDOFF)."""
import sys
from collections import deque
from pathlib import Path

MODEL = Path(__file__).resolve().parent / "data" / "models" / "u2netp.onnx"
SIDE = 320


def refine(pred):
    """pred: float 0..1 (H×W, ~320). Возвращает 0..1 маску: главный объект без мусора, дыр и дымки."""
    import numpy as np
    from PIL import Image, ImageFilter
    h, w = pred.shape
    b = Image.fromarray(((pred > 0.5) * 255).astype("uint8"))
    k = max(3, (min(h, w) // 64) | 1)             # ~1.5% стороны: рвёт тонкие линии (рамки, нитки)
    op = np.asarray(b.filter(ImageFilter.MinFilter(k)).filter(ImageFilter.MaxFilter(k))) > 127
    lab = np.zeros((h, w), np.int32)
    sizes = [0]
    for y0, x0 in zip(*np.nonzero(op)):
        if lab[y0, x0]:
            continue
        n = len(sizes); sizes.append(0)
        q = deque([(y0, x0)]); lab[y0, x0] = n
        while q:
            y, x = q.popleft(); sizes[n] += 1
            for yy, xx in ((y+1, x), (y-1, x), (y, x+1), (y, x-1)):
                if 0 <= yy < h and 0 <= xx < w and op[yy, xx] and not lab[yy, xx]:
                    lab[yy, xx] = n; q.append((yy, xx))
    if len(sizes) == 1:
        return pred
    big = max(sizes)
    keep = np.isin(lab, [i for i, s in enumerate(sizes) if i and s >= big * 0.15])
    # дыры внутри объекта — заливаю (всё, до чего не дотянуться от края по фону)
    bg = ~keep
    reach = np.zeros_like(bg)
    q = deque()
    for y in range(h):
        for x in (0, w - 1):
            if bg[y, x] and not reach[y, x]: reach[y, x] = True; q.append((y, x))
    for x in range(w):
        for y in (0, h - 1):
            if bg[y, x] and not reach[y, x]: reach[y, x] = True; q.append((y, x))
    while q:
        y, x = q.popleft()
        for yy, xx in ((y+1, x), (y-1, x), (y, x+1), (y, x-1)):
            if 0 <= yy < h and 0 <= xx < w and bg[yy, xx] and not reach[yy, xx]:
                reach[yy, xx] = True; q.append((yy, xx))
    holes = bg & ~reach
    region = np.asarray(Image.fromarray(((keep | holes) * 255).astype("uint8")).filter(ImageFilter.MaxFilter(k + 2))) > 127
    soft = np.clip((pred - 0.25) / 0.5, 0, 1)      # дымку (0.1–0.3) — в ноль, края мягкие
    soft[holes] = 1
    return soft * region


def cut(src: str, dst: str, model: str = str(MODEL)):
    import numpy as np
    import onnxruntime as ort
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    im.thumbnail((1024, 1024), Image.LANCZOS)
    x = np.asarray(im.resize((SIDE, SIDE), Image.LANCZOS), dtype=np.float32)
    x = x / max(float(x.max()), 1e-6)
    x = (x - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array([0.229, 0.224, 0.225], dtype=np.float32)
    x = x.transpose(2, 0, 1)[None].astype(np.float32)
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1          # сервер маленький — не душим соседей
    opts.enable_cpu_mem_arena = False      # без арены пик памяти в разы ниже
    opts.enable_mem_pattern = False
    opts.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_BASIC   # пик памяти ~240 МБ вместо ~320
    s = ort.InferenceSession(model, opts, providers=["CPUExecutionProvider"])
    pred = s.run(None, {s.get_inputs()[0].name: x})[0][0, 0]
    pred = (pred - pred.min()) / max(float(pred.max() - pred.min()), 1e-6)
    pred = refine(pred)
    mask = Image.fromarray((pred * 255).astype("uint8")).resize(im.size, Image.LANCZOS)
    out = im.convert("RGBA")
    out.putalpha(mask)
    out.save(dst, "PNG")


if __name__ == "__main__":
    cut(sys.argv[1], sys.argv[2], *(sys.argv[3:4]))
