"""Живая Соня: дни рождения, достижения, статистика группы, «пишет первой»."""
import asyncio
import logging
import random
import re
import time
from collections import Counter
from datetime import datetime
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery

import achievements
import db
import llm
import persona
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("life")
GROUPS = {"group", "supergroup"}

# ================= дни рождения =================
MONTHS = {"янв": 1, "фев": 2, "мар": 3, "апр": 4, "мая": 5, "май": 5, "июн": 6, "июл": 7, "авг": 8,
          "сен": 9, "окт": 10, "ноя": 11, "дек": 12}
MONTH_NAMES = ["", "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября",
               "октября", "ноября", "декабря"]
BDAY_PRIZE = 100
BDAY_HOUR = 10   # поздравляю в 10:00 мск
BDAY_RE = re.compile(r"^(?:запомни[\s,:-]*)?(?:у меня|мой)\s+(?:др|день рождения|днюха|день варенья)"
                     r"\s*(?:будет\s+)?[:,-]?\s*(.+)$", re.I)


def parse_bday(s: str) -> str | None:
    """«12.05», «12/5», «12 мая» → «12.05»."""
    s = s.lower().strip()
    m = re.search(r"\b(\d{1,2})[./-](\d{1,2})\b", s)
    if m:
        d, mo = int(m.group(1)), int(m.group(2))
    else:
        m = re.search(r"\b(\d{1,2})\s+([а-я]{3,})", s)
        if not m or m.group(2)[:3] not in MONTHS:
            return None
        d, mo = int(m.group(1)), MONTHS[m.group(2)[:3]]
    try:
        datetime(2000, mo, d)   # 2000 — високосный, 29.02 можно
    except ValueError:
        return None
    return f"{d:02d}.{mo:02d}"


def bday_human(b: str) -> str:
    d, mo = b.split(".")
    return f"{int(d)} {MONTH_NAMES[int(mo)]}"


def _days_until(b: str, now: datetime) -> int:
    d, mo = map(int, b.split("."))
    today = now.date()
    for y in (today.year, today.year + 1):
        try:
            dt = datetime(y, mo, d).date()
        except ValueError:          # 29.02 в невисокосный — празднуем 28-го
            dt = datetime(y, 2, 28).date()
        if dt >= today:
            return (dt - today).days
    return 366


async def set_bday(m: Message, raw: str):
    b = parse_bday(raw)
    if not b:
        return await m.reply("не поняла дату 🤔 напиши так: <code>/bday 12.05</code> или «у меня др 12 мая»")
    await db.q_run("UPDATE users SET bday=? WHERE id=?", b, m.from_user.id)
    left = _days_until(b, datetime.now(persona.MSK))
    tail = "это сегодня?! 🥳" if left == 0 else f"осталось {left} дн. жду 🎂"
    await m.reply(f"🎂 запомнила: <b>{bday_human(b)}</b>. {tail}")


async def upcoming(chat_id: int, days: int = 30) -> list[tuple[int, str, str]]:
    month_ago = int(time.time()) - 30 * 86400
    rows = await db.q_all("SELECT u.id, u.name, u.bday FROM chat_members cm JOIN users u ON u.id=cm.uid "
                          "WHERE cm.chat_id=? AND cm.last>? AND u.bday!='' AND u.banned=0", chat_id, month_ago)
    now = datetime.now(persona.MSK)
    out = [(_days_until(r["bday"], now), r["name"], r["bday"]) for r in rows]
    return sorted(x for x in out if x[0] <= days)


@router.message(Command("bday", "др", "bdays"))
async def cmd_bday(m: Message, command: CommandObject):
    arg = (command.args or "").strip()
    if arg in ("-", "удалить", "нет"):
        await db.q_run("UPDATE users SET bday='' WHERE id=?", m.from_user.id)
        return await m.reply("стёрла. буду делать вид, что ты вечно молодой 😌")
    if arg:
        return await set_bday(m, arg)
    if m.chat.type in GROUPS:
        rows = await upcoming(m.chat.id)
        if not rows:
            return await m.reply("🎂 в ближайший месяц именинников нет\n"
                                 "<i>свой ДР: /bday 12.05</i>")
        lines = ["<b>🎂 скоро дни рождения</b>", ui.LINE]
        for left, name, b in rows[:20]:
            when = "сегодня! 🥳" if left == 0 else "завтра" if left == 1 else f"через {left} дн."
            lines.append(f"• {escape(name)} — {bday_human(b)} · {when}")
        lines.append("\n<i>свой ДР: /bday 12.05</i>")
        return await m.reply("\n".join(lines))
    u = await db.get_user(m.from_user.id) or {}
    if u.get("bday"):
        left = _days_until(u["bday"], datetime.now(persona.MSK))
        when = "сегодня! 🥳" if left == 0 else f"через {left} дн."
        return await m.reply(f"🎂 твой ДР: <b>{bday_human(u['bday'])}</b> · {when}\n"
                             "поменять: <code>/bday 12.05</code> · стереть: <code>/bday -</code>")
    await m.reply("🎂 когда у тебя день рождения? <code>/bday 12.05</code>\n"
                  "в этот день поздравлю и подарю 🪙, а в группах — расскажу всем")


async def _bday_said(m: Message, bot: Bot) -> bool | dict:
    if not m.text or m.text.startswith("/"):
        return False
    from handlers import chat
    me = await bot.me()
    text = chat._addressed(m, me.id, me.username or "")
    if text is None:
        return False
    mt = BDAY_RE.match(text.strip())
    return {"raw": mt.group(1)} if mt else False


@router.message(_bday_said)
async def on_bday_said(m: Message, raw: str):
    await set_bday(m, raw)


async def congratulate(bot: Bot, now: datetime):
    keys = [now.strftime("%d.%m")]
    if keys[0] == "28.02" and now.year % 4:   # невисокосный: 29.02 празднуют 28-го
        keys.append("29.02")
    marks = ",".join("?" * len(keys))
    rows = await db.q_all(f"SELECT id, name FROM users WHERE bday IN ({marks}) AND bday_year!=? AND banned=0",
                          *keys, now.year)
    for u in rows:
        await db.q_run("UPDATE users SET bday_year=? WHERE id=?", now.year, u["id"])
        await db.add_coins(u["id"], BDAY_PRIZE)
        text = random.choice(["с днём рождения! 🎂 расти большим, но не зазнавайся",
                              "с днюхой! 🥳 желаю, чтобы вайб не кончался"])
        try:
            facts = await db.get_facts(u["id"])
            out = await llm.ask([{"role": "system", "content": persona.BASE + "\nСегодня у собеседника день "
                                  "рождения. Поздравь коротко (2–3 предложения), тепло и в своём стиле. "
                                  + ("Что ты о собеседнике знаешь: " + "; ".join(facts) if facts else "")},
                                 {"role": "user", "content": f"Меня зовут {u['name']}"}],
                                max_tokens=400, temperature=1.0, feature="bday")
            if out and len(out) < 800:
                text = out
        except Exception as e:
            log.info("bday llm: %s", e)
        try:
            await bot.send_message(u["id"], f"🎂 {escape(text)}\n\n🎁 подарок: <b>+{BDAY_PRIZE} 🪙</b>")
            await achievements.give(bot, u["id"], "bday")
        except (TelegramForbiddenError, TelegramBadRequest):
            pass
        month_ago = int(time.time()) - 30 * 86400
        chats = await db.q_all("SELECT cm.chat_id FROM chat_members cm JOIN chats c ON c.id=cm.chat_id "
                               "WHERE cm.uid=? AND cm.last>? AND c.bdays=1 ORDER BY cm.last DESC LIMIT 10",
                               u["id"], month_ago)
        for c in chats:
            try:
                await bot.send_message(c["chat_id"], f"🎂 сегодня день рождения у "
                                                     f'<a href="tg://user?id={u["id"]}">{escape(u["name"])}</a>! '
                                                     "налетаем с поздравлениями 🥳")
            except Exception as e:
                log.info("bday group %s: %s", c["chat_id"], e)
            await asyncio.sleep(0.5)


# ================= достижения =================
@router.message(Command("ach", "achievements", "ачивки"))
async def cmd_ach(m: Message):
    await ui.personal(m, await achievements.view(m.from_user.id))


@router.callback_query(F.data == "m:ach")
async def cb_ach(cb: CallbackQuery):
    try:
        await cb.message.edit_text(await achievements.view(cb.from_user.id), reply_markup=ui.back_kb())
    except TelegramBadRequest:
        pass
    await cb.answer()


# ================= статистика группы =================
STOP = set(("когда тогда потом через после перед может можно нужно очень вообще просто сейчас сегодня завтра "
            "вчера только тоже также этого этот эта эти этой того тебе меня тебя себя мной тобой было была были "
            "будет будут есть нету какой какая какие который которая которые потому почему зачем где куда "
            "откуда сколько всегда никогда ничего что-то кто-то короче вроде типа блин ладно давай давайте "
            "хорошо спасибо привет пока").split())
SPARK = "▁▂▃▄▅▆▇█"


def _spark(vals: list[int]) -> str:
    top = max(vals) or 1
    return "".join(SPARK[min(7, round(v / top * 7))] for v in vals)


async def stats_data(chat_id: int) -> dict | None:
    now = int(time.time())
    today = db._day(now)
    week = db._day(now - 6 * 86400)
    day_n = (await db.q_one("SELECT COALESCE(SUM(n),0) AS s FROM chat_daily WHERE chat_id=? AND day=?",
                            chat_id, today))["s"]
    tops = await db.q_all("SELECT cd.uid, COALESCE(u.name,'?') AS name, SUM(cd.n) AS s FROM chat_daily cd "
                          "LEFT JOIN users u ON u.id=cd.uid WHERE cd.chat_id=? AND cd.day>=? "
                          "GROUP BY cd.uid ORDER BY s DESC", chat_id, week)
    week_n = sum(r["s"] for r in tops)
    if not week_n:
        return None
    hours = {r["hour"]: r["n"] for r in await db.q_all("SELECT hour, n FROM chat_hours WHERE chat_id=?", chat_id)}
    hv = [hours.get(h, 0) for h in range(24)]
    log_rows = await db.q_all("SELECT text FROM chat_log WHERE chat_id=? AND ts>?", chat_id, now - 7 * 86400)
    words = Counter(w for r in log_rows   # волна 76: ссылки не слово («https» был «словом недели»)
                    for w in re.findall(r"[а-яёa-z]{5,}", re.sub(r"https?://\S+|www\.\S+|t\.me/\S+", " ", r["text"].lower()))
                    if w not in STOP)
    word, wn = words.most_common(1)[0] if words else ("", 0)
    return {"day": day_n, "week": week_n, "tops": tops, "hours": hv, "peak": max(range(24), key=lambda h: hv[h]),
            "word": word if wn >= 3 else "", "word_n": wn}


async def stats_text(chat_id: int, title: str, st: dict | None = None) -> str:
    st = st or await stats_data(chat_id)
    if not st:
        return "📊 пока считать нечего — я только начала вести статистику. загляни попозже"
    week_n, tops = st["week"], st["tops"]
    lines = [f"<b>📊 статистика · {escape(title[:40])}</b>", ui.LINE,
             f"💬 сегодня: <b>{st['day']}</b> · за неделю: <b>{week_n}</b> · активных: <b>{len(tops)}</b>", "",
             "<b>🏆 болтуны недели</b>"]
    for i, r in enumerate(tops[:10]):
        mark = ui.MEDALS[i] if i < 3 else f"{i + 1}."
        pct = round(r["s"] / week_n * 100)
        lines.append(f"{mark} {escape(r['name'][:24])} — <b>{r['s']}</b> ({pct}%)")
    lines += ["", f"<b>🕐 когда болтаете</b> · пик в {st['peak']}:00"]
    if st["word"]:
        lines.append(f"🔤 слово недели: <b>{escape(st['word'])}</b> ({st['word_n']} раз)")
    return "\n".join(lines)


@router.message(Command("stats", "стата"))
async def cmd_stats(m: Message):
    """Волна 76: статистика — картинкой-дашбордом (плитки, топ полосками, часы столбиками), текст — подписью."""
    import gameart
    import uikit
    if m.chat.type not in GROUPS:
        return await m.reply("📊 статистика — для групп. свою смотри в /me и /ach")
    st = await stats_data(m.chat.id)
    text = await stats_text(m.chat.id, m.chat.title or "", st)
    if not st:
        return await m.reply(text)
    title = m.chat.title or ""
    return await uikit.with_card(
        lambda: gameart.chat_stats(title, st["day"], st["week"], len(st["tops"]),
                                   [(r["name"], r["s"]) for r in st["tops"]], st["hours"], st["word"], st["word_n"]),
        lambda: m.reply(text))


# ================= Соня пишет первой =================
NUDGE_HOUR = 19
NUDGE_BATCH = 30
NUDGE_PROMPT = ("Ты давно (несколько дней) не переписывалась с собеседником по имени {name}. Напиши первой "
                "одно короткое живое сообщение, как подруга, которая соскучилась: 1–2 предложения, без «как дела?» "
                "в лоб. Если что-то о собеседнике знаешь — зацепись за это. {facts}")


def nudge_kb():
    return kb_rows([("🔕 Не пиши первой", "ndg:off")])


async def nudge(bot: Bot):
    now = int(time.time())
    rows = await db.q_all("SELECT id, name FROM users u WHERE nudge=1 AND banned=0 AND last_seen BETWEEN ? AND ? "
                          "AND last_nudge<? AND EXISTS(SELECT 1 FROM history h WHERE h.chat_id=u.id) "
                          "ORDER BY last_seen DESC LIMIT ?",
                          now - 7 * 86400, now - 3 * 86400, now - 7 * 86400, NUDGE_BATCH)
    for u in rows:
        await db.q_run("UPDATE users SET last_nudge=? WHERE id=?", now, u["id"])
        facts = await db.get_facts(u["id"])
        try:
            text = await llm.ask([{"role": "system", "content": persona.BASE + "\n" + persona.mood()},
                                  {"role": "user", "content": NUDGE_PROMPT.format(
                                      name=u["name"], facts=("Что знаешь: " + "; ".join(facts)) if facts else "")}],
                                 max_tokens=300, temperature=1.0, feature="nudge")
        except Exception as e:
            log.info("nudge llm: %s", e)
            continue
        if not text or len(text) > 500:
            continue
        try:
            await bot.send_message(u["id"], text, parse_mode=None, reply_markup=nudge_kb())
            await db.add_history(u["id"], 0, "assistant", text)
        except TelegramForbiddenError:
            await db.q_run("UPDATE users SET nudge=0 WHERE id=?", u["id"])
        except TelegramBadRequest as e:
            log.info("nudge %s: %s", u["id"], e)
        await asyncio.sleep(1.5)


@router.callback_query(F.data == "ndg:off")
async def cb_nudge_off(cb: CallbackQuery):
    await db.q_run("UPDATE users SET nudge=0 WHERE id=?", cb.from_user.id)
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass
    await cb.answer("ок, первой не пишу. вернуть: /nudge", show_alert=True)


@router.message(Command("nudge"))
async def cmd_nudge(m: Message):
    u = await db.get_user(m.from_user.id) or {}
    on = not u.get("nudge", 1)
    await db.q_run("UPDATE users SET nudge=? WHERE id=?", int(on), m.from_user.id)
    await m.reply("💌 ок, если пропадёшь — напишу первой" if on else "🔕 ок, первой не пишу")


# ================= фоновый цикл =================
async def loop(bot: Bot):
    done: dict[str, str] = {}
    while True:
        try:
            now = datetime.now(persona.MSK)
            today = now.strftime("%Y-%m-%d")
            if now.hour >= BDAY_HOUR and done.get("bday") != today:
                done["bday"] = today
                await congratulate(bot, now)
            if now.hour == NUDGE_HOUR and done.get("nudge") != today:
                done["nudge"] = today
                await nudge(bot)
        except Exception:
            log.exception("life loop")
        await asyncio.sleep(60)
