"""Волна 63: 🎲 розыгрыш кубиком в комментариях и в чате.
Админ пишет /roll (или /кубик, /жребий):
• в комментариях к посту — участвуют все, кто комментировал этот пост;
• ответом на сообщение в чате — все, кто ответил на это сообщение;
• просто в чате — все, кто писал за последние 24 ч (3 дня / неделю — кнопкой).
Бот присылает панель: число победителей и фильтры (старожилы, активность, возраст аккаунта, буст, Premium,
без пустых аккаунтов, подписка на канал, без админов). «🎲 Бросить» — бот публикует пронумерованный список
и бросает настоящие кубики Telegram: значения складываются в число по основанию 6 → номер победителя.
Подтасовать нельзя: кубик бросает Telegram, список опубликован до бросков. Выпало за пределами — перебрасываем."""
import asyncio
import json
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile, ReplyParameters

import db
import members
import ui
from handlers.ap_common import kb_rows

router = Router()
GROUPS = ("group", "supergroup")
DICE_PAUSE = 4.0          # анимация кубика ~3 с — ждём, прежде чем объявлять
MAX_WINNERS, MAX_PEOPLE = 10, 3000
DAYS = (0, 3, 7, 30, 90)
MSGS = (0, 3, 10, 30)
HOURS = (24, 72, 168)
LIST_INLINE = 60
WIN_DAYS = 30             # «без прошлых победителей» — за столько дней          # больше участников — списком-файлом


def _key(chat_id: int, mid: int) -> str:
    return f"roll:{chat_id}:{mid}"


async def _linked(bot: Bot, chat_id: int) -> int:
    """id канала, к которому эта группа — обсуждение (комментарии). 0 — обычный чат."""
    hit = _linked_cache.get(chat_id)
    if hit and time.time() - hit[0] < 3600:
        return hit[1]
    try:
        ch = (await bot.get_chat(chat_id)).linked_chat_id or 0
    except Exception:
        ch = 0
    _linked_cache[chat_id] = (time.time(), ch)
    return ch


_linked_cache: dict[int, tuple[float, int]] = {}


async def _can(bot: Bot, m_or_cb, chat_id: int, uid: int) -> bool:
    from handlers import groupmod
    return await groupmod.is_admin(bot, chat_id, uid)


async def _people(st: dict) -> list[int]:
    if st["src"] == "thread":
        return await members.thread_people(st["chat"], st["thread"])
    return await members.active_people(st["chat"], st.get("hours", 24))


def _src_text(st: dict) -> str:
    if st["src"] == "thread":
        return "все, кто комментировал пост" if st.get("ch") else "все, кто ответил на сообщение"
    h = st.get("hours", 24)
    return "все, кто писал в чате за " + {24: "сутки", 72: "3 дня", 168: "неделю"}.get(h, f"{h} ч")


def _filters_text(st: dict) -> str:
    f = []
    if st.get("days"):
        f.append(f"🧓 {'в канале' if st.get('ch') else 'в чате'} ≥ {st['days']} дн")
    if st.get("msgs"):
        f.append(f"💬 ≥ {st['msgs']} сообщ. в чате")
    if st.get("acc"):
        f.append("🗓 аккаунт старше 90 дн")
    if st.get("boost"):
        f.append("🚀 забустил " + ("канал" if st.get("ch") else "чат"))
    if st.get("prem"):
        f.append("⭐ Premium")
    if st.get("sub") and st.get("ch"):
        f.append("📢 подписан на канал")
    if st.get("noempty"):
        f.append("🤖 без пустых аккаунтов")
    if st.get("noadm"):
        f.append("👑 без админов")
    if st.get("nowin"):
        f.append("🔁 без победителей за 30 дн")
    return " · ".join(f) or "нет"


async def panel(st: dict) -> tuple[str, object]:
    n = len(await _people(st))
    tog = ui.tog
    text = (ui.head("🎲", "Розыгрыш кубиком", "кубики бросает Telegram — подтасовать нельзя") + "\n"
            + f"👥 участвуют: {_src_text(st)} — <b>{n}</b>\n"
            + f"🏆 победителей: <b>{st['winners']}</b>\n"
            + f"🔎 фильтры: {_filters_text(st)}\n\n"
            + ui.hint("перед бросками опубликую пронумерованный список — каждый проверит себя"))
    rows = [[("➖", "rl:w-"), (f"🏆 {st['winners']}", "rl:nop"), ("➕", "rl:w+")],
            [(f"🧓 Старожилы: {str(st['days']) + ' дн' if st.get('days') else 'выкл'}", "rl:days"),
             (f"💬 Активность: {'≥' + str(st['msgs']) if st.get('msgs') else 'выкл'}", "rl:msgs")],
            [(f"{tog(st.get('acc'))} 🗓 Аккаунт > 90 дн", "rl:acc"), (f"{tog(st.get('boost'))} 🚀 Забустил", "rl:boost")],
            [(f"{tog(st.get('prem'))} ⭐ Premium", "rl:prem"), (f"{tog(st.get('noempty'))} 🤖 Без пустых", "rl:noempty")],
            [(f"{tog(st.get('sub'))} 📢 Подписан на канал", "rl:sub") if st.get("ch") else None,
             (f"{tog(st.get('noadm'))} 👑 Без админов", "rl:noadm")],
            [(f"{tog(st.get('nowin'))} 🔁 Без прошлых победителей", "rl:nowin")]]
    if st["src"] == "active":
        rows.append([(f"🕐 Писали за: {_src_text(st).split(' за ')[1]}", "rl:hours")])
    rows.append([("🎲 Бросить кубики", "rl:go", "success"), ("✖️", "rl:x", "danger")])
    return text, kb_rows(*rows)


@router.message(Command("roll", "кубик", "жребий"))
async def cmd_roll(m: Message, bot: Bot):
    if m.chat.type not in GROUPS:
        return await m.answer(
            ui.head("🎲", "Розыгрыш кубиком") + "\n"
            "работает в группе или в комментариях канала (я должна быть там админом):\n"
            "• в комментариях к посту — <code>/roll</code> → участвуют все, кто комментировал\n"
            "• ответом на сообщение — участвуют все, кто ответил на него\n"
            "• просто <code>/roll</code> в чате — все, кто писал за сутки (или 3 дня / неделю)\n\n"
            "дальше — фильтры кнопками и «🎲 Бросить»: я публикую список и бросаю настоящие кубики Telegram")
    uid = m.from_user.id if m.from_user else 0
    anon = bool(m.sender_chat) and (m.sender_chat.id == m.chat.id
                                     or m.sender_chat.id == await _linked(bot, m.chat.id))
    if not anon and not await _can(bot, m, m.chat.id, uid):
        return await m.reply("🎲 розыгрыш запускают только админы")
    ch = await _linked(bot, m.chat.id)
    if m.message_thread_id:
        src, thread = "thread", m.message_thread_id
    elif m.reply_to_message:
        src, thread = "thread", m.reply_to_message.message_id
    else:
        src, thread = "active", 0
    st = {"chat": m.chat.id, "by": 0 if anon else uid, "src": src, "thread": thread, "hours": 24, "winners": 1,
          "ch": ch if (src == "thread" and m.message_thread_id) else 0, "days": 0, "msgs": 0, "acc": 0, "boost": 0,
          "prem": 0, "noempty": 1, "noadm": 1, "sub": 1, "reply": m.message_id}
    text, kb = await panel(st)
    p = await m.reply(text, reply_markup=kb)
    await db.kv_set(_key(m.chat.id, p.message_id), json.dumps(st))


async def _state(cb: CallbackQuery) -> dict | None:
    raw = await db.kv_get(_key(cb.message.chat.id, cb.message.message_id))
    return json.loads(raw) if raw else None


def _next(seq: tuple, v) -> int:
    return seq[(seq.index(v) + 1) % len(seq)] if v in seq else seq[0]


@router.callback_query(F.data.startswith("rl:"))
async def cb_roll(cb: CallbackQuery, bot: Bot):
    st = await _state(cb)
    if not st:
        return await cb.answer("панель устарела — напиши /roll ещё раз", show_alert=True)
    uid = cb.from_user.id
    if uid != st["by"] and not await _can(bot, cb, st["chat"], uid):
        return await cb.answer("это панель админа 🙃", show_alert=True)
    act = cb.data[3:]
    if act == "nop":
        return await cb.answer()
    if act == "x":
        await db.q_run("DELETE FROM kv WHERE k=?", _key(cb.message.chat.id, cb.message.message_id))
        await cb.answer()
        try:
            return await cb.message.edit_text("🎲 розыгрыш отменён")
        except TelegramBadRequest:
            return
    if act == "go":
        # захват одной командой: двойной тап не запустит два розыгрыша
        if not await db.q_change("DELETE FROM kv WHERE k=?", _key(cb.message.chat.id, cb.message.message_id)):
            return await cb.answer()
        await cb.answer("бросаю 🎲")
        return await run(bot, st, cb.message)
    if act == "w+":
        st["winners"] = min(MAX_WINNERS, st["winners"] + 1)
    elif act == "w-":
        st["winners"] = max(1, st["winners"] - 1)
    elif act == "days":
        st["days"] = _next(DAYS, st.get("days", 0))
    elif act == "msgs":
        st["msgs"] = _next(MSGS, st.get("msgs", 0))
    elif act == "hours":
        st["hours"] = _next(HOURS, st.get("hours", 24))
    elif act in ("acc", "boost", "prem", "noempty", "noadm", "sub", "nowin"):
        st[act] = 0 if st.get(act) else 1
    await db.kv_set(_key(cb.message.chat.id, cb.message.message_id), json.dumps(st))
    text, kb = await panel(st)
    await cb.answer()
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass


async def eligible(bot: Bot, st: dict, uid: int) -> tuple[bool, str]:
    """Проходит ли человек фильтры. → (да/нет, имя)."""
    from handlers import giveaway, groupmod
    chat, ch = st["chat"], st.get("ch") or 0
    try:
        mem = await bot.get_chat_member(chat, uid)
    except Exception:
        return False, ""
    user = mem.user
    name = user.full_name or "без имени"
    if user.is_bot or mem.status in ("left", "kicked") or (mem.status == "restricted" and not getattr(mem, "is_member", True)):
        return False, name
    if st.get("noadm") and (uid in await groupmod.admins_of(bot, chat) or uid == st.get("by")):
        return False, name
    if st.get("nowin") and uid in await recent_winners(chat):
        return False, name
    if st.get("prem") and not user.is_premium:
        return False, name
    if ch and (st.get("sub") or st.get("days")):
        try:
            cm = await bot.get_chat_member(ch, uid)
            if cm.status in ("left", "kicked"):
                return False, name
        except Exception:
            return False, name
    if st.get("days") and not await members.old_enough(ch or chat, uid, st["days"]):
        return False, name
    if st.get("msgs") and await members.msgs(chat, uid) < st["msgs"]:
        return False, name
    if st.get("acc") and await giveaway.too_new(uid, 90):
        return False, name
    if st.get("boost") and not await giveaway.boosts_of(bot, ch or chat, uid):
        return False, name
    if st.get("noempty") and await giveaway._suspicious(bot, user):
        return False, name
    return True, name


def _reply(st: dict, mid: int) -> dict:
    return {"reply_parameters": ReplyParameters(message_id=mid, allow_sending_without_reply=True)}


async def run(bot: Bot, st: dict, panel_msg: Message):
    chat = st["chat"]
    try:
        await panel_msg.edit_text("🎲 проверяю участников…")
    except TelegramBadRequest:
        pass
    people = (await _people(st))[:MAX_PEOPLE]
    sem = asyncio.Semaphore(8)

    async def one(u):
        async with sem:
            return u, *(await eligible(bot, st, u))
    checked = await asyncio.gather(*(one(u) for u in people))
    ok = [(u, name) for u, good, name in checked if good]
    if not ok:
        return await panel_msg.edit_text(f"🎲 никто не прошёл фильтры (было {len(people)}) 🤷\n"
                                         f"фильтры: {_filters_text(st)}")
    n = len(ok)
    lines = [f"{i + 1}. {escape(name[:40])}" for i, (_u, name) in enumerate(ok)]
    head = (f"🎲 <b>розыгрыш кубиком</b>\n👥 участников: <b>{n}</b>"
            + (f" (из {len(people)}, фильтры: {_filters_text(st)})" if n != len(people) else "") + "\n")
    if n <= LIST_INLINE:
        await panel_msg.edit_text(head + "\n" + "\n".join(lines))
    else:
        await panel_msg.edit_text(head + "\n📄 полный список — файлом ниже")
        await bot.send_document(chat, BufferedInputFile("\n".join(f"{i + 1}. {nm}" for i, (_u, nm) in enumerate(ok))
                                                        .encode(), "участники.txt"), **_reply(st, panel_msg.message_id))
    k = 1
    while 6 ** k < n:
        k += 1
    limit = n * (6 ** k // n)
    wins: list[int] = []
    need = min(st["winners"], n)
    tries = 0
    while len(wins) < need and tries < 60:
        tries += 1
        if n == 1:
            wins.append(0)
            break
        vals = []
        for _ in range(k):
            d = await bot.send_dice(chat, emoji="🎲", **_reply(st, panel_msg.message_id))
            vals.append(d.dice.value)
        await asyncio.sleep(DICE_PAUSE)
        v = 0
        for x in vals:
            v = v * 6 + (x - 1)
        shown = " · ".join(str(x) for x in vals)
        if v >= limit:
            await bot.send_message(chat, f"🎲 {shown} — вне списка, перебрасываю", **_reply(st, panel_msg.message_id))
            continue
        idx = v % n
        if idx in wins:
            await bot.send_message(chat, f"🎲 {shown} → №{idx + 1} уже выиграл, перебрасываю",
                                   **_reply(st, panel_msg.message_id))
            continue
        wins.append(idx)
        u, name = ok[idx]
        await bot.send_message(chat, f"🎲 {shown} → <b>№{idx + 1}</b> — 🏆 <a href=\"tg://user?id={u}\">{escape(name)}</a>",
                               **_reply(st, panel_msg.message_id))
    res = "\n".join(f"{j + 1}. <a href=\"tg://user?id={ok[i][0]}\">{escape(ok[i][1])}</a> (№{i + 1})"
                    for j, i in enumerate(wins))
    how = (f"\n\n<i>как считала: {k} кубик(а) → число от 0 до {6 ** k - 1} (основание 6: каждая грань минус 1), "
           f"номер = число mod {n} + 1; число ≥ {limit} — переброс, чтобы шансы у всех были равны</i>") if n > 1 else ""
    await bot.send_message(chat, "🏆 <b>итоги розыгрыша</b>\n" + res + how, **_reply(st, panel_msg.message_id))
    await db.kv_set(f"rolllast:{chat}", json.dumps({"ts": int(time.time()), "n": n,
                                                    "wins": [ok[i][0] for i in wins]}))
    now = int(time.time())
    hist = [w for w in json.loads(await db.kv_get(f"rollwins:{chat}") or "[]") if now - w[1] < WIN_DAYS * 86400]
    hist += [[ok[i][0], now] for i in wins]
    await db.kv_set(f"rollwins:{chat}", json.dumps(hist[-500:]))


async def recent_winners(chat: int) -> set[int]:
    """Кто выигрывал /roll в этом чате за WIN_DAYS дней."""
    now = time.time()
    return {w[0] for w in json.loads(await db.kv_get(f"rollwins:{chat}") or "[]") if now - w[1] < WIN_DAYS * 86400}
