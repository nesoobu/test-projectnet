"""Волна 52: редакторы пака для стикер-бота (BOT_PROFILE=stk).
• мастер нового пака: название (своё или 🎲 с именем человека) → ссылка t.me/addstickers/<своя>_by_<бот> (своя
  латиницей, кириллицу транслитерирую, проверяю занятость, или 🎲) → первая картинка. «⚡ всё случайно» — в одно касание
• 🛠 инструменты пака (только владелец): 🔗 новая ссылка (перенос: копия по file_id + удаление старого),
  📥 скачать архивом (PNG/WEBM/TGS), 🧩 эмодзи-версия пака стикеров (Соня+), 👥 соавторы по ссылке-приглашению
• соавторы добавляют стикеры в чужой пак: Bot API позволяет боту добавлять от имени владельца (user_id владельца)
Состояние мастера — kv stk:wiz:<uid> (JSON: k — тип, t — название, s — ссылка, st — шаг: title|link|move)."""
import asyncio
import io
import json
import random
import re
import secrets
import time
import zipfile
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import Message, CallbackQuery, BufferedInputFile, InputSticker

import db
import premium
import ui
from handlers import stickers as S
from handlers.ap_common import kb_rows, show

router = Router()
TITLES = ["{n}: лучшее", "{n} в деле", "{n}.exe", "{n} без фильтров", "мемы — {n}", "эмоции: {n}", "{n} отвечает",
          "{n} на связи", "{n} 24/7", "{n} mood", "{n} и точка", "лицо дня — {n}", "{n} не спит", "{n} одобряет",
          "вайб: {n}", "{n} в шоке"]
WORDS = ["mood", "vibe", "memes", "faces", "mix", "best", "daily", "chaos", "energy", "moments", "pack", "stuff"]
_TR = dict(zip("абвгдеёжзийклмнопрстуфхцчшщъыьэюя",
               ["a", "b", "v", "g", "d", "e", "e", "zh", "z", "i", "y", "k", "l", "m", "n", "o", "p", "r", "s", "t",
                "u", "f", "h", "ts", "ch", "sh", "sch", "", "y", "", "e", "yu", "ya"]))


# ================= ссылка и название =================
def translit(s: str) -> str:
    return "".join(_TR.get(ch, _TR.get(ch.lower(), ch)) for ch in s)


async def _tail(bot: Bot) -> str:
    return f"_by_{(await bot.me()).username}"


def clean_slug(text: str, tail: str) -> str:
    """Своя часть ссылки по правилам Telegram: латиница, цифры, «_», с буквы, без «__», всего ≤ 64."""
    s = translit(text.strip()).replace(" ", "_").replace("-", "_").replace(".", "_")
    s = re.sub(r"[^A-Za-z0-9_]", "", s)
    s = re.sub(r"_+", "_", s)
    s = re.sub(r"^[^A-Za-z]+", "", s).strip("_")
    return s[:64 - len(tail)].rstrip("_")


def rand_title(name: str) -> str:
    return random.choice(TITLES).format(n=(name or "мой пак")[:30])


def rand_slug(name: str, tail: str) -> str:
    base = clean_slug(name, tail)[:12] or "pack"
    return clean_slug(f"{base}_{random.choice(WORDS)}_{secrets.token_hex(2)}", tail)


async def slug_free(bot: Bot, slug: str) -> bool:
    name = slug + await _tail(bot)
    if await db.q_one("SELECT id FROM sticker_packs WHERE lower(name)=lower(?)", name):
        return False
    return await S._set_of(bot, name) is None


async def wiz_get(uid: int) -> dict | None:
    raw = await db.kv_get(f"stk:wiz:{uid}")
    return json.loads(raw) if raw else None


async def wiz_set(uid: int, w: dict | None):
    if w is None:
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:wiz:{uid}")
    else:
        await db.kv_set(f"stk:wiz:{uid}", json.dumps(w, ensure_ascii=False))


async def busy(uid: int) -> bool:
    """Идёт мастер (ждём название или ссылку) — картинки придержим до конца."""
    w = await wiz_get(uid)
    return bool(w and w.get("st") in ("title", "link"))


async def take(uid: int) -> tuple[str, str]:
    """Для создания пака: (название, своя часть ссылки) из мастера; мастер закрываю."""
    w = await wiz_get(uid) or {}
    if w.get("st") == "ready":
        await wiz_set(uid, None)
        return w.get("t") or "", w.get("s") or ""
    return "", ""


def _url(kind: str, name: str) -> str:
    return S.pack_url({"kind": kind, "name": name})


async def title_view(w: dict):
    kind = w["k"]
    text = (ui.head(S.KIND_ICON[kind], f"Новый пак {S.KIND_NAME[kind]}", "шаг 1 из 2 · название")
            + "\n✍️ напиши, как назовём пак — до 60 символов\n"
            + ui.hint("или доверься случаю — 🎲 придумаю с твоим именем"))
    return text, kb_rows([("🎲 Случайное", "stk:wt", "primary"), ("⚡ Всё случайно", "stk:wr", "success")],
                         [("‹ Назад", "stk:home")])


async def link_view(bot: Bot, w: dict):
    kind = w["k"]
    full = w["s"] + await _tail(bot)
    text = (ui.head(S.KIND_ICON[kind], escape(w["t"]), "шаг 2 из 2 · ссылка на пак")
            + f"\n🔗 <code>t.me/{'addemoji' if kind == 'emoji' else 'addstickers'}/{escape(full)}</code>\n"
            + ui.hint(f"напиши свою — латиницей (кириллицу переведу сама), конец «{await _tail(bot)}» "
                      "Telegram требует обязательно. изменить потом можно только переносом пака"))
    return text, kb_rows([("✅ Готово", "stk:wok", "success"), ("🎲 Другая", "stk:ws")],
                         [("✏️ Другое название", "stk:wb"), ("🎲 Название", "stk:wt")])


async def start(cb: CallbackQuery, kind: str):
    await wiz_set(cb.from_user.id, {"k": kind, "st": "title"})
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:want:{cb.from_user.id}")
    await show(cb, *await title_view({"k": kind}))


async def _to_link(target, bot: Bot, uid: int, w: dict):
    w["st"] = "link"
    if not w.get("s"):
        w["s"] = rand_slug(target.from_user.first_name or "", await _tail(bot))
    await wiz_set(uid, w)
    text, kb = await link_view(bot, w)
    if isinstance(target, CallbackQuery):
        return await show(target, text, kb)
    await target.answer(text, reply_markup=kb)


@router.callback_query(F.data.in_({"stk:wt", "stk:ws", "stk:wb", "stk:wr", "stk:wok"}))
async def cb_wiz(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    w = await wiz_get(uid)
    if not w or w.get("st") not in ("title", "link"):
        return await cb.answer("начни заново: /new", show_alert=True)
    name = cb.from_user.first_name or ""
    tail = await _tail(bot)
    if cb.data == "stk:wt":
        w["t"] = rand_title(name)
        return await _to_link(cb, bot, uid, w)
    if cb.data == "stk:ws":
        w["s"] = rand_slug(name, tail)
        return await _to_link(cb, bot, uid, w)
    if cb.data == "stk:wb":
        w["st"] = "title"
        await wiz_set(uid, w)
        return await show(cb, *await title_view(w))
    if cb.data == "stk:wr":
        w["t"] = rand_title(name)
        for _ in range(3):   # случайная почти всегда свободна, но проверяю
            w["s"] = rand_slug(name, tail)
            if await slug_free(bot, w["s"]):
                break
    if not await slug_free(bot, w["s"]):
        return await cb.answer("эта ссылка уже занята — напиши другую или жми 🎲", show_alert=True)
    await finish(cb, bot, uid, w)


async def finish(cb: CallbackQuery, bot: Bot, uid: int, w: dict):
    w["st"] = "ready"
    await wiz_set(uid, w)
    await db.kv_set(f"stk:want:{uid}", w["k"])
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:cur:{uid}")
    pending = S._pending.pop(uid, None)
    if pending:
        await cb.answer()
        try:
            await cb.message.delete()
        except TelegramBadRequest:
            pass
        return await S.add_many(pending, bot, kind_for_new=w["k"])
    await show(cb, f"{S.KIND_ICON[w['k']]} <b>{escape(w['t'])}</b>\n"
                   f"🔗 {escape(w['s'] + await _tail(bot))}\n\n"
                   "📸 присылай первую картинку — из неё создам пак\n"
                   + ui.hint("можно сразу альбомом, GIF, кружок или текст"),
               kb_rows([("‹ Отмена", "stk:home")]))


async def on_text(m: Message, bot: Bot) -> bool:
    """Ввод в мастер или при переносе пака. True — сообщение моё."""
    uid = m.from_user.id
    w = await wiz_get(uid)
    if not w or w.get("st") not in ("title", "link", "move"):
        return False
    text = (m.text or "").strip()
    if w["st"] == "title":
        if not text:
            return True
        w["t"] = text[:60]
        await _to_link(m, bot, uid, w)
        return True
    tail = await _tail(bot)
    slug = clean_slug(text, tail)
    if len(slug) < 2:
        await m.reply("🔗 ссылка — латиницей, хотя бы 2 буквы, первая — буква. например: <code>cats_2025</code>")
        return True
    if not await slug_free(bot, slug):
        await m.reply(f"😕 <code>{escape(slug + tail)}</code> уже занята — попробуй другую")
        return True
    w["s"] = slug
    if w["st"] == "move":
        await wiz_set(uid, w)
        text, kb = await move_view(bot, uid, w)
        await m.answer(text, reply_markup=kb)
        return True
    await wiz_set(uid, w)
    text, kb = await link_view(bot, w)
    await m.answer("✅ ссылка свободна\n\n" + text, reply_markup=kb)
    return True


# ================= соавторы: доступ =================
async def coauthors(pid: int) -> list[dict]:
    return await db.q_all("SELECT c.uid, COALESCE(u.name, '') AS name FROM sticker_coauthors c "
                          "LEFT JOIN users u ON u.id=c.uid WHERE c.pid=? ORDER BY c.ts", pid)


async def shared_of(uid: int) -> list[dict]:
    return await db.q_all("SELECT p.* FROM sticker_packs p JOIN sticker_coauthors c ON c.pid=p.id "
                          "WHERE c.uid=? ORDER BY p.id", uid)


async def _owned(cb: CallbackQuery) -> dict | None:
    p = await S.pack(cb.from_user.id, cb.data.split(":")[2])
    if not p or p["uid"] != cb.from_user.id:
        await cb.answer("это может только хозяин пака", show_alert=True)
        return None
    return p


# ================= 🛠 инструменты =================
async def tools_view(uid: int, p: dict):
    co = await coauthors(p["id"])
    text = (ui.head("🛠", f"Инструменты · {escape(p['title'])}", f"{p['n']} шт · пак {S.KIND_NAME[p['kind']]}")
            + "\n" + ui.quote("🔗 новая ссылка — перенесу пак, старая перестанет работать\n"
                              "📥 архив — все стикеры файлами: PNG, WEBM, TGS\n"
                              + ("🧩 эмодзи-версия — тот же пак эмодзи 100×100 💎\n" if p["kind"] == "sticker" else "")
                              + f"👥 соавторы — пополняют пак вместе с тобой · сейчас {len(co)}"))
    rows = [[("🔗 Новая ссылка", f"stk:mv:{p['id']}"), ("📥 Архив", f"stk:zip:{p['id']}")]]
    if p["kind"] == "sticker":
        rows.append([("🧩 Эмодзи-версия 💎", f"stk:ev:{p['id']}")])
    rows.append([(f"👥 Соавторы · {len(co)}", f"stk:co:{p['id']}")])
    rows.append([("‹ К паку", f"stk:p:{p['id']}")])
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("stk:t:"))
async def cb_tools(cb: CallbackQuery):
    p = await _owned(cb)
    if p:
        await show(cb, *await tools_view(cb.from_user.id, p))


# ---- 🔗 перенос на новую ссылку ----
async def move_view(bot: Bot, uid: int, w: dict):
    p = await S.pack(uid, w["pid"])
    full = w["s"] + await _tail(bot)
    text = (ui.head("🔗", "Новая ссылка", escape(p["title"]) if p else "")
            + f"\n<code>{escape(p['name']) if p else ''}</code>\n→ <code>{escape(full)}</code>\n"
            + ui.hint("напиши свою (латиницей) или жми 🎲. перенос: создам пак по новой ссылке с теми же стикерами, "
                      "а старый удалю — у тех, кто его добавил, он пропадёт, пусть добавят заново"))
    return text, kb_rows([("✅ Перенести", f"stk:mvy:{w['pid']}", "danger"), ("🎲 Другая", f"stk:mvr:{w['pid']}")],
                         [("Отмена", f"stk:t:{w['pid']}")])


@router.callback_query(F.data.startswith(("stk:mv:", "stk:mvr:")))
async def cb_move(cb: CallbackQuery, bot: Bot):
    p = await _owned(cb)
    if not p:
        return
    w = {"st": "move", "pid": p["id"], "s": rand_slug(cb.from_user.first_name or "", await _tail(bot))}
    await wiz_set(cb.from_user.id, w)
    await show(cb, *await move_view(bot, cb.from_user.id, w))


async def clone(bot: Bot, owner: int, items: list[InputSticker], name: str, title: str, kind: str,
                st: Message | None = None) -> int:
    """Новый пак из готовых стикеров: 50 сразу (предел createNewStickerSet), остальные — по одному."""
    await bot.create_new_sticker_set(user_id=owner, name=name, title=title, stickers=items[:50],
                                     sticker_type="custom_emoji" if kind == "emoji" else "regular")
    n = min(50, len(items))
    for i, it in enumerate(items[50:], 51):
        try:
            await bot.add_sticker_to_set(user_id=owner, name=name, sticker=it)
            n += 1
        except TelegramBadRequest:
            continue
        if st and i % 10 == 0:
            try:
                await st.edit_text(f"⏳ {i}/{len(items)} {S.bar(i, len(items))}")
            except Exception:
                pass
    return n


@router.callback_query(F.data.startswith("stk:mvy:"))
async def cb_move_yes(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    p = await _owned(cb)
    w = await wiz_get(uid)
    if not p or not w or w.get("st") != "move" or w.get("pid") != p["id"]:
        return await cb.answer("начни перенос заново", show_alert=True) if p else None
    if not await slug_free(bot, w["s"]):
        return await cb.answer("эта ссылка уже занята — напиши другую", show_alert=True)
    ss = await S._set_of(bot, p["name"])
    if not ss or not ss.stickers:
        return await cb.answer("не вижу пак в Telegram — попробуй через минуту", show_alert=True)
    await cb.answer()
    await wiz_set(uid, None)
    new = w["s"] + await _tail(bot)
    items = [InputSticker(sticker=s.file_id, format=S._fmt(s), emoji_list=[s.emoji or S.DEFAULT_EMOJI])
             for s in ss.stickers]
    st = await cb.message.edit_text(f"⏳ переношу {len(items)} шт…")
    try:
        n = await clone(bot, uid, items, new, ss.title or p["title"], p["kind"], st)
    except TelegramBadRequest as e:
        return await st.edit_text(f"😕 не вышло: {escape(str(e)[:150])}")
    try:
        await bot.delete_sticker_set(name=p["name"])
    except TelegramBadRequest:
        pass
    await db.q_run("UPDATE sticker_packs SET name=?, n=? WHERE id=?", new, n, p["id"])
    p = await S.pack(uid, p["id"])
    await st.edit_text(f"🔗 <b>готово!</b> новая ссылка:\n<code>{escape(S.pack_url(p))}</code>\n"
                       + ui.hint("старый пак удалён — разошли новую ссылку друзьям"),
                       reply_markup=kb_rows([(f"{S.KIND_ICON[p['kind']]} Открыть", S.pack_url(p)),
                                             ("📤 Поделиться", S.share_url(p))], [("📦 Пак", f"stk:p:{p['id']}")]))


# ---- 📥 архив ----
@router.callback_query(F.data.startswith("stk:zip:"))
async def cb_zip(cb: CallbackQuery, bot: Bot):
    p = await S.pack(cb.from_user.id, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    ss = await S._set_of(bot, p["name"])
    if not ss or not ss.stickers:
        return await cb.answer("пак пустой или Telegram его ещё не обновил", show_alert=True)
    await cb.answer("📥 собираю архив…")

    def _png(raw: bytes) -> bytes:
        from PIL import Image
        out = io.BytesIO()
        Image.open(io.BytesIO(raw)).save(out, "PNG")
        return out.getvalue()
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for i, s in enumerate(ss.stickers, 1):
            raw = io.BytesIO()
            try:
                await bot.download(s.file_id, destination=raw)
            except Exception:
                continue
            data, ext = raw.getvalue(), "webm" if s.is_video else "tgs" if s.is_animated else "png"
            if ext == "png":
                try:
                    data = await asyncio.to_thread(_png, data)
                except Exception:
                    ext = "webp"
            z.writestr(f"{i:03d}.{ext}", data)
    fname = (clean_slug(p["title"], "") or "pack") + ".zip"
    await cb.message.answer_document(BufferedInputFile(buf.getvalue(), fname),
                                     caption=f"📥 «{escape(p['title'])}» — {len(ss.stickers)} файлов")


# ---- 🧩 эмодзи-версия (Соня+) ----
@router.callback_query(F.data.startswith("stk:ev:"))
async def cb_emoji_version(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    p = await _owned(cb)
    if not p:
        return
    if not premium.plus(uid):
        await cb.answer()
        return await premium.upsell(cb.message, uid, "stk_emojiver")
    ss = await S._set_of(bot, p["name"])
    if not ss or not ss.stickers:
        return await cb.answer("пак пустой или Telegram его ещё не обновил", show_alert=True)
    await cb.answer()
    st = await cb.message.answer(f"⏳ делаю эмодзи из {len(ss.stickers)} стикеров… {S.bar(0, 1)}")
    from autopost import media_dl
    import uuid
    items = []
    for i, s in enumerate(ss.stickers[:S.TG_MAX["emoji"]], 1):
        if s.is_animated:
            continue
        try:
            if s.is_video:
                media_dl._dir()
                path = str(media_dl.DL / uuid.uuid4().hex)
                await bot.download(s.file_id, destination=path)
                data = await S.to_webm(path, "emoji")
                items.append(InputSticker(sticker=BufferedInputFile(data, "e.webm"), format="video",
                                          emoji_list=[s.emoji or S.DEFAULT_EMOJI]))
            else:
                raw = io.BytesIO()
                await bot.download(s.file_id, destination=raw)
                data = await asyncio.to_thread(S.to_png, raw.getvalue(), "emoji")
                items.append(InputSticker(sticker=BufferedInputFile(data, "e.png"), format="static",
                                          emoji_list=[s.emoji or S.DEFAULT_EMOJI]))
        except Exception:
            continue
        if i % 5 == 0:
            try:
                await st.edit_text(f"⏳ {i}/{len(ss.stickers)} {S.bar(i, len(ss.stickers))}")
            except Exception:
                pass
    if not items:
        return await st.edit_text("😕 не из чего делать эмодзи")
    tail = await _tail(bot)
    name = rand_slug(cb.from_user.first_name or "", tail) + tail
    title = f"{p['title'][:50]} · эмодзи"
    try:
        n = await clone(bot, uid, items, name, title, "emoji", st)
    except TelegramBadRequest as e:
        return await st.edit_text(f"😕 не вышло: {escape(str(e)[:150])}")
    pid = await db.q_run("INSERT INTO sticker_packs(uid, name, title, kind, n, ts) VALUES(?,?,?,?,?,?)",
                         uid, name, title, "emoji", n, int(time.time()))
    e = {"kind": "emoji", "name": name, "id": pid}
    await st.edit_text(f"🧩 <b>эмодзи-версия готова</b> — {n} шт\n"
                       + ui.hint("ставить такие эмодзи в сообщения могут владельцы Telegram Premium"),
                       reply_markup=kb_rows([("🧩 Открыть", S.pack_url(e)), ("📦 Пак", f"stk:p:{pid}")]))


# ---- 👥 соавторы ----
async def co_view(bot: Bot, uid: int, p: dict):
    co = await coauthors(p["id"])
    inv = await db.kv_get(f"stk:inv:{p['id']}")
    if not inv:
        inv = secrets.token_hex(4)
        await db.kv_set(f"stk:inv:{p['id']}", inv)
    me = await bot.me()
    link = f"https://t.me/{me.username}?start=stkj_{p['id']}_{inv}"
    names = "\n".join(f"• {escape(c['name'] or str(c['uid']))}" for c in co) or "пока никого"
    text = (ui.head("👥", "Соавторы", escape(p["title"]))
            + f"\n{names}\n\n" + ui.hint("соавторы добавляют стикеры и меняют эмодзи. удалить пак, переименовать "
                                         "и звать других можешь только ты. лимит пака — по твоей Соне+"))
    share = "https://t.me/share/url?url=" + S.quote_url(link) + "&text=" + S.quote_url("делаем стикеры вместе 🧩")
    rows = [[("📤 Пригласить", share, "success")],
            [("🔄 Новая ссылка-приглашение", f"stk:coi:{p['id']}")]]
    if co:
        rows.append([("🚫 Убрать всех", f"stk:cox:{p['id']}", "danger")])
    rows.append([("‹ Инструменты", f"stk:t:{p['id']}")])
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith(("stk:co:", "stk:coi:", "stk:cox:")))
async def cb_co(cb: CallbackQuery, bot: Bot):
    p = await _owned(cb)
    if not p:
        return
    if cb.data.startswith("stk:coi:"):
        await db.kv_set(f"stk:inv:{p['id']}", secrets.token_hex(4))
    if cb.data.startswith("stk:cox:"):
        await db.q_run("DELETE FROM sticker_coauthors WHERE pid=?", p["id"])
        await db.kv_set(f"stk:inv:{p['id']}", secrets.token_hex(4))   # и старое приглашение больше не работает
    await show(cb, *await co_view(bot, cb.from_user.id, p))


async def join(m: Message, bot: Bot, arg: str) -> bool:
    """/start stkj_<pid>_<код> — стать соавтором пака."""
    try:
        _, pid, code = arg.split("_", 2)
        pid = int(pid)
    except ValueError:
        return False
    uid = m.from_user.id
    p = await db.q_one("SELECT * FROM sticker_packs WHERE id=?", pid)
    if not p or await db.kv_get(f"stk:inv:{pid}") != code:
        await m.answer("😕 приглашение устарело — попроси новое")
        return True
    if p["uid"] == uid:
        await m.answer("это твой же пак 🙂")
        return True
    await db.q_run("INSERT OR IGNORE INTO sticker_coauthors(pid, uid, ts) VALUES(?,?,?)", pid, uid, int(time.time()))
    await db.kv_set(f"stk:cur:{uid}", str(pid))
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:want:{uid}")
    await m.answer(f"👥 ты соавтор пака «{escape(p['title'])}»!\n"
                   + ui.hint("присылай картинки — они попадут прямо туда"),
                   reply_markup=kb_rows([(f"{S.KIND_ICON[p['kind']]} Открыть пак", S.pack_url(p))]))
    try:
        await bot.send_message(p["uid"], f"👥 {escape(m.from_user.first_name or 'кто-то')} теперь соавтор "
                                         f"«{escape(p['title'])}»")
    except Exception:
        pass
    return True
