"""Волна 57: 💬 обратная связь во всех ботах — а приходит всё владельцу в основную Соню.
Как устроено: общая очередь — таблица feedback в базе ОСНОВНОЙ Сони (config.MAIN_DB_PATH, все боты на одном
сервере). Любой бот пишет туда отзыв (скрин кладёт файлом в data/feedback/). Основная Соня раз в 10 с забирает
новые и шлёт владельцу с кнопками ↩️ Ответить · ✅ Закрыть · 🚫 Блок; ответить можно и просто реплаем.
Ответ записывается в ту же строку — и каждый бот сам доставляет ответы СВОИМ пользователям (человек мог
никогда не запускать основную Соню). Лимит — 5 отзывов в день на человека, блок — во всех ботах сразу."""
import asyncio
import logging
import sqlite3
import time
from html import escape
from pathlib import Path

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile

import config
import db
import ui
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("feedback")
DAY_LIMIT = 5
KINDS = {"bug": "🐞 Ошибка", "idea": "💡 Идея", "thx": "❤️ Спасибо", "other": "💬 Другое"}
FILES = config.BASE / "data" / "feedback"
SCHEMA = ("CREATE TABLE IF NOT EXISTS feedback(id INTEGER PRIMARY KEY AUTOINCREMENT, profile TEXT, uid INTEGER, "
          "name TEXT, username TEXT, kind TEXT, text TEXT, file TEXT DEFAULT '', ts INTEGER, status TEXT DEFAULT 'new', "
          "owner_mid INTEGER DEFAULT 0, answer TEXT DEFAULT '', delivered INTEGER DEFAULT 0)",
          "CREATE TABLE IF NOT EXISTS feedback_blocks(uid INTEGER PRIMARY KEY, ts INTEGER)")


# ================= общая очередь в базе основной Сони =================
def _q(sql: str, args: tuple = (), many: bool = False, write: bool = False):
    con = sqlite3.connect(config.MAIN_DB_PATH, timeout=15)
    con.row_factory = sqlite3.Row
    try:
        for s in SCHEMA:
            con.execute(s)
        cur = con.execute(sql, args)
        if write:
            con.commit()
            return cur.lastrowid
        return [dict(r) for r in cur.fetchall()] if many else (dict(cur.fetchone() or {}) or None)
    finally:
        con.close()


async def q(sql: str, *args, many: bool = False, write: bool = False):
    return await asyncio.to_thread(_q, sql, args, many, write)


def bot_name() -> str:
    import fleet
    return fleet.NAMES.get(config.PROFILE, config.PROFILE)


# ================= пользователь пишет =================
def start_kb():
    return kb_rows([(KINDS["bug"], "fb:k:bug"), (KINDS["idea"], "fb:k:idea")],
                   [(KINDS["thx"], "fb:k:thx"), (KINDS["other"], "fb:k:other")])


async def open_form(target, uid: int):
    text = ("💬 <b>Обратная связь</b>\n"
            "что сломалось, чего не хватает, что понравилось — читаю всё сама, отвечу сюда же\n"
            + ui.hint("выбери, о чём, и напиши одним сообщением. можно приложить скрин"))
    if isinstance(target, CallbackQuery):
        return await show(target, text, start_kb())
    await target.answer(text, reply_markup=start_kb())


@router.message(Command("feedback", "отзыв", "support"), F.chat.type == "private")
async def cmd_feedback(m: Message):
    await open_form(m, m.from_user.id)


@router.callback_query(F.data == "fb:open")
async def cb_open(cb: CallbackQuery):
    await open_form(cb, cb.from_user.id)


@router.callback_query(F.data.startswith("fb:k:"))
async def cb_kind(cb: CallbackQuery):
    kind = cb.data[5:]
    if kind not in KINDS:
        return await cb.answer()
    await db.kv_set(f"fb:wait:{cb.from_user.id}", kind)
    hint = {"bug": "что делал(а) и что пошло не так? скрин очень поможет",
            "idea": "что добавить или как сделать удобнее?", "thx": "буду рада 🖤",
            "other": "пиши как есть"}[kind]
    await show(cb, f"{KINDS[kind]}\n✍️ напиши одним сообщением\n" + ui.hint(hint),
               kb_rows([("‹ Назад", "fb:open"), ("✖️ Отмена", "fb:no")]))


@router.callback_query(F.data == "fb:no")
async def cb_no(cb: CallbackQuery):
    await db.q_run("DELETE FROM kv WHERE k=?", f"fb:wait:{cb.from_user.id}")
    await show(cb, "ок, если что — /feedback 🙂")


async def _waiting(m: Message) -> bool | dict:
    if m.chat.type != "private" or not m.from_user or (m.text or "").startswith("/"):
        return False
    if not (m.text or m.caption or m.photo):
        return False
    kind = await db.kv_get(f"fb:wait:{m.from_user.id}")
    return {"fb_kind": kind} if kind else False


@router.message(_waiting)
async def on_text(m: Message, bot: Bot, fb_kind: str):
    uid = m.from_user.id
    await db.q_run("DELETE FROM kv WHERE k=?", f"fb:wait:{uid}")
    if await q("SELECT uid FROM feedback_blocks WHERE uid=?", uid):
        return await m.answer("💬 спасибо, получила")   # заблокированным — без подробностей
    n = await q("SELECT COUNT(*) n FROM feedback WHERE uid=? AND ts>?", uid, int(time.time()) - 86400)
    if n and n["n"] >= DAY_LIMIT:
        return await m.answer(f"на сегодня уже {DAY_LIMIT} сообщений — давай завтра, я всё прочитаю 🙂")
    text = (m.text or m.caption or "").strip()[:3000]
    fid = await q("INSERT INTO feedback(profile, uid, name, username, kind, text, ts) VALUES(?,?,?,?,?,?,?)",
                  config.PROFILE, uid, (m.from_user.full_name or "")[:60], m.from_user.username or "",
                  fb_kind, text, int(time.time()), write=True)
    if m.photo:   # скрин — файлом на общий диск: file_id другого бота основной Соне не подходит
        try:
            FILES.mkdir(parents=True, exist_ok=True)
            path = FILES / f"{fid}.jpg"
            await bot.download(m.photo[-1].file_id, destination=str(path))
            await q("UPDATE feedback SET file=? WHERE id=?", path.name, fid, write=True)
        except Exception as e:
            log.info("feedback photo: %s", e)
    await m.answer("✅ <b>отправила!</b> прочитаю и отвечу сюда же\n" + ui.hint(f"номер обращения #{fid}"),
                   reply_markup=kb_rows([("💬 Написать ещё", "fb:open")]))


# ================= владелец в основной Соне =================
def owner_text(r: dict) -> str:
    import fleet
    who = escape(r["name"] or "?") + (f" @{escape(r['username'])}" if r.get("username") else "")
    head = f"💬 <b>#{r['id']}</b> · {fleet.NAMES.get(r['profile'], r['profile'])} · {KINDS.get(r['kind'], r['kind'])}"
    body = ui.quote(escape(r["text"] or "(без текста)")[:3500])
    tail = f"👤 {who} · <code>{r['uid']}</code>"
    if r.get("answer"):
        tail += f"\n↩️ <b>ответ:</b> {escape(r['answer'][:500])}"
    if r["status"] == "closed":
        tail += "\n✅ закрыт"
    return f"{head}\n{body}\n{tail}"


def owner_kb(r: dict):
    if r["status"] == "closed":
        return kb_rows([("↩️ Ответить", f"fb:a:{r['id']}")])
    return kb_rows([("↩️ Ответить", f"fb:a:{r['id']}", "success"), ("✅ Закрыть", f"fb:x:{r['id']}")],
                   [("🚫 Блок", f"fb:b:{r['id']}", "danger")])


async def pump_new(bot: Bot):
    """Основная Соня: новые отзывы из всех ботов — владельцу."""
    if not config.OWNER_ID:
        return
    for r in await q("SELECT * FROM feedback WHERE owner_mid=0 ORDER BY id LIMIT 20", many=True):
        try:
            path = FILES / r["file"] if r.get("file") else None
            if path and path.exists():
                sent = await bot.send_photo(config.OWNER_ID, FSInputFile(str(path)), caption=owner_text(r)[:1024],
                                            reply_markup=owner_kb(r))
            else:
                sent = await bot.send_message(config.OWNER_ID, owner_text(r), reply_markup=owner_kb(r))
            await q("UPDATE feedback SET owner_mid=? WHERE id=?", sent.message_id, r["id"], write=True)
        except Exception as e:
            log.warning("feedback → owner: %s", e)
            return


async def pump_answers(bot: Bot):
    """Каждый бот: ответы владельца — своим пользователям."""
    for r in await q("SELECT * FROM feedback WHERE profile=? AND answer<>'' AND delivered=0 LIMIT 20",
                     config.PROFILE, many=True):
        try:
            await bot.send_message(r["uid"], f"💬 <b>ответ на твоё сообщение #{r['id']}</b>\n"
                                             + ui.quote(escape(r["answer"])[:3500]),
                                   reply_markup=kb_rows([("💬 Ответить", "fb:open")]))
        except Exception as e:
            log.info("feedback answer → %s: %s", r["uid"], e)
        await q("UPDATE feedback SET delivered=1 WHERE id=?", r["id"], write=True)


async def loop(bot: Bot):
    while True:
        try:
            if config.PROFILE == "full":
                await pump_new(bot)
            await pump_answers(bot)
        except Exception as e:
            log.warning("feedback loop: %s", e)
        await asyncio.sleep(10)


def _owner(ev) -> bool:
    return bool(config.OWNER_ID and ev.from_user and ev.from_user.id == config.OWNER_ID and config.PROFILE == "full")


async def _refresh_owner(bot: Bot, r: dict):
    r = await q("SELECT * FROM feedback WHERE id=?", r["id"])
    try:
        if r.get("file"):
            await bot.edit_message_caption(chat_id=config.OWNER_ID, message_id=r["owner_mid"],
                                           caption=owner_text(r)[:1024], reply_markup=owner_kb(r))
        else:
            await bot.edit_message_text(owner_text(r), chat_id=config.OWNER_ID, message_id=r["owner_mid"],
                                        reply_markup=owner_kb(r))
    except Exception:
        pass


@router.callback_query(F.data.regexp(r"^fb:[axb]:\d+$"), _owner)
async def cb_owner(cb: CallbackQuery, bot: Bot):
    act, fid = cb.data.split(":")[1], int(cb.data.split(":")[2])
    r = await q("SELECT * FROM feedback WHERE id=?", fid)
    if not r:
        return await cb.answer("не нашла", show_alert=True)
    if act == "a":
        await db.kv_set(f"fb:ans:{cb.from_user.id}", str(fid))
        return await cb.answer(f"✍️ напиши ответ на #{fid} одним сообщением (или ответь реплаем на отзыв)",
                               show_alert=True)
    if act == "x":
        await q("UPDATE feedback SET status='closed' WHERE id=?", fid, write=True)
        await cb.answer("✅ закрыт")
    else:
        await q("INSERT OR REPLACE INTO feedback_blocks VALUES(?,?)", r["uid"], int(time.time()), write=True)
        await q("UPDATE feedback SET status='closed' WHERE uid=? AND status='new'", r["uid"], write=True)
        await cb.answer("🚫 больше не будет писать ни в один бот", show_alert=True)
    await _refresh_owner(bot, r)


async def _answer_target(m: Message) -> bool | dict:
    if not _owner(m) or m.chat.type != "private" or not m.text or m.text.startswith("/"):
        return False
    if m.reply_to_message:
        r = await q("SELECT id FROM feedback WHERE owner_mid=?", m.reply_to_message.message_id)
        if r:
            return {"fb_id": r["id"]}
    fid = await db.kv_get(f"fb:ans:{m.from_user.id}")
    return {"fb_id": int(fid)} if fid else False


@router.message(_answer_target)
async def on_answer(m: Message, bot: Bot, fb_id: int):
    await db.q_run("DELETE FROM kv WHERE k=?", f"fb:ans:{m.from_user.id}")
    r = await q("SELECT * FROM feedback WHERE id=?", fb_id)
    if not r:
        return await m.reply("не нашла обращение")
    await q("UPDATE feedback SET answer=?, delivered=0, status='closed' WHERE id=?", m.text[:3500], fb_id, write=True)
    await m.reply(f"↩️ ответ на #{fb_id} уйдёт через {escape(bot_name_of(r['profile']))} в течение ~10 с")
    await _refresh_owner(bot, r)


def bot_name_of(profile: str) -> str:
    import fleet
    return fleet.NAMES.get(profile, profile)


@router.message(Command("feedbacks", "отзывы"), _owner)
async def cmd_list(m: Message):
    rows = await q("SELECT * FROM feedback WHERE status='new' ORDER BY id DESC LIMIT 15", many=True)
    if not rows:
        return await m.answer("💬 новых отзывов нет 🎉")
    lines = [f"💬 <b>открытые отзывы · {len(rows)}</b>"]
    for r in rows:
        lines.append(f"#{r['id']} · {bot_name_of(r['profile'])} · {KINDS.get(r['kind'], '')} — "
                     f"{escape((r['text'] or '')[:60])}")
    await m.answer("\n".join(lines) + "\n" + ui.hint("ответить — реплаем на сообщение отзыва или кнопкой под ним"))
