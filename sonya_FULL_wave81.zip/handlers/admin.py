import asyncio
import logging
from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter, TelegramBadRequest

import time
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery

import config
import tgapi
import db
import ui
from autopost import store as ap_store, timeparse
from handlers.ap_common import show, kb_rows

STARTED = time.time()

router = Router()
log = logging.getLogger("admin")
owner = F.from_user.id == config.OWNER_ID


class Adm(StatesGroup):
    broadcast = State()


async def admin_view():
    s = await db.stats()
    g = await ap_store.global_counts()
    text = (
        ui.head("⚙️", "Админка Сони", "всё под контролем")
        + "\n" + ui.stats(("👥 юзеров", f"{s['total']}  (+{s['new']} за сутки)"), ("🟢 активны за сутки", s["active"]),
                          ("💬 групп", s["chats"]), ("⭐ донатов", s["stars"]))
        + "\n" + ui.stats(("🧠 ИИ сегодня", f"{s['ai_calls']} запросов · {s['ai_tokens'] // 1000}k токенов"
                            + (f" · ❌ {s['ai_fails']}" if s["ai_fails"] else "")))
        + "\n" + ui.stats(("📢 каналов", g["channels"]), ("🤖 источников", f"{g['active']}/{g['rules']}"),
                          ("📤 постов за сутки", g["sent24"]), ("📅 в очереди", g["queue"]),
                          ("⚠️ источников с ошибками", g["errors"]) if g["errors"] else ("", ""))
    )
    kb = kb_rows(
        [("🔄 Обновить", "adm:home"), ("📣 Рассылка", "adm:bc")],
        [("👥 Юзеры", "adm:users"), ("🚫 Баны", "adm:bans")],
        [("📢 Все каналы", "adm:chs"), (f"⚠️ Ошибки · {g['errors']}" if g["errors"] else "⚠️ Ошибки", "adm:errs")],
        [("🧠 Проверить ИИ", "adm:ai"), ("📈 Расход ИИ", "adm:aistat")],
        [("📊 Графики и воронка", "adm:charts"), ("🗂 Сервер", "adm:srv")],
        [("📝 Профиль бота", "adm:bio"), ("📥 Скачивания", "adm:dls")],
        [("🤝 Помощники", "adm:helpers"), ("💰 Доходы", "adm:money")] if config.PROFILE == "full" else [],
        [("🩺 Здоровье ботов", "adm:fleet")] if config.PROFILE == "full" else [],
        [("📢 Мой автопостинг", "ap:home"), ("🎨 Интерфейс", "ui:home")],
    )
    return text, kb


BACK = [("‹ Админка", "adm:home")]


@router.message(Command("admin"), owner)
async def cmd_admin(m: Message, state: FSMContext):
    await state.clear()
    await show(m, *await admin_view())


@router.callback_query(F.data == "adm:home", owner)
async def cb_adm(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, *await admin_view())


@router.callback_query(F.data == "adm:users", owner)
async def cb_users(cb: CallbackQuery):
    us = await db.users_recent(15)
    lines = ["<b>👥 последние активные</b>", ui.LINE]
    for u in us:
        tag = f" @{u['username']}" if u["username"] else ""
        ban = " 🚫" if u["banned"] else ""
        lines.append(f"• {ui.esc(u['name'])}{ui.esc(tag)} · <code>{u['id']}</code> · 💬{u['msgs']} · "
                     f"{timeparse.fmt(u['last_seen'])}{ban}")
    lines.append("\n<i>/user id или @ник — карточка с выдачей 🪙 и Соня+ · /ban id · /unban id</i>")
    await show(cb, "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:bans", owner)
async def cb_bans(cb: CallbackQuery):
    us = await db.users_banned()
    text = "<b>🚫 баны</b>\n" + ui.LINE + ("\n<i>никого</i>" if not us else "")
    rows = [[(f"✅ разбанить {u['name'][:20]}", f"adm:unban:{u['id']}")] for u in us]
    await show(cb, text, kb_rows(*rows, BACK))


@router.callback_query(F.data.startswith("adm:unban:"), owner)
async def cb_unban(cb: CallbackQuery):
    await db.set_banned(int(cb.data.split(":")[2]), False)
    await cb_bans(cb)


@router.callback_query(F.data == "adm:chs", owner)
async def cb_all_ch(cb: CallbackQuery):
    chs = await ap_store.all_channels()
    lines = ["<b>📢 все каналы</b>", ui.LINE]
    if not chs:
        lines.append("<i>пусто</i>")
    for c in chs:
        st = "⏸" if c["paused"] else "🟢"
        lines.append(f"{st} {ui.esc(c['title'][:30])} · 🤖{c['nrules']} · владелец <code>{c['owner_id']}</code>")
    await show(cb, "\n".join(lines[:60]), kb_rows(BACK))


@router.callback_query(F.data == "adm:errs", owner)
async def cb_all_errs(cb: CallbackQuery):
    rs = await ap_store.errors_of(None)
    lines = ["<b>⚠️ ошибки источников</b>", ui.LINE]
    if not rs:
        lines.append("<i>всё чисто ✨</i>")
    for r in rs[:25]:
        lines.append(f"• <b>{ui.esc(r['title'][:25])}</b> ({r['type']}) → {ui.esc((r['ch_title'] or '?')[:20])}\n"
                     f"   <i>{ui.esc(r['last_error'][:120])}</i>")
    await show(cb, "\n".join(lines), kb_rows(BACK))


def draw_chart(days: list[str], dau: list[int], new: list[int]) -> bytes:
    """Столбики — активные за день, линия — новые."""
    import io
    from PIL import Image, ImageDraw
    from handlers.tools import _font
    W, H, pad = 900, 460, 50
    im = Image.new("RGB", (W, H), (22, 22, 28))
    d = ImageDraw.Draw(im)
    top = max(dau + new + [1])
    n = len(days)
    bw = (W - 2 * pad) / max(1, n)
    f, fs = _font(16), _font(13)
    d.text((pad, 14), "активные за день (столбики) · новые (линия)", font=f, fill=(220, 220, 230))
    pts = []
    for i, (a, b) in enumerate(zip(dau, new)):
        x = pad + i * bw
        y = H - pad - (H - 2 * pad - 20) * a / top
        d.rectangle([x + 2, y, x + bw - 2, H - pad], fill=(140, 110, 250))
        pts.append((x + bw / 2, H - pad - (H - 2 * pad - 20) * b / top))
        if i % 5 == 0 or i == n - 1:
            d.text((x, H - pad + 6), days[i][5:], font=fs, fill=(160, 160, 170))
    if len(pts) > 1:
        d.line(pts, fill=(255, 190, 80), width=3)
    d.text((W - pad - 60, 14), f"макс {top}", font=fs, fill=(160, 160, 170))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


async def funnel_text() -> str:
    now = int(time.time())
    since = now - 30 * 86400
    users = await db.q_all("SELECT id, joined FROM users WHERE joined>?", since)
    n = len(users)
    if not n:
        return "<i>за 30 дней новых нет</i>"
    back = week = paid = 0
    for u in users:
        d0 = db._day(u["joined"])
        rows = await db.q_all("SELECT day FROM daily_active WHERE uid=? AND day>?", u["id"], d0)
        days = sorted(r["day"] for r in rows)
        if days and days[0] <= db._day(u["joined"] + 2 * 86400):
            back += 1
        if days and days[-1] >= db._day(u["joined"] + 7 * 86400):
            week += 1
    paid = (await db.q_one("SELECT COUNT(DISTINCT user_id) AS n FROM donations WHERE user_id IN "
                           "(SELECT id FROM users WHERE joined>?)", since))["n"]
    pct = lambda x: f"{x} ({round(x / n * 100)}%)"
    return (f"<b>🔻 воронка новичков за 30 дней</b>\n"
            f"👋 пришли: <b>{n}</b>\n↩️ вернулись в первые 2 дня: <b>{pct(back)}</b>\n"
            f"📅 активны через неделю: <b>{pct(week)}</b>\n⭐ платили: <b>{pct(paid)}</b>")


@router.callback_query(F.data == "adm:charts", owner)
async def cb_charts(cb: CallbackQuery):
    from aiogram.types import BufferedInputFile
    await cb.answer("рисую…")
    now = int(time.time())
    days = [db._day(now - i * 86400) for i in range(29, -1, -1)]
    dau_rows = {r["day"]: r["n"] for r in await db.q_all(
        "SELECT day, COUNT(*) AS n FROM daily_active WHERE day>=? GROUP BY day", days[0])}
    new_rows = {}
    for r in await db.q_all("SELECT joined FROM users WHERE joined>?", now - 31 * 86400):
        k = db._day(r["joined"])
        new_rows[k] = new_rows.get(k, 0) + 1
    dau = [dau_rows.get(d, 0) for d in days]
    new = [new_rows.get(d, 0) for d in days]
    wau = (await db.q_one("SELECT COUNT(DISTINCT uid) AS n FROM daily_active WHERE day>=?", days[-7]))["n"]
    mau = (await db.q_one("SELECT COUNT(DISTINCT uid) AS n FROM daily_active WHERE day>=?", days[0]))["n"]
    stick = round(dau[-1] / mau * 100) if mau else 0
    png = await asyncio.to_thread(draw_chart, days, dau, new)
    cap = (f"📊 сегодня: <b>{dau[-1]}</b> · за неделю: <b>{wau}</b> · за месяц: <b>{mau}</b>\n"
           f"липкость (DAU/MAU): <b>{stick}%</b> · новых за 30 дн.: <b>{sum(new)}</b>\n\n" + await funnel_text())
    await cb.message.answer_photo(BufferedInputFile(png, "chart.png"), caption=cap[:1024],
                                  reply_markup=kb_rows(BACK))


@router.callback_query(F.data == "adm:aistat", owner)
async def cb_aistat(cb: CallbackQuery):
    import llm as _llm
    rows = await db.q_all("SELECT day, SUM(calls) AS c, SUM(tokens) AS t, SUM(fails) AS f FROM ai_stats "
                          "GROUP BY day ORDER BY day DESC LIMIT 7")
    feats = await db.q_all("SELECT feature, calls, tokens FROM ai_stats WHERE day=? ORDER BY tokens DESC", db._day())
    lines = ["<b>📈 расход ИИ</b>", ui.LINE, "<b>по дням</b>"]
    lines += [f"{r['day'][5:]} · {r['c']} запр. · {r['t'] // 1000}k ток." + (f" · ❌{r['f']}" if r["f"] else "")
              for r in rows] or ["<i>пусто</i>"]
    if feats:
        lines += ["", "<b>сегодня по фичам</b>"]
        lines += [f"• {ui.esc(r['feature'])}: {r['calls']} · {r['tokens'] // 1000}k" for r in feats]
    lim = config.AI_DAY_LIMIT
    if lim:
        hit = await db.q_one("SELECT COUNT(*) AS n FROM ai_usage WHERE day=? AND n>=?", db._day(), lim)
        lines += ["", f"лимит {lim}/день (Соня+ {config.AI_DAY_LIMIT_PLUS or '∞'}) · упёрлись сегодня: <b>{hit['n']}</b>"]
    chain = " → ".join(m for _u, _k, m in _llm.chain())
    lines += ["", f"<i>цепочка: {ui.esc(chain)}</i>"]
    await show(cb, "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:ai", owner)
async def cb_ai(cb: CallbackQuery):
    await cb.answer("проверяю…")
    import llm as _llm
    res = []
    t0 = time.time()
    try:
        out = await _llm.ask([{"role": "user", "content": "Ответь одним словом: ок"}], max_tokens=300)
        res.append(f"✅ текст ({config.LLM_MODEL}): «{ui.esc(out[:30])}» за {time.time() - t0:.1f}с")
    except Exception as e:
        res.append(f"❌ текст: <code>{ui.esc(str(e)[:150])}</code>")
    t0 = time.time()
    try:
        out = await _llm.ask_vision("Опиши картинку двумя словами.", "что тут?",
                                    "https://upload.wikimedia.org/wikipedia/commons/3/3a/Cat03.jpg")
        res.append(f"✅ зрение ({config.LLM_VISION_MODEL}): «{ui.esc(out[:40])}» за {time.time() - t0:.1f}с")
    except Exception as e:
        res.append(f"⚠️ зрение: <code>{ui.esc(str(e)[:150])}</code>\n<i>подписи будут по контексту, без картинки</i>")
    await show(cb.message, "<b>🧠 проверка ИИ</b>\n" + ui.LINE + "\n" + "\n".join(res), kb_rows(BACK))


def _size(path) -> int:
    import os
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


@router.callback_query(F.data == "adm:srv", owner)
async def cb_srv(cb: CallbackQuery):
    import shutil
    import system
    try:
        import yt_dlp
        ytv = yt_dlp.version.__version__
    except Exception:
        ytv = "не установлен"
    du = shutil.disk_usage(str(config.BASE))
    data = _size(config.BASE / "data") / 1024 / 1024
    lines = [
        "<b>🗂 сервер</b>", ui.LINE,
        f"💾 диск: свободно <b>{du.free / 1024**3:.1f} ГБ</b> из {du.total / 1024**3:.1f}",
        f"🗃 данные сони: <b>{data:.1f} МБ</b>",
        f"⏱ работаю: <b>{(time.time() - STARTED) / 3600:.1f} ч</b>",
        f"🎬 yt-dlp: <b>{ytv}</b> · ffmpeg: <b>{'есть' if shutil.which('ffmpeg') else 'нет'}</b>",
        # волна 54: с yt-dlp 2025.11 YouTube без JS-движка (Deno) и пакета yt-dlp-ejs отдаёт 403 и мало форматов
        f"🦕 deno: <b>{'есть' if shutil.which('deno') else '❌ нет — YouTube будет падать с 403'}</b>",
        f"📦 Bot API: <b>{tgapi.status()}</b>",
        f"💾 бэкап: <b>{system.backup_state()}</b>",
        "",
        "💾 бэкап базы приходит тебе каждый день в 04:00.",
        "<b>восстановить:</b> закинь файл в /root и выполни:",
        "<code>systemctl stop sonya</code>",
        # волна 61: зашифрованный (.enc) — openssl спросит пароль из BACKUP_PASS
        f"<code>{system.DECRYPT} -in /root/ФАЙЛ.db.gz.enc | gunzip &gt; /home/sonya/sonya/data/sonya.db</code>"
        if config.BACKUP_PASS else "<code>gunzip -c /root/ФАЙЛ.db.gz &gt; /home/sonya/sonya/data/sonya.db</code>",
        "<code>chown sonya:sonya /home/sonya/sonya/data/sonya.db; systemctl start sonya</code>",
    ]
    await show(cb, "\n".join(lines), kb_rows([("💾 Бэкап сейчас", "adm:bak"), ("⬆️ Обновить yt-dlp", "adm:ytup")],
                                                [("🧪 Проверить музыку", "adm:mus"), ("🖼 Обложки", "bn:home")],
                                                [("✨ Эмодзи Сони", "em:home")], BACK))


# ================= волна 68/70: анимированные премиум-эмодзи Сони =================
# Паки: 0 — «Соня · эмоции» (лицо Сони и ручные значки), 1..N — анимированные версии всех эмодзи из текстов бота.
PACK_MAX = 200     # лимит Telegram на пак custom emoji
FIRST_BATCH = 50   # createNewStickerSet — не больше 50 за раз, остальное по одному


class EmImport(StatesGroup):
    wait = State()


async def _moji_packs(bot: Bot) -> list[tuple[str, str, list[str]]]:
    """[(имя пака, название, ключи)] — что должно быть в паках. Волна 75: раскладка стабильная — эмодзи, уже
    лежащий в паке, там и остаётся; новые доливаются в паки, где есть место (иначе при смене порядка
    эмодзи «переезжали» бы и паки переполнялись)."""
    import json
    import sonyamoji
    me = await bot.me()
    inv = await asyncio.to_thread(sonyamoji.inventory)
    out = [(f"sonya_emoji_by_{me.username}", "Соня · эмоции", list(sonyamoji.SET))]
    placed, packs = set(), []
    k = 1
    while True:
        name = f"sonya_moji{k}_by_{me.username}"
        order = json.loads(await db.kv_get(f"moji:order:{name}") or "[]")
        if not order and k > 1 and len(packs) * PACK_MAX >= len(inv) + len(placed):
            break
        packs.append([name, f"Соня · эмодзи {k}", list(order)])
        placed |= set(order)
        k += 1
        if k > 10:
            break
    for e in inv:
        if e in placed:
            continue
        for p in packs:
            if len(p[2]) < PACK_MAX:
                p[2].append(e)
                break
        else:
            n = len(packs) + 1
            packs.append([f"sonya_moji{n}_by_{me.username}", f"Соня · эмодзи {n}", [e]])
        placed.add(e)
    return out + [tuple(p) for p in packs if p[2]]


async def emoji_view() -> tuple[str, object]:
    import json
    import moji
    import sonyamoji
    packs = json.loads(await db.kv_get("moji:packs") or "[]")
    mp = json.loads(await db.kv_get("moji:map") or "{}")
    ex = json.loads(await db.kv_get("moji:extra") or "{}")
    lines = [ui.head("✨", "Эмодзи Сони", f"лицо Сони · {len(sonyamoji.EMOTIONS) + 2} эмоций · всё анимированное")]
    if packs:
        lines.append(ui.quote("\n".join(f"• <a href=\"https://t.me/addemoji/{n}\">{t}</a>" for n, t in packs)
                              + f"\nпремиум-версий: <b>{len(mp)}</b>" + (f" · из чужих паков: <b>{len(ex)}</b>" if ex else "")))
        st = "⛔ Telegram не принял — пауза до " + time.strftime("%H:%M", time.localtime(moji.OFF["until"])) \
            if moji.OFF["until"] > time.time() else ("включена" if moji.OPT["text"] else "выключена")
        lines.append(f"замена в текстах: <b>{st}</b> · иконки на кнопках: <b>{'да' if moji.OPT['btn'] else 'нет'}</b>")
        if await db.kv_get("moji:artver") != sonyamoji.ART:
            lines.append(ui.quote("🆕 <b>новая анимация</b>: настоящая у ~200 эмодзи (рукопожатие трясётся, огонь горит, "
                                  "кубик катится) и смысловая у остальных (флаг развевается, машина едет). "
                                  "нажми «✨ Обновить анимацию» — заменю на месте, ~15 минут"))
            rows0 = [[("✨ Обновить анимацию", "em:make", "success")]]
        else:
            rows0 = []
        rows = rows0 + [[(("⏸ Не менять в текстах" if moji.OPT["text"] else "▶️ Менять в текстах"), "em:tt"),
                 (("⏸ Без иконок" if moji.OPT["btn"] else "▶️ Иконки на кнопки"), "em:tb")],
                [("🔄 Дособрать паки", "em:make", "success"), ("➕ Импорт пака", "em:imp")],
                [("👀 Лицо Сони", "em:pv"), ("👀 Все эмодзи", "em:pa")]]
        if ex:
            rows.append([("🧹 Забыть импорт", "em:exc")])
    else:
        lines.append(ui.quote("1. «👀» — посмотреть, как они двигаются\n"
                              "2. «🎨 Собрать паки» — нарисую и загружу в Telegram (5–15 минут, их ~350)\n"
                              "3. дальше всё само: эмодзи в текстах и кнопках всех ботов станут анимированными, "
                              "а в чате я иногда буду ставить своё лицо 😉"))
        rows = [[("👀 Лицо Сони", "em:pv"), ("👀 Все эмодзи", "em:pa")], [("🎨 Собрать паки", "em:make", "success")],
                [("➕ Импорт чужого пака", "em:imp")]]
    lines.append(ui.hint("Telegram показывает премиум-эмодзи от бота, если у владельца бота есть Premium. "
                         "Не примет — сама откачусь на обычные · анимация эмодзи: Google Noto, CC BY 4.0"))
    return "\n".join(lines), kb_rows(*rows, [("‹ Сервер", "adm:srv")])


@router.callback_query(F.data.startswith("em:"), owner)
async def cb_emoji(cb: CallbackQuery, bot: Bot, state: FSMContext):
    import json
    import moji
    import sonyamoji
    from aiogram.types import BufferedInputFile
    act = cb.data[3:]
    if act == "home":
        return await show(cb, *await emoji_view())
    if act in ("pv", "pa"):
        await cb.answer("рисую превью… полминуты")
        if act == "pv":
            names = ["sonya", "wink"] + list(sonyamoji.EMOTIONS)
            cap = "✨ лицо Сони — так эмоции будут двигаться"
        else:
            inv = await asyncio.to_thread(sonyamoji.inventory)
            names = [n for n in sonyamoji.SET if n not in sonyamoji.EMOTIONS and n not in ("sonya", "wink")] + inv[:35]
            cap = f"✨ значки Сони + первые из {len(inv)} эмодзи бота (остальные в том же стиле)"
        gif = await asyncio.to_thread(sonyamoji.preview_gif, names, 8 if act == "pa" else 5)
        return await cb.message.answer_animation(BufferedInputFile(gif, "sonya_emoji.gif"), caption=cap)
    if act == "make":
        if _moji_busy:
            return await cb.answer("уже собираю, подожди", show_alert=True)
        await cb.answer("начинаю — пришлю прогресс")
        asyncio.create_task(_make_pack(bot, cb.from_user.id, cb.message.chat.id))
        return
    if act in ("tt", "tb"):
        k = "moji:on" if act == "tt" else "moji:btn"
        opt = "text" if act == "tt" else "btn"
        moji.OPT[opt] = not moji.OPT[opt]
        await db.kv_set(k, "1" if moji.OPT[opt] else "0")
        if act == "tt" and moji.OPT["text"]:
            moji.OFF["until"] = 0
        return await show(cb, *await emoji_view())
    if act == "imp":
        await state.set_state(EmImport.wait)
        await cb.answer()
        return await cb.message.answer(ui.head("➕", "Импорт пака", "") + "\n" + ui.quote(
            "пришли сообщение с премиум-эмодзи из любого анимированного пака (или ссылку t.me/addemoji/…)\n"
            "я возьму из него все эмодзи, которых нет у меня, — и начну ими пользоваться") + "\n" + ui.hint("/cancel — отмена"))
    if act == "exc":
        await db.kv_set("moji:extra", "{}")
        await moji.load()
        return await show(cb, *await emoji_view())
    ids = json.loads(await db.kv_get("moji:ids") or "{}")
    if act in ("apply", "clear"):   # старые кнопки (волна 68) — иконки главного меню через конструктор
        n = await apply_menu_icons(ids if act == "apply" else {})
        await cb.answer(f"готово: {n} кнопок" if act == "apply" else "убрала иконки", show_alert=True)
        return await show(cb, *await emoji_view())


@router.message(EmImport.wait, owner)
async def em_import(m: Message, bot: Bot, state: FSMContext):
    import json
    import re
    import moji
    if (m.text or "").startswith("/"):
        await state.clear()
        return await m.answer("ок, отменила")
    set_name = None
    mt = re.search(r"t\.me/addemoji/([A-Za-z0-9_]+)", m.text or m.caption or "")
    if mt:
        set_name = mt.group(1)
    else:
        ids = [e.custom_emoji_id for e in (m.entities or m.caption_entities or []) if e.type == "custom_emoji"]
        if m.sticker and m.sticker.custom_emoji_id:
            ids.append(m.sticker.custom_emoji_id)
        if ids:
            try:
                st = await bot.get_custom_emoji_stickers(ids[:1])
                set_name = st[0].set_name if st else None
            except Exception as e:
                log.info("custom emoji: %s", e)
    if not set_name:
        return await m.answer("😕 не вижу премиум-эмодзи. пришли сообщение с ними или ссылку t.me/addemoji/… (/cancel — отмена)")
    try:
        ss = await bot.get_sticker_set(set_name)
    except Exception as e:
        return await m.answer(f"😕 пак не открылся: {str(e)[:150]}")
    own = json.loads(await db.kv_get("moji:map") or "{}")
    ex = json.loads(await db.kv_get("moji:extra") or "{}")
    n = 0
    for st in ss.stickers:
        e = moji.norm(st.emoji or "")
        if e and st.custom_emoji_id and e not in own and e not in ex:
            ex[e] = st.custom_emoji_id
            n += 1
    await db.kv_set("moji:extra", json.dumps(ex, ensure_ascii=False))
    await moji.load()
    await state.clear()
    text, kb = await emoji_view()
    await m.answer(f"✅ «{ss.title}»: взяла <b>{n}</b> новых эмодзи (свои Сонины в приоритете)\n\n" + text, reply_markup=kb)


_moji_busy: set = set()


async def _make_pack(bot: Bot, uid: int, chat_id: int):
    """Рисую эмодзи (WEBM) и загружаю в паки custom_emoji. Пак уже есть — только дозагружаю новое (быстро).
    Порядок ключей храню в moji:order:<пак> — по нему сопоставляю id после загрузки."""
    import json
    import moji
    import sonyamoji
    from aiogram.types import BufferedInputFile, InputSticker
    _moji_busy.add(1)
    status = None
    done = [0]

    async def progress(total, force=False):
        nonlocal status
        txt = f"🎨 рисую и загружаю эмодзи: <b>{done[0]}/{total}</b>"
        try:
            if status is None:
                status = await bot.send_message(chat_id, txt)
            elif force or done[0] % 10 == 0:
                await status.edit_text(txt)
        except Exception:
            pass

    def sticker(key, emoji=None, small=False):
        data = sonyamoji.webm(key, 40 * 1024) if small else sonyamoji.webm(key)
        return InputSticker(sticker=BufferedInputFile(data, "e.webm"), format="video",
                            emoji_list=[emoji or sonyamoji.pack_emoji(key)])

    async def call(fn, *a, **kw):
        for _ in range(4):
            try:
                return await fn(*a, **kw)
            except TelegramRetryAfter as e:
                await asyncio.sleep(min(e.retry_after, 60) + 1)
        return await fn(*a, **kw)

    try:
        owner_id = int(await db.kv_get("moji:owner") or 0) or uid
        packs = await _moji_packs(bot)
        own = json.loads(await db.kv_get("moji:map") or "{}")
        hand = json.loads(await db.kv_get("moji:ids") or "{}")
        old_keys = list(sonyamoji.SET)[:21]   # волна 68 создала пак из первых 21 ручных эмодзи
        todo = []
        for name, title, keys in packs:
            order = json.loads(await db.kv_get(f"moji:order:{name}") or "null")
            try:
                ss = await bot.get_sticker_set(name)
            except Exception:
                ss = None
            if ss is not None and order is None:
                order = old_keys[:len(ss.stickers)] if name.startswith("sonya_emoji_by_") else []
            if ss is None:
                order = None
            todo.append((name, title, keys, ss, order or []))
        arts = {name: await db.kv_get(f"moji:art:{name}") for name, *_ in todo}
        stale = {name: (order if ss is not None and name != packs[0][0] and arts[name] != sonyamoji.ART else [])
                 for name, _, _, ss, order in todo}
        total = sum(len([k for k in keys if k not in order]) for _, _, keys, _, order in todo) \
            + sum(len(v) for v in stale.values())
        await progress(total, True)
        from_packs: set = set()
        for name, title, keys, ss, order in todo:
            # волна 75: новая анимация — заменяю уже загруженные эмодзи на месте (replaceStickerInSet), с продолжением
            if stale[name]:
                start = int(await db.kv_get(f"moji:artpos:{name}") or 0)
                done[0] += start
                for i in range(start, min(len(order), len(ss.stickers))):
                    try:
                        await call(bot.replace_sticker_in_set, user_id=owner_id, name=name,
                                   old_sticker=ss.stickers[i].file_id,
                                   sticker=await asyncio.to_thread(sticker, order[i]))
                    except Exception as e:
                        if "too big" not in str(e).lower():
                            log.info("replace %s: %s", order[i], e)
                        else:
                            await call(bot.replace_sticker_in_set, user_id=owner_id, name=name,
                                       old_sticker=ss.stickers[i].file_id,
                                       sticker=await asyncio.to_thread(sticker, order[i], None, True))
                    await db.kv_set(f"moji:artpos:{name}", str(i + 1))
                    done[0] += 1
                    await progress(total)
            await db.kv_set(f"moji:art:{name}", sonyamoji.ART)
            await db.kv_set(f"moji:artpos:{name}", "0")
            missing = [k for k in keys if k not in order]
            if ss is None and missing:
                first = missing[:FIRST_BATCH]
                items = []
                for k in first:
                    items.append(await asyncio.to_thread(sticker, k))
                    done[0] += 1
                    await progress(total)
                try:
                    await call(bot.create_new_sticker_set, user_id=owner_id, name=name, title=title, stickers=items,
                               sticker_type="custom_emoji")
                except TelegramBadRequest as e:
                    if "too big" not in str(e).lower():
                        raise
                    items = [await asyncio.to_thread(sticker, k, None, True) for k in first]   # жму сильнее
                    await call(bot.create_new_sticker_set, user_id=owner_id, name=name, title=title, stickers=items,
                               sticker_type="custom_emoji")
                order = list(first)
                await db.kv_set("moji:owner", str(owner_id))
                await db.kv_set(f"moji:order:{name}", json.dumps(order, ensure_ascii=False))
                missing = missing[FIRST_BATCH:]
            for k in missing:
                if len(order) >= PACK_MAX:
                    break
                st = await asyncio.to_thread(sticker, k)
                try:
                    await call(bot.add_sticker_to_set, user_id=owner_id, name=name, sticker=st)
                except Exception as e:
                    err = str(e).lower()
                    try:
                        if "too big" in err:     # волна 71: жму сильнее
                            await call(bot.add_sticker_to_set, user_id=owner_id, name=name,
                                       sticker=await asyncio.to_thread(sticker, k, None, True))
                        elif "emoji" in err:     # эмодзи «не тот» → ✨
                            await call(bot.add_sticker_to_set, user_id=owner_id, name=name,
                                       sticker=await asyncio.to_thread(sticker, k, "✨"))
                        else:
                            raise
                    except Exception as e2:
                        log.info("add %s: %s", k, e2)
                        done[0] += 1
                        continue
                order.append(k)
                await db.kv_set(f"moji:order:{name}", json.dumps(order, ensure_ascii=False))
                done[0] += 1
                await progress(total)
            # сопоставляю: N-й стикер пака = N-й ключ порядка
            ss = await bot.get_sticker_set(name)
            if ss.title != title:   # волна 73: старый пак 68-й волны звался «Соня · эмодзи»
                try:
                    await bot.set_sticker_set_title(name=name, title=title)
                except Exception as e:
                    log.info("title %s: %s", name, e)
            for k, s in zip(order, ss.stickers):
                if k in sonyamoji.SET:
                    hand[k] = s.custom_emoji_id
                    own[moji.norm(sonyamoji.SET[k][1])] = own.get(moji.norm(sonyamoji.SET[k][1])) or s.custom_emoji_id
                else:
                    own[moji.norm(k)] = s.custom_emoji_id
                    from_packs.add(moji.norm(k))
        for e, k in sonyamoji.ALIAS.items():   # 😂 → лицо Сони «хохочет»; 🎲 → фирменный, если нет живого от Google
            if hand.get(k) and moji.norm(e) not in from_packs:
                own[moji.norm(e)] = hand[k]
        await db.kv_set("moji:set", packs[0][0])
        await db.kv_set("moji:ids", json.dumps(hand))
        await db.kv_set("moji:map", json.dumps(own, ensure_ascii=False))
        await db.kv_set("moji:packs", json.dumps([[n, t] for n, t, _ in packs], ensure_ascii=False))
        await db.kv_set("moji:artver", sonyamoji.ART)
        await moji.load()
        await progress(total, True)
        text, kb = await emoji_view()
        await bot.send_message(chat_id, "✅ паки готовы — эмодзи во всех ботах теперь анимированные 😊\n\n" + text,
                               reply_markup=kb)
    except Exception as e:
        log.warning("emoji pack: %s", e)
        await bot.send_message(chat_id, f"😕 пак не собрался: {str(e)[:200]}\nнажми «Дособрать» ещё раз — продолжу с места")
    finally:
        _moji_busy.discard(1)


async def apply_menu_icons(ids: dict) -> int:
    """Иконки-эмодзи на кнопки главного меню через слой оформления (uikit): эмодзи из текста убираю,
    чтобы не было двух значков. ids пустой — снимаю иконки."""
    import re
    import sonyamoji
    import uikit
    n = 0
    for row in ui.main_menu(True).inline_keyboard:
        for b in row:
            moji = sonyamoji.MENU.get(b.callback_data or "")
            if not moji:
                continue
            key = uikit.bkey(b)
            o = uikit.BTNS.setdefault(key, {"data": b.callback_data})
            if ids.get(moji):
                o["icon"] = ids[moji]
                o["text"] = re.sub(r"^[^\w«]+", "", b.text).strip()
                n += 1
            else:
                o.pop("icon", None)
                o.pop("text", None)
            uikit.bid(key)
            await uikit.save_btn(key)
    return n


# ================= волна 65: обложки экранов =================
@router.callback_query(F.data == "bn:home", owner)
@router.message(Command("banners", "обложки"), owner)
async def banners_home(ev, bot: Bot = None):
    import banners
    rows, line = [], []
    for name, th in banners.THEMES.items():
        mark = "🖼" if banners.bg_path(name).exists() else "▫️"
        line.append((f"{mark} {th[0]}", f"bn:v:{name}"))
        if len(line) == 2:
            rows.append(line)
            line = []
    if line:
        rows.append(line)
    rows.append([("🎨 Дорисовать недостающие", "bn:all")])
    text = (ui.head("🖼", "Обложки экранов", "рисунок фона + текст поверх") + "\n"
            + ui.quote("🖼 — фон-рисунок есть · ▫️ — пока запасной градиент\n"
                       "фоны рисует pollinations (тот же ключ, что /draw) — один раз, потом лежат в data/banners")
            + "\n" + ui.hint("нажми на раздел — пришлю обложку, там же «🔄 перерисовать» и «↩️ вернуть прошлую»"))
    if isinstance(ev, CallbackQuery):
        return await show(ev, text, kb_rows(*rows))
    await ev.answer(text, reply_markup=kb_rows(*rows))


async def _banner_preview(cb: CallbackQuery, name: str):
    import asyncio
    import banners
    from aiogram.types import BufferedInputFile
    png = await asyncio.to_thread(banners.cached, name)
    await cb.message.answer_photo(BufferedInputFile(png, f"{name}.jpg"),
                                  caption=f"🖼 <b>{banners.THEMES[name][0]}</b>",
                                  reply_markup=kb_rows([("🔄 Перерисовать", f"bn:r:{name}"),
                                                        ("↩️ Вернуть прошлую", f"bn:u:{name}")],
                                                       [("‹ Обложки", "bn:home")]))


@router.callback_query(F.data.startswith("bn:"), owner)
async def cb_banner(cb: CallbackQuery):
    import banners
    act, _, name = cb.data[3:].partition(":")
    if act == "all":
        await cb.answer("рисую в фоне — минуту-две")
        asyncio.create_task(banners.prepare())
        return
    if name not in banners.THEMES:
        return await cb.answer()
    if act == "v":
        await cb.answer()
        return await _banner_preview(cb, name)
    if act == "r":
        await cb.answer("рисую… секунд 20")
        if not await banners.draw_bg(name):
            return await cb.message.answer("😕 не нарисовалось — pollinations не ответил, попробуй ещё раз")
        return await _banner_preview(cb, name)
    if act == "u":
        if not banners.restore_prev(name):
            return await cb.answer("прошлой картинки нет", show_alert=True)
        await cb.answer("вернула")
        return await _banner_preview(cb, name)


@router.callback_query(F.data == "adm:mus", owner)
async def cb_mus(cb: CallbackQuery):
    from downloader import catalog
    await cb.answer("проверяю каталоги…")
    rows = await catalog.diag()
    text = (ui.head("🧪", "Музыкальные каталоги", "поиск «oxvgen memory»") + "\n"
            + "\n".join(f"<b>{t}</b>: {r}" for t, r in rows) + "\n\n"
            + ui.hint("ищу по порядку: Яндекс → Deezer → YouTube. хватает одного ✅. "
                      "звук всегда берётся с YouTube — подбираю по длительности"))
    await show(cb, text, kb_rows([("🔄 Ещё раз", "adm:mus")], [("‹ Сервер", "adm:srv")]))


async def dls_view(days: int = 7) -> str:
    since = int(time.time()) - days * 86400
    rows = await db.q_all("SELECT platform, SUM(ok) ok, COUNT(*) n, AVG(CASE WHEN ok=1 THEN sec END) sec "
                          "FROM dl_log WHERE ts>? GROUP BY platform ORDER BY n DESC", since)
    lines = [ui.head("📥", "Скачивания", f"за {days} дн. · что качают и что сломалось"), ""]
    if not rows:
        return "\n".join(lines + [ui.quote("пока пусто — данные копятся с волны 32")])
    tot_ok = sum(r["ok"] or 0 for r in rows)
    tot = sum(r["n"] for r in rows)
    lines.append(ui.stats(("всего", tot), ("✅ успешно", f"{tot_ok * 100 // tot}%")))
    lines.append("")
    for r in rows:
        ok, n = r["ok"] or 0, r["n"]
        rate = ok * 100 // n
        icon = "🟢" if rate >= 85 else "🟡" if rate >= 60 else "🔴"
        sec = f" · ~{r['sec']:.0f} с" if r["sec"] else ""
        lines.append(f"{icon} <b>{ui.esc(r['platform'])}</b> — {n} шт · {rate}%{sec}")
    errs = await db.q_all("SELECT platform, err, COUNT(*) n FROM dl_log WHERE ts>? AND ok=0 "
                          "GROUP BY platform, err ORDER BY n DESC LIMIT 6", since)
    if errs:
        lines += ["", "<b>частые ошибки</b>"]
        lines += [f"• {ui.esc(e['platform'])}: <i>{ui.esc(e['err'][:70])}</i> ×{e['n']}" for e in errs]
    lines += ["", ui.hint("🔴 у платформы — скорее всего, сломался yt-dlp: «🗂 Сервер» → «⬆️ Обновить yt-dlp»")]
    return "\n".join(lines)


@router.callback_query(F.data == "adm:dls", owner)
async def cb_dls(cb: CallbackQuery):
    await show(cb, await dls_view(), kb_rows([("🔄 Обновить", "adm:dls")], BACK))


KIND_NAMES = {"plus": "✨ Соня+", "plussub": "🔁 подписка", "gift": "🎁 подарки", "donate": "🖤 донаты", "": "прочее"}


async def money_view() -> str:
    import premium
    now = int(time.time())
    one = lambda r: (r or {}).get("n") or 0  # noqa: E731

    async def stars(since: int) -> int:
        return one(await db.q_one("SELECT SUM(stars) n FROM donations WHERE ts>?", since))
    lines = [ui.head("💰", "Доходы", "звёзды Telegram"), ""]
    lines.append(ui.stats(("сегодня", f"{await stars(now - 86400)} ⭐"), ("7 дней", f"{await stars(now - 7 * 86400)} ⭐"),
                          ("30 дней", f"{await stars(now - 30 * 86400)} ⭐"), ("всего", f"{await stars(0)} ⭐")))
    kinds = await db.q_all("SELECT kind, SUM(stars) s, COUNT(*) n FROM donations WHERE ts>? GROUP BY kind "
                           "ORDER BY s DESC", now - 30 * 86400)
    if kinds:
        lines += ["", "<b>за 30 дней</b>"] + [f"• {KIND_NAMES.get(k['kind'], k['kind'])}: {k['s']} ⭐ · {k['n']} шт"
                                               for k in kinds]
    active = one(await db.q_one("SELECT COUNT(*) n FROM users WHERE plus_until>? AND id!=?", now, config.OWNER_ID))
    trials = one(await db.q_one("SELECT COUNT(*) n FROM users WHERE plus_trial>0"))
    paid_after = one(await db.q_one(
        "SELECT COUNT(DISTINCT u.id) n FROM users u JOIN donations d ON d.user_id=u.id "
        "WHERE u.plus_trial>0 AND d.ts>u.plus_trial AND d.kind IN ('plus','plussub')"))
    lines += ["", ui.stats(("✨ Соня+ сейчас", active), ("🎁 пробовали", trials),
                           ("💳 купили после пробы", f"{paid_after} ({paid_after * 100 // trials if trials else 0}%)"))]
    hits = await db.q_all("SELECT feat, COUNT(*) n FROM feat_usage WHERE day=? GROUP BY feat", db._day())
    hit = {h["feat"]: h["n"] for h in hits}
    if hit:
        lines.append(ui.stats(*[(premium.NAMES.get(f, f)[:18], n) for f, n in hit.items()]))
        lines.append(ui.hint("сколько людей сегодня пользовались платными лимитами — это твоя аудитория для Сони+"))
    top = await db.q_all("SELECT d.user_id, u.name, SUM(d.stars) s FROM donations d LEFT JOIN users u ON u.id=d.user_id "
                         "GROUP BY d.user_id ORDER BY s DESC LIMIT 5")
    if top:
        lines += ["", "<b>топ поддержавших</b>"] + [f"{i}. {ui.esc(t['name'] or str(t['user_id']))} — {t['s']} ⭐"
                                                     for i, t in enumerate(top, 1)]
    lines += ["", ui.hint("вывод звёзд — в @BotFather → бот → «Баланс», через Fragment; "
                          "звёзды становятся доступны к выводу через 21 день после оплаты")]
    return "\n".join(lines)


@router.callback_query(F.data == "adm:money", owner)
async def cb_money(cb: CallbackQuery):
    await show(cb, await money_view(), kb_rows([("🔄 Обновить", "adm:money")], BACK))


HELPER_NAMES = {"dl.db": "⬇️ скачивалка", "music.db": "🎵 музыка"}


def helper_stats(path) -> dict | None:
    """Чужая база помощника — только чтение, чтобы не мешать его процессу."""
    import sqlite3
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=3)
    except sqlite3.Error:
        return None
    try:
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
        if "dls" not in cols:
            return None
        now = int(time.time())
        one = lambda sql, *a: c.execute(sql, a).fetchone()[0] or 0  # noqa: E731
        return {"users": one("SELECT COUNT(*) FROM users"),
                "new24": one("SELECT COUNT(*) FROM users WHERE joined>?", now - 86400),
                "act24": one("SELECT COUNT(*) FROM users WHERE last_seen>?", now - 86400),
                "act7": one("SELECT COUNT(*) FROM users WHERE last_seen>?", now - 7 * 86400),
                "dls": one("SELECT SUM(dls) FROM users"),
                "cache": one("SELECT COUNT(*) FROM dl_cache") if c.execute(
                    "SELECT 1 FROM sqlite_master WHERE name='dl_cache'").fetchone() else 0}
    except sqlite3.Error:
        return None
    finally:
        c.close()


_BOT_USERNAMES: dict[str, str] = {}


async def _helper_username(token: str) -> str:
    """@ник помощника по его токену (getMe), кэш в памяти и в kv — чтобы не дёргать Telegram каждый раз."""
    if not token:
        return ""
    key = token.split(":")[0]
    if key in _BOT_USERNAMES:
        return _BOT_USERNAMES[key]
    name = await db.kv_get(f"botname:{key}")
    if not name:
        try:
            b = Bot(token)
            try:
                name = (await asyncio.wait_for(b.get_me(), 8)).username or ""
            finally:
                await b.session.close()
            if name:
                await db.kv_set(f"botname:{key}", name)
        except Exception as e:
            log.info("getMe помощника: %s", e)
            name = ""
    _BOT_USERNAMES[key] = name
    return name


async def helpers_view() -> str:
    """Волна 75: по названиям ботов (🎁 розыгрыши · @ник), а не по файлам баз; скачивания — только у качалок."""
    import fleet
    from pathlib import Path
    main = Path(config.DB_PATH).resolve()
    lines = [ui.head("🤝", "Боты-помощники", "узкие боты на твоём коде"), ""]
    known = {Path(h["db"]).name: h for h in fleet.helpers()}
    found = 0
    for p in sorted((config.BASE / "data").glob("*.db")):
        if p.resolve() == main:
            continue
        st = await asyncio.to_thread(helper_stats, p)
        if not st:
            continue
        found += 1
        h = known.get(p.name) or {}
        prof = h.get("profile") or p.stem
        title = h.get("name") or fleet.NAMES.get(prof) or HELPER_NAMES.get(p.name) or p.stem
        uname = await _helper_username(h.get("token", ""))
        lines.append(f"<b>{title}</b>" + (f" · @{uname}" if uname else ""))
        rows = [("👥 всего", st["users"]), ("🆕 за сутки", st["new24"]), ("🔥 активны 24ч", st["act24"]),
                ("📅 за неделю", st["act7"])]
        if prof in ("dl", "music") or st["dls"]:
            rows += [("⬇️ скачиваний", st["dls"]), ("🗃 в кэше", st["cache"])]
        lines.append(ui.stats(*rows))
        lines.append("")
    if not found:
        lines.append(ui.quote("пока ни одного не нашла в data/ — запусти по инструкции волны 27"))
    lines.append(ui.hint("🆕 растёт — значит, их находят в поиске"))
    return "\n".join(lines)


@router.callback_query(F.data == "adm:helpers", owner)
async def cb_helpers(cb: CallbackQuery):
    await show(cb, await helpers_view(), kb_rows([("🔄 Обновить", "adm:helpers")], BACK))


@router.callback_query(F.data == "adm:ytup", owner)
async def cb_ytup(cb: CallbackQuery):
    """TikTok, Instagram и YouTube часто ломают загрузку — свежий yt-dlp обычно чинит."""
    import sys
    await cb.answer("обновляю, это до минуты…")
    proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "pip", "install", "-U", "--quiet",
                                                "yt-dlp[default]", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), 180)
    except asyncio.TimeoutError:
        proc.kill()
        out = b"timeout"
    if proc.returncode == 0:
        text = ("⬆️ <b>yt-dlp обновлён</b>\nчтобы новая версия заработала, перезапусти Соню:\n"
                "<code>systemctl restart sonya</code>")
    else:
        text = ("😕 не вышло обновить отсюда (скорее всего, папка с venv защищена). выполни на сервере:\n"
                f"<code>{ui.esc(sys.executable)} -m pip install -U \"yt-dlp[default]\"</code>\n<code>systemctl restart sonya</code>\n\n"
                f"<i>{ui.esc(out.decode(errors='ignore')[-300:])}</i>")
    await cb.message.answer(text)


@router.callback_query(F.data == "adm:bak", owner)
async def cb_backup(cb: CallbackQuery, bot: Bot):
    import system
    await cb.answer("собираю бэкап…")
    res = await system.send_backup(bot, cb.from_user.id)
    if res != "ok":
        await cb.message.answer(f"⚠️ {res}")


@router.message(Command("backup"), owner)
async def cmd_backup(m: Message, bot: Bot):
    import system
    res = await system.send_backup(bot, m.from_user.id)
    if res != "ok":
        await m.answer(f"⚠️ {res}")


@router.callback_query(F.data == "adm:bc", owner)
async def cb_bc(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Adm.broadcast)
    await show(cb, "<b>📣 рассылка</b>\nпришли сообщение (текст, фото, видео — что угодно), "
                   "покажу превью и спрошу подтверждение", kb_rows([("✖️ Отмена", "adm:home")]))


SEGMENTS = {"all": "👥 всем", "active": "🟢 активным 7 дн.", "plus": "✨ с Соней+", "free": "🆓 без Соня+",
            "groups": "💬 в группы"}


async def segment_ids(seg: str) -> list[int]:
    now = int(time.time())
    if seg == "active":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND last_seen>?", now - 7 * 86400)]
    if seg == "plus":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND plus_until>?", now)]
    if seg == "free":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND plus_until<=?", now)]
    if seg == "groups":
        return [r["id"] for r in await db.q_all("SELECT id FROM chats")]
    return await db.all_user_ids()


@router.message(Adm.broadcast, owner)
async def st_bc(m: Message, state: FSMContext):
    obj = (m.photo[-1] if m.photo else None) or m.video or m.animation
    await state.update_data(src_chat=m.chat.id, src_id=m.message_id, html=m.html_text or "",
                            mfid=obj.file_id if obj else "", mkind="photo" if m.photo else "video" if m.video
                            else "animation" if m.animation else "", msize=getattr(obj, "file_size", 0) if obj else 0)
    rows = [[(f"{name} · {len(await segment_ids(k))}", f"adm:bcgo:{k}")] for k, name in SEGMENTS.items()]
    if config.PROFILE == "full":
        import fleet
        hs = fleet.helpers()
        if hs:
            n = sum(len(fleet.users_of(h["db"])) for h in hs)
            rows.append([(f"🤖 + во всех помощниках · {n}", "adm:bcfleet")])
    await m.answer("👆 так увидят. кому отправляем?", reply_markup=kb_rows(*rows, [("✖️ Отмена", "adm:home")]))


@router.callback_query(F.data.startswith("adm:bcgo"), owner)
async def cb_bcgo(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    await state.clear()
    if not d.get("src_id"):
        return await cb.answer("нечего рассылать", show_alert=True)
    seg = cb.data.split(":")[2] if cb.data.count(":") >= 2 else "all"
    ids = await segment_ids(seg if seg in SEGMENTS else "all")
    await cb.message.edit_text(f"📣 рассылка ({SEGMENTS.get(seg, 'всем')}) на {len(ids)}…")
    ok, fail = await _broadcast(bot, d["src_chat"], d["src_id"], ids)
    await show(cb.message, f"📣 готово: ✅ {ok} · ❌ {fail}", kb_rows(BACK))


@router.callback_query(F.data == "adm:bcfleet", owner)
async def cb_bcfleet(cb: CallbackQuery, state: FSMContext, bot: Bot):
    """Сначала всем в Соне, потом каждому помощнику — от его имени. Медиа перезаливаю (file_id у ботов разные)."""
    import fleet
    d = await state.get_data()
    await state.clear()
    if not d.get("src_id"):
        return await cb.answer("нечего рассылать", show_alert=True)
    if d.get("msize", 0) > 20 * 1024 * 1024:
        return await cb.answer("файл больше 20 МБ — для помощников не скачать", show_alert=True)
    await cb.answer("поехали…")
    await cb.message.edit_text("📣 рассылка во все боты… пришлю отчёт")
    lines = []
    ok, fail = await _broadcast(bot, d["src_chat"], d["src_id"], await segment_ids("all"))
    lines.append(f"🖤 Соня: ✅ {ok} · ❌ {fail}")
    content = {"text": d.get("html", ""), "kind": d.get("mkind", ""), "data": b""}
    if content["kind"]:
        import io
        buf = io.BytesIO()
        await bot.download(d["mfid"], destination=buf)
        content["data"] = buf.getvalue()
    for h in fleet.helpers():
        try:
            o, f = await fleet.broadcast_helper(h, content)
            lines.append(f"{h['name']}: ✅ {o} · ❌ {f}")
        except Exception as e:
            lines.append(f"{h['name']}: ⚠️ {ui.esc(str(e)[:80])}")
    await show(cb.message, "📣 <b>рассылка во все боты — готово</b>\n" + "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:fleet", owner)
async def cb_fleet(cb: CallbackQuery):
    import fleet
    await cb.answer()
    await show(cb, await fleet.status_view(),
               kb_rows([("🔄 Обновить", "adm:fleet"), ("💾 Бэкап всех баз", "adm:fbak")], BACK))


@router.callback_query(F.data == "adm:fbak", owner)
async def cb_fbak(cb: CallbackQuery, bot: Bot):
    import fleet
    await cb.answer("собираю архив…")
    res = await fleet.send_backup_all(bot, cb.from_user.id)
    if res != "ok":
        await cb.message.answer(f"⚠️ {res}")


async def _broadcast(bot: Bot, chat_id: int, msg_id: int, ids: list[int]) -> tuple[int, int]:
    ok = fail = 0
    for uid in ids:
        try:
            await bot.copy_message(uid, chat_id, msg_id)
            ok += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.copy_message(uid, chat_id, msg_id)
                ok += 1
            except Exception:
                fail += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    return ok, fail


def _target(m: Message, args: str | None) -> int | None:
    if m.reply_to_message:
        return m.reply_to_message.from_user.id
    a = (args or "").strip()
    return int(a) if a.lstrip("-").isdigit() else None


@router.message(Command("ban"), owner, F.chat.type == "private")
async def cmd_ban(m: Message, command: CommandObject):
    uid = _target(m, command.args)
    if not uid or uid == config.OWNER_ID:
        return await m.answer("кого? ответь на сообщение или дай id")
    await db.set_banned(uid, True)
    await m.answer(f"🚫 <code>{uid}</code> в бане")


@router.message(Command("unban"), owner, F.chat.type == "private")
async def cmd_unban(m: Message, command: CommandObject):
    uid = _target(m, command.args)
    if not uid:
        return await m.answer("кого? ответь на сообщение или дай id")
    await db.set_banned(uid, False)
    await m.answer(f"✅ <code>{uid}</code> разбанен")


@router.message(Command("ai"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_ai(m: Message, command: CommandObject, bot: Bot):
    if m.from_user.id != config.OWNER_ID:
        mem = await bot.get_chat_member(m.chat.id, m.from_user.id)
        if mem.status not in ("administrator", "creator"):
            return
    arg = (command.args or "").strip().lower()
    if arg not in ("on", "off"):
        state = "вкл" if await db.chat_ai_on(m.chat.id) else "выкл"
        return await m.answer(f"болтовня сони здесь: <b>{state}</b>\n/ai on · /ai off")
    await db.set_chat_ai(m.chat.id, arg == "on")
    await m.answer("ок, я тут 🖤" if arg == "on" else "ладно, молчу 🤐")


@router.message(Command("broadcast"), owner)
async def cmd_broadcast(m: Message, bot: Bot):
    src = m.reply_to_message
    if not src:
        return await m.answer("ответь этой командой на сообщение, которое разослать")
    ids = await db.all_user_ids()
    status = await m.answer(f"📣 рассылка на {len(ids)}…")
    ok = fail = 0
    for uid in ids:
        try:
            await src.copy_to(uid)
            ok += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await src.copy_to(uid)
                ok += 1
            except Exception:
                fail += 1
        except TelegramForbiddenError:
            fail += 1
        except Exception as e:
            log.warning("broadcast %s: %s", uid, e)
            fail += 1
        await asyncio.sleep(0.05)
    await status.edit_text(f"📣 готово: ✅ {ok} · ❌ {fail}")


# ================= 👤 карточка юзера и выдача =================
async def _find_user(m: Message, arg: str) -> dict | None:
    if m.reply_to_message and m.reply_to_message.from_user:
        return await db.get_user(m.reply_to_message.from_user.id)
    a = (arg or "").strip()
    if a.startswith("@"):
        return await db.q_one("SELECT * FROM users WHERE lower(username)=?", a[1:].lower())
    if a.lstrip("-").isdigit():
        return await db.get_user(int(a))
    return None


async def user_card(uid: int):
    u = await db.get_user(uid)
    if not u:
        return "не нашла такого", kb_rows(BACK)
    donated = await db.user_donated(uid)
    plus = (u.get("plus_until") or 0) > time.time()
    text = (ui.head("👤", ui.esc(u["name"]), (f"@{ui.esc(u['username'])} · " if u["username"] else "") + f"id {uid}")
            + "\n" + ui.stats(("📅 с нами с", timeparse.fmt(u["joined"])), ("👀 был(а)", timeparse.fmt(u["last_seen"])),
                              ("💬 сообщений", u["msgs"]), ("🪙 монетки", u.get("coins", 0)),
                              ("✨ Соня+", f"до {timeparse.fmt(u['plus_until'])}" if plus else "нет"),
                              ("⭐ донатил", donated), ("👥 привёл", u.get("refs") or 0),
                              ("🎂 ДР", u.get("bday") or "—"), ("🚫 бан", "да" if u["banned"] else "нет")))
    kb = kb_rows([("+100 🪙", f"adm:g:{uid}:c100"), ("+1000 🪙", f"adm:g:{uid}:c1000")],
                 [("✨ +7 дней", f"adm:g:{uid}:p7"), ("✨ +30 дней", f"adm:g:{uid}:p30")],
                 [("✅ Разбанить" if u["banned"] else "🚫 Забанить", f"adm:g:{uid}:ban")],
                 BACK)
    return text, kb


@router.message(Command("user", "юзер"), owner)
async def cmd_user(m: Message, command: CommandObject):
    u = await _find_user(m, command.args)
    if not u:
        return await m.answer("👤 <code>/user 123456</code> · <code>/user @username</code> · или ответом на сообщение")
    text, kb = await user_card(u["id"])
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("adm:g:"), owner)
async def cb_grant(cb: CallbackQuery):
    _, _, uid, what = cb.data.split(":")
    uid = int(uid)
    if not await db.get_user(uid):
        return await cb.answer("нет такого", show_alert=True)
    if what.startswith("c"):
        await db.add_coins(uid, int(what[1:]))
        note = f"+{what[1:]} 🪙"
    elif what.startswith("p"):
        from handlers import extra
        await extra.grant_plus(uid, int(what[1:]))
        note = f"✨ Соня+ +{what[1:]} дн."
    else:
        u = await db.get_user(uid)
        await db.set_banned(uid, not u["banned"])
        note = "разбанен" if u["banned"] else "забанен"
    await cb.answer(f"готово: {note}")
    await show(cb, *await user_card(uid))


@router.message(Command("grant"), owner)
async def cmd_grant(m: Message, command: CommandObject):
    """/grant 123 coins 500 · /grant @user plus 30"""
    parts = (command.args or "").split()
    if len(parts) < 3 or parts[1] not in ("coins", "plus") or not parts[2].isdigit():
        return await m.answer("🎁 <code>/grant 123456 coins 500</code> · <code>/grant @user plus 30</code>")
    u = await _find_user(m, parts[0])
    if not u:
        return await m.answer("не нашла такого юзера")
    n = int(parts[2])
    if parts[1] == "coins":
        await db.add_coins(u["id"], n)
        note = f"+{n} 🪙"
    else:
        from handlers import extra
        await extra.grant_plus(u["id"], n)
        note = f"✨ Соня+ на {n} дн."
    await m.answer(f"🎁 {ui.esc(u['name'])}: {note}")


# ================= 📝 профиль бота (то, что видят в каталоге и до /start) =================
BOT_SHORT = "Соня — ИИ-подруга с характером: болтает, качает видео, рисует, играет и ведёт твои каналы 🖤"
BOT_DESC = ("хей, я соня 🖤 альтушка с сарказмом и памятью\n\n"
            "💬 болтаю как живая и помню, что ты рассказывал\n"
            "⬇️ качаю видео и музыку: TikTok, YouTube, Insta, Pinterest\n"
            "🎙 расшифрую голосовые · 🎨 нарисую · 🗣 озвучу · 👀 посмотрю фото\n"
            "🎮 игры на монетки, питомец, колесо фортуны, блэкджек\n"
            "👥 в группах: мафия, шпион, крокодил, РП-команды, модерация\n"
            "📢 сама веду каналы по расписанию\n\n"
            "жми «Старт» и просто напиши мне 👇")


BIO = {
    "grp": ("Помощник для групп: голосовые в текст, капча, антиспам, варны и муты 🛡",
            "🛡 добавь меня в группу и дай админку\n\n"
            "🎙 голосовые и кружки — сразу превращаю в текст\n"
            "🛡 капча для новичков, антифлуд, ссылки только у админов\n"
            "⚠️ варны, муты, баны · 📜 правила · 📝 заметки · 🌙 ночная тишина · 🤬 фильтр мата\n"
            "🧾 /summary — что вы пропустили · 🏆 /top — самые активные\n\nбесплатно, без обязательных подписок"),
    "stk": ("Сделаю стикеры и эмодзи-пак из твоих картинок за пару секунд 🧩",
            "🧩 пришли картинку, альбом, GIF или кружок — получишь свой пак стикеров\n\n"
            "✂️ вырежу фон нейросетью и обведу белым, как наклейку\n"
            "✍️ подпись к картинке — напишу её на стикере · 💬 стикер из текста\n"
            "⭕ кружок → круглый видео-стикер · 🎬 GIF и видео → видео-стикеры\n"
            "😀 эмодзи, порядок, обложка — кнопками под каждым стикером · 👀 витрина пака\n"
            "🎲 своё или случайное название и ссылка · 👥 соавторы · 📥 пак архивом\n"
            "📥 скачаю любой стикер картинкой · 📦 весь чужой пак себе — с Соней+\n\nбесплатно, без рекламы и водяных знаков"),
    "dl": ("Скачаю видео и музыку из TikTok, YouTube, Instagram, Pinterest, VK — без водяных знаков и рекламы ⬇️",
           "⬇️ просто кинь ссылку — пришлю видео или mp3\n\n"
           "TikTok (и фото-карусели) · YouTube и Shorts · Instagram Reels · Pinterest · VK · RuTube · X · Reddit · "
           "Likee · Threads · Twitch · Дзен\n🎧 SoundCloud, Spotify, Яндекс Музыка → mp3\n"
           "🎙 голосовые и кружки → текст\n\nбыстро, бесплатно, работает и в группах"),
    "music": ("Найду любую песню по названию или строчке и узнаю, что играет в видео 🎵",
              "🎵 напиши название или строчку из песни — пришлю mp3\n"
              "🎧 пришли голосовое, видео или кружок — скажу, что за трек\n"
              "🔗 Spotify, Яндекс Музыка, SoundCloud — скачаю по ссылке\n\nбесплатно и без рекламы"),
    "games": ("Игры для чата: мафия, крокодил, викторина, угадай мелодию, дуэли и питомцы 🎮",
              "🎮 добавь меня в беседу — и скучно не будет\n\n"
              "🕵️ мафия и шпион с ролями в личку · 🐊 крокодил по картинке · ❓ викторины\n"
              "🎵 угадай мелодию на скорость · ⚔️ дуэли · 🎡 колесо фортуны · 🃏 блэкджек\n"
              "🐣 питомец · 💍 браки · 🤗 РП: обнять, кусь, дай пять\n\nбесплатно"),
    "anon": ("Анонимные вопросы: получи ссылку — друзья напишут тебе анонимно 💌",
             "💌 получи свою ссылку и кинь её в сторис или био\n\n"
             "🤫 тебе пишут анонимно — текст, голосовые, фото\n↩️ отвечаешь, не зная автора\n"
             "🎭 у каждого анонима своя маска — видно, кто пишет снова; сгорает через 12 ч тишины\n"
             "🎲 анонимный чат со случайным собеседником по темам\n"
             "🚫 блок и жалоба на тех, кто грубит\n\nбесплатно"),
    "gw": ("Розыгрыши в твоём канале: проверка подписки, спонсоры, билеты за друзей и подарки Telegram 🎁",
           "🎁 запусти розыгрыш в своём канале за минуту\n\n"
           "✅ проверка подписки на канал и спонсоров\n🎟 билеты за приглашённых друзей\n"
           "⭐ подарки Telegram победителям — они сами выбирают\n🏁 итоги по времени или числу участников\n"
           "🔍 честный выбор: барабан вживую и проверка для каждого\n"
           "📣 напоминания, ⏰ продление, 🖼 карточка итогов\n\nбесплатно, без рекламы в постах"),
}


def _bio() -> tuple[str, str]:
    return BIO.get(config.PROFILE, (BOT_SHORT, BOT_DESC))


@router.callback_query(F.data == "adm:bio", owner)
async def cb_bio(cb: CallbackQuery, bot: Bot):
    try:
        cur_s = (await bot.get_my_short_description()).short_description or "—"
        cur_d = (await bot.get_my_description()).description or "—"
    except Exception:
        cur_s = cur_d = "?"
    text = (ui.head("📝", "Профиль бота", "это видят в поиске, каталогах и до нажатия «Старт»")
            + "\n<b>сейчас — коротко:</b>\n" + ui.quote(ui.esc(cur_s))
            + "\n<b>сейчас — описание:</b>\n" + ui.quote(ui.esc(cur_d), expandable=True)
            + "\n<b>предлагаю:</b>\n" + ui.quote(ui.esc(_bio()[0])) + "\n" + ui.quote(ui.esc(_bio()[1]), expandable=True))
    await show(cb, text, kb_rows([("✅ Поставить предложенное", "adm:bioset")], BACK))


@router.callback_query(F.data == "adm:bioset", owner)
async def cb_bioset(cb: CallbackQuery, bot: Bot):
    try:
        short, desc = _bio()
        await bot.set_my_short_description(short_description=short)
        await bot.set_my_description(description=desc)
        await cb.answer("готово! открой профиль Сони — там новое описание", show_alert=True)
    except Exception as e:
        await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
