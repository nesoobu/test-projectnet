"""Удача: 🎡 колесо фортуны, 🃏 блэкджек, 🔮 гороскоп по дню рождения."""
import asyncio
import logging
import random
import time
import uuid
from html import escape

from aiogram import Router, F
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery

import db
import llm
import ui
from handlers import games
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("luck")


# ================= 🎡 колесо фортуны =================
WHEEL_EVERY = 20 * 3600
# (вес, подпись, монетки, дней Соня+)
WHEEL = [(28, "10 🪙", 10, 0), (24, "25 🪙", 25, 0), (16, "50 🪙", 50, 0), (9, "100 🪙", 100, 0),
         (3, "250 🪙 💥", 250, 0), (1, "777 🪙 🤑 ДЖЕКПОТ", 777, 0), (14, "пусто 🫠", 0, 0), (5, "✨ Соня+ на день", 0, 1)]
SPIN = ["🎡 крууутим…", "🎡 ✦ · · · ✧", "🎡 · ✦ · ✧ ·", "🎡 · · ✦ · ✧"]


async def wheel_left(uid: int) -> int:
    last = int(await db.kv_get(f"wheel:{uid}") or 0)
    return max(0, WHEEL_EVERY - (int(time.time()) - last))


async def spin(uid: int) -> tuple[str, int, int]:
    _w, label, coins, days = random.choices(WHEEL, weights=[w[0] for w in WHEEL])[0]
    await db.kv_set(f"wheel:{uid}", str(int(time.time())))
    if coins:
        await db.add_coins(uid, coins, win=coins >= 100)
    if days:
        from handlers import extra
        await extra.grant_plus(uid, days)
    db.emit("game", uid)
    return label, coins, days


async def _claim_wheel(uid: int) -> bool:
    """Волна 62: занять попытку ДО анимации, одной командой. Раньше отметка ставилась после 2.4 с кручения —
    пять быстрых /wheel давали пять прокрутов (джекпоты, дни Сони+)."""
    now, k = int(time.time()), f"wheel:{uid}"
    if await db.q_change("INSERT OR IGNORE INTO kv(k, v) VALUES(?, ?)", k, str(now)):
        return True
    return bool(await db.q_change("UPDATE kv SET v=? WHERE k=? AND CAST(v AS INTEGER) <= ?", str(now), k,
                                  now - WHEEL_EVERY))


async def wheel_play(m: Message, user):
    left = await wheel_left(user.id)
    if left or not await _claim_wheel(user.id):
        left = left or await wheel_left(user.id)
        return await m.answer(f"🎡 колесо отдыхает. следующая попытка через <b>{left // 3600} ч {left % 3600 // 60} мин</b>")
    msg = await m.answer(SPIN[0])
    for frame in SPIN[1:]:
        await asyncio.sleep(0.6)
        try:
            await msg.edit_text(frame)
        except TelegramBadRequest:
            pass
    label, coins, days = await spin(user.id)
    text = (ui.head("🎡", "Колесо фортуны", games.name_of(user)) + "\n"
            + ui.quote(f"выпало: <b>{label}</b>") + "\n"
            + ui.hint("крутить можно раз в 20 часов"))
    share = await ui.share_url(m.bot, user.id, f"🎡 мне выпало «{label}» на колесе фортуны у Сони! крутани и ты 👇")
    kb = kb_rows([("📤 Похвастаться", share), ("🎮 Игры", "g:menu")])
    import gameart
    import uikit
    labels = [wheel_label(w) for w in WHEEL]   # волна 66: колесо картинкой, стрелка на выпавшем секторе
    idx = next((i for i, w in enumerate(WHEEL) if w[1] == label), 0)
    try:
        await uikit.with_card(lambda: gameart.wheel(labels, idx), lambda: msg.edit_text(text, reply_markup=kb))
    except TelegramBadRequest:
        await m.answer(text, reply_markup=kb)


def wheel_label(w) -> str:
    """Подпись сектора для картинки (эмодзи шрифт не рисует)."""
    _wt, _label, coins, days = w
    if days:
        return "Соня+ на день"
    if coins >= 777:
        return f"ДЖЕКПОТ {coins}"
    return f"{coins} монет" if coins else "пусто"


@router.message(Command("wheel", "колесо"))
async def cmd_wheel(m: Message):
    await wheel_play(m, m.from_user)


@router.callback_query(F.data == "g:wheel")
async def cb_wheel(cb: CallbackQuery):
    await cb.answer()
    await wheel_play(cb.message, cb.from_user)


# ================= 🃏 блэкджек =================
BETS = [10, 25, 50, 100]
RANKS = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A"]
SUITS = ["♠️", "♥️", "♦️", "♣️"]
_bj: dict[str, dict] = {}


def score(hand: list[str]) -> int:
    total, aces = 0, 0
    for c in hand:
        r = c[:-2]
        if r == "A":
            aces += 1
            total += 11
        elif r in ("J", "Q", "K"):
            total += 10
        else:
            total += int(r)
    while total > 21 and aces:
        total -= 10
        aces -= 1
    return total


def _deck() -> list[str]:
    d = [r + s for r in RANKS for s in SUITS]
    random.shuffle(d)
    return d


def bj_text(g: dict, final: str = "") -> str:
    dealer = g["dealer"] if final else [g["dealer"][0], "🂠"]
    ds = score(g["dealer"]) if final else "?"
    lines = [ui.head("🃏", "Блэкджек", f"ставка {g['bet']} 🪙"),
             ui.quote(f"Соня: {' '.join(dealer)}  <b>({ds})</b>\nты: {' '.join(g['hand'])}  <b>({score(g['hand'])})</b>")]
    if final:
        lines.append(final)
    else:
        lines.append(ui.hint("набери ближе к 21, чем я, но не больше"))
    return "\n".join(lines)


def bj_kb(gid: str):
    return kb_rows([("➕ Ещё карту", f"bj:h:{gid}"), ("✋ Хватит", f"bj:s:{gid}")])


async def _bj_send(g: dict, final: str, coro_fn):
    """Волна 66: блэкджек картинкой — стол, карты (у Сони вторая рубашкой до конца)."""
    import gameart
    import uikit
    dealer = list(g["dealer"]) if final else [g["dealer"][0], "🂠"]
    ds = score(g["dealer"]) if final else "?"
    hand, ps, bet = list(g["hand"]), score(g["hand"]), g["bet"]
    return await uikit.with_card(lambda: gameart.blackjack(dealer, hand, final, ds, ps, bet), coro_fn)


def bet_kb():
    return kb_rows([(f"{b} 🪙", f"bj:new:{b}") for b in BETS], [("🎮 Игры", "g:menu")])


async def bj_finish(g: dict) -> str:
    while score(g["dealer"]) < 17:
        g["dealer"].append(g["deck"].pop())
    p, d = score(g["hand"]), score(g["dealer"])
    bet = g["bet"]
    natural = p == 21 and len(g["hand"]) == 2
    if p > 21:
        res, pay = "💥 перебор — я забираю ставку 😏", 0
    elif natural and not (d == 21 and len(g["dealer"]) == 2):
        res, pay = f"🖤 <b>блэкджек!</b> +{int(bet * 1.5)} 🪙", int(bet * 2.5)
    elif d > 21 or p > d:
        res, pay = f"🏆 ты выиграл(а)! +{bet} 🪙", bet * 2
    elif p == d:
        res, pay = "🤝 ничья — ставку вернула", bet
    else:
        res, pay = "😏 я выиграла", 0
    if pay:
        await db.add_coins(g["uid"], pay, win=pay > bet)
    db.emit("game", g["uid"])
    return res


@router.message(Command("bj", "blackjack", "21"))
async def cmd_bj(m: Message, command: CommandObject):
    arg = (command.args or "").strip()
    if arg.isdigit():
        return await bj_start(m, m.from_user.id, int(arg))
    await m.answer(ui.head("🃏", "Блэкджек", "на сколько играем?"), reply_markup=bet_kb())


@router.callback_query(F.data == "g:bj")
async def cb_bj_menu(cb: CallbackQuery):
    await cb.answer()
    await cb.message.answer(ui.head("🃏", "Блэкджек", "на сколько играем?"), reply_markup=bet_kb())


async def bj_start(m: Message, uid: int, bet: int):
    if not 5 <= bet <= 5000:
        return await m.answer("ставка от 5 до 5000 🪙")
    if not await db.take_coins(uid, bet):
        return await m.answer("не хватает монеток 🥲 /bonus или 🎡 /wheel")
    deck = _deck()
    g = {"id": uuid.uuid4().hex[:8], "uid": uid, "bet": bet, "deck": deck,
         "hand": [deck.pop(), deck.pop()], "dealer": [deck.pop(), deck.pop()]}
    if score(g["hand"]) == 21:
        res = await bj_finish(g)
        return await _bj_send(g, res, lambda: m.answer(bj_text(g, res), reply_markup=kb_rows([("🔁 Ещё раз", "g:bj")])))
    _bj[g["id"]] = g
    await games._put("bj", g["id"], g)
    await _bj_send(g, "", lambda: m.answer(bj_text(g), reply_markup=bj_kb(g["id"])))


@router.callback_query(F.data.startswith("bj:new:"))
async def cb_bj_new(cb: CallbackQuery):
    bet = int(cb.data.split(":")[2])
    await cb.answer()
    await bj_start(cb.message, cb.from_user.id, bet)


@router.callback_query(F.data.startswith(("bj:h:", "bj:s:")))
async def cb_bj_move(cb: CallbackQuery):
    _, act, gid = cb.data.split(":")
    if gid in _bj_busy:   # волна 62: двойной тап «хватит» раньше выплачивал выигрыш дважды
        return await cb.answer()
    _bj_busy.add(gid)
    try:
        await _bj_move(cb, act, gid)
    finally:
        _bj_busy.discard(gid)


_bj_busy: set[str] = set()


async def _bj_move(cb: CallbackQuery, act: str, gid: str):
    g = await games._get("bj", gid, _bj)
    if not g:
        return await cb.answer("партия закончилась")
    if cb.from_user.id != g["uid"]:
        return await cb.answer("это не твоя партия — начни свою: /bj", show_alert=True)
    final = ""
    if act == "h":
        g["hand"].append(g["deck"].pop())
        if score(g["hand"]) >= 21:
            final = await bj_finish(g)
    else:
        final = await bj_finish(g)
    if final:
        _bj.pop(gid, None)
        await games._drop("bj", gid)
        row = [("🔁 Ещё раз", "g:bj"), ("🎮 Игры", "g:menu")]
        if "выиграл" in final or "блэкджек" in final:
            row.insert(0, ("📤 Похвастаться", await ui.share_url(
                cb.bot, cb.from_user.id, f"🃏 обыграл(а) Соню в блэкджек на {g['bet']} 🪙 — попробуй и ты 👇")))
        kb = kb_rows(row)
    else:
        await games._put("bj", gid, g)
        kb = bj_kb(gid)
    await cb.answer()
    try:
        await _bj_send(g, final, lambda: cb.message.edit_text(bj_text(g, final), reply_markup=kb))
    except TelegramBadRequest:
        pass


# ================= 🔮 гороскоп =================
ZODIAC = [((1, 20), "♑", "козерог"), ((2, 19), "♒", "водолей"), ((3, 21), "♓", "рыбы"), ((4, 20), "♈", "овен"),
          ((5, 21), "♉", "телец"), ((6, 21), "♊", "близнецы"), ((7, 23), "♋", "рак"), ((8, 23), "♌", "лев"),
          ((9, 23), "♍", "дева"), ((10, 23), "♎", "весы"), ((11, 22), "♏", "скорпион"), ((12, 22), "♐", "стрелец"),
          ((12, 32), "♑", "козерог")]
SIGNS = {name: icon for _d, icon, name in ZODIAC}
HORO_FALLBACK = ["день для смелых решений, но без фанатизма", "звёзды советуют выспаться и не спорить в чатах",
                 "кто-то думает о тебе. возможно, курьер", "хороший день, чтобы закончить то, что начал(а) неделю назад",
                 "не трать деньги на ерунду. ну, почти не трать", "вселенная на твоей стороне, но кофе всё равно нужен"]


def sign_of(bday: str) -> tuple[str, str] | None:
    """«12.05» → ('♉', 'телец')."""
    try:
        d, mo = map(int, bday.split("."))
    except (ValueError, AttributeError):
        return None
    for (m_, d_), icon, name in ZODIAC:
        if (mo, d) < (m_, d_):
            return icon, name
    return None


async def horoscope(sign: str) -> str:
    day = db._day()
    key = f"horo:{day}:{sign}"
    cached = await db.kv_get(key)
    if cached:
        return cached
    text = random.choice(HORO_FALLBACK)
    try:
        out = await llm.ask([{"role": "system", "content": "Ты Соня — дерзкая альтушка. Напиши гороскоп на сегодня для "
                              "знака, 2 коротких предложения, с иронией, без мистического пафоса и без опасных советов."},
                             {"role": "user", "content": f"Знак: {sign}. Дата: {day}"}],
                            max_tokens=300, temperature=1.0, feature="horo")
        if out and len(out) < 400:
            text = out.strip()
            await db.kv_set(key, text)
    except Exception as e:
        log.info("horo: %s", e)
    return text


async def horo_line(uid: int) -> str:
    u = await db.get_user(uid) or {}
    s = sign_of(u.get("bday") or "")
    if not s:
        return ""
    return f"🔮 <b>{s[1]}</b> {s[0]}: {escape(await horoscope(s[1]))}"


@router.message(Command("horo", "гороскоп"))
async def cmd_horo(m: Message, command: CommandObject):
    arg = (command.args or "").strip().lower()
    if arg in SIGNS:
        icon, name = SIGNS[arg], arg
    else:
        u = await db.get_user(m.from_user.id) or {}
        s = sign_of(u.get("bday") or "")
        if not s:
            return await m.reply("🔮 скажи свой ДР — <code>/bday 12.05</code>, и я буду знать твой знак.\n"
                                 "или сразу: <code>/horo телец</code>")
        icon, name = s
    text = await horoscope(name)
    share = await ui.share_url(m.bot, m.from_user.id, f"🔮 {name} {icon} на сегодня: {text}\n\nгороскоп от Сони 👇")
    import gameart
    import uikit
    months = ("января февраля марта апреля мая июня июля августа сентября октября ноября декабря").split()
    t = time.gmtime(time.time() + 3 * 3600)
    date = f"{t.tm_mday} {months[t.tm_mon - 1]}"
    await uikit.with_card(lambda: gameart.horoscope(name, date), lambda: m.reply(
        ui.head("🔮", f"Гороскоп · {name} {icon}", "на сегодня") + "\n" + ui.quote(escape(text)),
        reply_markup=kb_rows([("📤 Отправить другу", share)])))
