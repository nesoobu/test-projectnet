import asyncio
import logging
import random
import re
from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import Message

import config
import db
import limits
import llm
import persona

router = Router()
log = logging.getLogger("chat")

TRIGGER = re.compile(r"^\s*(" + "|".join(config.GROUP_TRIGGERS) + r")[\s,!.:?-]*", re.I)
REMEMBER = re.compile(r"^\s*запомни[\s,:-]+(.+)", re.I | re.S)

FAILS = [
    "мозг завис, дай минутку 🫠",
    "что-то я туплю. спроси ещё раз чуть позже",
    "у меня перерыв на кофе, вернусь скоро ☕",
]


def _addressed(m: Message, me_id: int, me_username: str) -> str | None:
    """Вернёт текст для Сони, если обращаются к ней, иначе None."""
    text = m.text or ""
    t = TRIGGER.match(text)
    if m.chat.type == "private":
        return text[t.end():].strip() if t else text
    if m.reply_to_message and m.reply_to_message.from_user.id == me_id:
        return text
    if me_username and f"@{me_username.lower()}" in text.lower():
        return re.sub(f"@{me_username}", "", text, flags=re.I).strip()
    if t:
        return text[t.end():].strip()
    return None


@router.message(F.text, ~F.text.startswith("/"))
async def talk(m: Message, bot: Bot):
    me = await bot.me()
    text = _addressed(m, me.id, me.username or "")
    if text is None:
        return
    group = m.chat.type != "private"
    if group and not await db.chat_ai_on(m.chat.id):
        return
    if not text:
        return await m.reply(random.choice(["м?", "я тут", "чего? 👀"]))
    r = REMEMBER.match(text)
    if r:
        await db.add_fact(m.from_user.id, r.group(1).strip())
        return await m.reply(random.choice(["запомнила 🖤", "ок, записала себе", "буду знать 😌"]))
    await converse(m, bot, text, group)


# ================= разговор =================
_since_mem: dict[int, int] = {}
MEM_EVERY = 6
VOICE_REPLY_CHANCE = 0.5      # если тебе прислали голосовое — ответить голосом
NIGHT_VOICE_CHANCE = 0.12     # ночью иногда отвечает голосом и на текст
DM_REACT_CHANCE = 0.12


def _night() -> bool:
    from datetime import datetime
    h = datetime.now(persona.MSK).hour
    return h >= 23 or h < 6


async def converse(m: Message, bot: Bot, text: str, group: bool, voice_in: bool = False):
    uid = m.from_user.id
    name = m.from_user.first_name or "аноним"
    if not await limits.take(uid):
        return await m.reply(limits.tired_text(uid))
    await bot.send_chat_action(m.chat.id, ChatAction.TYPING)
    u = await db.get_user(uid) or {}
    mode = user_mode(u)
    hist = await db.get_history(m.chat.id, config.HISTORY_LEN)
    msgs = [{"role": "system", "content": persona.system_prompt(name, await db.get_facts(uid), group, mode,
                                                                u.get("close") or 0)}]
    if not group:
        from handlers import studio
        doc = await studio.doc_context(m.chat.id)
        if doc:
            msgs[0]["content"] += "\n\n" + doc
    msgs += [{"role": h["role"], "content": h["text"]} for h in hist]
    user_line = f"{name}: {text}" if group else text
    msgs.append({"role": "user", "content": user_line})
    want_voice = not group and ((voice_in and random.random() < VOICE_REPLY_CHANCE)
                                or (_night() and random.random() < NIGHT_VOICE_CHANCE))
    shown = None
    try:
        if not group and not want_voice and config.STREAM:
            answer, shown = await _streamed(m, msgs)
        else:
            answer = await llm.ask(msgs, feature="chat")
    except Exception as e:
        log.warning("llm: %s", e)
        await limits.give_back(uid)
        return await m.reply(random.choice(FAILS))
    if not answer:
        return await m.reply("…")
    await db.add_history(m.chat.id, uid, "user", user_line)
    await db.add_history(m.chat.id, 0, "assistant", answer)
    db.emit("chat", uid)

    if not group:
        await db.q_run("UPDATE users SET close=close+1 WHERE id=?", uid)
        if random.random() < DM_REACT_CHANCE:
            asyncio.create_task(_react(bot, m, text))
        _since_mem[uid] = _since_mem.get(uid, 0) + 1
        if _since_mem[uid] >= MEM_EVERY:
            _since_mem[uid] = 0
            asyncio.create_task(auto_memory(m.chat.id, uid))
    if shown:
        return
    if want_voice and len(answer) < 600 and await _voice_reply(m, bot, answer, mode):
        return
    import moji   # волна 70: иногда — моё лицо с эмоцией по настроению
    await m.reply(moji.decorate(text, answer[:3990]), parse_mode=None)


def user_mode(u: dict) -> str:
    """Режим личности; платные — только пока активна Соня+."""
    from handlers import extra
    mode = u.get("mode") or "base"
    info = persona.MODES.get(mode)
    if not info or (info[2] and not extra.active(u.get("id") or 0)):
        return "base"
    return mode


STREAM_FIRST = 25     # первое сообщение — когда набралось столько символов
STREAM_EVERY = 1.2    # дальше правим не чаще раза в 1.2 с (лимиты телеграма)
DRAFT_EVERY = 0.35    # черновик можно обновлять часто — он анимируется


async def _streamed(m: Message, msgs: list) -> tuple[str, Message | None]:
    """Ответ по мере набора. В личке — нативный черновик Telegram (sendMessageDraft: плавно, без лимита правок),
    не вышло — старый способ: шлём начало и дописываем правками. → (текст, отправленное сообщение или None)."""
    import time as _t
    text, shown, last = "", None, 0.0
    draft = m.chat.type == "private"
    draft_id = random.randint(1, 2 ** 31 - 1)
    if draft:
        try:
            await m.bot.send_message_draft(m.chat.id, draft_id, text="")   # «думает…»
        except Exception as e:
            log.info("draft off: %s", e)
            draft = False
    try:
        async for piece in llm.stream(msgs, feature="chat"):
            text += piece
            now = _t.monotonic()
            if draft:
                if now - last >= DRAFT_EVERY:
                    last = now
                    try:
                        await m.bot.send_message_draft(m.chat.id, draft_id, text=text.strip()[:4000])
                    except Exception as e:
                        log.info("draft → правки: %s", e)
                        draft = False
                continue
            if shown is None and len(text.strip()) >= STREAM_FIRST:
                shown, last = await m.reply(text.strip()[:4000] + " ▍", parse_mode=None), now
            elif shown is not None and now - last >= STREAM_EVERY:
                last = now
                try:
                    await shown.edit_text(text.strip()[:4000] + " ▍", parse_mode=None)
                except TelegramBadRequest:
                    pass
    except llm.LLMError as e:
        if not text.strip():
            log.info("stream → обычный ответ: %s", e)
            return await llm.ask(msgs, feature="chat"), None
    text = text.strip()
    if draft:   # черновик живёт ~30 с — закрепляем ответ настоящим сообщением
        import moji
        user = str(msgs[-1].get("content") or "") if msgs else ""
        return text, (await m.reply(moji.decorate(user, text[:3990]) or "…", parse_mode=None) if text else None)
    if shown is not None:
        try:
            await shown.edit_text(text[:4000] or "…", parse_mode=None)
        except TelegramBadRequest:
            pass
    return text, shown


def voice_style(mode: str) -> tuple[str, str]:
    """Интонация озвучки: ночью тише и медленнее, злая — бойчее, милая — выше."""
    if _night():
        return "-10%", "-4Hz"
    return {"evil": ("+8%", "-2Hz"), "sweet": ("+0%", "+6Hz"), "nerd": ("+5%", "+0Hz"),
            "psy": ("-8%", "-2Hz")}.get(mode, ("+0%", "+0Hz"))


async def _voice_reply(m: Message, bot: Bot, answer: str, mode: str = "base") -> bool:
    from aiogram.types import FSInputFile
    from handlers import tools
    from downloader import core
    path = None
    try:
        await bot.send_chat_action(m.chat.id, ChatAction.RECORD_VOICE)
        rate, pitch = voice_style(mode)
        path = await tools.tts(re.sub(r"[*_`#>]", "", answer), "sonya", rate, pitch)
        await m.reply_voice(FSInputFile(path))
        return True
    except Exception as e:
        log.info("voice reply: %s", e)
        return False
    finally:
        core.remove(path)


async def _react(bot: Bot, m: Message, text: str):
    from aiogram.types import ReactionTypeEmoji
    from handlers.intents import MOODS
    emoji = next((random.choice(o) for rx, o in MOODS if rx.search(text)), random.choice(["❤️", "👍", "🔥", "😁"]))
    await asyncio.sleep(random.uniform(0.5, 2))
    try:
        await bot.set_message_reaction(m.chat.id, m.message_id, [ReactionTypeEmoji(emoji=emoji)])
    except Exception:
        pass


MEM_PROMPT = (
    "Из переписки выдели НОВЫЕ долговременные факты о собеседнике (не о Соне): имя/как зовут, город, "
    "учёба/работа, увлечения, любимое (музыка, игры, аниме…), питомцы, важные планы. "
    "Не записывай: пароли, деньги, здоровье, политику, религию, интим, адреса, телефоны, мимолётное настроение. "
    "Каждый факт — короткая фраза от третьего лица («любит аниме»). "
    "Уже известно: {known}. Повторы не нужны. "
    "Ответ строго JSON-массив строк, максимум 3. Если нового нет — []."
)


async def auto_memory(chat_id: int, uid: int):
    import json
    try:
        hist = await db.get_history(chat_id, 12)
        user_lines = [h["text"] for h in hist if h["role"] == "user"]
        if not user_lines:
            return
        known = await db.get_facts(uid)
        out = await llm.ask([{"role": "system", "content": MEM_PROMPT.format(known="; ".join(known) or "ничего")},
                             {"role": "user", "content": "\n".join(user_lines)[-3000:]}],
                            max_tokens=400, temperature=0.2, feature="memory")
        mt = re.search(r"\[.*\]", out, re.S)
        facts = json.loads(mt.group(0)) if mt else []
        low = [k.lower() for k in known]
        for f in facts[:3]:
            f = str(f).strip()[:150]
            if len(f) > 3 and not any(f.lower() in k or k in f.lower() for k in low):
                await db.add_fact(uid, f)
    except Exception as e:
        log.info("auto memory: %s", e)
