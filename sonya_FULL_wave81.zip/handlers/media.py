"""Скачивание по ссылкам, расшифровка голосовых/кружков, настройки группы."""
import asyncio
import logging
import re
import shutil
import time
import uuid
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import llm
import stt
import ui
from autopost import media_dl
from downloader import core, links as L
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("media")

LONG_VIDEO = 10 * 60          # дольше — спрашиваем: видео или звук
PLUS_LONG = 30 * 60           # волна 44: видео дольше — с Соней+ (звук — всем)
_long_tok: set[str] = set()   # токены видео длиннее PLUS_LONG
MAX_VOICE = 15 * 60           # голосовые длиннее не расшифровываем
_busy: set[int] = set()       # кто сейчас качает
_tokens: dict[str, tuple[str, str, str, float]] = {}  # token → (url, platform, label, ts)
_texts: dict[str, tuple[str, float]] = {}             # token → (расшифровка, ts)


def _token(url: str, platform: str, label: str) -> str:
    """Короткий ключ ссылки для кнопок. Один и тот же для одной ссылки и переживает перезапуск (kv)."""
    import hashlib
    now = time.time()
    for k, v in list(_tokens.items()):
        if now - v[3] > 86400:
            _tokens.pop(k, None)
    t = hashlib.md5(url.encode()).hexdigest()[:10]
    _tokens[t] = (url, platform, label, now)
    try:
        asyncio.get_running_loop().create_task(db.kv_set(f"dlt:{t}", f"{platform}|{label}|{url}"))
    except RuntimeError:
        pass
    return t


async def get_token(tok: str) -> tuple[str, str, str] | None:
    """→ (url, platform, label)"""
    if tok in _tokens:
        return _tokens[tok][:3]
    raw = await db.kv_get(f"dlt:{tok}")
    if raw.count("|") >= 2:
        platform, label, url = raw.split("|", 2)
        _tokens[tok] = (url, platform, label, time.time())
        return url, platform, label
    return None


def video_kb(tok: str, tc: bool = False):
    from handlers import tochannel
    return kb_rows([("🎵 Звук", f"dl:a:{tok}"), ("🔎 Что за песня", f"dl:s:{tok}")],
                   [("🛠 Ещё: качество, кружок, обрезка…", f"vt:more:{tok}")], [tochannel.BTN] if tc else [])


async def _hist(uid: int, tok: str, kind: str, file_id: str, title: str):
    await db.q_run("INSERT INTO dl_hist VALUES(?,?,?,?,?,?)", uid, tok, kind, file_id, title[:120], int(time.time()))


def _is_group(m: Message) -> bool:
    return m.chat.type in ("group", "supergroup")


async def _allowed(m: Message, flag: str) -> bool:
    if m.chat.type == "private":
        return True
    if _is_group(m):
        return await db.chat_flag(m.chat.id, flag)
    return False


# ================= скачивание =================
def _links_of(m: Message) -> list[L.Link]:
    return L.find_links(m.text or m.caption or "")


async def has_links(m: Message) -> bool | dict:
    if m.from_user and m.from_user.is_bot:
        return False
    found = _links_of(m)
    return {"links": found} if found else False


def _caption(link: L.Link, title: str, bot_username: str) -> str:
    t = escape((title or link.label)[:90])
    cap = f'<a href="{escape(link.url, quote=True)}">{link.label}</a> · {t}'
    if bot_username:
        cap += f"\n<i>скачала @{bot_username}</i>"
    return cap


async def _status(m: Message, text: str) -> Message | None:
    try:
        return await m.reply(text, disable_notification=True)
    except TelegramBadRequest:
        return None


async def _fail(m: Message, status: Message | None, reason: str):
    text = f"😕 не вышло: {escape(reason)}"
    try:
        if status:
            await status.edit_text(text)
        else:
            status = await m.reply(text)
    except TelegramBadRequest:
        return
    if _is_group(m) and status:
        await asyncio.sleep(20)
        try:
            await status.delete()
        except TelegramBadRequest:
            pass


async def _send_cached(m: Message, key: str, caption: str, kb) -> bool:
    c = await db.dl_cache_get(key)
    if not c:
        return False
    if c["type"] == "audio" and c.get("title"):
        from handlers import tools
        kb = kb_rows([tools.lyrics_btn(c["title"])])
    fn = {"video": m.reply_video, "audio": m.reply_audio, "photo": m.reply_photo}[c["type"]]
    try:
        await fn(c["file_id"], caption=caption, reply_markup=kb)
        return True
    except TelegramBadRequest:
        return False


async def _deliver(m: Message, bot: Bot, link: L.Link, kind: str, status: Message | None):
    """kind: video | audio"""
    me = await bot.me()
    key = f"{kind}:{link.url}"
    tok = _token(link.url, link.platform, link.label)
    from handlers import tochannel
    tc = await tochannel.has_channels(m.from_user.id)
    kb = video_kb(tok, tc) if kind == "video" else (kb_rows([tochannel.BTN]) if tc else None)
    if await _send_cached(m, key, _caption(link, "", me.username), kb):
        c = await db.dl_cache_get(key)
        await _hist(m.from_user.id, tok, kind, c["file_id"], c.get("title") or link.label)
        await db.count_dl(m.from_user.id)
        await _after_dl(m)
        if status:
            await status.delete()
        return
    await bot.send_chat_action(m.chat.id, ChatAction.UPLOAD_VIDEO if kind == "video" else ChatAction.UPLOAD_VOICE)
    f = None
    prog: dict = {}
    stop = asyncio.Event()
    live = asyncio.create_task(_live(status, prog, link.label, stop)) if status else None
    t0 = time.time()
    try:
        if link.kind == "music_search":
            f = await core.music_search(link.url, link.platform)
        else:
            import premium
            f = await core.download(link.url, kind, progress=prog,
                                    priority=config.PROFILE == "full" and premium.plus(m.from_user.id))
        stop.set()
        if status:
            try:
                await status.edit_text("📤 отправляю…")
            except TelegramBadRequest:
                pass
        cap = _caption(link, f.get("title"), me.username) + _who(m)
        if kind == "video":
            sent = await m.reply_video(FSInputFile(f["path"]), caption=cap, reply_markup=kb, supports_streaming=True,
                                       duration=f.get("duration") or None, width=f.get("width"), height=f.get("height"))
            fid = sent.video.file_id if sent.video else None
        else:
            from handlers import tools
            name = " ".join(x for x in (f.get("performer"), f.get("title")) if x) or f.get("query") or ""
            sent = await m.reply_audio(FSInputFile(f["path"]), caption=cap, title=f.get("title") or None,
                                       performer=f.get("performer") or None, duration=f.get("duration") or None,
                                       reply_markup=kb_rows([tools.lyrics_btn(name)] if name else [],
                                                            [tochannel.BTN] if tc else []) if name or tc else None)
            fid = sent.audio.file_id if sent.audio else None
        if fid:
            await db.dl_cache_put(key, kind, fid, f.get("title") or "")
            await _hist(m.from_user.id, tok, kind, fid, f.get("title") or link.label)
        await db.count_dl(m.from_user.id)
        await log_dl(link.platform, True, "", time.time() - t0)
        if status:
            await status.delete()
        await _clean_link(m)
        if kind == "video":   # файл ещё пригодится для кружка, GIF, обрезки — подержим 20 минут
            from handlers import vtools
            vtools.keep(tok, f["path"])
            f = None
        await _after_dl(m)
    except media_dl.DLError as e:
        stop.set()
        await log_dl(link.platform, False, str(e), time.time() - t0)
        await _fail(m, status, str(e))
    except TelegramBadRequest as e:
        stop.set()
        await log_dl(link.platform, False, "telegram: " + str(e)[:60], time.time() - t0)
        await _fail(m, status, f"телеграм не принял файл ({str(e)[:60]})")
    except Exception as e:   # что угодно ещё — не оставляем вечное «качаю…»
        stop.set()
        log.warning("deliver %s: %r", link.platform, e)
        await log_dl(link.platform, False, type(e).__name__ + ": " + str(e)[:80], time.time() - t0)
        await _fail(m, status, "что-то сломалось на моей стороне, попробуй ещё раз")
    finally:
        stop.set()
        if live:
            live.cancel()
        core.remove(f and f.get("path"))


# ---------- живой статус: очередь → проценты → отправка ----------
def _bar(pct: int) -> str:
    n = max(0, min(10, pct // 10))
    return "▰" * n + "▱" * (10 - n)


def progress_text(prog: dict, label: str) -> str | None:
    if not prog:
        if core._sem.locked():
            ahead = max(0, core.WAITING[0] - 1)
            return "⏳ много желающих — ты в очереди" + (f", перед тобой {ahead}" if ahead else ", следующий")
        return None
    pct = prog.get("pct")
    if pct is None:
        return f"⏬ качаю с {label}… {prog.get('done', 0) / 1048576:.1f} МБ"
    speed = prog.get("speed") or 0
    eta = prog.get("eta")
    tail = " · ".join(x for x in (f"{speed / 1048576:.1f} МБ/с" if speed else "",
                                  f"~{eta} с" if eta else "") if x)
    return f"⏬ качаю с {label}\n{_bar(pct)} {pct}%" + (f"\n<i>{tail}</i>" if tail else "")


LIVE_EVERY = 2.5


async def _live(status: Message, prog: dict, label: str, stop: asyncio.Event):
    last = ""
    while not stop.is_set():
        try:
            await asyncio.wait_for(stop.wait(), LIVE_EVERY)
            return
        except asyncio.TimeoutError:
            pass
        text = progress_text(prog, label)
        if text and text != last:
            try:
                await status.edit_text(text)
                last = text
            except TelegramBadRequest:
                pass
            except Exception:
                return


def _who(m: Message) -> str:
    if _is_group(m) and m.from_user:
        return f"\n<i>по просьбе {escape(m.from_user.first_name or '')[:30]}</i>"
    return ""


async def _clean_link(m: Message):
    """В группе (если включено): удаляем сообщение, где была только ссылка — остаётся аккуратное видео."""
    if not _is_group(m) or not await db.chat_flag(m.chat.id, "dl_clean"):
        return
    text = (m.text or m.caption or "").strip()
    if any(not w.startswith("http") for w in text.split()):
        return   # в сообщении есть ещё что-то кроме ссылки — не трогаем
    try:
        await m.delete()
    except TelegramBadRequest:
        pass


async def log_dl(platform: str, ok: bool, err: str, sec: float):
    try:
        await db.q_run("INSERT INTO dl_log VALUES(?,?,?,?,?)", platform, int(ok), err[:120], round(sec, 1),
                       int(time.time()))
    except Exception as e:
        log.info("dl_log: %s", e)


async def _after_dl(m: Message):
    import config
    if config.PROFILE != "full" and m.chat.type == "private" and m.from_user:
        from handlers import solo
        await solo.nudge(m, m.from_user.id)


async def _album(m: Message, urls: list[str], cap: str):
    """Фото альбомами по 10. Качаем сами — CDN соцсетей часто не пускают Telegram."""
    from aiogram.types import InputMediaPhoto, BufferedInputFile
    photos = []
    for u in urls:
        try:
            photos.append(BufferedInputFile(await core.fetch_bytes(u), "p.jpg"))
        except media_dl.DLError as e:
            log.info("album photo: %s", e)
    if not photos:
        raise media_dl.DLError("фото не скачались")
    for i in range(0, len(photos), 10):
        chunk = photos[i:i + 10]
        if len(chunk) == 1:
            await m.reply_photo(chunk[0], caption=cap if i == 0 else None)
        else:
            await m.reply_media_group([InputMediaPhoto(media=p, caption=cap if i == 0 and k == 0 else None)
                                       for k, p in enumerate(chunk)])


async def _tiktok_photos(m: Message, bot: Bot, link: L.Link, status: Message | None, url: str):
    me = await bot.me()
    try:
        if status:
            await status.edit_text("🖼 это фото-карусель — собираю все кадры…")
        got = await core.tiktok_photos(url)
        await _album(m, got["images"], _caption(link, got.get("title") or "фото", me.username))
        if got.get("music"):
            try:
                data = await core.fetch_bytes(got["music"])
                from aiogram.types import BufferedInputFile
                await m.reply_audio(BufferedInputFile(data, "sound.mp3"), title="звук из поста", performer="TikTok")
            except Exception as e:
                log.info("tt music: %s", e)
        if status:
            await status.delete()
    except media_dl.DLError as e:
        await _fail(m, status, str(e))
    except TelegramBadRequest as e:
        await _fail(m, status, f"телеграм не принял ({str(e)[:60]})")


async def _pin(m: Message, bot: Bot, link: L.Link, status: Message | None):
    me = await bot.me()
    f = None
    try:
        f = await core.pinterest(link.url)
        cap = _caption(link, "", me.username)
        many = []
        if f["type"] != "video":   # карусель пина — альбомом
            try:
                url = link.url if "pin.it/" not in link.url else await core.resolve_redirect(link.url)
                many = media_dl.pinterest_images(await media_dl.pinterest_pin(url))
            except Exception as e:
                log.info("pin carousel: %s", e)
        if f["type"] == "video":
            await m.reply_video(FSInputFile(f["path"]), caption=cap, supports_streaming=True)
        elif len(many) > 1:
            await _album(m, many, cap)
        else:
            await m.reply_photo(f["url"], caption=cap)
        if status:
            await status.delete()
    except media_dl.DLError as e:
        await _fail(m, status, str(e))
    except TelegramBadRequest as e:
        await _fail(m, status, f"телеграм не принял ({str(e)[:60]})")
    finally:
        core.remove(f and f.get("path"))


async def handle_link(m: Message, bot: Bot, link: L.Link):
    group = _is_group(m)
    if link.kind == "collection":
        if not group:
            await m.reply(f"это {link.label}-канал или плейлист 🙃 кинь ссылку на конкретное видео или трек")
        return
    if link.kind == "pin":
        status = await _status(m, "⏬ достаю из Pinterest…")
        return await _pin(m, bot, link, status)
    if link.kind in ("audio", "music_search"):
        what = "ищу трек…" if link.kind == "music_search" else f"качаю звук с {link.label}…"
        status = await _status(m, f"🎧 {what}")
        return await _deliver(m, bot, link, "audio", status)

    import config
    if config.PROFILE == "music":   # музыкальному боту видео не нужно — нужен трек из него
        from handlers import melody
        return await melody.whatsong(m, link.url)
    # видео: сначала смотрим, что там
    status = await _status(m, f"⏬ смотрю, что на {link.label}…")
    if link.platform == "tiktok":
        try:   # короткие vt./vm. — раскрываем: так видно, фото-карусель это или видео
            full = await core.resolve_redirect(link.url) if re.search(r"//(vt|vm)\.", link.url) else link.url
        except Exception:
            full = link.url
        if "/photo/" in full:
            return await _tiktok_photos(m, bot, link, status, full)
        link = L.Link(full, link.platform, link.kind, link.label)
    try:
        info = await core.probe(link.url)
    except media_dl.DLError as e:
        if link.platform == "tiktok" and "не умею" in str(e):
            return await _tiktok_photos(m, bot, link, status, link.url)
        if link.platform == "tiktok":   # yt-dlp сломался — tikwm качает сам
            if status:
                await status.edit_text(f"⏬ качаю с {link.label}…")
            return await _deliver(m, bot, link, "video", status)
        await log_dl(link.platform, False, str(e), 0)
        return await _fail(m, status, str(e))
    if info.get("collection"):
        if status:
            await status.edit_text("это подборка/плейлист — кинь ссылку на одно видео")
        return
    if info.get("is_live"):
        return await _fail(m, status, "это прямой эфир, его не скачать")
    if info.get("audio_only"):
        if status:
            await status.edit_text(f"🎧 качаю звук с {link.label}…")
        return await _deliver(m, bot, link, "audio", status)
    dur = info.get("duration") or 0
    if dur > LONG_VIDEO:
        return await long_card(m, link, info, status)
    if status:
        await status.edit_text(f"⏬ качаю с {link.label}…")
    await _deliver(m, bot, link, "video", status)


# ================= волна 55: карточка длинного видео =================
def hms(sec: int) -> str:
    h, m_, s_ = sec // 3600, sec % 3600 // 60, sec % 60
    return f"{h}:{m_:02d}:{s_:02d}" if h else f"{m_}:{s_:02d}"


def _num(n) -> str:
    if not n:
        return ""
    return f"{n / 1e6:.1f} млн".replace(".0 ", " ") if n >= 1e6 else f"{n / 1e3:.0f} тыс" if n >= 1e3 else str(n)


def card_view(info: dict, tok: str, plus: bool) -> tuple[str, object]:
    """Обложка + название, автор, длина, просмотры; кнопки — только то, что реально влезет в Telegram,
    с весом файла. Не влезает видео — честно говорю и предлагаю звук (битрейт под лимит) или фрагмент."""
    dur = info.get("duration") or 0
    lim = media_dl.MAX_BYTES
    long_ = dur > PLUS_LONG
    meta = " · ".join(x for x in (f"👤 {escape((info.get('uploader') or '')[:40])}" if info.get("uploader") else "",
                                   f"⏱ {hms(dur)}", f"👁 {_num(info.get('views'))}" if info.get("views") else "") if x)
    fits = [(h, sz) for h, sz in (info.get("qualities") or []) if sz and sz <= lim * 0.97]
    fits = fits[-3:]
    kbps = core.fit_kbps(dur)
    a_mb = max(1, round(dur * kbps / 8 / 1024))
    rows, vrow = [], []
    for h, sz in fits:
        gem = "💎 " if (long_ or h > 720) and not plus else ""
        vrow.append((f"{gem}🎬 {h}p · {sz / 1048576:.0f} МБ", f"vt:qh:{h}:{tok}"))
    if vrow:
        rows.append(vrow)
    rows.append([(f"🎵 MP3 · ~{a_mb} МБ", f"dl:a:{tok}", "success"), ("✂️ Фрагмент", f"vt:cut:{tok}")])
    rows.append([("ℹ️ Описание", f"vt:info:{tok}"), ("🖼 Обложка", f"vt:cover:{tok}")])
    lines = [f"🎬 <b>{escape((info.get('title') or '')[:120])}</b>", meta, ""]
    if fits:
        lines.append("<i>выбери, что скачать — рядом вес файла</i>")
    else:
        smallest = min((sz for _, sz in (info.get("qualities") or []) if sz), default=0)
        lines.append(ui.quote(f"видео целиком — {'от ' + str(round(smallest / 1048576)) + ' МБ' if smallest else 'слишком большое'}, "
                              f"а ботам Telegram разрешает только {config.mb(lim)}.\n"
                              "🎵 звук сожму, чтобы влез · ✂️ фрагмент — любой кусок видео"))
    if kbps < 128:
        lines.append(ui.hint(f"звук {kbps} кбит/с — для речи и подкастов отлично"))
    if long_ and not plus and fits:
        lines.append(ui.hint("💎 видео длиннее 30 мин — с Соней+, звук и фрагменты — бесплатно"))
    return "\n".join(x for x in lines if x is not None), kb_rows(*rows)


async def long_card(m: Message, link: L.Link, info: dict, status: Message | None):
    import premium
    tok = _token(link.url, link.platform, link.label)
    if (info.get("duration") or 0) > PLUS_LONG:
        _long_tok.add(tok)
    text, kb = card_view(info, tok, premium.plus(m.from_user.id if m.from_user else 0))
    if info.get("thumbnail"):
        try:
            await m.reply_photo(info["thumbnail"], caption=text[:1024], reply_markup=kb)
            if status:
                await status.delete()
            return
        except TelegramBadRequest as e:
            log.info("card photo: %s", e)
    if status:
        return await status.edit_text(text, reply_markup=kb)
    await m.reply(text, reply_markup=kb)


def _asked(m: Message) -> bool:
    """«Сонь, скачай …» — просьба лично, работает даже при выключенном авто-скачивании."""
    from handlers.chat import TRIGGER
    t = TRIGGER.match(m.text or m.caption or "")
    return bool(t and re.match(r"(скачай|скачать|загрузи|сохрани|качни)", (m.text or m.caption or "")[t.end():], re.I))


@router.message(has_links)
async def on_links(m: Message, bot: Bot, links: list):
    if not await _allowed(m, "auto_dl") and not _asked(m):
        return
    uid = m.from_user.id
    if uid in _busy:
        if m.chat.type == "private":
            await m.reply("⏳ погоди, я ещё прошлое качаю")
        return
    _busy.add(uid)
    try:
        for link in links[:5 if m.chat.type == "private" else 2]:
            await handle_link(m, bot, link)
    finally:
        _busy.discard(uid)


@router.callback_query(F.data.startswith("dl:"))
async def cb_dl(cb: CallbackQuery, bot: Bot):
    _, kind, tok = cb.data.split(":")
    rec = await get_token(tok)
    if not rec:
        return await cb.answer("ссылка устарела — пришли её ещё раз", show_alert=True)
    if cb.from_user.id in _busy:
        return await cb.answer("⏳ я ещё качаю прошлое", show_alert=True)
    url, platform, label = rec
    if kind == "v" and tok in _long_tok:
        import premium
        if not premium.plus(cb.from_user.id):
            await cb.answer()
            return await premium.upsell(cb.message, cb.from_user.id, "long")
    if kind == "s":
        await cb.answer("слушаю…")
        from handlers import melody
        _busy.add(cb.from_user.id)
        try:
            return await melody.whatsong(cb.message, url)
        finally:
            _busy.discard(cb.from_user.id)
    link = L.Link(url, platform, "video", label)
    await cb.answer("качаю…")
    src = cb.message.reply_to_message or cb.message
    status = None
    if cb.message.reply_markup and cb.message.text:  # это было сообщение-вопрос — превращаем в статус
        try:
            status = await cb.message.edit_text("⏬ качаю…")
        except TelegramBadRequest:
            status = None
    elif cb.message.photo:   # волна 55: карточка с обложкой остаётся, статус — отдельным ответом
        try:
            status = await cb.message.reply("⏬ качаю…" if kind != "a" else "🎧 качаю звук…", disable_notification=True)
        except TelegramBadRequest:
            status = None
    _busy.add(cb.from_user.id)
    try:
        await _deliver(src, bot, link, "audio" if kind == "a" else "video", status)
    finally:
        _busy.discard(cb.from_user.id)


# ================= расшифровка =================
async def _extract_audio(path: str) -> str:
    """Из видео/большого аудио — лёгкий mp3 (моно 16 кГц), чтобы влезть в лимиты Whisper."""
    if not shutil.which("ffmpeg"):
        return path
    out = path.rsplit(".", 1)[0] + "_a.mp3"
    proc = await asyncio.create_subprocess_exec(
        "ffmpeg", "-y", "-loglevel", "error", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-b:a", "48k", out,
        stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    await proc.wait()
    return out if proc.returncode == 0 else path


async def transcribe_message(m: Message, bot: Bot, target: Message, quiet: bool = False):
    obj = target.voice or target.video_note or target.audio or target.video
    if not obj:
        return await m.reply("ответь /text на голосовое, кружок, аудио или видео")
    dur = getattr(obj, "duration", 0) or 0
    if dur > MAX_VOICE:
        if not quiet:
            await m.reply(f"слишком длинное ({dur // 60} мин) — расшифровываю до {MAX_VOICE // 60} мин")
        return
    if (getattr(obj, "file_size", 0) or 0) > config.TG_GET_MAX:
        if not quiet:
            await m.reply(f"файл больше {config.mb(config.TG_GET_MAX)} — телеграм не даёт мне его скачать")
        return
    await bot.send_chat_action(m.chat.id, ChatAction.TYPING)
    media_dl._dir()
    ext = ".oga" if target.voice else ".mp4" if (target.video_note or target.video) else ".mp3"
    path = str(media_dl.DL / (uuid.uuid4().hex + ext))
    paths = [path]
    try:
        await bot.download(obj.file_id, destination=path)
        if target.video_note or target.video or (target.audio and (obj.file_size or 0) > 8 * 1024 * 1024):
            a = await _extract_audio(path)
            if a != path:
                paths.append(a)
                path = a
        text = await stt.transcribe(path)
    except stt.STTError as e:
        if not quiet:
            await target.reply(f"😕 не расшифровала: {escape(str(e)[:150])}")
        return
    except Exception as e:
        log.warning("stt: %s", e)
        if not quiet:
            await target.reply("😕 не получилось скачать запись")
        return
    finally:
        for p in paths:
            core.remove(p)
    if not text:
        return await target.reply("🤐 тут тишина или неразборчиво")
    icon = "🎥" if target.video_note else "🎙" if target.voice else "📝"
    body = escape(text)
    if len(body) > 3900:
        body = body[:3900] + "…"
    html = f"{icon} <blockquote expandable>{body}</blockquote>" if len(text) > 300 else f"{icon} <i>{body}</i>"
    kb = None
    if len(text) > 500:
        tok = uuid.uuid4().hex[:10]
        _texts[tok] = (text, time.time())
        kb = kb_rows([("✨ Кратко", f"vt:sum:{tok}")])
    await target.reply(html, reply_markup=kb)
    return text


@router.message(F.voice | F.video_note)
async def on_voice(m: Message, bot: Bot):
    if not await _allowed(m, "auto_voice"):
        return
    text = await transcribe_message(m, bot, m, quiet=_is_group(m))
    # в личке голосовое (не пересланное) — это разговор с Соней: отвечаем, иногда голосом
    import config
    if isinstance(text, str) and text and m.chat.type == "private" and not m.forward_origin and config.PROFILE == "full":
        from handlers import chat
        await chat.converse(m, bot, text, group=False, voice_in=True)


@router.message(Command("text"))
async def cmd_text(m: Message, bot: Bot):
    target = m.reply_to_message
    if not target:
        return await m.reply("ответь <b>/text</b> на голосовое, кружок, аудио или видео — расшифрую")
    await transcribe_message(m, bot, target)


@router.callback_query(F.data.startswith("vt:sum:"))
async def cb_sum(cb: CallbackQuery):
    rec = _texts.get(cb.data.split(":")[2])
    if not rec:
        return await cb.answer("текст устарел", show_alert=True)
    await cb.answer("сокращаю…")
    try:
        out = await llm.ask([{"role": "system", "content": "Перескажи суть голосового сообщения в 2–4 коротких "
                                                           "пунктах, на языке оригинала. Без вступлений."},
                             {"role": "user", "content": rec[0][:6000]}], max_tokens=500, temperature=0.3)
    except Exception as e:
        return await cb.message.reply(f"ии не ответил: {escape(str(e)[:100])}")
    await cb.message.reply(f"✨ <b>кратко</b>\n{escape(out)}")


# ================= настройки группы =================
FLAGS = [("ai_on", "💬 Болтовня Сони"), ("auto_dl", "⬇️ Авто-скачивание ссылок"),
         ("auto_voice", "📝 Расшифровка голосовых и кружков"), ("greet", "👋 Приветствие новичков"),
         ("reacts", "💜 Живые реакции Сони"), ("captcha", "🛡 Капча для новичков"),
         ("antiflood", "🚫 Антифлуд (мут на 5 мин)"), ("antilink", "🔗 Ссылки только у админов"),
         ("bdays", "🎂 Поздравлять с днём рождения"), ("daily_sum", "🌙 Итоги дня в 23:00"),
         ("antispam", "🤖 ИИ-антиспам для новичков"), ("clean_service", "🧹 Удалять «вошёл / вышел»"),
         ("rp", "🤗 РП-действия (обнять, кусь…)"), ("dl_clean", "🧹 Удалять ссылку после скачивания")]


async def _is_admin(bot: Bot, chat_id: int, uid: int) -> bool:
    import config
    if uid == config.OWNER_ID:
        return True
    try:
        mem = await bot.get_chat_member(chat_id, uid)
        return mem.status in ("administrator", "creator")
    except TelegramBadRequest:
        return False


async def settings_view(chat_id: int):
    import ui
    rows = []
    on_n = 0
    for flag, name in FLAGS:
        v = await db.chat_flag(chat_id, flag)
        on_n += bool(v)
        rows.append([(f"{ui.tog(v)} {name}", f"gs:{flag}")])
    text = (ui.head("⚙️", "Соня в этой группе", f"включено {on_n} из {len(FLAGS)} · нажми, чтобы переключить")
            + "\n" + ui.hint("менять могут админы. для капчи, антифлуда и антиспама дай мне право «блокировать», "
                             "для антиссылок — «удалять сообщения»"))
    return text, kb_rows(*rows)


@router.message(Command("settings"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_settings(m: Message, bot: Bot):
    await db.add_chat(m.chat.id, m.chat.title or "")
    if not await _is_admin(bot, m.chat.id, m.from_user.id):
        return await m.reply("настройки — только для админов группы")
    text, kb = await settings_view(m.chat.id)
    await m.reply(text, reply_markup=kb)


@router.message(Command("settings"))
async def cmd_settings_dm(m: Message):
    await m.answer("в личке я всегда качаю ссылки и расшифровываю голосовые 🖤\n"
                   "<b>/settings</b> работает в группах — там админы включают и выключают функции")


@router.callback_query(F.data.startswith("gs:"))
async def cb_gs(cb: CallbackQuery, bot: Bot):
    flag = cb.data[3:]
    if flag not in dict(FLAGS) or not cb.message:
        return await cb.answer()
    if not await _is_admin(bot, cb.message.chat.id, cb.from_user.id):
        return await cb.answer("только для админов", show_alert=True)
    cur = await db.chat_flag(cb.message.chat.id, flag)
    await db.set_chat_flag(cb.message.chat.id, flag, not cur)
    text, kb = await settings_view(cb.message.chat.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer("включено" if not cur else "выключено")
