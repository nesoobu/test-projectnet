"""Волна 58: 🤝 Соня-ассистент в личных чатах (Telegram Business).
Любой с Telegram Premium добавляет @Sonya_rubot в Settings → Telegram Business → Chatbots, и Соня помогает
в его личке: 🌙 автоответ (всем / только новым / по списку), 🎙 расшифровка входящих голосовых ему в ЛС,
🤖 ИИ-черновик ответа (отправляет он сам кнопкой), 📋 утренняя сводка «кому не ответил больше суток».
Работает только в профиле full. Настройки — у владельца подключения в личке с ботом.

Что НЕ делаем принципиально: не сохраняем и не показываем удалённые/одноразовые сообщения собеседников —
это слежка за людьми без их согласия (обработчик deleted_business_messages намеренно не регистрируем)."""
import asyncio
import json
import logging
import time
import uuid
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BusinessConnection
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("business")
OWNER_QUIET = 30 * 60      # сам писал в этот чат за последние 30 мин — молчу
DEF_COOL = 3 * 3600        # одному и тому же собеседнику автоответ не чаще раза в 3 часа
DEF_TEXT = "🤖 На связи чуть позже — вижу сообщение, скоро отвечу."
MODES = {"all": "всем", "new": "только новым", "list": "по списку"}
DEFAULT = {"on": 0, "mode": "new", "text": DEF_TEXT, "stt": 0, "draft": 0, "paused": 0, "summary": 1}
SCHEMA = ("CREATE TABLE IF NOT EXISTS biz_conn(bc TEXT PRIMARY KEY, uid INTEGER, can_reply INTEGER, "
          "can_read INTEGER, enabled INTEGER, ts INTEGER)",
          "CREATE TABLE IF NOT EXISTS biz_seen(uid INTEGER, chat_id INTEGER, name TEXT, first_ts INTEGER, "
          "last_in INTEGER DEFAULT 0, last_out INTEGER DEFAULT 0, replied INTEGER DEFAULT 0, "
          "PRIMARY KEY(uid, chat_id))")
_drafts: dict[str, tuple] = {}   # tok → (uid, bc, chat_id, text)


async def _ensure():
    for s in SCHEMA:
        await db.q_run(s)


# ================= настройки владельца =================
async def cfg_of(uid: int) -> dict:
    raw = await db.kv_get(f"biz:cfg:{uid}")
    return {**DEFAULT, **(json.loads(raw) if raw else {})}


async def save_cfg(uid: int, c: dict):
    await db.kv_set(f"biz:cfg:{uid}", json.dumps(c, ensure_ascii=False))


async def conn_of(uid: int) -> dict | None:
    await _ensure()
    return await db.q_one("SELECT * FROM biz_conn WHERE uid=? AND enabled=1 ORDER BY ts DESC LIMIT 1", uid)


# ================= подключение/отключение =================
@router.business_connection()
async def on_connect(bc: BusinessConnection, bot: Bot):
    await _ensure()
    r = bc.rights
    can_reply = bool(getattr(r, "can_reply", False)) if r else bool(getattr(bc, "can_reply", False))
    can_read = bool(getattr(r, "can_read_messages", False)) if r else False
    enabled = 1 if bc.is_enabled else 0
    await db.q_run("INSERT INTO biz_conn(bc, uid, can_reply, can_read, enabled, ts) VALUES(?,?,?,?,?,?) "
                   "ON CONFLICT(bc) DO UPDATE SET can_reply=excluded.can_reply, can_read=excluded.can_read, "
                   "enabled=excluded.enabled, ts=excluded.ts",
                   bc.id, bc.user.id, int(can_reply), int(can_read), enabled, int(time.time()))
    if not enabled:
        return
    text = (ui.head("🤝", "Соня-ассистент подключена!", "теперь помогаю в твоих личных чатах")
            + "\n" + ui.quote("🌙 автоответ, пока ты занят\n🎙 расшифрую входящие голосовые — сюда, в этот чат\n"
                              "🤖 подскажу ответ, а отправишь ты сам\n📋 утром — кому ты не ответил больше суток")
            + "\n" + ui.hint("ничего чужого не сохраняю и не показываю — работаю честно. настрой под себя 👇"))
    try:
        await bot.send_message(bc.user.id, text, reply_markup=await _settings_kb(bc.user.id))
    except TelegramBadRequest:
        pass


# ================= входящие сообщения в личке владельца =================
async def _seen(uid: int, chat_id: int, name: str) -> dict:
    await _ensure()
    row = await db.q_one("SELECT * FROM biz_seen WHERE uid=? AND chat_id=?", uid, chat_id)
    if not row:
        await db.q_run("INSERT OR IGNORE INTO biz_seen(uid, chat_id, name, first_ts) VALUES(?,?,?,?)",
                       uid, chat_id, name[:60], int(time.time()))
        return await db.q_one("SELECT * FROM biz_seen WHERE uid=? AND chat_id=?", uid, chat_id)
    return row


@router.business_message()
async def on_biz_message(m: Message, bot: Bot):
    if config.PROFILE != "full":
        return
    bc_id = m.business_connection_id
    conn = await db.q_one("SELECT * FROM biz_conn WHERE bc=? AND enabled=1", bc_id) if bc_id else None
    if not conn:
        return
    owner = conn["uid"]
    now = int(time.time())
    # исходящее самого владельца (он ответил вручную) — запоминаем и молчим
    if m.from_user and m.from_user.id == owner:
        await _seen(owner, m.chat.id, "")
        await db.q_run("UPDATE biz_seen SET last_out=? WHERE uid=? AND chat_id=?", now, owner, m.chat.id)
        return
    if not m.from_user or m.from_user.is_bot:
        return
    name = m.from_user.full_name or "собеседник"
    seen = await _seen(owner, m.chat.id, name)
    is_new = not (seen["last_in"] or seen["last_out"])
    await db.q_run("UPDATE biz_seen SET last_in=?, name=? WHERE uid=? AND chat_id=?", now, name[:60], owner, m.chat.id)
    cfg = await cfg_of(owner)
    # 🎙 расшифровка входящих голосовых — владельцу в ЛС
    if cfg.get("stt") and (m.voice or m.video_note):
        asyncio.create_task(_transcribe_for_owner(bot, owner, m, name))
    text = (m.text or m.caption or "").strip()
    # 🤖 ИИ-черновик ответа — владельцу, отправит он сам
    if cfg.get("draft") and text and not cfg.get("paused"):
        asyncio.create_task(_draft_for_owner(bot, owner, bc_id, m, name, text))
    # 🌙 автоответ собеседнику
    if not cfg.get("on") or cfg.get("paused") or not conn["can_reply"]:
        return
    mode = cfg.get("mode", "new")
    bl = cfg.get("bl") or []
    wl = cfg.get("wl") or []
    if m.chat.id in bl:
        return
    if mode == "new" and not is_new:
        return
    if mode == "list" and m.chat.id not in wl:
        return
    if seen["last_out"] and now - seen["last_out"] < OWNER_QUIET:   # недавно сам писал — не лезу
        return
    if seen["replied"] and now - seen["replied"] < cfg.get("cool", DEF_COOL):
        return
    try:
        await bot.send_message(m.chat.id, cfg["text"], business_connection_id=bc_id)
        await db.q_run("UPDATE biz_seen SET replied=? WHERE uid=? AND chat_id=?", now, owner, m.chat.id)
    except TelegramBadRequest as e:
        log.info("biz autoreply: %s", e)


async def _transcribe_for_owner(bot: Bot, owner: int, m: Message, name: str):
    from handlers import media
    from autopost import media_dl
    import stt
    obj = m.voice or m.video_note
    if (getattr(obj, "duration", 0) or 0) > media.MAX_VOICE:
        return
    media_dl._dir()
    ext = ".oga" if m.voice else ".mp4"
    path = str(media_dl.DL / (uuid.uuid4().hex + ext))
    paths = [path]
    try:
        await bot.download(obj.file_id, destination=path)
        if m.video_note:
            a = await media._extract_audio(path)
            if a != path:
                paths.append(a)
                path = a
        text = await stt.transcribe(path)
    except Exception as e:
        log.info("biz stt: %s", e)
        return
    finally:
        from downloader import core
        for p in paths:
            core.remove(p)
    if not text:
        return
    icon = "🎥" if m.video_note else "🎙"
    try:
        await bot.send_message(owner, f"{icon} <b>{escape(name)}</b> (голосовое):\n"
                               + ui.quote(escape(text[:3500])))
    except TelegramBadRequest:
        pass


async def _draft_for_owner(bot: Bot, owner: int, bc_id: str, m: Message, name: str, text: str):
    import llm
    try:
        sys = ("Ты — личный ассистент. Пользователю в личку написали. Предложи ОДИН короткий вежливый вариант "
               "ответа от его лица, по-русски, 1–2 предложения, без приветствий-штампов и без пояснений. "
               "Только сам текст ответа.")
        ans = await llm.ask([{"role": "system", "content": sys},
                             {"role": "user", "content": f"Сообщение от {name}: {text[:800]}"}],
                            max_tokens=160, temperature=0.6, feature="biz_draft")
    except Exception as e:
        log.info("biz draft: %s", e)
        return
    ans = (ans or "").strip().strip('"')
    if not ans:
        return
    tok = uuid.uuid4().hex[:10]
    if len(_drafts) > 300:
        _drafts.pop(next(iter(_drafts)))
    _drafts[tok] = (owner, bc_id, m.chat.id, ans)
    try:
        await bot.send_message(owner, f"🤖 <b>{escape(name)}:</b> {escape(text[:300])}\n\n"
                               f"✍️ <b>черновик ответа:</b>\n" + ui.quote(escape(ans)),
                               reply_markup=kb_rows([("✅ Отправить", f"biz:snd:{tok}"),
                                                     ("✏️ Свой ответ", f"biz:own:{tok}")]))
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("biz:snd:"))
async def cb_send_draft(cb: CallbackQuery, bot: Bot):
    rec = _drafts.pop(cb.data.split(":")[2], None)
    if not rec or rec[0] != cb.from_user.id:
        return await cb.answer("черновик устарел", show_alert=True)
    _, bc_id, chat_id, text = rec
    try:
        await bot.send_message(chat_id, text, business_connection_id=bc_id)
    except TelegramBadRequest as e:
        return await cb.answer(f"не вышло: {str(e)[:120]}", show_alert=True)
    now = int(time.time())
    await db.q_run("UPDATE biz_seen SET last_out=? WHERE uid=? AND chat_id=?", now, cb.from_user.id, chat_id)
    await cb.answer("✅ отправила от твоего имени")
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("biz:own:"))
async def cb_own_draft(cb: CallbackQuery):
    rec = _drafts.get(cb.data.split(":")[2])
    if not rec or rec[0] != cb.from_user.id:
        return await cb.answer("черновик устарел", show_alert=True)
    await db.kv_set(f"biz:reply:{cb.from_user.id}", cb.data.split(":")[2])
    await cb.answer("✍️ напиши свой ответ одним сообщением — отправлю от твоего имени", show_alert=True)


async def _own_waiting(m: Message) -> bool | dict:
    if m.chat.type != "private" or not m.text or m.text.startswith("/"):
        return False
    tok = await db.kv_get(f"biz:reply:{m.from_user.id}")
    return {"biz_tok": tok} if tok and tok in _drafts else False


@router.message(_own_waiting)
async def on_own_reply(m: Message, bot: Bot, biz_tok: str):
    await db.q_run("DELETE FROM kv WHERE k=?", f"biz:reply:{m.from_user.id}")
    rec = _drafts.pop(biz_tok, None)
    if not rec or rec[0] != m.from_user.id:
        return
    _, bc_id, chat_id, _ = rec
    try:
        await bot.send_message(chat_id, m.text[:4000], business_connection_id=bc_id)
    except TelegramBadRequest as e:
        return await m.reply(f"😕 не вышло: {escape(str(e)[:120])}")
    await db.q_run("UPDATE biz_seen SET last_out=? WHERE uid=? AND chat_id=?", int(time.time()), m.from_user.id, chat_id)
    await m.reply("✅ отправила от твоего имени")


# ================= экран настроек =================
async def _settings_kb(uid: int):
    c = await cfg_of(uid)
    tog = ui.tog
    nxt = {"all": "new", "new": "list", "list": "all"}
    return kb_rows(
        [(f"{tog(c['on'])} 🌙 Автоответ: {MODES[c['mode']]}", "biz:on")],
        [(f"✏️ Текст автоответа", "biz:text"), (f"🔀 Режим: {MODES[c['mode']]}", "biz:mode")],
        [(f"{tog(c['stt'])} 🎙 Расшифровка голосовых", "biz:stt")],
        [(f"{tog(c['draft'])} 🤖 ИИ-черновики ответов", "biz:draft")],
        [(f"{tog(c['summary'])} 📋 Утренняя сводка", "biz:sum")],
        [("📃 Списки чатов", "biz:lists")],
        [(f"{'▶️ Снять паузу' if c['paused'] else '⏸ Пауза везде'}", "biz:pause",
          "success" if c["paused"] else "danger")])


async def settings_view(uid: int):
    c = await cfg_of(uid)
    conn = await conn_of(uid)
    warn = ""
    if conn and not conn["can_reply"] and c["on"]:
        warn = "\n⚠️ <b>нет права отвечать</b> — включи его в Telegram Business → Chatbots"
    text = (ui.head("🤝", "Соня-ассистент", "помощь в твоих личных чатах")
            + "\n" + ui.quote(f"🌙 автоответ — {MODES[c['mode']]}, пока ты не в сети\n"
                              "🎙 входящие голосовые — текстом сюда\n"
                              "🤖 черновик ответа — отправляешь ты сам\n"
                              "📋 утром — кому ты не ответил больше суток")
            + warn + "\n" + ui.hint("автоответ молчит, если ты сам писал в чат за последние 30 минут"))
    return text, await _settings_kb(uid)


@router.message(Command("assistant", "ассистент", "business"), F.chat.type == "private")
async def cmd_settings(m: Message):
    if not await conn_of(m.from_user.id):
        return await m.answer(_connect_hint((await m.bot.me()).username or ""))
    text, kb = await settings_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


def _connect_hint(username: str) -> str:
    return (ui.head("🤝", "Соня-ассистент для личных чатов", "нужен Telegram Premium")
            + "\n" + ui.quote("1. открой Настройки → Telegram для бизнеса → Чат-боты\n"
                              f"2. выбери @{username}\n3. дай право «отвечать на сообщения»")
            + "\n" + ui.hint("после подключения я напишу сюда, и настроим под тебя. "
                             "удалённые сообщения собеседников не сохраняю и не показываю"))


@router.callback_query(F.data == "biz:home")
async def cb_home(cb: CallbackQuery, bot: Bot):
    if not await conn_of(cb.from_user.id):
        return await show(cb, _connect_hint((await bot.me()).username or ""), kb_rows([("‹ Назад", "m:home")]))
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data.in_({"biz:on", "biz:stt", "biz:draft", "biz:sum", "biz:pause", "biz:mode"}))
async def cb_toggle(cb: CallbackQuery):
    c = await cfg_of(cb.from_user.id)
    key = cb.data.split(":")[1]
    if key == "mode":
        c["mode"] = {"all": "new", "new": "list", "list": "all"}[c["mode"]]
    elif key == "pause":
        c["paused"] = 0 if c["paused"] else 1
    else:
        fld = {"on": "on", "stt": "stt", "draft": "draft", "sum": "summary"}[key]
        c[fld] = 0 if c.get(fld) else 1
    await save_cfg(cb.from_user.id, c)
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data == "biz:text")
async def cb_text(cb: CallbackQuery):
    await db.kv_set(f"biz:settext:{cb.from_user.id}", "1")
    await cb.answer("✏️ пришли новый текст автоответа одним сообщением", show_alert=True)


@router.callback_query(F.data == "biz:lists")
async def cb_lists(cb: CallbackQuery):
    c = await cfg_of(cb.from_user.id)
    text = (ui.head("📃", "Списки чатов", "для режима «по списку» и исключений")
            + "\n" + ui.quote(f"✅ отвечаю только этим: {len(c.get('wl') or [])}\n"
                              f"🚫 никогда не отвечаю: {len(c.get('bl') or [])}")
            + "\n" + ui.hint("перешли мне сюда сообщение из нужного личного чата — добавлю его в список. "
                             "режим «по списку» — отвечаю только тем, кто в ✅"))
    await show(cb, text, kb_rows([("➕ В белый (отвечать)", "biz:add:wl"), ("➕ В чёрный (не отвечать)", "biz:add:bl")],
                                 [("🗑 Очистить списки", "biz:clr")], [("‹ Назад", "biz:home")]))


@router.callback_query(F.data.startswith("biz:add:"))
async def cb_add(cb: CallbackQuery):
    which = cb.data.split(":")[2]
    if which not in ("wl", "bl"):
        return await cb.answer()
    await db.kv_set(f"biz:addlist:{cb.from_user.id}", which)
    await cb.answer("перешли сюда сообщение из нужного личного чата", show_alert=True)


@router.callback_query(F.data == "biz:clr")
async def cb_clr(cb: CallbackQuery):
    c = await cfg_of(cb.from_user.id)
    c["wl"], c["bl"] = [], []
    await save_cfg(cb.from_user.id, c)
    await cb.answer("списки очищены")
    await show(cb, *await settings_view(cb.from_user.id))


async def _text_input(m: Message) -> bool | dict:
    if m.chat.type != "private" or not m.text or m.text.startswith("/"):
        return False
    if await db.kv_get(f"biz:settext:{m.from_user.id}"):
        return {"biz_act": "text"}
    return False


@router.message(_text_input)
async def on_set_text(m: Message, biz_act: str):
    await db.q_run("DELETE FROM kv WHERE k=?", f"biz:settext:{m.from_user.id}")
    c = await cfg_of(m.from_user.id)
    c["text"] = m.text[:500]
    await save_cfg(m.from_user.id, c)
    text, kb = await settings_view(m.from_user.id)
    await m.answer("✅ текст автоответа обновлён\n\n" + text, reply_markup=kb)


async def _fwd_list(m: Message) -> bool | dict:
    if m.chat.type != "private" or not m.from_user:
        return False
    which = await db.kv_get(f"biz:addlist:{m.from_user.id}")
    if not which:
        return False
    orig = getattr(m, "forward_origin", None)
    return {"biz_which": which} if orig else False


@router.message(_fwd_list)
async def on_fwd_list(m: Message, biz_which: str):
    await db.q_run("DELETE FROM kv WHERE k=?", f"biz:addlist:{m.from_user.id}")
    orig = m.forward_origin
    chat_id = getattr(getattr(orig, "sender_user", None), "id", None)
    if not chat_id:
        return await m.reply("это не личный чат — перешли сообщение от человека")
    c = await cfg_of(m.from_user.id)
    lst = set(c.get(biz_which) or [])
    lst.add(chat_id)
    c[biz_which] = list(lst)
    await save_cfg(m.from_user.id, c)
    await m.reply(f"✅ добавила в {'белый' if biz_which == 'wl' else 'чёрный'} список")


# ================= утренняя сводка =================
async def _summary_once(bot: Bot):
    await _ensure()
    now = int(time.time())
    import datetime as dt
    msk = dt.datetime.utcnow() + dt.timedelta(hours=3)
    if not (8 <= msk.hour < 9):
        return
    day = msk.date().isoformat()
    for owner in [r["uid"] for r in await db.q_all("SELECT DISTINCT uid FROM biz_conn WHERE enabled=1")]:
        c = await cfg_of(owner)
        if not c.get("summary"):
            continue
        if await db.kv_get(f"biz:sumday:{owner}") == day:
            continue
        rows = await db.q_all("SELECT name FROM biz_seen WHERE uid=? AND last_in>last_out AND last_in<? ORDER BY last_in",
                              owner, now - 86400)
        await db.kv_set(f"biz:sumday:{owner}", day)
        if not rows:
            continue
        names = "\n".join(f"• {escape(r['name'] or 'собеседник')}" for r in rows[:30])
        try:
            await bot.send_message(owner, f"📋 <b>доброе утро!</b> ты не ответил больше суток:\n{names}\n"
                                   + ui.hint("ответишь — я больше не напомню"))
        except TelegramBadRequest:
            pass


async def loop(bot: Bot):
    while True:
        try:
            await _summary_once(bot)
        except Exception as e:
            log.warning("biz summary: %s", e)
        await asyncio.sleep(20 * 60)
