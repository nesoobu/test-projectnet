"""🎨 Картинки для сторис: «задай мне вопрос» с QR и «вопрос → ответ». 1080×1920.
Волна 48: стиль настраивается — фон (градиенты, своё фото), шрифт (7 штук с кириллицей из assets/fonts,
лицензия OFL), плашка (светлая / стекло / тёмная), свой текст."""
import io
from pathlib import Path

THEMES = [((255, 94, 98), (255, 153, 102)), ((106, 17, 203), (37, 117, 252)), ((17, 153, 142), (56, 239, 125)),
          ((252, 70, 107), (63, 94, 251)), ((40, 40, 60), (120, 60, 140)), ((255, 175, 189), (255, 195, 160)),
          ((15, 32, 39), (44, 83, 100)), ((142, 45, 226), (74, 0, 224))]
THEME_NAMES = ["закат", "ночь", "мята", "неон", "графит", "персик", "океан", "фиалка"]
W, H = 1080, 1920
FONT_DIR = Path(__file__).resolve().parent.parent / "assets" / "fonts"
FONTS = {"classic": ("Классика", None), "comfortaa": ("Comfortaa", "Comfortaa.ttf"),
         "caveat": ("Рукописный", "Caveat.ttf"), "lobster": ("Lobster", "Lobster.ttf"),
         "marck": ("Каллиграфия", "MarckScript.ttf"), "russo": ("Russo", "RussoOne.ttf"),
         "mono": ("Жирный", "RubikMonoOne.ttf"), "pixel": ("Пиксели", "PressStart2P.ttf")}
FONT_KEYS = list(FONTS)
BOXES = {"light": "светлая", "glass": "стекло", "dark": "тёмная"}
BOX_KEYS = list(BOXES)
DEFAULT = {"bg": 0, "font": "classic", "box": "light", "text": ""}
# пиксельный и моноширинный шрифты широкие — уменьшаем кегль, чтобы текст влез
SCALE = {"pixel": 0.7, "mono": 0.8, "caveat": 1.25, "marck": 1.15}


def font(style: dict, size: int, bold: bool = True):
    from PIL import ImageFont
    from handlers.tools import _font
    key = style.get("font") or "classic"
    file = FONTS.get(key, FONTS["classic"])[1]
    size = int(size * SCALE.get(key, 1))
    if file and (FONT_DIR / file).exists():
        try:
            return ImageFont.truetype(str(FONT_DIR / file), size)
        except OSError:
            pass
    return _font(size, bold)


def _bg(style: dict, photo: bytes | None = None):
    """Фон: своё фото (обрезка под 9:16 и лёгкое затемнение) или градиент."""
    from PIL import Image, ImageDraw, ImageEnhance, ImageOps
    if photo and style.get("bg") == "photo":
        try:
            im = ImageOps.fit(ImageOps.exif_transpose(Image.open(io.BytesIO(photo))).convert("RGB"), (W, H))
            im = ImageEnhance.Brightness(im).enhance(0.8)
            return im, ImageDraw.Draw(im, "RGBA")
        except Exception:
            pass
    t = style.get("bg") if isinstance(style.get("bg"), int) else 0
    a, b = THEMES[t % len(THEMES)]
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im, "RGBA")
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(3)))
    return im, d


def _box(im, d, xy, style: dict, r=48, dark: bool = False):
    """Плашка под текст: светлая, «стекло» (размытый фон + полупрозрачность) или тёмная."""
    from PIL import ImageFilter, Image
    kind = "dark" if dark else style.get("box", "light")
    xy = tuple(int(v) for v in xy)
    if kind == "glass":
        part = im.crop(xy).filter(ImageFilter.GaussianBlur(28))
        mask = Image.new("L", part.size, 0)
        from PIL import ImageDraw
        ImageDraw.Draw(mask).rounded_rectangle((0, 0, part.size[0] - 1, part.size[1] - 1), r, fill=255)
        im.paste(part, xy[:2], mask)
        d.rounded_rectangle(xy, r, fill=(255, 255, 255, 70), outline=(255, 255, 255, 140), width=3)
        return (255, 255, 255)
    if kind == "dark":
        d.rounded_rectangle(xy, r, fill=(22, 22, 32, 235))
        return (255, 255, 255)
    d.rounded_rectangle(xy, r, fill=(255, 255, 255, 245))
    return (30, 30, 40)


def _center(d, y, text, f, fill, width=W):
    w = d.textlength(text, font=f)
    d.text(((width - w) / 2, y), text, font=f, fill=fill)


def _shadow_center(d, y, text, f):
    _center(d, y + 3, text, f, (0, 0, 0, 110))
    _center(d, y, text, f, (255, 255, 255))


def ask_card(prompt: str, link: str, bot_name: str, theme: int = 0, style: dict | None = None,
             photo: bytes | None = None) -> bytes:
    """Карточка-приглашение: тема крупно + QR + «ссылка в профиле»."""
    from handlers.tools import _wrap
    st = {**DEFAULT, "bg": theme, **(style or {})}
    im, d = _bg(st, photo)
    text = st.get("text") or prompt
    f = font(st, 76)
    lines = _wrap(d, text, f, W - 280)[:5]
    lh = int(f.size * 1.32)
    box_h = max(420, 160 + len(lines) * lh)
    top = 980 - box_h
    ink = _box(im, d, (90, top, W - 90, top + box_h), st)
    y = top + (box_h - len(lines) * lh) // 2
    for ln in lines:
        _center(d, y, ln, f, ink)
        y += lh
    try:
        import qrcode
        q = qrcode.QRCode(box_size=10, border=2)
        q.add_data(link)
        q.make(fit=True)
        qi = q.make_image(fill_color="black", back_color="white").convert("RGB").resize((420, 420))
        d.rounded_rectangle((W / 2 - 240, 1120, W / 2 + 240, 1600), 36, fill=(255, 255, 255))
        im.paste(qi, (int(W / 2 - 210), 1150))
    except Exception:
        pass
    _shadow_center(d, 1680, "анонимно · отвечаю всем", font(st, 44, False))
    _shadow_center(d, 1750, f"@{bot_name}", font(st, 44))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


def answer_card(question: str, answer: str, bot_name: str, theme: int = 1, style: dict | None = None,
                photo: bytes | None = None) -> bytes:
    """Карточка «вопрос → ответ» для сторис — в том же стиле, что и приглашение."""
    from handlers.tools import _wrap
    st = {**DEFAULT, "bg": theme, **(style or {})}
    im, d = _bg(st, photo)
    fq, fa = font(st, 54), font(st, 52, False)
    ql = _wrap(d, question or "(медиа-сообщение)", fq, W - 300)[:7]
    al = _wrap(d, answer, fa, W - 300)[:9]
    lq, la = int(fq.size * 1.3), int(fa.size * 1.3)
    top = 360
    qh = 120 + len(ql) * lq
    ink = _box(im, d, (90, top, W - 90, top + qh), st)
    d.text((150, top + 40), "АНОНИМНЫЙ ВОПРОС", font=font({"font": "classic"}, 34), fill=(150, 150, 170))
    y = top + 100
    for ln in ql:
        d.text((150, y), ln, font=fq, fill=ink)
        y += lq
    top2 = top + qh + 60
    ah = 80 + len(al) * la
    _box(im, d, (90, top2, W - 90, top2 + ah), st, dark=True)
    y = top2 + 40
    for ln in al:
        d.text((150, y), ln, font=fa, fill=(255, 255, 255))
        y += la
    _shadow_center(d, H - 200, "задай мне вопрос — ссылка в профиле", font(st, 44, False))
    _shadow_center(d, H - 130, f"@{bot_name}", font(st, 44))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


def rating_card(avg: float, n: int, dist: list[int], link: str, bot_name: str, style: dict | None = None,
                photo: bytes | None = None) -> bytes:
    """Волна 49: «оцени меня» — средняя оценка крупно, звёзды и столбики 1–10, QR на ссылку."""
    st = {**DEFAULT, **(style or {})}
    im, d = _bg(st, photo)
    ink = _box(im, d, (90, 260, W - 90, 1180), st)
    _center(d, 320, "МЕНЯ ОЦЕНИЛИ", font({"font": "classic"}, 40), (150, 150, 170))
    big = font(st, 230)
    _center(d, 380, f"{avg:.1f}".replace(".", ","), big, ink)
    stars = round(avg / 2)
    _center(d, 690, "★" * stars + "☆" * (5 - stars), font({"font": "classic"}, 90), (255, 190, 40))
    _center(d, 810, f"{n} оценок", font(st, 50, False), ink)
    top, base, bw = 900, 1130, 62
    mx = max(dist) or 1
    for i, v in enumerate(dist):
        x = 160 + i * 78
        h = int((base - top - 40) * v / mx)
        d.rounded_rectangle((x, base - h - 4, x + bw, base), 14,
                            fill=(255, 190, 40, 255) if i >= 6 else (200, 200, 215, 255))
        _center(d, base + 6, str(i + 1), font({"font": "classic"}, 30), ink, width=2 * x + bw)
    try:
        import qrcode
        q = qrcode.QRCode(box_size=10, border=2)
        q.add_data(link)
        q.make(fit=True)
        qi = q.make_image(fill_color="black", back_color="white").convert("RGB").resize((360, 360))
        d.rounded_rectangle((W / 2 - 210, 1290, W / 2 + 210, 1710), 36, fill=(255, 255, 255))
        im.paste(qi, (int(W / 2 - 180), 1320))
    except Exception:
        pass
    _shadow_center(d, 1750, "а ты как оценишь? анонимно", font(st, 44, False))
    _shadow_center(d, 1820, f"@{bot_name}", font(st, 44))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()
