"""Волна 74: листание длинных экранов с картинкой (кнопки «‹ 1/3 ›» добавляет uikit)."""
from aiogram import Router, F
from aiogram.exceptions import TelegramBadRequest
from aiogram.types import CallbackQuery

import uikit

router = Router()


@router.callback_query(F.data.startswith("uipg:"))
async def cb_page(cb: CallbackQuery):
    try:
        _, tok, i = cb.data.split(":")
        i = int(i)
    except ValueError:
        return await cb.answer()
    o = uikit.PAGES.get(tok)
    if not o:
        return await cb.answer("экран устарел — открой его заново", show_alert=True)
    i = max(0, min(i, len(o["pages"]) - 1))
    await cb.answer()
    try:
        await cb.message.edit_caption(caption=o["pages"][i], parse_mode=o["pm"],
                                      reply_markup=uikit.page_markup(tok, i, len(o["pages"]), o["mk"]))
    except TelegramBadRequest as e:
        if "not modified" not in str(e).lower():
            raise
