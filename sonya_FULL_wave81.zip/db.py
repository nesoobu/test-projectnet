import random
import time
import aiosqlite
from config import DB_PATH

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
    id INTEGER PRIMARY KEY,
    name TEXT, username TEXT,
    joined INTEGER, last_seen INTEGER,
    msgs INTEGER DEFAULT 0,
    xp INTEGER DEFAULT 0, last_xp INTEGER DEFAULT 0,
    rep INTEGER DEFAULT 0,
    banned INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS history(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER, user_id INTEGER, role TEXT, text TEXT, ts INTEGER
);
CREATE INDEX IF NOT EXISTS ix_hist ON history(chat_id, id);
CREATE TABLE IF NOT EXISTS facts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, fact TEXT, ts INTEGER
);
CREATE TABLE IF NOT EXISTS rep_log(
    giver INTEGER, taker INTEGER, chat_id INTEGER, ts INTEGER
);
CREATE TABLE IF NOT EXISTS donations(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER, stars INTEGER, charge_id TEXT, ts INTEGER
);
CREATE TABLE IF NOT EXISTS chats(
    id INTEGER PRIMARY KEY, title TEXT, added INTEGER, ai_on INTEGER DEFAULT 1
);
"""

SCHEMA_V10 = """
CREATE TABLE IF NOT EXISTS reminders(
    id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, chat_id INTEGER,
    at INTEGER, text TEXT, repeat_h INTEGER DEFAULT 0, done INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_rem ON reminders(done, at);
CREATE TABLE IF NOT EXISTS chat_log(
    id INTEGER PRIMARY KEY AUTOINCREMENT, chat_id INTEGER, name TEXT, text TEXT, ts INTEGER
);
CREATE INDEX IF NOT EXISTS ix_clog ON chat_log(chat_id, id);
CREATE TABLE IF NOT EXISTS warns(chat_id INTEGER, uid INTEGER, n INTEGER, PRIMARY KEY(chat_id, uid));
CREATE TABLE IF NOT EXISTS giveaways(
    id INTEGER PRIMARY KEY AUTOINCREMENT, owner_id INTEGER, chat_id INTEGER, msg_id INTEGER,
    prize TEXT, winners INTEGER, ends INTEGER, need_sub INTEGER DEFAULT 1,
    status TEXT DEFAULT 'active', result TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS giveaway_users(gid INTEGER, uid INTEGER, name TEXT, PRIMARY KEY(gid, uid));
CREATE TABLE IF NOT EXISTS ui_over(kind TEXT, key TEXT, data TEXT, PRIMARY KEY(kind, key));
CREATE TABLE IF NOT EXISTS morning(
    chat_id INTEGER PRIMARY KEY, city TEXT DEFAULT 'Москва', hh INTEGER DEFAULT 8, mm INTEGER DEFAULT 0,
    on_ INTEGER DEFAULT 0, last TEXT DEFAULT ''
);
"""

SCHEMA_V14 = """
CREATE TABLE IF NOT EXISTS ai_usage(uid INTEGER, day TEXT, n INTEGER DEFAULT 0, PRIMARY KEY(uid, day));
CREATE TABLE IF NOT EXISTS ai_stats(day TEXT, feature TEXT, calls INTEGER DEFAULT 0, tokens INTEGER DEFAULT 0,
    fails INTEGER DEFAULT 0, PRIMARY KEY(day, feature));
CREATE TABLE IF NOT EXISTS game_state(id TEXT PRIMARY KEY, kind TEXT, data TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS party_live(chat_id INTEGER PRIMARY KEY, kind TEXT, ts INTEGER);
CREATE TABLE IF NOT EXISTS ach(uid INTEGER, code TEXT, ts INTEGER, PRIMARY KEY(uid, code));
CREATE TABLE IF NOT EXISTS chat_members(chat_id INTEGER, uid INTEGER, last INTEGER, PRIMARY KEY(chat_id, uid));
CREATE TABLE IF NOT EXISTS chat_daily(chat_id INTEGER, uid INTEGER, day TEXT, n INTEGER DEFAULT 0,
    PRIMARY KEY(chat_id, uid, day));
CREATE TABLE IF NOT EXISTS chat_hours(chat_id INTEGER, hour INTEGER, n INTEGER DEFAULT 0, PRIMARY KEY(chat_id, hour));
"""

SCHEMA_V15 = """
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY, v TEXT);
CREATE TABLE IF NOT EXISTS quests(uid INTEGER, day TEXT, code TEXT, need INTEGER, got INTEGER DEFAULT 0,
    done INTEGER DEFAULT 0, PRIMARY KEY(uid, day, code));
CREATE TABLE IF NOT EXISTS marriages(a INTEGER, b INTEGER, ts INTEGER, PRIMARY KEY(a, b));
CREATE TABLE IF NOT EXISTS pets(uid INTEGER PRIMARY KEY, kind TEXT, name TEXT, born INTEGER, fed INTEGER,
    played INTEGER, xp INTEGER DEFAULT 0, alive INTEGER DEFAULT 1);
CREATE TABLE IF NOT EXISTS lottery(chat_id INTEGER, day TEXT, uid INTEGER, name TEXT, n INTEGER DEFAULT 0,
    PRIMARY KEY(chat_id, day, uid));
CREATE TABLE IF NOT EXISTS notes(chat_id INTEGER, name TEXT, text TEXT, PRIMARY KEY(chat_id, name));
CREATE TABLE IF NOT EXISTS daily_active(day TEXT, uid INTEGER, PRIMARY KEY(day, uid));
"""

SCHEMA_V16 = """
CREATE TABLE IF NOT EXISTS sticker_packs(id INTEGER PRIMARY KEY AUTOINCREMENT, uid INTEGER, name TEXT UNIQUE,
    title TEXT, kind TEXT, n INTEGER DEFAULT 0, ts INTEGER);
CREATE INDEX IF NOT EXISTS ix_stk_uid ON sticker_packs(uid);
CREATE TABLE IF NOT EXISTS game_stats(uid INTEGER, kind TEXT, games INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
    PRIMARY KEY(uid, kind));
CREATE TABLE IF NOT EXISTS chat_profiles(uid INTEGER PRIMARY KEY, gender TEXT DEFAULT '', want TEXT DEFAULT '',
    topic TEXT DEFAULT 'any', agreed INTEGER DEFAULT 0, banned_until INTEGER DEFAULT 0, likes INTEGER DEFAULT 0,
    dislikes INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS chat_reports(reporter INTEGER, target INTEGER, ts INTEGER, PRIMARY KEY(reporter, target));
CREATE TABLE IF NOT EXISTS sticker_coauthors(pid INTEGER, uid INTEGER, ts INTEGER, PRIMARY KEY(pid, uid));
"""

_db: aiosqlite.Connection | None = None


async def db() -> aiosqlite.Connection:
    global _db
    if _db is None:
        _db = await aiosqlite.connect(DB_PATH)
        _db.row_factory = aiosqlite.Row
        await _db.execute("PRAGMA journal_mode=WAL")
    return _db


async def init():
    c = await db()
    await c.executescript(SCHEMA)
    cols = {r[1] for r in await (await c.execute("PRAGMA table_info(chats)")).fetchall()}
    for col in ("auto_dl", "auto_voice", "greet", "reacts"):
        if col not in cols:
            await c.execute(f"ALTER TABLE chats ADD COLUMN {col} INTEGER DEFAULT 1")
    for col in ("captcha", "antiflood", "antilink"):  # модерация — по умолчанию выключена
        if col not in cols:
            await c.execute(f"ALTER TABLE chats ADD COLUMN {col} INTEGER DEFAULT 0")
    if "bdays" not in cols:
        await c.execute("ALTER TABLE chats ADD COLUMN bdays INTEGER DEFAULT 1")
    for col in ("daily_sum", "antispam"):   # волна 16 — по умолчанию выключено
        if col not in cols:
            await c.execute(f"ALTER TABLE chats ADD COLUMN {col} INTEGER DEFAULT 0")
    for col in ("rules", "quiet", "welcome"):
        if col not in cols:
            await c.execute(f"ALTER TABLE chats ADD COLUMN {col} TEXT DEFAULT ''")
    if "clean_service" not in cols:   # волна 25
        await c.execute("ALTER TABLE chats ADD COLUMN clean_service INTEGER DEFAULT 0")
    if "dl_clean" not in cols:   # волна 32: удалять сообщение со ссылкой после скачивания
        await c.execute("ALTER TABLE chats ADD COLUMN dl_clean INTEGER DEFAULT 0")
    if "antimat" not in cols:   # волна 45: фильтр мата в группах, по умолчанию выключен
        await c.execute("ALTER TABLE chats ADD COLUMN antimat INTEGER DEFAULT 0")
    if "rp" not in cols:   # волна 26 — по умолчанию включено
        await c.execute("ALTER TABLE chats ADD COLUMN rp INTEGER DEFAULT 1")
    await c.executescript(SCHEMA_V10)
    await c.executescript(SCHEMA_V14)
    await c.executescript(SCHEMA_V15)
    await c.executescript(SCHEMA_V16)   # волна 44: паки стикеров
    import members
    await c.executescript(members.SCHEMA)   # волна 63: стаж в чате/канале, участники веток
    ucols = {r[1] for r in await (await c.execute("PRAGMA table_info(users)")).fetchall()}
    for col, ddl in (("ref_by", "INTEGER DEFAULT 0"), ("refs", "INTEGER DEFAULT 0"),
                     ("plus_until", "INTEGER DEFAULT 0"), ("title", "TEXT DEFAULT ''"), ("titles", "TEXT DEFAULT ''"),
                     ("coins", "INTEGER DEFAULT 0"), ("last_bonus", "INTEGER DEFAULT 0"),
                     ("streak", "INTEGER DEFAULT 0"), ("voice", "TEXT DEFAULT ''"),
                     ("wins", "INTEGER DEFAULT 0"), ("bday", "TEXT DEFAULT ''"),
                     ("bday_year", "INTEGER DEFAULT 0"), ("dls", "INTEGER DEFAULT 0"),
                     ("nudge", "INTEGER DEFAULT 1"), ("last_nudge", "INTEGER DEFAULT 0"),
                     ("season_wins", "INTEGER DEFAULT 0"), ("mode", "TEXT DEFAULT 'base'"),
                     ("close", "INTEGER DEFAULT 0"), ("plus_trial", "INTEGER DEFAULT 0"),
                     ("gift_stars", "INTEGER DEFAULT 0")):
        if col not in ucols:
            await c.execute(f"ALTER TABLE users ADD COLUMN {col} {ddl}")
    await c.execute("CREATE TABLE IF NOT EXISTS dl_cache(key TEXT PRIMARY KEY, type TEXT, file_id TEXT, "
                    "title TEXT, ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS music_tracks(key TEXT PRIMARY KEY, data TEXT, ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS music_fav(uid INTEGER, key TEXT, ts INTEGER, PRIMARY KEY(uid, key))")
    await c.execute("CREATE TABLE IF NOT EXISTS music_plays(uid INTEGER, key TEXT, ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS anon_links(uid INTEGER PRIMARY KEY, code TEXT UNIQUE, open INTEGER DEFAULT 1)")
    await c.execute("CREATE TABLE IF NOT EXISTS anon_msgs(id INTEGER PRIMARY KEY AUTOINCREMENT, to_uid INTEGER, "
                    "from_uid INTEGER, ts INTEGER, answered INTEGER DEFAULT 0)")
    lcols = {r[1] for r in await (await c.execute("PRAGMA table_info(anon_links)")).fetchall()}
    if "nomat" not in lcols:   # волна 45: получатель не принимает сообщения с матом
        await c.execute("ALTER TABLE anon_links ADD COLUMN nomat INTEGER DEFAULT 0")
    for col, d in (("quiet", 0), ("daily", 1), ("mask_hours", 0)):   # волна 49: тишина ночью, вопрос дня, срок маски
        if col not in lcols:
            await c.execute(f"ALTER TABLE anon_links ADD COLUMN {col} INTEGER DEFAULT {d}")
    acols = {r[1] for r in await (await c.execute("PRAGMA table_info(anon_msgs)")).fetchall()}
    for col in ("topic", "qtext", "atext"):   # волна 42: темы, тексты для карточек
        if acols and col not in acols:
            await c.execute(f"ALTER TABLE anon_msgs ADD COLUMN {col} TEXT DEFAULT ''")
    acols = {r[1] for r in await (await c.execute("PRAGMA table_info(anon_msgs)")).fetchall()}
    for col in ("src_mid", "dlv_mid", "ans_mid", "parent"):   # волна 46: ветки переписки
        if col not in acols:
            await c.execute(f"ALTER TABLE anon_msgs ADD COLUMN {col} INTEGER DEFAULT 0")
    # волна 46: маски — постоянная маска анонима у конкретного получателя
    await c.execute("CREATE TABLE IF NOT EXISTS anon_masks(id INTEGER PRIMARY KEY AUTOINCREMENT, owner INTEGER, "
                    "sender INTEGER, mask TEXT, label TEXT DEFAULT '', UNIQUE(owner, sender), UNIQUE(owner, mask))")
    # волна 46b: маски сгорают после тишины — у пары может быть много масок по очереди (активна одна)
    await c.execute("CREATE TABLE IF NOT EXISTS anon_masks2(id INTEGER PRIMARY KEY AUTOINCREMENT, owner INTEGER, "
                    "sender INTEGER, mask TEXT, label TEXT DEFAULT '', last_ts INTEGER DEFAULT 0, active INTEGER DEFAULT 1)")
    await c.execute("CREATE INDEX IF NOT EXISTS ix_amask ON anon_masks2(owner, sender, active)")
    if not await (await c.execute("SELECT 1 FROM anon_masks2 LIMIT 1")).fetchone():
        await c.execute("INSERT INTO anon_masks2(id, owner, sender, mask, label, last_ts, active) "
                        "SELECT id, owner, sender, mask, label, strftime('%s','now'), 1 FROM anon_masks")
    acols = {r[1] for r in await (await c.execute("PRAGMA table_info(anon_msgs)")).fetchall()}
    if "react" not in acols:   # волна 49: реакция получателя и оценка из «оцени меня»
        await c.execute("ALTER TABLE anon_msgs ADD COLUMN react TEXT DEFAULT ''")
        await c.execute("ALTER TABLE anon_msgs ADD COLUMN score INTEGER DEFAULT 0")
    if "seen" not in acols:   # волна 48: «прочитано» отдельно от «отвечено»
        await c.execute("ALTER TABLE anon_msgs ADD COLUMN seen INTEGER DEFAULT 0")
        await c.execute("UPDATE anon_msgs SET seen=1")   # всё старое считаем прочитанным
    if "mask_id" not in acols:
        await c.execute("ALTER TABLE anon_msgs ADD COLUMN mask_id INTEGER DEFAULT 0")
        await c.execute("UPDATE anon_msgs SET mask_id=COALESCE((SELECT id FROM anon_masks2 m WHERE m.owner=anon_msgs.to_uid "
                        "AND m.sender=anon_msgs.from_uid AND m.active=1), 0)")
    await c.execute("CREATE TABLE IF NOT EXISTS anon_blocks(owner INTEGER, sender INTEGER, ts INTEGER, "
                    "PRIMARY KEY(owner, sender))")
    await c.execute("CREATE TABLE IF NOT EXISTS gift_ledger(uid INTEGER, delta INTEGER, reason TEXT, ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS gift_wins(id INTEGER PRIMARY KEY AUTOINCREMENT, gid INTEGER, uid INTEGER, "
                    "stars INTEGER, gift_id TEXT, title TEXT, status TEXT, ts INTEGER)")
    gcols = {r[1] for r in await (await c.execute("PRAGMA table_info(giveaways)")).fetchall()}
    for col, ddl in (("gift_kind", "TEXT DEFAULT ''"), ("gift_stars", "INTEGER DEFAULT 0"), ("gift_id", "TEXT DEFAULT ''"),
                     ("extra_chats", "TEXT DEFAULT '[]'"), ("premium_only", "INTEGER DEFAULT 0"),
                     ("ref_bonus", "INTEGER DEFAULT 0"), ("max_users", "INTEGER DEFAULT 0"), ("photo", "TEXT DEFAULT ''"),
                     ("seed", "TEXT DEFAULT ''"), ("captcha", "INTEGER DEFAULT 0"), ("antibot", "INTEGER DEFAULT 1"),
                     ("boost_bonus", "INTEGER DEFAULT 0"), ("confirm_h", "INTEGER DEFAULT 0"),
                     ("btn_text", "TEXT DEFAULT ''"), ("media_type", "TEXT DEFAULT 'photo'"),
                     ("secret", "TEXT DEFAULT ''"), ("members_start", "INTEGER DEFAULT 0"),
                     ("members_end", "INTEGER DEFAULT 0"), ("starts", "INTEGER DEFAULT 0"), ("notify", "INTEGER DEFAULT 0"),
                     ("min_age", "INTEGER DEFAULT 0"), ("member_days", "INTEGER DEFAULT 0"),
                     ("need_boost", "INTEGER DEFAULT 0")):   # волна 63: старожилы канала, только забустившие   # волна 62: не пускать аккаунты моложе N дней
        if col not in gcols:   # волны 36–37: подарки, спонсоры, билеты, картинка, честность
            await c.execute(f"ALTER TABLE giveaways ADD COLUMN {col} {ddl}")
    ucols2 = {r[1] for r in await (await c.execute("PRAGMA table_info(giveaway_users)")).fetchall()}
    for col in ("tickets", "ref_by", "ts", "boosts"):
        if col not in ucols2:
            await c.execute(f"ALTER TABLE giveaway_users ADD COLUMN {col} INTEGER DEFAULT {1 if col == 'tickets' else 0}")
    if "flags" not in ucols2:   # волна 38: «sus» — похож на бота
        await c.execute("ALTER TABLE giveaway_users ADD COLUMN flags TEXT DEFAULT ''")
    await c.execute("CREATE TABLE IF NOT EXISTS gw_wins(gid INTEGER, uid INTEGER, status TEXT, ts INTEGER, "
                    "PRIMARY KEY(gid, uid))")
    await c.execute("CREATE TABLE IF NOT EXISTS feat_usage(uid INTEGER, day TEXT, feat TEXT, n INTEGER DEFAULT 0, "
                    "PRIMARY KEY(uid, day, feat))")
    dcols = {r[1] for r in await (await c.execute("PRAGMA table_info(donations)")).fetchall()}
    if "kind" not in dcols:   # волна 35: за что заплатили
        await c.execute("ALTER TABLE donations ADD COLUMN kind TEXT DEFAULT ''")
    await c.execute("CREATE TABLE IF NOT EXISTS dl_log(platform TEXT, ok INTEGER, err TEXT, sec REAL, ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS dl_hist(uid INTEGER, tok TEXT, kind TEXT, file_id TEXT, title TEXT, "
                    "ts INTEGER)")
    await c.execute("CREATE TABLE IF NOT EXISTS music_subs(uid INTEGER, artist_id TEXT, name TEXT, "
                    "PRIMARY KEY(uid, artist_id))")
    await c.execute("CREATE TABLE IF NOT EXISTS music_releases(artist_id TEXT PRIMARY KEY, last_id TEXT, ts INTEGER, title TEXT, name TEXT)")
    await c.commit()


async def close():
    global _db
    if _db:
        await _db.close()
        _db = None


# ---------- users ----------
XP_COOLDOWN = 30


async def touch_user(u, count: bool = True) -> dict:
    """Регистрирует/обновляет юзера, начисляет xp (не чаще раза в 30с)."""
    c = await db()
    now = int(time.time())
    await c.execute("INSERT OR IGNORE INTO daily_active VALUES(?,?)", (_day(now), u.id))
    name = (u.full_name or "")[:64]
    await c.execute(
        "INSERT INTO users(id,name,username,joined,last_seen) VALUES(?,?,?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET name=excluded.name, username=excluded.username, "
        "last_seen=excluded.last_seen, msgs=msgs+?",
        (u.id, name, u.username, now, now, int(count)),
    )
    if count:
        await c.execute(
            "UPDATE users SET xp=xp+1, last_xp=? WHERE id=? AND last_xp<?",
            (now, u.id, now - XP_COOLDOWN),
        )
    await c.commit()
    return await get_user(u.id)


async def get_user(uid: int) -> dict | None:
    c = await db()
    cur = await c.execute("SELECT * FROM users WHERE id=?", (uid,))
    r = await cur.fetchone()
    return dict(r) if r else None


async def set_banned(uid: int, val: bool):
    c = await db()
    await c.execute("UPDATE users SET banned=? WHERE id=?", (int(val), uid))
    await c.commit()


async def top(field: str, limit: int = 10) -> list[dict]:
    assert field in ("xp", "rep", "msgs", "coins", "season_wins")
    c = await db()
    cur = await c.execute(
        f"SELECT id,name,{field} AS v FROM users WHERE banned=0 ORDER BY {field} DESC LIMIT ?",
        (limit,),
    )
    return [dict(r) for r in await cur.fetchall()]


async def rank_of(uid: int) -> int:
    c = await db()
    cur = await c.execute(
        "SELECT COUNT(*)+1 FROM users WHERE xp > (SELECT xp FROM users WHERE id=?)", (uid,)
    )
    return (await cur.fetchone())[0]


async def all_user_ids() -> list[int]:
    c = await db()
    cur = await c.execute("SELECT id FROM users WHERE banned=0")
    return [r[0] for r in await cur.fetchall()]


async def stats() -> dict:
    c = await db()
    day = int(time.time()) - 86400
    q = lambda s, *a: c.execute(s, a)
    total = (await (await q("SELECT COUNT(*) FROM users")).fetchone())[0]
    active = (await (await q("SELECT COUNT(*) FROM users WHERE last_seen>?", day)).fetchone())[0]
    new = (await (await q("SELECT COUNT(*) FROM users WHERE joined>?", day)).fetchone())[0]
    chats = (await (await q("SELECT COUNT(*) FROM chats")).fetchone())[0]
    stars = (await (await q("SELECT COALESCE(SUM(stars),0) FROM donations")).fetchone())[0]
    ai = await (await q("SELECT COALESCE(SUM(calls),0), COALESCE(SUM(tokens),0), COALESCE(SUM(fails),0) "
                        "FROM ai_stats WHERE day=?", _day())).fetchone()
    return dict(total=total, active=active, new=new, chats=chats, stars=stars,
                ai_calls=ai[0], ai_tokens=ai[1], ai_fails=ai[2])


# ---------- reputation ----------
REP_COOLDOWN = 3600


async def give_rep(giver: int, taker: int, chat_id: int) -> bool:
    c = await db()
    now = int(time.time())
    cur = await c.execute(
        "SELECT 1 FROM rep_log WHERE giver=? AND taker=? AND ts>?",
        (giver, taker, now - REP_COOLDOWN),
    )
    if await cur.fetchone():
        return False
    await c.execute("INSERT INTO rep_log VALUES(?,?,?,?)", (giver, taker, chat_id, now))
    await c.execute("UPDATE users SET rep=rep+1 WHERE id=?", (taker,))
    await c.commit()
    return True


# ---------- dialog history ----------
async def add_history(chat_id: int, user_id: int, role: str, text: str):
    c = await db()
    await c.execute(
        "INSERT INTO history(chat_id,user_id,role,text,ts) VALUES(?,?,?,?,?)",
        (chat_id, user_id, role, text[:2000], int(time.time())),
    )
    await c.commit()


async def get_history(chat_id: int, limit: int) -> list[dict]:
    c = await db()
    cur = await c.execute(
        "SELECT role,text,user_id FROM history WHERE chat_id=? ORDER BY id DESC LIMIT ?",
        (chat_id, limit),
    )
    return [dict(r) for r in reversed(await cur.fetchall())]


async def clear_history(chat_id: int):
    c = await db()
    await c.execute("DELETE FROM history WHERE chat_id=?", (chat_id,))
    await c.commit()


async def cleanup(days: int = 30):
    c = await db()
    now = int(time.time())
    await c.execute("DELETE FROM history WHERE ts<?", (now - days * 86400,))
    await c.execute("DELETE FROM game_state WHERE ts<?", (now - 3 * 86400,))
    await c.execute("DELETE FROM ai_usage WHERE day<?", (_day(now - 3 * 86400),))
    await c.execute("DELETE FROM chat_daily WHERE day<?", (_day(now - 35 * 86400),))
    await c.execute("DELETE FROM thread_users WHERE ts<?", (now - 90 * 86400,))   # волна 63
    await c.commit()


def _day(ts: float | None = None) -> str:
    """Дата по МСК: «2026-10-12»."""
    return time.strftime("%Y-%m-%d", time.gmtime((ts or time.time()) + 3 * 3600))


# ---------- facts (что Соня помнит о юзере) ----------
MAX_FACTS = 15


async def add_fact(uid: int, fact: str):
    c = await db()
    await c.execute("INSERT INTO facts(user_id,fact,ts) VALUES(?,?,?)",
                    (uid, fact[:200], int(time.time())))
    await c.execute(
        "DELETE FROM facts WHERE user_id=? AND id NOT IN "
        "(SELECT id FROM facts WHERE user_id=? ORDER BY id DESC LIMIT ?)",
        (uid, uid, MAX_FACTS),
    )
    await c.commit()


async def get_facts(uid: int) -> list[str]:
    c = await db()
    cur = await c.execute("SELECT fact FROM facts WHERE user_id=? ORDER BY id", (uid,))
    return [r[0] for r in await cur.fetchall()]


async def clear_facts(uid: int):
    c = await db()
    await c.execute("DELETE FROM facts WHERE user_id=?", (uid,))
    await c.commit()


# ---------- chats ----------
async def add_chat(chat_id: int, title: str):
    c = await db()
    await c.execute(
        "INSERT INTO chats(id,title,added) VALUES(?,?,?) "
        "ON CONFLICT(id) DO UPDATE SET title=excluded.title",
        (chat_id, title, int(time.time())),
    )
    await c.commit()


async def remove_chat(chat_id: int):
    c = await db()
    await c.execute("DELETE FROM chats WHERE id=?", (chat_id,))
    await c.commit()


async def chat_ai_on(chat_id: int) -> bool:
    c = await db()
    cur = await c.execute("SELECT ai_on FROM chats WHERE id=?", (chat_id,))
    r = await cur.fetchone()
    return True if r is None else bool(r[0])


async def set_chat_ai(chat_id: int, on: bool):
    c = await db()
    await c.execute("UPDATE chats SET ai_on=? WHERE id=?", (int(on), chat_id))
    await c.commit()


# ---------- donations ----------
async def add_donation(uid: int, stars: int, charge_id: str, kind: str = ""):
    c = await db()
    await c.execute("INSERT INTO donations(user_id,stars,charge_id,ts,kind) VALUES(?,?,?,?,?)",
                    (uid, stars, charge_id, int(time.time()), kind))
    await c.commit()


async def user_donated(uid: int) -> int:
    c = await db()
    cur = await c.execute("SELECT COALESCE(SUM(stars),0) FROM donations WHERE user_id=?", (uid,))
    return (await cur.fetchone())[0]


async def users_recent(limit: int = 15) -> list[dict]:
    c = await db()
    cur = await c.execute("SELECT * FROM users ORDER BY last_seen DESC LIMIT ?", (limit,))
    return [dict(r) for r in await cur.fetchall()]


async def users_banned() -> list[dict]:
    c = await db()
    cur = await c.execute("SELECT * FROM users WHERE banned=1 ORDER BY last_seen DESC LIMIT 30")
    return [dict(r) for r in await cur.fetchall()]


# ---------- настройки группы ----------
CHAT_FLAGS = {"ai_on", "auto_dl", "auto_voice", "greet", "reacts", "captcha", "antiflood", "antilink", "bdays",
              "daily_sum", "antispam", "clean_service", "rp", "dl_clean", "antimat"}


async def chat_flag(chat_id: int, flag: str) -> bool:
    if flag not in CHAT_FLAGS:   # не assert: с python -O он исчезает, а имя колонки идёт прямо в SQL
        raise ValueError(f"неизвестный флаг {flag!r}")
    c = await db()
    cur = await c.execute(f"SELECT {flag} FROM chats WHERE id=?", (chat_id,))
    r = await cur.fetchone()
    return True if r is None else bool(r[0])


async def set_chat_flag(chat_id: int, flag: str, on: bool):
    if flag not in CHAT_FLAGS:
        raise ValueError(f"неизвестный флаг {flag!r}")
    c = await db()
    await c.execute(f"UPDATE chats SET {flag}=? WHERE id=?", (int(on), chat_id))
    await c.commit()


# ---------- кэш скачиваний (file_id по ссылке) ----------
async def dl_cache_get(key: str) -> dict | None:
    c = await db()
    cur = await c.execute("SELECT * FROM dl_cache WHERE key=?", (key,))
    r = await cur.fetchone()
    return dict(r) if r else None


async def count_dl(uid: int):
    await q_run("UPDATE users SET dls=dls+1 WHERE id=?", uid)
    emit("dl", uid)


async def dl_cache_put(key: str, type_: str, file_id: str, title: str):
    c = await db()
    await c.execute("INSERT OR REPLACE INTO dl_cache VALUES(?,?,?,?,?)",
                    (key, type_, file_id, title[:200], int(time.time())))
    await c.commit()


# ---------- монетки ----------
async def add_coins(uid: int, n: int, win: bool = False) -> int:
    c = await db()
    await c.execute("UPDATE users SET coins=MAX(0, coins+?), wins=wins+?, season_wins=season_wins+? WHERE id=?",
                    (n, int(win), int(win), uid))
    await c.commit()
    if win:
        emit("win", uid)
    cur = await c.execute("SELECT coins FROM users WHERE id=?", (uid,))
    r = await cur.fetchone()
    return r[0] if r else 0


async def take_coins(uid: int, n: int) -> bool:
    """Списать, если хватает."""
    if n < 0:   # волна 62: «списать минус 100» = начислить — не даём
        return False
    c = await db()
    cur = await c.execute("UPDATE users SET coins=coins-? WHERE id=? AND coins>=?", (n, uid, n))
    await c.commit()
    return cur.rowcount > 0


async def claim_bonus(uid: int) -> tuple[int, int, int]:
    """→ (выдано, стрик, секунд до следующего). выдано=0 — рано."""
    now = int(time.time())
    u = await get_user(uid)
    last = u.get("last_bonus") or 0
    if now - last < 20 * 3600:
        return 0, u.get("streak") or 0, 20 * 3600 - (now - last)
    streak = (u.get("streak") or 0) + 1 if now - last < 48 * 3600 else 1
    amount = min(100, 20 + (streak - 1) * 5)
    c = await db()
    # волна 62: «если last_bonus всё ещё тот, что прочитали» — двойной /bonus раньше давал монеты дважды
    cur = await c.execute("UPDATE users SET coins=coins+?, last_bonus=?, streak=? WHERE id=? AND COALESCE(last_bonus,0)=?",
                          (amount, now, streak, uid, last))
    await c.commit()
    if not cur.rowcount:
        return 0, u.get("streak") or 0, 20 * 3600
    emit("bonus", uid)
    return amount, streak, 0


async def set_voice(uid: int, voice: str):
    c = await db()
    await c.execute("UPDATE users SET voice=? WHERE id=?", (voice, uid))
    await c.commit()


# ---------- события (для заданий дня и т.п.) ----------
HOOKS: dict[str, list] = {}


def on(event: str, fn):
    HOOKS.setdefault(event, []).append(fn)


def emit(event: str, uid: int, n: int = 1):
    """Сообщить подписчикам: «юзер сделал X». Не блокирует и не падает."""
    import asyncio
    for fn in HOOKS.get(event, []):
        try:
            asyncio.get_running_loop().create_task(fn(uid, event, n))
        except RuntimeError:
            pass


async def kv_get(k: str, default: str = "") -> str:
    r = await q_one("SELECT v FROM kv WHERE k=?", k)
    return r["v"] if r else default


async def kv_set(k: str, v: str):
    await q_run("INSERT OR REPLACE INTO kv VALUES(?,?)", k, v)


# ---------- универсальные хелперы ----------
async def q_all(sql, *a) -> list[dict]:
    c = await db()
    cur = await c.execute(sql, a)
    return [dict(r) for r in await cur.fetchall()]


async def q_one(sql, *a) -> dict | None:
    c = await db()
    cur = await c.execute(sql, a)
    r = await cur.fetchone()
    return dict(r) if r else None


async def q_run(sql, *a) -> int:
    c = await db()
    cur = await c.execute(sql, a)
    await c.commit()
    return cur.lastrowid


async def q_change(sql, *a) -> int:
    """Волна 62: сколько строк изменилось. Для «захвата»: UPDATE … WHERE status='wait' → 1 только у первого,
    двойной тап получит 0 (раньше SELECT-потом-UPDATE пропускал оба нажатия)."""
    c = await db()
    cur = await c.execute(sql, a)
    await c.commit()
    return cur.rowcount


# ---------- лог группы (для «что я пропустил») ----------
async def log_group(chat_id: int, name: str, text: str):
    await q_run("INSERT INTO chat_log(chat_id,name,text,ts) VALUES(?,?,?,?)",
                chat_id, name[:40], text[:500], int(time.time()))
    if random.random() < 0.02:
        await q_run("DELETE FROM chat_log WHERE chat_id=? AND id NOT IN "
                    "(SELECT id FROM chat_log WHERE chat_id=? ORDER BY id DESC LIMIT 600)", chat_id, chat_id)


# ---------- статистика группы (/stats, дни рождения) ----------
async def track_group(chat_id: int, uid: int):
    c = await db()
    now = int(time.time())
    hour = time.gmtime(now + 3 * 3600).tm_hour
    await c.execute("INSERT INTO chat_members VALUES(?,?,?) ON CONFLICT(chat_id, uid) DO UPDATE SET last=excluded.last",
                    (chat_id, uid, now))
    await c.execute("INSERT INTO chat_daily VALUES(?,?,?,1) ON CONFLICT(chat_id, uid, day) DO UPDATE SET n=n+1",
                    (chat_id, uid, _day(now)))
    await c.execute("INSERT INTO chat_hours VALUES(?,?,1) ON CONFLICT(chat_id, hour) DO UPDATE SET n=n+1",
                    (chat_id, hour))
    await c.commit()
