import os
from pathlib import Path

BASE = Path(__file__).parent


def _load_env():
    p = BASE / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
# узкие боты на том же коде: full — Соня целиком, dl — только скачивание, music — только музыка
PROFILE = os.getenv("BOT_PROFILE", "full").strip().lower() or "full"
MAIN_BOT = os.getenv("MAIN_BOT", "Sonya_rubot").lstrip("@")   # куда зовут узкие боты
DB_PATH = str(BASE / "data" / (os.getenv("DB_FILE", "") or "sonya.db"))
# волна 44: Соня+ общая — помощники читают подписку из базы основной Сони
MAIN_DB_PATH = str(BASE / "data" / (os.getenv("MAIN_DB_FILE", "") or "sonya.db"))

# LLM: любой OpenAI-совместимый провайдер (groq / deepseek / gemini)
LLM_URL = os.getenv("LLM_URL", "https://api.groq.com/openai/v1/chat/completions")
LLM_KEY = os.getenv("LLM_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "openai/gpt-oss-120b")
LLM_MODEL_FALLBACK = os.getenv("LLM_MODEL_FALLBACK", "qwen/qwen3-32b")
# модель, которая видит картинки (для живых подписей к фото); пусто — без зрения
# llama-4-scout Groq убрал; сейчас картинки понимает qwen3.8-27b (думающая — размышления отключаем)
LLM_VISION_MODEL = os.getenv("LLM_VISION_MODEL", "qwen/qwen3.8-27b")
# второй провайдер — если Groq лёг или упёрся в лимит (OpenRouter, Gemini, DeepSeek…)
LLM_URL_2 = os.getenv("LLM_URL_2", "")
LLM_KEY_2 = os.getenv("LLM_KEY_2", "")
LLM_MODEL_2 = os.getenv("LLM_MODEL_2", "")

# поиск в интернете (Groq compound сам ищет); пусто — выключен
SEARCH_MODEL = os.getenv("SEARCH_MODEL", "groq/compound-mini")
# отвечать в личке по мере набора текста (0 — выключить)
STREAM = os.getenv("STREAM", "1") != "0"

# токен pollinations.ai (рисование без водяного знака и без лимитов); пусто — бесплатно, со знаком
POLLINATIONS_TOKEN = os.getenv("POLLINATIONS_TOKEN", "")

# сервисный ключ VK — для автоисточника «VK-паблик»
VK_TOKEN = os.getenv("VK_TOKEN", "")

# обязательная подписка на канал (@username или -100…); пусто — выключено
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "")
# сколько каналов автопостинга без Соня+ (0 — без ограничений)
FREE_CHANNELS = int(os.getenv("FREE_CHANNELS", "0") or 0)
FREE_SOURCES = int(os.getenv("FREE_SOURCES", "0") or 0)   # волна 35: автоисточников без Сони+ (0 — без лимита)

# сколько ИИ-ответов в сутки на человека (болтовня, фото, инлайн); 0 — без лимита
AI_DAY_LIMIT = int(os.getenv("AI_DAY_LIMIT", "100") or 0)
AI_DAY_LIMIT_PLUS = int(os.getenv("AI_DAY_LIMIT_PLUS", "500") or 0)

# расшифровка голосовых (Groq Whisper); по умолчанию тот же ключ, что у LLM
STT_URL = os.getenv("STT_URL", LLM_URL.replace("chat/completions", "audio/transcriptions"))
STT_KEY = os.getenv("STT_KEY", LLM_KEY)
STT_MODEL = os.getenv("STT_MODEL", "whisper-large-v3-turbo")

HISTORY_LEN = 12          # сколько последних реплик помнит в диалоге
GROUP_TRIGGERS = ("соня", "сонь", "сонька", "sonya")

# свой сервер Bot API (telegram-bot-api, --local): файлы до 2 ГБ. Пусто — обычный api.telegram.org (50 МБ)
BOT_API_URL = os.getenv("BOT_API_URL", "").rstrip("/")
BOT_API_DOWN = ""   # 43b: сервер указан, но не отвечает — работаем через облако, а не падаем


def _api_alive(url: str, wait: int = 60) -> bool:
    """Порт своего Bot API открыт? Ждём до wait секунд (docker после ребута встаёт не сразу)."""
    import socket
    import time
    from urllib.parse import urlparse
    u = urlparse(url)
    end = time.time() + wait
    while True:
        try:
            socket.create_connection((u.hostname or "127.0.0.1", u.port or 80), 3).close()
            return True
        except OSError:
            if time.time() > end:
                return False
            time.sleep(3)


if BOT_API_URL and not _api_alive(BOT_API_URL, int(os.getenv("BOT_API_WAIT", "60") or 60)):
    BOT_API_DOWN, BOT_API_URL = BOT_API_URL, ""
# волна 43: папка, которую telegram-bot-api видит как --dir (в контейнере смонтирована по тому же пути).
# Отсюда Соня берёт скачанные файлы и чистит старые
BOT_API_DIR = os.getenv("BOT_API_DIR", "/home/sonya/tgapi").rstrip("/")
LOCAL_API = bool(BOT_API_URL)
_MB = 1024 * 1024
# сколько можно ОТПРАВИТЬ (облако — 50 МБ, свой сервер — 2 ГБ; TG_SEND_MB — урезать, если мало диска)
TG_SEND_MAX = (int(os.getenv("TG_SEND_MB", "1990") or 1990) if LOCAL_API else 49) * _MB
# сколько можно СКАЧАТЬ из телеграма для обработки (облако — 20 МБ; свой сервер — по умолчанию 500 МБ)
TG_GET_MAX = (int(os.getenv("TG_GET_MB", "500") or 500) if LOCAL_API else 20) * _MB
# волна 61: пароль на бэкапы (openssl AES-256). Пусто — бэкап уходит открытым, как раньше
BACKUP_PASS = os.getenv("BACKUP_PASS", "")
# волна 65: обложки-картинки на главных экранах (0 — выключить)
BANNERS = os.getenv("BANNERS", "1") != "0"
BANNERS_ALL = os.getenv("BANNERS_ALL", "1") != "0"   # волна 74: картинка на каждом экране с кнопками и шапкой


def mb(n: int) -> str:
    """Лимит для текста: 50 МБ / 2 ГБ."""
    n = round(n / _MB)
    return f"{round(n / 1024)} ГБ" if n >= 1000 else f"{n + 1 if n % 10 == 9 else n} МБ"
