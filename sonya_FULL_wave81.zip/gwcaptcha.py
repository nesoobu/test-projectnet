"""Волна 62: капча для розыгрышей картинкой. Ответ только на изображении — в тексте и в кнопках его нет,
поэтому скрипт, читающий сообщение, не пройдёт (старая «нажми на 🐱» сдавалась любому боту).
Виды: 1 «Фигуры» (цифра на нужной фигуре), 2 «Число» (в шуме), 3 «Провода» (куда ведёт провод), 4 «Случайная».
make(kind) → (png, вопрос, кнопки, индекс правильной). Рисуем PIL, ~10–20 мс, память копеечная."""
import io
import math
import random
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

KINDS = {1: "🧩 Фигуры", 2: "🔢 Число", 3: "🔌 Провода", 4: "🎲 Случайная"}
W, H = 640, 360
_FONT = Path(__file__).parent / "assets" / "fonts" / "RussoOne.ttf"
_rng = random.SystemRandom()
COLORS = {"красн": (230, 57, 70), "син": (40, 110, 230), "зелён": (40, 170, 90), "жёлт": (240, 190, 20),
          "фиолетов": (150, 70, 200)}
SHAPES = ("круг", "квадрат", "треугольник", "ромб")


def _font(size: int):
    try:
        return ImageFont.truetype(str(_FONT), size)
    except OSError:
        return ImageFont.load_default()


def _noise(d: ImageDraw.ImageDraw, n_lines=10, n_dots=900):
    for _ in range(n_lines):
        d.line([(_rng.randint(0, W), _rng.randint(0, H)), (_rng.randint(0, W), _rng.randint(0, H))],
               fill=tuple(_rng.randint(120, 200) for _ in range(3)), width=_rng.randint(1, 3))
    for _ in range(n_dots):
        x, y = _rng.randint(0, W - 1), _rng.randint(0, H - 1)
        d.point((x, y), fill=tuple(_rng.randint(60, 220) for _ in range(3)))


def _png(im: Image.Image) -> bytes:
    buf = io.BytesIO()
    im.save(buf, "PNG", optimize=True)
    return buf.getvalue()


def _shape(d, kind, cx, cy, r, color):
    if kind == "круг":
        d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=color)
    elif kind == "квадрат":
        d.rectangle([cx - r, cy - r, cx + r, cy + r], fill=color)
    elif kind == "треугольник":
        d.polygon([(cx, cy - r), (cx - r, cy + r), (cx + r, cy + r)], fill=color)
    else:
        d.polygon([(cx, cy - r), (cx + r, cy), (cx, cy + r), (cx - r, cy)], fill=color)


def _shapes() -> tuple[bytes, str, list[str], int]:
    """6 фигур с цифрами; спрашиваем цифру на «красном треугольнике». Таких фигур ровно одна."""
    im = Image.new("RGB", (W, H), (245, 243, 238))
    d = ImageDraw.Draw(im)
    _noise(d, 6, 500)
    combos = _rng.sample([(c, s) for c in COLORS for s in SHAPES], 6)
    digits = _rng.sample(range(1, 10), 6)
    f = _font(44)
    for i, ((c, s), n) in enumerate(zip(combos, digits)):
        cx = 110 + (i % 3) * 210 + _rng.randint(-25, 25)
        cy = 95 + (i // 3) * 170 + _rng.randint(-15, 15)
        _shape(d, s, cx, cy, 58, COLORS[c])
        d.text((cx, cy + (12 if s == "треугольник" else 0)), str(n), font=f, fill="white", anchor="mm",
               stroke_width=3, stroke_fill=(30, 30, 30))
    k = _rng.randrange(6)
    c, s = combos[k]
    adj = {"красн": "красном", "син": "синем", "зелён": "зелёном", "жёлт": "жёлтом", "фиолетов": "фиолетовом"}[c]
    opts = [str(x) for x in digits]
    _rng.shuffle(opts)
    return _png(im.filter(ImageFilter.SMOOTH)), f"какая цифра на <b>{adj} {s}е</b>?", opts, opts.index(str(digits[k]))


def _number() -> tuple[bytes, str, list[str], int]:
    """Трёхзначное число, буквы повёрнуты и в шуме; кнопки — оно и три похожих."""
    n = _rng.randint(100, 999)
    im = Image.new("RGB", (W, H), tuple(_rng.randint(225, 250) for _ in range(3)))
    d = ImageDraw.Draw(im)
    _noise(d, 14, 2500)
    x = 140
    for ch in str(n):
        tile = Image.new("RGBA", (160, 180), (0, 0, 0, 0))
        td = ImageDraw.Draw(tile)
        td.text((80, 90), ch, font=_font(_rng.randint(120, 150)), anchor="mm",
                fill=tuple(_rng.randint(20, 110) for _ in range(3)) + (255,))
        tile = tile.rotate(_rng.randint(-28, 28), resample=Image.BICUBIC, expand=False)
        im.paste(tile, (x - 80 + _rng.randint(-10, 10), 90 + _rng.randint(-25, 25)), tile)
        x += 130 + _rng.randint(-10, 10)
    _noise(ImageDraw.Draw(im), 6, 600)   # линии поверх цифр
    decoys = set()
    while len(decoys) < 3:   # похожие: одна цифра другая — угадать «на глаз» по кнопкам нельзя
        s = list(str(n))
        i = _rng.randrange(3)
        s[i] = str((int(s[i]) + _rng.randint(1, 9)) % 10)
        v = "".join(s)
        if v != str(n) and v[0] != "0":
            decoys.add(v)
    opts = [str(n)] + list(decoys)
    _rng.shuffle(opts)
    return _png(im), "какое <b>число</b> на картинке?", opts, opts.index(str(n))


def _bez(p0, p1, p2, p3, steps=60):
    out = []
    for i in range(steps + 1):
        t = i / steps
        a, b, c, e = (1 - t) ** 3, 3 * t * (1 - t) ** 2, 3 * t * t * (1 - t), t ** 3
        out.append((a * p0[0] + b * p1[0] + c * p2[0] + e * p3[0], a * p0[1] + b * p1[1] + c * p2[1] + e * p3[1]))
    return out


def _wires() -> tuple[bytes, str, list[str], int]:
    """Слева А–Г, справа 1–4, провода одного цвета перепутаны. «Куда ведёт провод от Б?»"""
    im = Image.new("RGB", (W, H), (240, 240, 236))
    d = ImageDraw.Draw(im)
    _noise(d, 0, 700)
    letters = ["А", "Б", "В", "Г"]
    ys = [60 + i * 80 for i in range(4)]
    perm = list(range(4))
    while perm == sorted(perm):
        _rng.shuffle(perm)
    f = _font(40)
    color = (60, 60, 70)
    wire = [(230, 57, 70), (40, 110, 230), (40, 170, 90), (150, 70, 200)]
    _rng.shuffle(wire)
    for i in range(4):
        y0, y1 = ys[i], ys[perm[i]]
        pts = _bez((70, y0), (_rng.randint(200, 300), _rng.randint(0, H)), (_rng.randint(340, 440), _rng.randint(0, H)),
                   (W - 70, y1))
        d.line(pts, fill=wire[i], width=6, joint="curve")
    for i in range(4):
        d.ellipse([30, ys[i] - 26, 82, ys[i] + 26], fill=(255, 255, 255), outline=color, width=3)
        d.text((56, ys[i]), letters[i], font=f, fill=color, anchor="mm")
        d.ellipse([W - 82, ys[i] - 26, W - 30, ys[i] + 26], fill=(255, 255, 255), outline=color, width=3)
        d.text((W - 56, ys[i]), str(i + 1), font=f, fill=color, anchor="mm")
    k = _rng.randrange(4)
    opts = ["1", "2", "3", "4"]
    return _png(im), f"куда ведёт провод от <b>{letters[k]}</b>?", opts, perm[k]


_MAKERS = {1: _shapes, 2: _number, 3: _wires}


def make(kind: int) -> tuple[bytes, str, list[str], int]:
    """kind 1–3 — свой вид, 4 (и всё прочее) — случайный."""
    return _MAKERS.get(kind, _MAKERS[_rng.choice((1, 2, 3))])()


# ================= возраст аккаунта =================
# id в Telegram растут со временем. Порог «новый аккаунт»: самый большой id из тех, кого бот видел
# раньше чем N дней назад (их аккаунты точно старше N дней). Кто выше порога — создан, скорее всего, позже.
# Без внешних сервисов; чем больше у ботов пользователей, тем точнее порог.
def age_threshold_sql(days: int) -> tuple[str, tuple]:
    import time
    return "SELECT MAX(id) m FROM users WHERE joined>0 AND joined<=?", (int(time.time()) - days * 86400,)
