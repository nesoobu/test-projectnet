"""Волна 79: картинки автопилота без кракозябр (генератор рисует без текста, буквы кладём сами),
факты без выдумок, тема без названия канала. python test_w79.py ../sonya"""
import asyncio, io, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from PIL import Image


def jpg(color=(80, 60, 40)):
    b = io.BytesIO()
    Image.new("RGB", (1024, 1024), color).save(b, "JPEG")
    return b.getvalue()


async def main():
    await db.init()
    import llm, gameart
    from autopost import autopilot as AP
    from handlers import tools
    calls = {"img": 0}

    async def fimg(url):
        calls["img"] += 1
        assert "no text" in url.replace("%20", " ")
        return jpg()
    tools.fetch_image = fimg
    answers = ['{"text": true}', '{"text": false}']

    async def vis(system, text, img, max_tokens=30):
        return answers.pop(0) if answers else '{"text": false}'

    async def ask(msgs, **k):
        return "guitar player on stage, warm light"
    llm.ask_vision, llm.ask = vis, ask
    pic = await AP._picture("Первый рэп-хит записали в 1979 году\nтекст", "Первый рэп-хит записали в 1979 году")
    out = Image.open(pic["src"])
    check("генератор написал текст → перерисовала; заголовок — нашим шрифтом, 1080×1080",
          calls["img"] == 2 and out.size == (1080, 1080))
    check("цитата на картинке: текст и автор отдельно",
          AP.card_text("quote", "«Где слова бессильны, туда приходит музыка». — Ханс Кристиан Андерсен\n\nмысль")
          == ("Где слова бессильны, туда приходит музыка", "— Ханс Кристиан Андерсен"))

    async def ask_judge(msgs, **k):
        return '{"score": 9, "made_up": true, "why": "выдуманный термин"}'
    llm.ask = ask_judge
    check("фактчек: выдумка («9-й обертон H9») — в брак, даже при высокой оценке",
          await AP.judge_text("Таинственный 9-й обертон H9") == 0)
    check("промпты: факт — только проверяемый, название канала не упоминать",
          "НЕ выдумывай" in AP.AI_PROMPTS["fact"])
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
