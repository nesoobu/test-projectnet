"""⭐ Фонд звёзд на подарки: пополняешь звёздами → тратишь на подарки Telegram в розыгрышах.
Звёзды падают на баланс бота, бот дарит подарки из этого баланса (sendGift). У каждого — свой учёт в users.gift_stars."""
import json
import logging
import re
import secrets
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, LabeledPrice

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("gifts")
TOPUP = [15, 50, 100, 250, 500]
CLAIM_DAYS = 3          # не выбрал подарок за 3 дня — дарю первый подходящий сам
_cache: dict = {"ts": 0, "gifts": []}


# ================= баланс =================
async def balance(uid: int) -> int:
    u = await db.get_user(uid) or {}
    return u.get("gift_stars") or 0


async def change(uid: int, delta: int, reason: str) -> bool:
    """Списать/начислить. Списание не уходит в минус — тогда False."""
    # волна 62: одной командой — два одновременных списания не уведут фонд в минус
    if not await db.q_change("UPDATE users SET gift_stars=COALESCE(gift_stars,0)+? "
                             "WHERE id=? AND COALESCE(gift_stars,0)+? >= 0", delta, uid, delta):
        return False
    await db.q_run("INSERT INTO gift_ledger VALUES(?,?,?,?)", uid, delta, reason[:80], int(time.time()))
    return True


async def bot_balance(bot: Bot) -> int | None:
    try:
        from aiogram.methods import GetMyStarBalance
        r = await bot(GetMyStarBalance())
        return int(getattr(r, "amount", 0))
    except Exception as e:
        log.info("star balance: %s", e)
        return None


# ================= каталог подарков Telegram =================
async def catalog(bot: Bot) -> list[dict]:
    """[{id, stars, emoji, sticker}] — только те, что можно отправить (не закончились)."""
    if time.time() - _cache["ts"] < 600 and _cache["gifts"]:
        return _cache["gifts"]
    try:
        res = await bot.get_available_gifts()
        out = []
        for g in res.gifts:
            if g.remaining_count == 0:
                continue
            out.append({"id": g.id, "stars": g.star_count, "emoji": (g.sticker.emoji if g.sticker else "") or "🎁",
                        "sticker": g.sticker.file_id if g.sticker else None, "limited": bool(g.total_count)})
        _cache.update(ts=time.time(), gifts=sorted(out, key=lambda x: x["stars"]))
    except Exception as e:
        log.warning("gifts: %s", e)
    return _cache["gifts"]


async def prices(bot: Bot) -> list[int]:
    return sorted({g["stars"] for g in await catalog(bot)})


async def for_price(bot: Bot, stars: int) -> list[dict]:
    """Подарки ровно за N звёзд, а если таких нет — самые дорогие из тех, что дешевле."""
    gifts = await catalog(bot)
    exact = [g for g in gifts if g["stars"] == stars]
    if exact:
        return exact
    cheaper = [g for g in gifts if g["stars"] <= stars]
    top = max((g["stars"] for g in cheaper), default=0)
    return [g for g in cheaper if g["stars"] == top]


async def send(bot: Bot, uid: int, gift_id: str, text: str) -> bool:
    try:
        await bot.send_gift(gift_id=gift_id, user_id=uid, text=text[:128])
        return True
    except Exception as e:
        log.warning("send gift %s → %s: %s", gift_id, uid, e)
        return False


# ================= экран фонда =================
async def fund_view(uid: int, bot: Bot):
    b = await balance(uid)
    lines = [ui.head("⭐", "Звёзды на подарки", "для розыгрышей и подарков друзьям"),
             ui.stats(("на балансе", f"{b} ⭐")),
             ui.quote("1. пополни звёздами\n2. /giveaway → «⭐ Подарок на N звёзд» или «🎁 Конкретный подарок»\n"
                      "3. победители сами выберут подарок — я подарю его от имени бота\n"
                      "🎁 или дари друзьям: в чате ответь на сообщение «подарить сердечко» (/gift — все подарки)"),
             ui.hint("подарки Telegram стоят от 15 ⭐. звёзды за неразыгранные призы возвращаются на баланс")]
    if uid == config.OWNER_ID:
        bb = await bot_balance(bot)
        if bb is not None:
            lines.append(ui.hint(f"баланс бота в Telegram: {bb} ⭐ · /fund add 100 — перенести в свой фонд"))
    kb = kb_rows([(f"+{n} ⭐", f"fund:buy:{n}") for n in TOPUP[:3]],
                 [(f"+{n} ⭐", f"fund:buy:{n}") for n in TOPUP[3:]] + [("🎁 Каталог", "fund:cat")])
    return "\n".join(lines), kb


@router.message(Command("fund", "звезды", "подарки"))
async def cmd_fund(m: Message, bot: Bot, command: CommandObject):
    args = (command.args or "").split()
    if m.from_user.id == config.OWNER_ID and len(args) == 2 and args[0] == "add" and args[1].isdigit():
        n = int(args[1])
        bb = await bot_balance(bot)
        reserved = (await db.q_one("SELECT SUM(gift_stars) s FROM users WHERE id!=?", config.OWNER_ID))["s"] or 0
        if bb is not None and n + reserved + await balance(m.from_user.id) > bb:
            return await m.answer(f"на балансе бота {bb} ⭐, из них {reserved} ⭐ — чужие фонды. столько не перенести")
        await change(m.from_user.id, n, "из баланса бота")
        return await m.answer(f"✅ +{n} ⭐ в твой фонд подарков. теперь: <b>{await balance(m.from_user.id)} ⭐</b>")
    text, kb = await fund_view(m.from_user.id, bot)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "m:fund")
async def cb_fund(cb: CallbackQuery, bot: Bot):
    text, kb = await fund_view(cb.from_user.id, bot)
    await cb.answer()
    await cb.message.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("fund:buy:"))
async def cb_buy(cb: CallbackQuery, bot: Bot):
    n = int(cb.data.split(":")[2])
    if n not in TOPUP:
        return await cb.answer()
    await cb.answer()
    await bot.send_invoice(cb.message.chat.id, title=f"⭐ {n} звёзд на подарки",
                           description="звёзды для подарков в твоих розыгрышах — потратишь, когда захочешь",
                           payload=f"fund:{n}", currency="XTR", prices=[LabeledPrice(label="Фонд подарков", amount=n)])


@router.callback_query(F.data == "fund:cat")
async def cb_cat(cb: CallbackQuery, bot: Bot):
    gifts = await catalog(bot)
    await cb.answer()
    if not gifts:
        return await cb.message.answer("😕 Telegram не отдал список подарков, попробуй позже")
    by: dict[int, list] = {}
    for g in gifts:
        by.setdefault(g["stars"], []).append(g["emoji"])
    lines = ["🎁 <b>подарки, которые я могу дарить</b>"] + [f"<b>{p} ⭐</b> — {' '.join(e[:12])}" for p, e in by.items()]
    await cb.message.answer("\n".join(lines))


async def paid(m: Message, n: int):
    """Вызывается из donate.paid для payload fund:N."""
    await change(m.from_user.id, n, "пополнение")
    await m.answer(f"⭐ <b>+{n}</b> на подарки! на балансе: <b>{await balance(m.from_user.id)} ⭐</b>\n"
                   "запускай розыгрыш: /giveaway")


# ================= выдача приза победителю =================
async def claim_view(bot: Bot, w: dict) -> tuple[str, list]:
    """w — строка gift_wins. Возвращает текст и варианты."""
    opts = await for_price(bot, w["stars"])
    text = (f"🎉 <b>ты выиграл подарок на {w['stars']} ⭐!</b>\n<i>{escape(w['title'] or '')}</i>\n"
            f"выбери, какой хочешь — жми под стикером 👇")
    return text, opts


async def offer(bot: Bot, w: dict, chat_id: int) -> bool:
    text, opts = await claim_view(bot, w)
    if not opts:
        return False
    try:
        await bot.send_message(chat_id, text)
        for g in opts[:8]:
            kb = kb_rows([(f"🎁 Хочу этот · {g['stars']} ⭐", f"gwc:{w['id']}:{g['id']}")])
            if g["sticker"]:
                await bot.send_sticker(chat_id, g["sticker"], reply_markup=kb)
            else:
                await bot.send_message(chat_id, g["emoji"], reply_markup=kb)
        return True
    except Exception as e:
        log.info("offer: %s", e)
        return False


@router.callback_query(F.data.startswith("gwc:"))
async def cb_claim(cb: CallbackQuery, bot: Bot):
    _, wid, gift_id = cb.data.split(":", 2)
    w = await db.q_one("SELECT * FROM gift_wins WHERE id=?", int(wid))
    if not w or w["uid"] != cb.from_user.id:
        return await cb.answer("это не твой приз 🙃", show_alert=True)
    if w["status"] != "pending":
        return await cb.answer("приз уже вручён 🎁", show_alert=True)
    if gift_id not in {g["id"] for g in await for_price(bot, w["stars"])}:
        return await cb.answer("этот подарок уже недоступен — выбери другой", show_alert=True)
    if not await db.q_change("UPDATE gift_wins SET status='sending' WHERE id=? AND status='pending'", w["id"]):
        return await cb.answer("приз уже вручается 🎁", show_alert=True)   # волна 62: двойной тап
    ok = await send(bot, w["uid"], gift_id, f"🎁 приз из розыгрыша: {w['title'] or ''}")
    if not ok:
        await db.q_run("UPDATE gift_wins SET status='pending' WHERE id=?", w["id"])
        return await cb.answer("😕 не получилось подарить — попробуй ещё раз позже", show_alert=True)
    await db.q_run("UPDATE gift_wins SET status='done', gift_id=? WHERE id=?", gift_id, w["id"])
    await cb.answer("🎁 подарок отправлен!", show_alert=True)
    await cb.message.answer("🎉 готово! подарок уже у тебя в профиле 🖤")


async def pending_for(uid: int) -> list[dict]:
    return await db.q_all("SELECT * FROM gift_wins WHERE uid=? AND status='pending'", uid)


async def deliver_wins(bot: Bot, gw: dict, winners: list[dict]) -> int:
    """После итогов розыгрыша: конкретный подарок — дарим сразу, «на N звёзд» — даём выбрать.
    Возвращаем владельцу звёзды за места, на которые не нашлось победителей."""
    kind, stars, gift_id = gw["gift_kind"], gw["gift_stars"], gw["gift_id"]
    for w in winners:
        wid = await db.q_run("INSERT INTO gift_wins(gid, uid, stars, gift_id, title, status, ts) VALUES(?,?,?,?,?,?,?)",
                             gw["id"], w["uid"], stars, gift_id or "", gw["prize"][:120], "pending", int(time.time()))
        row = await db.q_one("SELECT * FROM gift_wins WHERE id=?", wid)
        if kind == "exact":
            if await send(bot, w["uid"], gift_id, f"🎁 приз из розыгрыша: {gw['prize'][:90]}"):
                await db.q_run("UPDATE gift_wins SET status='done' WHERE id=?", wid)
                try:
                    await bot.send_message(w["uid"], "🎉 ты выиграл в розыгрыше — подарок уже у тебя в профиле! 🖤")
                except Exception:
                    pass
            continue
        await offer(bot, row, w["uid"])   # не получилось написать — заберёт по кнопке под итогами
    unused = gw["winners"] - len(winners)
    if unused > 0:
        await change(gw["owner_id"], unused * stars, f"возврат за розыгрыш #{gw['id']}")
    return unused


async def auto_claim(bot: Bot):
    """Победитель не выбрал за CLAIM_DAYS — дарю первый подходящий подарок сам."""
    old = await db.q_all("SELECT * FROM gift_wins WHERE status='pending' AND ts<?", int(time.time()) - CLAIM_DAYS * 86400)
    for w in old:
        opts = await for_price(bot, w["stars"])
        if not opts or not await db.q_change("UPDATE gift_wins SET status='sending' WHERE id=? AND status='pending'",
                                             w["id"]):
            continue   # волна 62: победитель как раз сам выбирает — не дарим второй
        if await send(bot, w["uid"], opts[0]["id"], f"🎁 приз из розыгрыша: {w['title'] or ''}"):
            await db.q_run("UPDATE gift_wins SET status='done', gift_id=? WHERE id=?", opts[0]["id"], w["id"])
        else:
            await db.q_run("UPDATE gift_wins SET status='pending' WHERE id=?", w["id"])


# ================= волна 64: «подарить сердечко» — подарок Telegram другу из своего баланса =================
# В чате ответом на сообщение: «подарить сердечко» / «подари мишку спасибо!» / /gift алмаз.
# Платит тот, кто дарит, — из своего баланса ⭐ (/fund). Подтверждение одной кнопкой (деньги настоящие).
NAMES = {
    "💝": ("сердечко", "сердечка", "сердце", "сердечком", "валентинку"),
    "🧸": ("мишку", "мишка", "мишутку", "медведя", "медведь", "медвежонка"),
    "🎁": ("подарок", "подарочек", "коробку", "коробочку"),
    "🌹": ("розу", "роза", "розочку", "цветочек"),
    "🎂": ("торт", "тортик"),
    "💐": ("букет", "цветы"),
    "🚀": ("ракету", "ракета"),
    "🍾": ("шампанское", "шампусик"),
    "🏆": ("кубок",),
    "💍": ("кольцо", "колечко"),
    "💎": ("алмаз", "алмазик", "бриллиант", "брюлик", "кристалл"),
}
ALIAS = {w: e for e, ws in NAMES.items() for w in ws}
DAY_LIMIT = 30           # подарков в сутки от одного человека — защита от случайного слива
_RX = re.compile(r"^\s*(?:подарить|подари|дарю|подарю)\s+(\S+)\s*(.*)$", re.I | re.S)


async def basic_gift(bot: Bot, emoji: str) -> dict | None:
    """Обычный (не лимитированный) подарок с этим эмодзи — самый дешёвый."""
    hits = [g for g in await catalog(bot) if g["emoji"].startswith(emoji) or emoji.startswith(g["emoji"])]
    hits.sort(key=lambda g: (g.get("limited", False), g["stars"]))
    return hits[0] if hits else None


def _parse(text: str) -> tuple[str, str] | None:
    m = _RX.match(text or "")
    if not m:
        return None
    word = m.group(1).lower().strip(".,!?")
    emoji = ALIAS.get(word) or (word if word in NAMES else None)
    return (emoji, m.group(2).strip()) if emoji else None


async def _gift_req(m: Message) -> bool | dict:
    """Фильтр: ответ на чьё-то сообщение + «подарить <что>». Иначе не трогаем сообщение (не глотаем)."""
    if not m.text or not m.from_user:
        return False
    got = _parse(m.text)
    if not got:
        return False
    return {"gift_req": got}


@router.message(Command("gift"))
async def cmd_gift(m: Message, bot: Bot, command: CommandObject):
    got = _parse("подарить " + (command.args or ""))
    if not got:
        return await m.answer(await gifts_list_text(bot, m.from_user.id))
    await _offer_gift(m, bot, *got)


@router.message(_gift_req)
async def on_gift_word(m: Message, bot: Bot, gift_req: tuple):
    await _offer_gift(m, bot, *gift_req)


async def gifts_list_text(bot: Bot, uid: int) -> str:
    rows = []
    for e, ws in NAMES.items():
        g = await basic_gift(bot, e)
        if g:
            rows.append(f"{e} {ws[0]} — <b>{g['stars']} ⭐</b>")
    return (ui.head("🎁", "Подарки друзьям", f"твой баланс: {await balance(uid)} ⭐") + "\n"
            + ("\n".join(rows) or "каталог Telegram сейчас не отвечает") + "\n\n"
            + ui.hint("в чате ответь на сообщение человека: «подарить сердечко» (можно с текстом). "
                      "платишь из своего баланса — пополнить: /fund"))


async def _offer_gift(m: Message, bot: Bot, emoji: str, note: str):
    rt = m.reply_to_message
    to = rt.from_user if rt else None
    if not to:
        return await m.reply("🎁 ответь на сообщение того, кому даришь: «подарить сердечко»")
    if to.is_bot or to.id == m.from_user.id:
        return await m.reply("🙃 себе и ботам подарки не дарю")
    g = await basic_gift(bot, emoji)
    if not g:
        return await m.reply("😕 такого подарка сейчас нет в каталоге Telegram")
    me = await bot.me()
    have = await balance(m.from_user.id)
    if have < g["stars"]:
        return await m.reply(f"{emoji} стоит <b>{g['stars']} ⭐</b>, у тебя на балансе <b>{have} ⭐</b>",
                             reply_markup=kb_rows([("⭐ Пополнить", f"https://t.me/{me.username}?start=fund")]))
    tok = secrets.token_hex(5)
    who = (m.from_user.first_name or "друг")[:30]
    await db.kv_set(f"giftreq:{tok}", json.dumps({
        "from": m.from_user.id, "who": who, "to": to.id, "to_name": (to.first_name or "друг")[:30],
        "gift": g["id"], "emoji": emoji, "stars": g["stars"], "note": note[:90], "ts": int(time.time())}))
    await m.reply(f"{emoji} подарить <b>{escape(to.first_name or 'другу')}</b> за <b>{g['stars']} ⭐</b>?\n"
                  + (f"<i>с текстом: {escape(note[:90])}</i>\n" if note else "")
                  + ui.hint(f"на балансе {have} ⭐"),
                  reply_markup=kb_rows([(f"✅ Подарить за {g['stars']} ⭐", f"gf:y:{tok}", "success"),
                                        ("✖️", f"gf:n:{tok}", "danger")]))


@router.callback_query(F.data.startswith(("gf:y:", "gf:n:")))
async def cb_gift(cb: CallbackQuery, bot: Bot):
    _, act, tok = cb.data.split(":", 2)
    raw = await db.kv_get(f"giftreq:{tok}")
    if not raw:
        return await cb.answer("уже неактуально", show_alert=True)
    r = json.loads(raw)
    if cb.from_user.id != r["from"]:
        return await cb.answer("это не твой подарок 🙃", show_alert=True)
    # захват одной командой: двойной тап не подарит дважды
    if not await db.q_change("DELETE FROM kv WHERE k=?", f"giftreq:{tok}"):
        return await cb.answer()
    if act == "n" or time.time() - r["ts"] > 3600:
        await cb.answer("отменила" if act == "n" else "устарело")
        try:
            return await cb.message.edit_text("🎁 подарок отменён")
        except Exception:
            return
    day = time.strftime("%Y-%m-%d")
    n = int(await db.kv_get(f"giftday:{r['from']}:{day}") or 0)
    if n >= DAY_LIMIT:
        return await cb.answer(f"на сегодня хватит подарков 🙂 лимит {DAY_LIMIT}", show_alert=True)
    if not await change(r["from"], -r["stars"], f"подарок {r['emoji']} → {r['to']}"):
        return await cb.answer("не хватает ⭐ на балансе — пополни: /fund", show_alert=True)
    text = f"{r['emoji']} от {r['who']}" + (f": {r['note']}" if r["note"] else "")
    if not await send(bot, r["to"], r["gift"], text):
        await change(r["from"], r["stars"], "возврат: подарок не ушёл")
        try:
            await bot.send_message(config.OWNER_ID, f"⚠️ подарок {r['emoji']} не ушёл (баланс бота?). "
                                                    f"{r['stars']} ⭐ вернула дарителю")
        except Exception:
            pass
        return await cb.answer("😕 Telegram не принял подарок — звёзды вернула", show_alert=True)
    await db.kv_set(f"giftday:{r['from']}:{day}", str(n + 1))
    await cb.answer("🎁 подарено!")
    try:
        await cb.message.edit_text(f"{r['emoji']} <b>{escape(r['who'])}</b> дарит <b>{escape(r['to_name'])}</b> "
                                   f"подарок за {r['stars']} ⭐! уже в профиле 🖤"
                                   + (f"\n<i>«{escape(r['note'])}»</i>" if r["note"] else ""))
    except Exception:
        pass
