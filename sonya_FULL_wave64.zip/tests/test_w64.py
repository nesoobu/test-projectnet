"""Волна 64: «подарить сердечко» — подарок Telegram другу из своего баланса ⭐.
python test_w64.py ../sonya full   (и gw)"""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import AnswerCallbackQuery
from aiogram.types import Update, CallbackQuery, Message, Chat, User

G_ID = -100


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


def alerts():
    return [a.text or "" for a in H.sent(AnswerCallbackQuery)]


def gcb(data, uid, mid=1):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name=f"U{uid}"),
        message=Message(message_id=mid, date=datetime.now(), text="x", chat=Chat(id=G_ID, type="supergroup"))))


async def token():
    r = await db.q_one("SELECT k FROM kv WHERE k LIKE 'giftreq:%' ORDER BY rowid DESC LIMIT 1")
    return r["k"].split(":", 1)[1] if r else ""


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import gifts
    cat = [{"id": "heart", "stars": 15, "emoji": "💝", "limited": False},
           {"id": "bear", "stars": 15, "emoji": "🧸", "limited": False},
           {"id": "dia_lim", "stars": 50, "emoji": "💎", "limited": True},
           {"id": "dia", "stars": 100, "emoji": "💎", "limited": False}]

    async def fake_cat(bot_): return cat
    sent, fail = [], [False]

    async def fake_send(bot_, uid, gid, text):
        await asyncio.sleep(0.01)
        if fail[0]:
            return False
        sent.append((uid, gid, text))
        return True
    gifts.catalog, gifts.send = fake_cat, fake_send

    for u in (500, 501):
        await dp.feed_update(bot, msg("/start", u, u))
    friend = reply_to(501, name="Kostfire", chat_id=G_ID, text="Хорошо")

    # ---------- нет денег ----------
    SENT.clear()
    await dp.feed_update(bot, msg("Подарить сердечко", G_ID, 500, reply=friend))
    check(f"[{P}] не хватает ⭐ — цена, баланс и кнопка «Пополнить» (/start fund)",
          "15 ⭐" in all_text() and "start=fund" in kbs() and not await token())
    SENT.clear()
    await dp.feed_update(bot, msg("/start fund", 500, 500))
    check(f"[{P}] /start fund — экран пополнения", "Звёзды на подарки" in all_text() and "fund:buy" in kbs())

    # ---------- дарим ----------
    await gifts.change(500, 20, "тест")
    SENT.clear()
    await dp.feed_update(bot, msg("подарить сердечко спасибо за помощь!", G_ID, 500, reply=friend))
    tok = await token()
    check(f"[{P}] подтверждение: кому, цена, текст, кнопка", tok and "Kostfire" in all_text() and "15 ⭐" in all_text()
          and "спасибо за помощь" in all_text() and f"gf:y:{tok}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, gcb(f"gf:y:{tok}", 777))
    check(f"[{P}] чужой не может нажать", any("не твой" in a for a in alerts()) and not sent)
    await asyncio.gather(dp.feed_update(bot, gcb(f"gf:y:{tok}", 500)), dp.feed_update(bot, gcb(f"gf:y:{tok}", 500)))
    check(f"[{P}] двойной тап — подарок один, списано 15", len(sent) == 1 and await gifts.balance(500) == 5)
    check(f"[{P}] подарок ушёл другу с подписью дарителя", sent and sent[0][:2] == (501, "heart")
          and "от Тим: спасибо за помощь!" in sent[0][2])
    check(f"[{P}] в чате — «дарит»", "дарит" in all_text())

    # ---------- выбор подарка, отказы ----------
    await gifts.change(500, 200, "тест")
    SENT.clear()
    await dp.feed_update(bot, msg("подари алмазик", G_ID, 500, reply=friend))
    check(f"[{P}] алмазик → обычный за 100 ⭐, не лимитированный", "100 ⭐" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("подарить мишку", G_ID, 500, reply=reply_to(500, chat_id=G_ID)))
    check(f"[{P}] себе — нельзя", "себе" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("подарить мишку", G_ID, 500))
    check(f"[{P}] без ответа — подсказываю, как", "ответь на сообщение" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("подарить бы кому-нибудь машину", G_ID, 500, reply=friend))
    check(f"[{P}] обычная фраза — не трогаю", "⭐" not in all_text())

    # ---------- Telegram не принял — возврат ----------
    fail[0] = True
    before = await gifts.balance(500)
    await dp.feed_update(bot, msg("подарить мишку", G_ID, 500, reply=friend))
    SENT.clear()
    await dp.feed_update(bot, gcb(f"gf:y:{await token()}", 500))
    check(f"[{P}] не ушёл — звёзды вернулись", await gifts.balance(500) == before and any("вернула" in a for a in alerts()))
    fail[0] = False

    # ---------- отмена и лимит ----------
    await dp.feed_update(bot, msg("подарить мишку", G_ID, 500, reply=friend))
    await dp.feed_update(bot, gcb(f"gf:n:{await token()}", 500))
    check(f"[{P}] ✖️ — отменено, без списания", await gifts.balance(500) == before)
    await db.kv_set(f"giftday:500:{time.strftime('%Y-%m-%d')}", str(gifts.DAY_LIMIT))
    await dp.feed_update(bot, msg("подарить мишку", G_ID, 500, reply=friend))
    SENT.clear()
    await dp.feed_update(bot, gcb(f"gf:y:{await token()}", 500))
    check(f"[{P}] лимит в сутки", any("лимит" in a for a in alerts()) and await gifts.balance(500) == before)

    SENT.clear()
    await dp.feed_update(bot, msg("/gift", 500, 500))
    check(f"[{P}] /gift — список подарков с ценами и баланс", "💝 сердечко — <b>15 ⭐</b>" in all_text()
          and "баланс" in all_text())

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
