"""Волна 80: автопилот музыкального канала — рубрика «Музыка» (Яндекс по токену из твоего источника + YouTube),
видео без своих ссылок (Pinterest-видео по поиску и YouTube Shorts). python test_w80.py ../sonya"""
import asyncio, json, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"

CID, UID = -100777, 1


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import autopilot as AP, store, sources, media_dl as md, rules as R
    await store.add_channel(CID, UID, "H9 музыка/music", "h9")

    async def ask(msgs, **k):
        if "3–8 словами" in msgs[0]["content"]:
            return "русский рэп и эстетика"
        return "вайб на вечер"
    llm.ask = ask
    # у Тима уже есть источник Яндекс Музыки с токеном
    rid0 = await store.add_rule(UID, CID, "yamusic", "likes", "мои лайки")
    await store.set_cfg(rid0, token="YM_TOKEN_X")
    await store.mark_seen(rid0, "11:1")   # волна 82: музыка — похожие на уже выложенные треки

    async def meta0(ids, token):
        return [{"key": i, "artist": "MiyaGi", "title": "x", "duration": 200} for i in ids]
    md.ym_meta = meta0

    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:h:{CID}", UID, UID))
    p = await AP.profile(CID)
    check("музыкальный канал: по умолчанию включены Музыка и Видео", "music" in p["on"] and "video" in p["on"]
          and p["theme"] == "русский рэп и эстетика")
    _p = await AP.profile(CID)
    _p["discover"] = True   # волна 85: здесь проверяется «ищу сама»
    await AP.save(CID, _p)
    await dp.feed_update(bot, cbq(f"apl:go:{CID}", UID, UID))
    p = await AP.profile(CID)
    mr = await store.rule(p["rules"]["music"])
    mc = store.cfg_of(mr)
    check("музыка: токен Яндекса из твоего источника, треки — похожие на выложенные (волна 82)",
          mc["token"] == "YM_TOKEN_X" and ["yamusic", "similar:11"] in mc["sources"])
    vr = await store.rule(p["rules"]["video"])
    vc = store.cfg_of(vr)
    check("видео без твоих ссылок: Pinterest-видео по теме (YouTube-каши больше нет)", vr["active"]
          and any(s.startswith("v:") for _, s in vc["sources"]) and not any("shorts" in s for _, s in vc["sources"]))

    # ---------- кандидаты и трек ----------
    async def ym_ids(src, token):
        assert token == "YM_TOKEN_X"
        return ["11:1", "12:1", "13:2"]

    async def ym_meta(ids, token):
        return [{"key": i, "title": "Мир" if i != "12:1" else "Хиты 2026 — сборник", "artist": "MiyaGi",
                 "duration": 200, "genre": "rusrap", "link": ""} for i in ids]

    async def fetch(t, src, limit=10):
        return []
    md.ym_ids, md.ym_meta, sources.fetch = ym_ids, ym_meta, fetch
    cands = await AP.candidates(mr, mc, set(), 1)
    check("кандидаты: похожие треки (уже выложенный 11:1 — нет)", {c["ym_id"] for c in cands} == {"12:1", "13:2"})

    async def ym_dl(tid, token):
        return {"path": "/tmp/t.mp3", "title": "Мир", "performer": "MiyaGi", "duration": 200, "thumb": None}
    md.ym_download = ym_dl
    bad = next(c for c in cands if c["ym_id"] == "12:1")
    try:
        await AP.materialize(mr, mc, bad)
        ok = False
    except R.SkipItem as e:
        ok = "сборник" in str(e)
    check("сборники/миксы/караоке — не трек, мимо", ok)
    good = next(c for c in cands if c["ym_id"] == "13:2")
    post = await AP.materialize(mr, mc, good)
    check("трек — аудиофайлом с исполнителем и живой подписью", post["media"][0]["type"] == "audio"
          and post["media"][0]["performer"] == "MiyaGi" and post["text"])

    # ---------- видео: поиск Pinterest во вкладке «Видео» ----------
    calls = []

    async def api(resource, options):
        calls.append(options.get("scope"))
        return {"resource_response": {"data": {"results": [
            {"id": "5", "type": "pin", "images": {"736x": {"url": "https://i.pinimg.com/736x/a.jpg"}},
             "videos": {"video_list": {"V_720P": {"url": "https://v1.pinimg.com/videos/mc/720p/a.mp4", "width": 720}}}},
            {"id": "6", "type": "pin", "images": {"736x": {"url": "https://i.pinimg.com/736x/b.jpg"}}}]}}}
    sources._pin_api = api
    items = await sources.pinterest_discover("v:русский рэп", 10)
    check("Pinterest: ищу во вкладке «Видео» и беру только видео-пины", calls[0] == "videos"
          and [i["key"] for i in items] == ["pin:5"] and items[0]["video_list"])
    check("свои ссылки: Яндекс Музыка и SoundCloud → рубрика «Музыка»",
          AP.detect_source("https://music.yandex.ru/album/123")[0] == "yamusic"
          and AP.detect_source("https://soundcloud.com/x/y")[0] == "music")
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
