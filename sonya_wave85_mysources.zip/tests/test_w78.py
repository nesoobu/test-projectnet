"""Волна 78: 🤖 автопилот канала — рубрики со своими источниками и фильтрами качества.
python test_w78.py ../sonya"""
import asyncio, json, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
config.LLM_VISION_MODEL = config.LLM_VISION_MODEL or "test-vision"
from aiogram.methods import SendPoll, SendPhoto, SendMessage

CID, UID = -100555, 1


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import autopilot as AP, store, sources, rules as R
    from handlers import tools
    await store.add_channel(CID, UID, "Рэп Новости", "rapnews")

    # ---------- ИИ подменяем: ответ по смыслу запроса ----------
    vision = {"next": []}

    async def ask(msgs, **k):
        sysm = msgs[0]["content"]
        user = msgs[-1]["content"]
        if "тему" in sysm and "3–8 словами" in sysm:
            return "городские новости и юмор"
        if "редактор новостного" in sysm:
            if "скидка" in user:
                return '{"news": true, "relevant": 8, "ad": true}'
            if "погода" in user:
                return '{"news": true, "relevant": 1, "ad": false}'
            return '{"news": true, "relevant": 9, "ad": false}'
        if "Перескажи новость" in sysm:
            return "Моргенштерн выпустил альбом\nВышел новый альбом. В нём 12 треков."
        if "Оцени пост" in sysm:
            return '{"score": 8}'
        if "опрос" in sysm:
            return '{"q": "какой трек недели?", "options": ["первый", "второй", "оба мимо"]}'
        if "English prompt" in sysm:
            return "cat with headphones"
        return "Факт: у рэпа есть история\nПервый рэп-трек записали в 1979 году."
    llm.ask = ask

    async def ask_vision(system, text, img, max_tokens=120):
        return vision["next"].pop(0) if vision["next"] else '{"meme": false, "funny": 0, "why": "пейзаж"}'
    llm.ask_vision = ask_vision

    async def fimg(url): return b"\xff\xd8\xff" + b"0" * 2000
    tools.fetch_image = fimg

    # ---------- профиль и запуск ----------
    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:h:{CID}", UID, UID))
    p = await AP.profile(CID)
    txt = "\n".join(H.texts())
    check("экран автопилота: тема угадана из канала, рубрики по умолчанию", p["theme"] == "городские новости и юмор"
          and "Мемы" in txt and set(AP.DEFAULT_ON) <= set(p["on"]))
    _p = await AP.profile(CID)
    _p["discover"] = True   # волна 85: здесь проверяется «ищу сама»
    await AP.save(CID, _p)
    await dp.feed_update(bot, cbq(f"apl:go:{CID}", UID, UID))
    p = await AP.profile(CID)
    rs = {k: await store.rule(v) for k, v in p["rules"].items()}
    on_rules = {k: r for k, r in rs.items() if r["active"]}
    meme_cfg = store.cfg_of(on_rules["meme"])
    check("🚀 запуск: по источнику на рубрику, тип «auto», расписание по часам, модерация «сначала мне»",
          set(on_rules) == set(AP.DEFAULT_ON) and all(r["type"] == "auto" and r["moderation"] == 1 for r in on_rules.values())
          and meme_cfg["sched"] == "times" and meme_cfg["times"] == ["13:00", "21:00"])
    news_cfg = store.cfg_of(on_rules["news"])
    check("новости по умолчанию — Google News по теме (ru)", any("news.google.com/rss/search" in s for _, s in news_cfg["sources"]))

    # ---------- мемы: только настоящие и смешные ----------
    async def fetch(t, src, limit=10):
        if t == "pinterest":
            return [{"key": "pin:1", "title": "", "text": "", "image": "https://i.pinimg.com/736x/sunset.jpg", "is_video": False},
                    {"key": "pin:2", "title": "", "text": "", "image": "https://i.pinimg.com/736x/meme.jpg", "is_video": False}]
        if t == "reddit":
            return [{"key": "r1", "title": "", "text": "", "image": "https://i.redd.it/x.jpg", "views": 0}]
        if t == "rss":
            now = int(time.time())
            return [{"key": "n1", "title": "Моргенштерн выпустил альбом", "text": "новость", "link": "https://a.ru/1", "ts": now},
                    {"key": "n2", "title": "Старая новость про рэп", "text": "x", "link": "https://a.ru/2", "ts": now - 5 * 86400},
                    {"key": "n3", "title": "скидка на кроссовки рэперов", "text": "скидка 50%", "link": "https://a.ru/3", "ts": now},
                    {"key": "n4", "title": "погода в Москве", "text": "погода", "link": "https://a.ru/4", "ts": now}]
        return []
    sources.fetch = fetch
    mr = on_rules["meme"]
    try:
        await AP.materialize(mr, meme_cfg, {"key": "pinterest|pin:1", "_src": "pinterest",
                                            "image": "https://i.pinimg.com/736x/sunset.jpg", "is_video": False})
        ok = False
    except R.SkipItem as e:
        ok = "не мем" in str(e)
    check("«мем» с закатом — отбракован по картинке", ok)
    vision["next"] = ['{"meme": true, "funny": 3, "lang": "ru", "why": "баян"}']
    try:
        await AP.materialize(mr, meme_cfg, {"key": "x", "_src": "pinterest", "image": "https://i.pinimg.com/736x/m.jpg",
                                            "is_video": False})
        ok = False
    except R.SkipItem as e:
        ok = "не смешно" in str(e)
    check("мем, но не смешной (3/10) — тоже нет", ok)
    vision["next"] = ['{"meme": true, "funny": 8, "lang": "ru", "why": "жиза"}']
    post = await AP.materialize(mr, meme_cfg, {"key": "y", "_src": "pinterest", "image": "https://i.pinimg.com/736x/m2.jpg",
                                               "is_video": False})
    check("смешной мем 8/10 — картинка без подписей «мем дня»", post["media"] and post["media"][0]["type"] == "photo"
          and post["text"] in ("", "@rapnews"))   # волна 84: только @канала
    # через обычный запуск источника: первый — закат, второй — мем
    vision["next"] = ['{"meme": false, "funny": 0, "why": "закат"}', '{"meme": true, "funny": 9, "lang": "none"}']
    msg_before = len(SENT)
    res = await R.run_rule(bot, await store.rule(mr["id"]))
    st = store.cfg_of(await store.rule(mr["id"]))["apl_stats"]
    check("в работе: закат пропущен, мем ушёл тебе на модерацию; в статистике — причина отсева",
          "на модерации" in "\n".join(H.texts()) and st["rej"] >= 1 and any("не мем" in k for k in st["why"]))

    # ---------- новости ----------
    nr = on_rules["news"]
    ncfg = store.cfg_of(nr)
    cands = await AP.candidates(nr, ncfg, set(), 1)
    outs = []
    for it in cands:
        try:
            outs.append(await AP.materialize(nr, ncfg, it))
        except R.SkipItem as e:
            outs.append(str(e))
    good = [o for o in outs if isinstance(o, dict)]
    bad = [o for o in outs if isinstance(o, str)]
    check("новости: старая, реклама и не по теме — мимо; хорошая — пересказ, заголовок жирным, источник",
          len(good) == 1 and good[0]["text"].startswith("<b>Моргенштерн выпустил альбом</b>") and "источник" in good[0]["text"]
          and any("старая" in b for b in bad) and any("реклама" in b for b in bad) and any("не по теме" in b for b in bad))
    ncfg = store.cfg_of(await store.rule(nr["id"]))
    try:
        await AP.materialize(nr, ncfg, {"key": "rss|n9", "title": "Моргенштерн выпустил новый альбом", "text": "",
                                        "link": "https://b.ru/x", "ts": int(time.time())})
        ok = False
    except R.SkipItem as e:
        ok = "уже была" in str(e)
    check("та же новость с другого сайта — дубль, не выкладываю", ok)

    # ---------- факт с картинкой, опрос ----------
    fr = on_rules["fact"]
    post = await AP.materialize(fr, store.cfg_of(fr), {"key": "ai:1", "_ai": True})
    check("факт: текст с жирным заголовком + нарисованная картинка", post["text"].startswith("<b>Факт")
          and post["media"] and post["media"][0]["src"].endswith(".jpg"))
    pr = on_rules["poll"]
    post = await AP.materialize(pr, store.cfg_of(pr), {"key": "ai:2", "_ai": True})
    from autopost import publisher
    SENT.clear()
    await publisher.send(bot, {"text": "", "media": [], "buttons": [], "reactions": [], "opts": post["opts"]}, CID)
    sp = H.sent(SendPoll)
    check("опрос — настоящий опрос Telegram", sp and sp[-1].question == "какой трек недели?" and len(sp[-1].options) == 3)

    # ---------- свои источники ----------
    check("ссылки распознаю: сайт, t.me, vk, reddit, youtube",
          AP.detect_source("https://lenta.ru")[0] == "rss" and AP.detect_source("t.me/rapnews")[0] == "tg"
          and AP.detect_source("https://vk.com/rapmemes")[0] == "vk" and AP.detect_source("reddit.com/r/memes")[0] == "reddit"
          and AP.detect_source("https://youtu.be/abc")[0] == "video")

    async def get(url, *a, **k):
        if url == "https://site.ru":
            return 200, b'<html><head><link rel="alternate" type="application/rss+xml" href="/news.rss"></head></html>'
        return 404, b""
    sources._get = get
    check("сайт без RSS-ссылки в адресе — нахожу ленту сама", await AP.find_feed("https://site.ru") == "https://site.ru/news.rss")

    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:rep:{CID}", UID, UID))
    check("итоги недели: сколько вышло и что отсеяно", "Мемы" in "\n".join(H.texts()) and "отсеяла" in "\n".join(H.texts()))
    SENT.clear()
    from handlers import ap_panel
    t, kb = await ap_panel.hub_view(CID, UID)
    check("в канале — кнопка «🤖 Автопилот»", f"apl:h:{CID}" in str(kb))
    await dp.feed_update(bot, cbq(f"apl:off:{CID}", UID, UID))
    p = await AP.profile(CID)
    act = [(await store.rule(v))["active"] for v in p["rules"].values()]
    check("⏸ остановить — все рубрики на паузе", not any(act))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
