"""Волна 85: автопилот берёт только ТВОИ источники (как нормальные сервисы автопостинга), «ищу похожее» — по желанию.
python test_w85.py ../sonya"""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"

CID, UID = -100321, 1


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import autopilot as AP, store, sources
    await store.add_channel(CID, UID, "H9 музыка/music", "HudG9m")
    ym = await store.add_rule(UID, CID, "yamusic", "playlist:nesoobu:3", "мой плейлист")
    await store.set_cfg(ym, token="TOK")
    pin = await store.add_rule(UID, CID, "pinterest", "Nesoobu/h9", "h9")

    async def ask(msgs, **k):
        return "русский рэп и эстетика"
    llm.ask = ask

    async def board(src):
        return []
    sources.pinterest_board = board
    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:h:{CID}", UID, UID))
    p = await AP.profile(CID)
    check("при первом открытии беру то, что уже подключено: плейлист → Музыка, доска → Картинки и Видео",
          ["yamusic", "playlist:nesoobu:3"] in p["sources"]["music"] and ["pinterest", "Nesoobu/h9"] in p["sources"]["art"]
          and ["pinterest", "Nesoobu/h9"] in p["sources"]["video"] and p["discover"] is False)
    txt = "\n".join(H.texts())
    check("на экране: «только мои источники», у мемов без источника — предупреждение",
          "Ищу похожее сама ⬜" in str([getattr(x, "reply_markup", "") for x in SENT]) and "нет источника" in txt)

    await dp.feed_update(bot, cbq(f"apl:go:{CID}", UID, UID))
    p = await AP.profile(CID)
    rs = {k: await store.rule(v) for k, v in p["rules"].items()}
    mc = store.cfg_of(rs["music"])
    check("музыка — только твой плейлист, без «похожих» и чарта", mc["sources"] == [["yamusic", "playlist:nesoobu:3"]])
    check("мемы без твоего источника — не включаю (а не ищу что попало)", not (rs.get("meme") or {}).get("active"))

    async def fetch(t, src, limit=10):
        return [{"key": "pin:1", "is_video": True, "image": "u1"}, {"key": "pin:2", "is_video": False, "image": "u2"}]
    sources.fetch = fetch
    ac = await AP.candidates(rs["art"], store.cfg_of(rs["art"]), set(), 1)
    vc = await AP.candidates(rs["video"], store.cfg_of(rs["video"]), set(), 1)
    check("с одной доски: картинки → «Картинки», видео → «Видео»", [x["key"] for x in ac] == ["pinterest|pin:2"]
          and [x["key"] for x in vc] == ["pinterest|pin:1"])

    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:po:{CID}", UID, UID))
    check("«старые источники на паузу» — без двойных постов", not (await store.rule(ym))["active"]
          and not (await store.rule(pin))["active"] and (await store.rule(p["rules"]["music"]))["active"])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:sl:{CID}", UID, UID))
    check("🗂 Источники — список по рубрикам с удалением", "плейлист" in "\n".join(H.texts()) or "playlist" in "\n".join(H.texts()))
    await dp.feed_update(bot, cbq(f"apl:sd:art:0:{CID}", UID, UID))
    p = await AP.profile(CID)
    check("✖ — источник убран из рубрики", not p["sources"].get("art"))
    await dp.feed_update(bot, cbq(f"apl:ds:{CID}", UID, UID))
    p = await AP.profile(CID)
    check("🔎 «ищу похожее сама» включается отдельно", p["discover"] is True)
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
