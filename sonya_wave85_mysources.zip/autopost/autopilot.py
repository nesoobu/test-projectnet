"""Волна 78: 🤖 Автопилот канала — Соня сама ведёт канал по рубрикам.

Как у сервисов-автопилотов (Mira, Creaflow) и мем-ботов (just-memes, MemeBot), только строже:
• у каждой рубрики свои источники и СВОЙ фильтр качества — мем проверяется нейросетью по картинке («это
  правда мем? смешно ли?»), новость — на свежесть, тему и рекламу, факт — на «воду»; не прошло — следующий;
• новости — пересказ своими словами + ссылка на источник, смысловые дубли (одна новость с разных сайтов) — мимо;
• рубрики без источника (факт, совет, цитата, вопрос, опрос) — пишет ИИ, картинку рисует генератор;
• расписание по дням и часам, «сначала мне» — каждый пост приходит на ✅/🗑;
• в воскресенье — итоги недели: что вышло, что и почему отбраковано.
Каждая рубрика — обычный источник автопостинга (тип «auto»): его видно и можно настроить в панели."""
import asyncio
import io
import json
import logging
import random
import re
import time
from html import escape
from urllib.parse import quote

import llm
from autopost import media_dl, sources, store

log = logging.getLogger("autopilot")

# ключ → эмодзи, название, вид, расписание по умолчанию (дни 0=пн), описание
RUBRICS = {
    "news": {"emoji": "📰", "name": "Новости", "kind": "news", "times": ["10:00", "18:00"], "days": list(range(7)),
             "desc": "свежие новости по теме: пересказ в 2–3 предложения и ссылка"},
    "meme": {"emoji": "😂", "name": "Мемы", "kind": "meme", "times": ["13:00", "21:00"], "days": list(range(7)),
             "desc": "только настоящие смешные мемы — каждый проверяю по картинке"},
    "art": {"emoji": "🎨", "name": "Картинки в тему", "kind": "art", "times": ["16:00"], "days": list(range(7)),
            "desc": "красивые картинки по теме канала с живой подписью"},
    "fact": {"emoji": "🧠", "name": "Факт", "kind": "ai", "times": ["11:00"], "days": [0, 2, 4],
             "desc": "интересный факт по теме + картинка"},
    "tip": {"emoji": "💡", "name": "Совет", "kind": "ai", "times": ["12:00"], "days": [1, 3],
            "desc": "полезный практичный совет + картинка"},
    "quote": {"emoji": "💬", "name": "Цитата", "kind": "ai", "times": ["09:30"], "days": [6],
              "desc": "цитата со смыслом и коротким комментарием"},
    "question": {"emoji": "❓", "name": "Вопрос подписчикам", "kind": "ai", "times": ["20:00"], "days": [3],
                 "desc": "вопрос для обсуждения в комментариях"},
    "poll": {"emoji": "📊", "name": "Опрос", "kind": "poll", "times": ["19:00"], "days": [1, 5],
             "desc": "настоящий опрос Telegram по теме"},
    "video": {"emoji": "🎬", "name": "Видео", "kind": "video", "times": ["17:00"], "days": [1, 3, 5],
              "desc": "короткие видео по теме: Pinterest и YouTube Shorts (сама ищу) + твои источники"},
    "music": {"emoji": "🎵", "name": "Музыка", "kind": "music", "times": ["09:00", "15:00", "21:00"],
              "days": list(range(7)), "desc": "треки файлами с обложкой: Яндекс Музыка (чарт и поиск по теме) и YouTube"},
}
DEFAULT_ON = ["news", "meme", "fact", "poll", "art"]
MUSIC_ON = ["music", "video", "meme", "news", "art", "poll"]   # волна 80: музыкальный канал — упор на музыку
MUSIC_RX = re.compile(r"музык|рэп|реп\b|трек|хип[- ]?хоп|рок|поп|бит|альбом|песн|phonk|фонк|rap|music|lo-?fi|диджей|dj",
                      re.I)


def is_music(theme: str) -> bool:
    return bool(MUSIC_RX.search(theme or ""))
AI_PROMPTS = {
    "fact": "Один удивительный, НО ДОСТОВЕРНЫЙ факт по теме «{theme}» — такой, что есть в Википедии или учебнике. "
            "НЕ выдумывай терминов, явлений, названий и цифр; не связывай факт с названием канала. Если не уверена — "
            "возьми другой, общеизвестный факт. Первая строка — цепляющий заголовок (до 60 символов), дальше 2–4 "
            "предложения простым языком.",
    "tip": "Один практичный совет по теме «{theme}», который можно применить сегодня. Заголовок, потом 3–5 "
           "коротких пунктов или предложений. Без банальностей вроде «пейте воду».",
    "quote": "Короткая известная цитата, подходящая каналу о «{theme}», с автором (только реальная, без выдуманных "
             "авторов), и 1–2 предложения от себя — почему она откликается.",
    "question": "Вопрос подписчикам канала о «{theme}», на который хочется ответить в комментариях. 1–2 "
                "предложения контекста и сам вопрос. Без «а вы знали».",
}
STATE_KEY = "apl:{cid}"


# ================= профиль автопилота =================
async def profile(cid: int) -> dict:
    import db
    try:
        return json.loads(await db.kv_get(STATE_KEY.format(cid=cid)) or "{}")
    except ValueError:
        return {}


async def save(cid: int, p: dict):
    import db
    await db.kv_set(STATE_KEY.format(cid=cid), json.dumps(p, ensure_ascii=False))


def new_profile(theme: str) -> dict:
    return {"theme": theme, "lang": "ru", "mode": "moderate", "active": False,
            "on": list(MUSIC_ON if is_music(theme) else DEFAULT_ON), "sources": {}, "rules": {},
            "created": int(time.time()), "v80": True, "discover": False, "v85": True}


async def guess_theme(cid: int, owner: int) -> str:
    """Тема канала из названия и последних постов — ИИ одной строкой."""
    import db
    c = await store.channel(cid) or {}
    recent = await db.q_all("SELECT p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                            "WHERE s.chat_id=? AND s.status='sent' ORDER BY s.sent_at DESC LIMIT 12", cid)
    bits = [re.sub(r"<[^>]+>", "", r.get("text") or "")[:80] for r in recent]
    try:
        out = await llm.ask([{"role": "system", "content": "По названию и постам Telegram-канала опиши его тему "
                              "3–8 словами по-русски, без кавычек, БЕЗ названия канала и брендов (не «музыка H9», а "
                              "«русский рэп и эстетика»). Только тема."},
                             {"role": "user", "content": f"Канал: {c.get('title', '')}\nПосты: " + " | ".join(b for b in bits if b)}],
                            max_tokens=60, temperature=0.3)
        out = out.strip().strip("«»\"'.").split("\n")[0][:80]
        if len(out) >= 3:
            return out
    except Exception as e:
        log.info("тема: %s", e)
    return (c.get("title") or "жизнь и интересное")[:60]


# ================= волна 82: «вкус» канала — учусь на том, что уже выходит =================
TASTE_TTL = 12 * 3600


def clean_theme(theme: str, title: str) -> str:
    """Название канала в теме ломало всё («аккорд H9», «гармоника H9»): вырезаю слова названия и коды."""
    t = theme or ""
    for w in set(re.findall(r"[\w]{2,}", title or "")):
        if w.lower() not in ("музыка", "music", "рэп", "рок", "поп", "арт", "art", "мемы", "новости"):
            t = re.sub(rf"(?i)(?<![\w]){re.escape(w)}(?![\w])", "", t)
    t = re.sub(r"(?i)\b[a-zа-я]\d+\b", "", t)   # «H9», «X5» — коды/названия, не тема
    t = re.sub(r"[\s,;/·—-]+$", "", re.sub(r"^[\s,;/·—-]+", "", re.sub(r"\s{2,}", " ", t))).strip()
    return t or "музыка и эстетика"


async def taste(owner: int, cid: int) -> dict:
    """Что уже выходит в канале из твоих источников: треки Яндекса (→ похожие и артисты), доски Pinterest
    (→ видео с них и похожие по словам их пинов)."""
    import db
    from collections import Counter
    t = {"token": "", "seeds": [], "ym_src": [], "artists": [], "boards": [], "kw": [], "at": int(time.time())}
    for r in await store.rules_of(owner, cid):
        if r["type"] == "auto":
            continue
        c = store.cfg_of(r)
        if r["type"] == "yamusic":
            t["token"] = t["token"] or c.get("token", "")
            t["ym_src"].append(r["source"])
            rows = await db.q_all("SELECT key FROM ap_seen WHERE rule_id=? ORDER BY ts DESC LIMIT 30", r["id"])
            t["seeds"] += [x["key"] for x in rows if re.match(r"^\d", x["key"] or "")]
        elif r["type"] == "pinterest":
            src = r["source"]
            if src.startswith("q:"):
                t["kw"].append(src[2:])
            elif "/" in src and not src.startswith(("rel:", "v:")):
                t["boards"].append(src)
    if t["seeds"] and t["token"]:
        try:
            meta = await media_dl.ym_meta(t["seeds"][:20], t["token"])
            cnt = Counter(a.strip() for m in meta for a in (m.get("artist") or "").split(",") if a.strip())
            t["artists"] = [a for a, _ in cnt.most_common(8)]
        except Exception as e:
            log.info("вкус: артисты: %s", e)
    kws = Counter()
    for b in t["boards"][:3]:
        try:
            for it in await sources.pinterest_board(b):
                if it.get("kw"):
                    kws[it["kw"]] += 1
        except Exception as e:
            log.info("вкус: доска %s: %s", b, e)
    t["kw"] = list(dict.fromkeys(t["kw"] + [k for k, _ in kws.most_common(6)]))[:8]
    return t


async def theme_from_taste(t: dict, title: str) -> str:
    if not (t.get("artists") or t.get("kw")):
        return ""
    try:
        out = await llm.ask([{"role": "system", "content": "Опиши тему Telegram-канала 3–8 словами по-русски: жанр и "
                              "настроение. По артистам и словам картинок. Без названий каналов, без кавычек. Только тема."},
                             {"role": "user", "content": f"Артисты: {', '.join(t.get('artists', [])[:8])}\n"
                                                         f"Картинки: {'; '.join(t.get('kw', [])[:8])}"}],
                            max_tokens=60, temperature=0.3)
        return clean_theme(out.strip().strip("«»\"'.").split("\n")[0][:80], title)
    except Exception as e:
        log.info("тема по вкусу: %s", e)
        return ""


# ================= источники =================
def _gnews(q: str) -> str:
    return f"https://news.google.com/rss/search?q={quote(q + ' when:3d')}&hl=ru&gl=RU&ceid=RU:ru"


def default_sources(key: str, theme: str, token: str = "", t: dict | None = None) -> list[list[str]]:
    """Источники по умолчанию. Волна 82: от «вкуса» канала (твои источники), а не от общих слов:
    музыка — похожие на твои треки, видео — с твоих досок и похожие на их пины, новости — про твоих артистов."""
    t = t or {}
    if key == "music":
        seeds = [s_.split(":")[0] for s_ in t.get("seeds", [])][:6]
        if token and seeds:
            return [["yamusic", f"similar:{x}"] for x in seeds]
        return []   # без твоей музыки не гадаю: из чарта прилетает чужое
    if key == "video":
        out = [["pinterest", b] for b in t.get("boards", [])[:2]]
        out += [["pinterest", f"v:{k}"] for k in t.get("kw", [])[:3]]
        return out or [["pinterest", f"v:{theme}"]]
    if key == "news":
        arts = t.get("artists", [])[:6]
        if arts:
            return [["rss", _gnews(" OR ".join(f'"{a}"' for a in arts))]]
        return [["rss", _gnews(theme)]]
    if key == "meme":
        return [["pinterest", "q:смешные мемы"], ["pinterest", f"q:мемы {theme}"], ["reddit", "memes"]]
    if key == "art":
        kws = t.get("kw", [])[:3]
        return [["pinterest", f"q:{k}"] for k in kws] or [["pinterest", f"q:{theme} эстетика"]]
    return []


def detect_source(raw: str) -> tuple[str, str] | None:
    """Ссылка → (тип, источник) для автопостинга."""
    raw = raw.strip()
    low = raw.lower()
    try:
        if "music.yandex" in low:
            return "yamusic", media_dl.ym_parse(raw)
        if "soundcloud.com" in low:
            return "music", raw
        if "t.me/" in low or raw.startswith("@"):
            return "tg", sources.normalize("tg", raw)[0]
        if "vk.com/" in low or "vk.ru/" in low:
            if "video" in low or "clip" in low:
                return "video", raw
            return "vk", sources.normalize("vk", raw)[0]
        if "reddit.com/r/" in low:
            return "reddit", sources.normalize("reddit", raw)[0]
        if "pinterest." in low:
            return "pinterest", sources.normalize("pinterest", raw)[0]
        if any(h in low for h in ("youtube.com", "youtu.be", "rutube.ru", "tiktok.com", "dzen.ru/video")):
            return "video", raw
        if low.startswith(("http://", "https://")) or re.match(r"^[\w-]+(\.[\w-]+)+(/.*)?$", low):
            return "rss", raw if low.startswith("http") else "https://" + raw
    except sources.SourceError:
        return None
    return None


async def find_feed(url: str) -> str:
    """Сайт → его RSS (как браузеры: <link rel=alternate type=rss>). Уже лента — она и есть."""
    st, body = await sources._get(url)
    if st != 200:
        raise sources.SourceError(f"сайт ответил {st}")
    head = body[:4000].lower()
    if b"<rss" in head or b"<feed" in head or b"<rdf" in head:
        return url
    page = body.decode("utf-8", "ignore")
    for m in re.finditer(r"<link[^>]+>", page, re.I):
        tag = m.group(0)
        if re.search(r"application/(rss|atom)\+xml", tag, re.I):
            h = re.search(r'href=["\']([^"\']+)', tag)
            if h:
                return sources._web(h.group(1), url) or h.group(1)
    for guess in ("/feed", "/rss", "/rss.xml", "/feed.xml"):
        u = re.sub(r"(https?://[^/]+).*", r"\1", url) + guess
        try:
            st, b = await sources._get(u)
            if st == 200 and (b"<rss" in b[:4000].lower() or b"<feed" in b[:4000].lower()):
                return u
        except sources.SourceError:
            continue
    raise sources.SourceError("не нашла RSS на сайте — пришли ссылку на ленту или другой сайт")


def all_sources(cfg: dict) -> list[list[str]]:
    return [list(x[:2]) for x in (cfg.get("sources") or [])]


async def candidates(rule: dict, cfg: dict, seen: set, want: int) -> list[dict]:
    key = cfg.get("rubric") or rule["source"]
    kind = RUBRICS.get(key, {}).get("kind", "ai")
    if kind in ("ai", "poll"):
        return [{"key": f"ai:{time.time()}:{i}", "_ai": True} for i in range(want)]
    items, errs = [], []
    for t, src in all_sources(cfg):
        try:
            if t == "yamusic":   # волна 80: треки Яндекса — id, метаданные потом
                import db
                posted = {r_["key"] for r_ in await db.q_all(   # волна 82: что уже было из твоего Яндекса — не повторяю
                    "SELECT s.key FROM ap_seen s JOIN ap_rules r ON r.id=s.rule_id WHERE r.chat_id=? AND r.type='yamusic'",
                    rule["chat_id"])}
                ids = [i for i in await media_dl.ym_ids(src, cfg.get("token", ""))
                       if f"yamusic|{i}" not in seen and i not in posted]
                got = await media_dl.ym_meta(random.sample(ids, min(8, len(ids))), cfg.get("token", "")) if ids else []
                for it in got:
                    it["ym_id"] = it["key"]
            else:
                got = await sources.fetch(t, src, 30)
        except Exception as e:   # один сайт упал — остальные работают
            errs.append(f"{t}: {e}")
            continue
        for it in got:
            it["_src"] = t
            it["_board"] = t == "pinterest" and "/" in src and not src.startswith(("q:", "rel:", "v:"))
            it["key"] = f"{t}|{it['key']}"
            if t in ("video", "music") and it.get("link") and not it.get("video_page"):
                it["video_page"] = it["link"]
        items += got
    if not items and errs:
        raise sources.SourceError("; ".join(errs)[:200])
    fresh = [i for i in items if i["key"] not in seen]
    if kind == "video":   # волна 82: с доски — только видео-пины
        fresh = [i for i in fresh if i.get("is_video") or i.get("_src") in ("video", "music")]
    if kind in ("art", "meme"):   # волна 85: в картинки/мемы — без видео-пинов (их берёт «Видео»)
        fresh = [i for i in fresh if not i.get("is_video")]
    if kind == "news":   # свежие первыми
        fresh.sort(key=lambda i: i.get("ts") or 0, reverse=True)
    else:
        random.shuffle(fresh)
        fresh.sort(key=lambda i: -(i.get("views") or 0))   # популярное (просмотры ТГ) — вперёд
    return fresh[:max(want * 8, 12)]


# ================= фильтры качества =================
class Reject(Exception):
    pass


def _json(out: str) -> dict:
    m = re.search(r"\{.*\}", out or "", re.S)
    if not m:
        return {}
    try:
        return json.loads(m.group(0))
    except ValueError:
        return {}


MEME_JUDGE = (
    "Ты строгий редактор мем-канала. Посмотри на картинку и ответь ТОЛЬКО JSON: "
    '{"meme": true|false, "funny": 0-10, "lang": "ru"|"en"|"other"|"none", "why": "3-6 слов"}. '
    "meme=true — только если это мем: шутка, смешная подпись/диалог, абсурдная или жизненная ситуация, реакция, "
    "шаблон мема, смешной кадр. meme=false: пейзаж, закат, просто красивое фото, арт без шутки, реклама, "
    "скриншот длинного текста, мотивационная цитата, новость. funny — насколько реально смешно обычному человеку "
    "(7+ — засмеялся бы). lang — язык текста на картинке (none — текста нет).")
NEWS_JUDGE = (
    "Ты редактор новостного канала на тему «{theme}». Оцени запись и ответь ТОЛЬКО JSON: "
    '{"news": true|false, "relevant": 0-10, "ad": true|false, "why": "3-6 слов"}. '
    "news=true — это сообщение о событии/факте (не реклама, не вакансия, не гороскоп, не подборка «10 лучших»). "
    "relevant — насколько это про тему канала. ad=true — реклама/промо/партнёрский материал.")
ART_JUDGE = (
    "Ты редактор эстетичного канала на тему «{theme}». Ответь ТОЛЬКО JSON: "
    '{"relevant": 0-10, "quality": 0-10, "junk": true|false, "why": "3-6 слов"}. '
    "junk=true — реклама, водяные знаки магазинов, скриншот, коллаж с ценами, мем, текст вместо картинки, "
    "неестественная сгенерированная нейросетью «каша» (лишние пальцы, плывущие лица, кислотные молнии и огонь), "
    "мокап/шаблон (пустой экран телефона, рамка), картинка на прозрачном фоне в шахматку, клипарт, стоковый шаблон.")
TEXT_JUDGE = ("Ты редактор Telegram-канала и фактчекер. Оцени пост и ответь ТОЛЬКО JSON: "
              '{"score": 0-10, "made_up": true|false, "why": "3-6 слов"}. made_up=true — если есть выдуманные '
              "термины, явления, «секретные» эффекты, неверные цитаты/авторы или факты, которых нет в справочниках. "
              "7+ — интересно и по делу; ниже — вода, банальность, канцелярит, «как ИИ», ошибки.")
MEME_MIN_FUNNY = 6


def _first_image(item: dict, media: list) -> str | None:
    for m in media:
        if m.get("type") == "photo" and str(m.get("src", "")).startswith("http"):
            return m["src"]
    img = item.get("image")
    return img if img and str(img).startswith("http") else None


async def judge_meme(item: dict, media: list, lang: str = "ru") -> dict:
    img = _first_image(item, media)
    if not img:
        raise Reject("нет картинки — нечем проверить, что это мем")
    try:
        out = await llm.ask_vision(MEME_JUDGE, "Это мем? Насколько смешно?", img, max_tokens=120)
    except Exception as e:
        raise Reject(f"не смогла посмотреть картинку ({str(e)[:40]}) — без проверки мемы не выкладываю")
    j = _json(out)
    if not j.get("meme"):
        raise Reject(f"не мем: {j.get('why') or 'обычная картинка'}")
    if int(j.get("funny") or 0) < MEME_MIN_FUNNY:
        raise Reject(f"не смешно ({j.get('funny')}/10): {j.get('why') or ''}".strip())
    if lang == "ru" and j.get("lang") == "other":
        raise Reject("текст на непонятном языке")
    return j


def _words(s: str) -> set:
    return {w for w in re.findall(r"[а-яёa-z0-9]{4,}", (s or "").lower())}


def is_dup_title(title: str, recent: list[str], thr: float = 0.5) -> bool:
    """Одна и та же новость с разных сайтов: много общих слов в заголовке."""
    a = _words(title)
    if len(a) < 3:
        return False
    for r in recent:
        b = _words(r)
        if b and len(a & b) / max(1, min(len(a), len(b))) >= thr:
            return True
    return False


async def judge_news(item: dict, theme: str, recent: list[str], max_age_h: int = 72,
                     artists: list | None = None) -> dict:
    ts = item.get("ts") or 0
    blob = f"{item.get('title', '')} {item.get('text', '')}".lower()
    if artists and not any(a.lower() in blob for a in artists):
        raise Reject("не про артистов канала")
    if ts and time.time() - ts > max_age_h * 3600:
        raise Reject(f"старая новость ({int((time.time() - ts) / 3600)} ч)")
    if is_dup_title(item.get("title", ""), recent):
        raise Reject("эта новость уже была (с другого сайта)")
    out = await llm.ask([{"role": "system", "content": NEWS_JUDGE.replace("{theme}", theme)},
                         {"role": "user", "content": f"{item.get('title', '')}\n{item.get('text', '')[:600]}"}],
                        max_tokens=120, temperature=0)
    j = _json(out)
    if j and (not j.get("news") or j.get("ad")):
        raise Reject("реклама" if j.get("ad") else f"не новость: {j.get('why') or ''}")
    if j and int(j.get("relevant") or 0) < 5:
        raise Reject(f"не по теме ({j.get('relevant')}/10)")
    return j


async def judge_art(item: dict, media: list, theme: str) -> dict:
    img = _first_image(item, media)
    if not img:
        return {}
    try:
        out = await llm.ask_vision(ART_JUDGE.replace("{theme}", theme), "Оцени картинку для канала.", img, max_tokens=100)
    except Exception:
        return {}   # vision упал — картинки и так с доски/поиска по теме
    j = _json(out)
    if j.get("junk"):
        raise Reject(f"мусор: {j.get('why') or ''}")
    if j and (int(j.get("relevant") or 0) < 5 or int(j.get("quality") or 0) < 5):
        raise Reject(f"не в тему/некрасиво ({j.get('relevant')}/{j.get('quality')})")
    return j


async def judge_text(text: str) -> int:
    try:
        out = await llm.ask([{"role": "system", "content": TEXT_JUDGE}, {"role": "user", "content": text[:1500]}],
                            max_tokens=80, temperature=0)
        j = _json(out)
        if j.get("made_up"):   # волна 79: «9-й обертон H9» и прочие выдумки — в брак
            return 0
        return int(j.get("score") or 7)
    except Exception:
        return 7


# ================= сборка поста =================
TEXT_CHECK = ('Есть ли на картинке буквы, надписи, текст, подписи, логотипы? Ответ ТОЛЬКО JSON: {"text": true|false}')
NO_TEXT = ("textless image, absolutely no text, no letters, no words, no captions, no typography, no logo, "
           "no watermark, no signs with writing")


SCENE_SYS = ("You write prompts for an image generator. Read the Telegram post and invent ONE concrete, rich, "
             "well-lit scene that illustrates it: a clear main subject, a specific place, foreground details, light "
             "source and colors, camera angle. Example: 'close-up of a vintage cassette player on a wooden desk, warm "
             "lamp light, neon city lights through rain-streaked window, purple and orange tones, shallow depth of "
             "field'. 25-45 words. Never use abstract mood words alone (moody, atmospheric, mysterious) — show it with "
             "objects and light. Never include words, titles, letters, quotes, logos. Only the prompt.")
QUALITY = "cinematic photo, highly detailed, rich colors, good exposure, sharp focus, 35mm film look"


def _too_empty(data: bytes) -> bool:
    """Волна 83: почти чёрная или пустая картинка (было «слишком пусто») — перерисовать."""
    try:
        from PIL import Image, ImageStat
        im = Image.open(io.BytesIO(data)).convert("L").resize((128, 128))
        st = ImageStat.Stat(im)
        return st.mean[0] < 55 or st.stddev[0] < 28
    except Exception:
        return False


async def _picture(prompt_ru: str, title: str = "", sub: str = "", style: str = "", tag: str = "") -> dict | None:
    """Картинку рисует генератор БЕЗ текста, нейросеть проверяет, что букв нет; пустую/тёмную — перерисовываю
    (до 3 раз); заголовок кладу сама. style — эстетика канала (слова твоих пинов: vhs, film grain…)."""
    import gameart
    from handlers import tools
    try:
        en = await llm.ask([{"role": "system", "content": SCENE_SYS},
                            {"role": "user", "content": prompt_ru[:800]}], max_tokens=160, temperature=0.8)
    except Exception:
        en = ""
    en = re.sub(r"[\"«»“”]", "", (en or "vinyl record player on a desk, warm lamp light, city lights in the window"))[:300]
    en = re.sub(r"(?i)\b(moody|atmospheric|mysterious)\b", "", en)
    full = ", ".join(x for x in (en, style[:60], QUALITY, "no text") if x)
    data = None
    for attempt in range(3):
        url = (f"https://image.pollinations.ai/prompt/{quote(full)}?width=1024&height=1024"
               f"&nologo=true&seed={random.randint(1, 10 ** 6)}&model=flux")
        try:
            got = await tools.fetch_image(url)
        except Exception as e:
            log.info("картинка не нарисовалась: %s", e)
            continue
        if _too_empty(got):
            log.info("картинка почти пустая/тёмная — перерисовываю (%s)", attempt + 1)
            data = data or got   # на крайний случай
            continue
        try:
            import base64
            chk = _json(await llm.ask_vision(TEXT_CHECK, "Есть текст?",
                                             "data:image/jpeg;base64," + base64.b64encode(got).decode(), max_tokens=30))
            if chk.get("text"):
                log.info("на картинке генератор написал текст — перерисовываю (%s)", attempt + 1)
                continue
        except Exception:
            pass   # vision недоступен — снизу всё равно наша дымка с заголовком
        data = got
        break
    else:
        if data and _too_empty(data):
            return None
    if not data:
        return None
    if title:
        try:
            data = await asyncio.to_thread(gameart.post_card, data, title, sub, tag=tag)
        except Exception as e:   # не открылась как картинка — оставляю как есть
            log.info("заголовок на картинку: %s", e)
    try:
        path = str(media_dl._dir() / f"apl_{int(time.time() * 1000)}.jpg")
        with open(path, "wb") as f:
            f.write(data)
        return {"type": "photo", "src": path, "path": path}
    except Exception as e:
        log.info("обложка поста: %s", e)
        return None


def card_text(key: str, text: str) -> tuple[str, str]:
    """Что написать на картинке: факт/совет — заголовок; цитата — сама цитата и автор."""
    first = text.strip().split("\n")[0].strip().strip("«»\"'")
    if key == "quote":
        m = re.search(r"«([^»]{5,160})»\.?\s*[—–-]\s*([^\n.]{3,40})", text)
        if m:
            return m.group(1).strip(), "— " + m.group(2).strip()
        return first[:140], ""
    return first[:120], ""


def _clean_ai(s: str) -> str:
    s = (s or "").strip()
    s = re.sub(r"\*\*(.+?)\*\*", r"\1", s)
    s = re.sub(r"(?m)^#{1,4}\s*", "", s)
    return s


def _headed(text: str) -> str:
    """Первая строка — жирный заголовок."""
    lines = text.strip().split("\n", 1)
    head = escape(lines[0].strip().strip("«»\"'"))
    body = escape(lines[1].strip()) if len(lines) > 1 else ""
    return f"<b>{head}</b>" + (f"\n\n{body}" if body else "")


async def _bump(rule: dict, cfg: dict, ok: bool, why: str = ""):
    st = cfg.get("apl_stats") or {}
    wk = time.strftime("%G-%V")
    if st.get("wk") != wk:
        st = {"wk": wk, "ok": 0, "rej": 0, "why": {}}
    if ok:
        st["ok"] += 1
    else:
        st["rej"] += 1
        w = re.sub(r"\(.*?\)|:.*$", "", why).strip()[:40] or "другое"
        st["why"][w] = st["why"].get(w, 0) + 1
    cfg["apl_stats"] = st
    await store.set_cfg(rule["id"], apl_stats=st)


async def channel_tag(chat_id: int) -> str:
    """Волна 84: @юз канала (для подписи и картинок). Закрытый канал без юза — пусто."""
    ch = await store.channel(chat_id) or {}
    u = (ch.get("username") or "").lstrip("@")
    return f"@{u}" if u else ""


async def materialize(rule: dict, cfg: dict, item: dict) -> dict:
    """Пост рубрики + @канала в конце (если у канала нет своей подписи — иначе её добавит публикация)."""
    ch = await store.channel(rule["chat_id"]) or {}
    tag = await channel_tag(rule["chat_id"])
    post = await _materialize(rule, {**cfg, "tag": tag}, item)
    key = cfg.get("rubric") or rule["source"]
    if tag and RUBRICS.get(key, {}).get("kind") in ("meme", "art", "news") and post.get("media"):
        post.setdefault("opts", {})["wm"] = tag   # фото из интернета — @канала знаком (свои картинки уже с плашкой)
    if tag and not ch.get("signature") and not (post.get("opts") or {}).get("poll"):
        t = (post.get("text") or "").rstrip()
        if tag.lower() not in t.lower():
            post["text"] = (t + "\n\n" if t else "") + escape(tag)
    return post


async def _materialize(rule: dict, cfg: dict, item: dict) -> dict:
    """Пост рубрики. Не прошёл фильтр качества → rules.SkipItem (берём следующую запись)."""
    from autopost import publisher, rules
    key = cfg.get("rubric") or rule["source"]
    rb = RUBRICS.get(key, RUBRICS["fact"])
    theme = cfg.get("theme") or "интересное"
    reacts = publisher.REACTION_SETS[cfg.get("reacts", 0) % len(publisher.REACTION_SETS)]
    opts = {"silent": bool(cfg.get("silent")), "link_preview": False}
    footer = ("\n\n" + escape(rule["footer"])) if rule.get("footer") else ""
    try:
        if rb["kind"] == "ai":
            recent = cfg.get("recent") or []
            arts = cfg.get("artists") or []
            sys_p = (AI_PROMPTS[key].format(theme=theme)
                     + (f" Можно взять факт про кого-то из артистов, которых слушают в канале: {', '.join(arts[:6])}." if arts else "")
                     + " Название канала в тексте не упоминай. "
                     "Пиши по-русски, живо, как человек в своём канале, "
                     "300–600 символов (обязательно законченный текст), без хэштегов, без markdown, без «Конечно». Только текст поста.")
            if recent:
                sys_p += " Не повторяй прошлые темы: " + " | ".join(recent[-10:])
            text = ""
            for attempt in range(2):
                out = _clean_ai(await llm.ask([{"role": "system", "content": sys_p},
                                               {"role": "user", "content": "Новый пост."}],
                                              max_tokens=1500, temperature=0.95))
                ban = [w for w in cfg.get("ban") or [] if re.search(rf"(?i)(?<!\w){re.escape(w)}(?!\w)", out or "")]
                if ban:   # волна 82: «аккорд H9», «гармоника H9» — название канала в факте = выдумка
                    log.info("автопилот %s: в тексте название канала (%s) — переписываю", key, ban)
                    continue
                if out and await judge_text(out) >= 6:
                    text = out
                    break
                log.info("автопилот %s: текст слабый, переписываю", key)
            if not text:
                raise Reject("ИИ дважды написал слабо")
            await store.set_cfg(rule["id"], recent=(recent + [text.split("\n")[0][:60]])[-12:])
            style = " ".join((cfg.get("style_kw") or [])[:2])
            pic = await _picture(text, *card_text(key, text), style=style, tag=cfg.get("tag", "")) \
                if key != "question" else None
            body = _headed(text) if key in ("fact", "tip") else escape(text)
            await _bump(rule, cfg, True)
            return {"text": body + footer, "media": [pic] if pic else [], "buttons": [], "reactions": reacts,
                    "opts": opts}

        if rb["kind"] == "poll":
            recent = cfg.get("recent") or []
            out = await llm.ask([{"role": "system", "content":
                                  f"Придумай живой опрос для Telegram-канала о «{theme}». Ответ — ТОЛЬКО JSON: "
                                  '{"q": "вопрос до 200 символов", "options": ["2–6 вариантов, каждый до 80 символов"]}. '
                                  "Варианты смешные или жизненные, не «да/нет». Без повторов: " + " | ".join(recent[-8:])},
                                 {"role": "user", "content": "Новый опрос."}], max_tokens=400, temperature=1.0)
            j = _json(out)
            q = str(j.get("q") or "").strip()[:290]
            opts_l = [str(o).strip()[:95] for o in (j.get("options") or []) if str(o).strip()][:10]
            if not q or len(opts_l) < 2:
                raise Reject("ИИ не собрал опрос")
            await store.set_cfg(rule["id"], recent=(recent + [q[:60]])[-12:])
            await _bump(rule, cfg, True)
            return {"text": "", "media": [], "buttons": [], "reactions": [],
                    "opts": {**opts, "poll": {"q": q, "options": opts_l}}}

        if rb["kind"] == "news":
            recent = cfg.get("news_recent") or []
            await judge_news(item, theme, recent, artists=cfg.get("artists") or None)
            out = _clean_ai(await llm.ask([{"role": "system", "content":
                                            "Перескажи новость для Telegram-канала по-русски: первая строка — короткий "
                                            "заголовок без кавычек, потом 2–3 предложения сути своими словами. "
                                            "Только факты из текста, ничего не добавляй. Без хэштегов и markdown."},
                                           {"role": "user", "content": f"{item.get('title', '')}\n{item.get('text', '')[:1500]}"}],
                                          max_tokens=500, temperature=0.4))
            if not out:
                raise Reject("ИИ не пересказал")
            await store.set_cfg(rule["id"], news_recent=(recent + [item.get("title", "")])[-60:])
            media = []
            if item.get("image"):
                media = [{"type": "photo", "src": item["image"]}]
            link = f'\n\n<a href="{escape(item.get("link", ""), quote=True)}">источник</a>' if item.get("link") else ""
            await _bump(rule, cfg, True)
            return {"text": _headed(out) + link + footer, "media": media, "buttons": [], "reactions": reacts,
                    "opts": opts}

        kind = rb["kind"]
        if kind == "music":
            return await _music(rule, cfg, item, reacts, opts, footer)
        if kind == "video" and item.get("duration") and int(item["duration"]) > 240:
            raise Reject("длинное видео — беру короткие")
        # meme / art / video — медиа из источника
        fake = {**rule, "type": item.get("_src") or "rss", "with_media": 1}
        media = await rules.resolve_media(fake, {**cfg, "media_kind": "video" if kind == "video" else "all"}, item)
        if not media:
            raise Reject("в записи нет картинки/видео")
        if kind == "video" and item.get("image") and item.get("_src") == "pinterest" and not item.get("_board"):
            await judge_art(item, media, theme)   # волна 82: видео из поиска — без нейро-каши
        if kind == "meme":
            if not all(m["type"] in ("photo", "animation", "video") for m in media):
                raise Reject("не картинка")
            await judge_meme(item, media, cfg.get("lang", "ru"))
            text = ""
        elif kind == "art":
            await judge_art(item, media, theme)
            from autopost import captions
            text = ""
            try:
                text = escape(await captions.live_caption({"type": "pinterest", "source": theme},
                                                          {**cfg, "caption": cfg.get("caption") if cfg.get("caption", "none") != "none" else "vibe"},
                                                          item, media))
            except Exception as e:
                log.info("подпись: %s", e)
        else:   # видео: живая подпись, а не чужой заголовок («Fusión de Rave…»)
            from autopost import captions
            text = ""
            try:
                text = escape(await captions.live_caption({"type": "pinterest", "source": theme}, {**cfg, "caption": "vibe"},
                                                          item, media))
            except Exception as e:
                log.info("подпись к видео: %s", e)
        await _bump(rule, cfg, True)
        return {"text": (text + footer).strip(), "media": media, "buttons": [], "reactions": reacts, "opts": opts}
    except Reject as e:
        await _bump(rule, cfg, False, str(e))
        raise rules.SkipItem(str(e))


BAD_TRACK = re.compile(r"\b(mix|микс|сборник|full album|полный альбом|playlist|плейлист|подборка|\d+\s*(час|hour)|"
                       r"караоке|karaoke|минус|instrumental cover|8d|slowed|sped up|nightcore|ремикс 1 час)\b", re.I)


async def _music(rule, cfg, item, reacts, opts, footer) -> dict:
    """Трек файлом с обложкой: Яндекс (полный трек) или YouTube (звук). Сборники, часовые миксы,
    караоке и «замедленные» версии — мимо; 1–8 минут."""
    from autopost import captions
    title = f"{item.get('artist', '')} {item.get('title', '')}"
    if BAD_TRACK.search(title):
        raise Reject("сборник/микс/караоке — не трек")
    d = int(item.get("duration") or 0)
    if d and not 60 <= d <= 480:
        raise Reject("не похоже на трек (длительность)")
    if item.get("_src") == "yamusic":
        f = await media_dl.ym_download(item["ym_id"], cfg.get("token", ""))
        m = {"type": "audio", "src": f["path"], "path": f["path"], "thumb": f.get("thumb"),
             "title": f["title"], "performer": f["performer"], "duration": f["duration"]}
    else:
        f = await media_dl.ytdlp_download(item.get("video_page") or item["link"], "audio")
        if f.get("duration") and not 60 <= int(f["duration"]) <= 480:
            raise Reject("не похоже на трек (длительность)")
        m = {"type": "audio", "src": f["path"], "path": f["path"], "title": f["title"],
             "performer": f["performer"], "duration": f["duration"]}
        if f.get("thumb"):
            m["thumb"] = f["thumb"]
    text = ""
    try:
        text = escape(await captions.live_caption({"type": "yamusic", "source": cfg.get("theme", "")},
                                                  {**cfg, "caption": "vibe"},
                                                  {"artist": m.get("performer", ""), "title": m.get("title", ""),
                                                   "genre": item.get("genre", "")}, []))
    except Exception as e:
        log.info("подпись к треку: %s", e)
    await _bump(rule, cfg, True)
    return {"text": (text + footer).strip(), "media": [m], "buttons": [], "reactions": reacts, "opts": opts}


async def _ym_token(owner: int, p: dict) -> str:
    """Токен Яндекс Музыки: из профиля или из любого твоего источника Яндекса (уже настроенного)."""
    if p.get("ym_token"):
        return p["ym_token"]
    try:
        import db
        rows = await db.q_all("SELECT cfg FROM ap_rules WHERE owner_id=? AND type='yamusic'", owner)
        for r in rows:
            tok = (json.loads(r["cfg"] or "{}") or {}).get("token")
            if tok:
                return tok
    except Exception as e:
        log.info("токен яндекса: %s", e)
    return ""


# ================= волна 85: «📥 взять мои источники канала» =================
def map_rule(r: dict) -> list[str]:
    """Твой источник канала → в какие рубрики он подходит."""
    t, src = r["type"], r["source"]
    if t == "yamusic" or t == "music":
        return ["music"]
    if t == "pinterest":
        return ["art", "video"]   # картинки и видео с доски разойдутся сами (фильтр по типу)
    if t == "video":
        return ["video"]
    if t == "rss":
        return ["news"]
    return []   # ТГ/VK/Reddit — спрошу при добавлении: мемы, новости или картинки


async def import_channel_sources(owner: int, cid: int, p: dict) -> list[tuple[str, str]]:
    """Источники, которые уже есть в канале (не автопилота), → в рубрики. → [(рубрика, название)]."""
    got = []
    for r in await store.rules_of(owner, cid):
        if r["type"] == "auto":
            continue
        for key in map_rule(r):
            pair = [r["type"], r["source"]]
            lst = p.setdefault("sources", {}).setdefault(key, [])
            if pair not in lst:
                lst.append(pair)
                got.append((key, r["title"]))
            if key not in p.setdefault("on", []):
                p["on"].append(key)
    return got


# ================= включение / выключение =================
async def refresh_taste(owner: int, cid: int, p: dict, force: bool = False):
    t = p.get("taste") or {}
    if force or not t or time.time() - t.get("at", 0) > TASTE_TTL:
        p["taste"] = await taste(owner, cid)


async def apply(owner: int, cid: int, p: dict) -> list[int]:
    """Профиль → источники «auto» (по одному на включённую рубрику). Выключенные — на паузу."""
    from autopost import rules as R
    made = []
    try:
        await refresh_taste(owner, cid, p)
    except Exception as e:
        log.info("вкус: %s", e)
    ch = await store.channel(cid)
    for key, rb in RUBRICS.items():
        rid = (p.get("rules") or {}).get(key)
        r = await store.rule(rid) if rid else None
        on = p.get("active") and key in p.get("on", [])
        token = await _ym_token(owner, p)
        srcs = list((p.get("sources") or {}).get(key, []))
        if p.get("discover"):   # волна 85: по умолчанию — ТОЛЬКО твои источники; «ищу сама» — по желанию
            srcs += default_sources(key, p["theme"], token, p.get("taste"))
        if on and rb["kind"] in ("news", "meme", "art", "video", "music") and not srcs:
            on = False
        if not on:
            if r and r.get("active"):
                await store.set_rule(rid, active=0)
            continue
        cfg = {"rubric": key, "theme": p["theme"], "lang": p.get("lang", "ru"), "sources": srcs, "token": token,
               "artists": (p.get("taste") or {}).get("artists", []),
               "style_kw": (p.get("taste") or {}).get("kw", [])[:3],
               "ban": [w for w in re.findall(r"[\w]{2,}", (ch or {}).get("title", ""))
                       if re.search(r"\d", w) or w.lower() not in ("музыка", "music", "рэп", "рок", "арт", "art", "мемы")],
               "sched": "times", "times": (p.get("times") or {}).get(key) or rb["times"],
               "days": (p.get("days") or {}).get(key) or rb["days"], "autopilot": cid,
               "caption": "none", "tags": "none", "link_style": "none"}
        title = f"🤖 {rb['emoji']} {rb['name']}"
        if not r:
            rid = await store.add_rule(owner, cid, "auto", key, title)
            p.setdefault("rules", {})[key] = rid
            r = await store.rule(rid)
        await store.set_rule(rid, active=1, moderation=1 if p.get("mode", "moderate") == "moderate" else 0, title=title)
        await store.set_cfg(rid, **cfg)
        r = await store.rule(rid)
        await store.set_rule(rid, next_run=R.next_run(r, store.cfg_of(r), ch))
        made.append(rid)
    return made


async def report(cid: int) -> str:
    p = await profile(cid)
    lines = []
    wk = time.strftime("%G-%V")
    for key, rid in (p.get("rules") or {}).items():
        r = await store.rule(rid)
        if not r:
            continue
        st = store.cfg_of(r).get("apl_stats") or {}
        if st.get("wk") != wk:
            st = {"ok": 0, "rej": 0, "why": {}}
        rb = RUBRICS.get(key, {})
        why = ", ".join(f"{k} — {v}" for k, v in sorted(st.get("why", {}).items(), key=lambda x: -x[1])[:3])
        lines.append(f"{rb.get('emoji', '•')} <b>{rb.get('name', key)}</b>: вышло {st.get('ok', 0)}"
                     + (f" · отсеяла {st['rej']} ({escape(why)})" if st.get("rej") else ""))
    return "\n".join(lines) or "пока ничего не выходило"


async def report_loop(bot):
    """По воскресеньям в 20:00 МСК — итоги недели владельцу каждого канала на автопилоте."""
    import db
    from datetime import datetime, timedelta, timezone
    msk = timezone(timedelta(hours=3))
    while True:
        await asyncio.sleep(600)
        try:
            now = datetime.now(msk)
            if now.weekday() != 6 or now.hour < 20:
                continue
            rows = await db.q_all("SELECT k, v FROM kv WHERE k LIKE 'apl:%' AND k NOT LIKE 'apl:rep:%'")
            for row in rows:
                try:
                    cid = int(row["k"].split(":")[1])
                    p = json.loads(row["v"])
                except (ValueError, IndexError):
                    continue
                if not p.get("active"):
                    continue
                mark = f"apl:rep:{cid}:{time.strftime('%G-%V')}"
                if await db.kv_get(mark):
                    continue
                await db.kv_set(mark, "1")
                ch = await store.channel(cid) or {}
                owner = ch.get("owner_id")
                if owner:
                    await bot.send_message(owner, f"📈 <b>итоги недели · {escape(ch.get('title', ''))}</b>\n\n"
                                           + await report(cid))
        except Exception as e:
            log.warning("итоги автопилота: %s", e)
