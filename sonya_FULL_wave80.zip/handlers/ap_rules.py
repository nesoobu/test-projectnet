"""Авто-источники (гибкие настройки), копилка, модерация, реакции под постами."""
import asyncio
import json
import time
from html import escape
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import ui
from autopost import store, sources, engine, publisher, timeparse, media_dl
from autopost import rules as R, captions
from handlers.ap_common import AP, show, kb_rows, cancel_kb, is_owner, MAX_RULES

router = Router()
INTERVALS = [15, 30, 60, 120, 180, 360, 720, 1440]
PER_RUN = [1, 2, 3, 5]
ORDERS = {"new": "сначала новые", "random": "случайно", "old": "по порядку (старые первыми)"}
TAGS = {"none": "нет", "meta": "из метаданных", "ai": "популярные (ИИ)"}
MAXLEN = [0, 300, 600, 1000]
DAYS = "пн вт ср чт пт сб вс".split()
LINK_STYLES = {"text": "словом в тексте", "button": "кнопкой", "none": "не показывать"}

SOURCE_HINTS = {
    "yamusic": "что берём?\n• <code>лайки</code> — твои «мне нравится»\n• <code>чарт</code>\n"
               "• ссылка на плейлист / альбом / артиста с music.yandex.ru",
    "music": "ссылка на SoundCloud-артиста, плейлист YouTube и т.п.\n"
             "<code>https://soundcloud.com/artist</code>",
    "video": "ссылка на канал или плейлист\n<code>@MrBeast</code> · <code>youtube.com/@x/shorts</code> · "
             "<code>rutube.ru/channel/123</code>",
    "pinterest": "три способа — и искать самому не нужно:\n"
                 "🔎 <b>слова для поиска</b>: <code>парные аватарки аниме</code> · <code>поиск: aesthetic</code>\n"
                 "🧲 <b>ссылка на один пин</b> — возьму похожие на него и дальше по цепочке\n"
                 "📋 ссылка на доску или профиль: <code>https://pinterest.com/user/board</code>",
    "tg": "публичный канал\n<code>@durov</code>",
    "reddit": "сабреддит\n<code>r/aww</code>",
    "vk": "открытый паблик ВКонтакте\n<code>vk.com/mudakoff</code> · <code>club12345</code>",
    "rss": "ссылка на RSS-ленту\n<code>https://habr.com/ru/rss/all/</code>",
    "pool": "придумай название копилки\n<code>треки на осень</code>",
    "ai": "опиши рубрику, ИИ будет писать по ней посты\n"
          "<code>интересный факт о космосе</code> · <code>цитата дня с пояснением</code>",
    "youtube": "ссылка на канал или @handle",
}
TYPE_DEFAULTS = {
    "yamusic": dict(cfg={"order": "random", "tags": "ai"}, moderation=0),
    "music": dict(cfg={"order": "random", "tags": "ai"}, moderation=0),
    "video": dict(cfg={"order": "new"}, moderation=1),
    "pinterest": dict(cfg={"order": "random", "caption": "vibe", "tags": "ai"}, moderation=0),
    "pool": dict(cfg={"order": "old", "loop": True}, moderation=0),
    "ai": dict(cfg={}, moderation=1),
}
TPL_HELP = ("<b>📝 шаблон поста</b>\n"
            "пиши как обычный пост, жирный/курсив/ссылки работают. подстановки:\n"
            "<code>{title}</code> заголовок · <code>{text}</code> текст · <code>{link}</code> ссылка\n"
            "<code>{src}</code> ссылка «источник» · <code>{tags}</code> хэштеги · <code>{source}</code> источник\n"
            "<code>{artist}</code> · <code>{track}</code> · <code>{album}</code> · <code>{genre}</code>\n"
            "<code>{caption}</code> — живая подпись от ИИ (если включена)\n\n"
            "пример:\n<code>🎧 {artist} — {track}\n\n{tags}</code>\n\n«-» — вернуть по умолчанию")


def _every(m: int) -> str:
    return f"{m} мин" if m < 60 else f"{m // 60} ч"


# ================= список =================
@router.callback_query(F.data == "ap:rules")
async def cb_rules(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    rs = await store.rules(cb.from_user.id)
    text = (f"<b>🤖 автоисточники</b>\n{ui.LINE}\n"
            "сама беру контент и выкладываю по расписанию: музыка, видео, картинки, новости, "
            "твоя копилка или посты от ИИ.\n")
    if not rs:
        text += "\n<i>пока ни одного — жми «➕ Добавить»</i>"
    rows = []
    for r in sorted(rs, key=lambda x: (x["ch_title"] or "", x["id"])):
        icon = sources.TYPES.get(r["type"], ("•",))[0]
        st = "🟢" if r["active"] else "⏸"
        warn = " ⚠️" if r["last_error"] else ""
        rows.append([(f"{st} {icon} {r['title'][:18]} → {(r['ch_title'] or '?')[:12]}{warn}", f"ap:r:{r['id']}")])
    await show(cb, text, kb_rows(*rows, [("➕ Добавить источник", "ap:radd")], [("‹ Назад", "ap:home")]))


# ================= добавление =================
@router.callback_query(F.data == "ap:radd")
@router.callback_query(F.data.startswith("ap:radd:"))
async def cb_radd(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    pre = ""
    if cb.data.startswith("ap:radd:"):
        cid = int(cb.data.split(":")[2])
        if await store.channel(cid, cb.from_user.id):
            pre = f":{cid}"
    n_rules = len(await store.rules(cb.from_user.id))
    if n_rules >= MAX_RULES and not is_owner(cb.from_user.id):
        return await cb.answer(f"максимум {MAX_RULES} источников", show_alert=True)
    import premium
    if not premium.can_have(cb.from_user.id, "ap_rules", n_rules):
        await cb.answer()
        return await premium.upsell(cb.message, cb.from_user.id, "ap_rules")
    if not await store.channels(cb.from_user.id):
        return await cb.answer("сначала подключи канал: 📢 Каналы", show_alert=True)
    lines = [f"<b>➕ откуда берём контент?</b>", ui.LINE]
    for k in sources.NEW_TYPES:
        i, n = sources.TYPES[k]
        lines.append(f"{i} <b>{n}</b> — {sources.TYPE_INFO[k]}")
    btns = [(f"{sources.TYPES[k][0]} {sources.TYPES[k][1]}", f"ap:rt:{k}{pre}") for k in sources.NEW_TYPES]
    rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]
    back = f"ap:ch{pre}" if pre else "ap:rules"
    await show(cb, "\n".join(lines), kb_rows(*rows, [("‹ Назад", back)]))


@router.callback_query(F.data.startswith("ap:rt:"))
async def cb_rtype(cb: CallbackQuery, state: FSMContext):
    parts = cb.data.split(":")
    t = parts[2]
    if t not in sources.TYPES:
        return await cb.answer()
    if len(parts) > 3 and await store.channel(int(parts[3]), cb.from_user.id):
        return await _after_channel(cb, state, t, int(parts[3]))
    chs = await store.channels(cb.from_user.id)
    if len(chs) == 1:
        return await _after_channel(cb, state, t, chs[0]["chat_id"])
    rows = [[(c["title"][:30], f"ap:rc:{t}:{c['chat_id']}")] for c in chs]
    await show(cb, "<b>в какой канал публиковать?</b>", kb_rows(*rows, [("‹ Назад", "ap:radd")]))


@router.callback_query(F.data.startswith("ap:rc:"))
async def cb_rchan(cb: CallbackQuery, state: FSMContext):
    _, _, t, cid = cb.data.split(":")
    cid = int(cid)
    if not await store.channel(cid, cb.from_user.id):
        return await cb.answer("канал не найден", show_alert=True)
    await _after_channel(cb, state, t, cid)


async def _known_token(uid: int) -> str:
    for r in await store.rules(uid):
        if r["type"] == "yamusic":
            tok = store.cfg_of(r).get("token")
            if tok:
                return tok
    return ""


async def _after_channel(cb, state, t, cid):
    await state.update_data(t=t, cid=cid)
    if t == "yamusic":
        tok = await _known_token(cb.from_user.id)
        if not tok:
            await state.set_state(AP.rule_token)
            return await show(cb, "<b>🎵 Яндекс Музыка</b>\nпришли токен аккаунта (начинается с <code>y0_</code>).\n"
                                  "сообщение с токеном я сразу удалю из чата 🤐",
                              cancel_kb("ap:rules"))
        await state.update_data(token=tok)
    await state.set_state(AP.rule_source)
    icon, name = sources.TYPES[t]
    await show(cb, f"<b>{icon} {name}</b>\n{SOURCE_HINTS[t]}", cancel_kb("ap:rules"))


@router.message(AP.rule_token, F.text)
async def st_token(m: Message, state: FSMContext):
    tok = m.text.strip()
    try:
        await m.delete()
    except TelegramBadRequest:
        pass
    if len(tok) < 20:
        return await m.answer("это не похоже на токен 🤔", reply_markup=cancel_kb("ap:rules"))
    d = await state.get_data()
    if d.get("rid"):  # смена токена у существующего источника
        await store.set_cfg(d["rid"], token=tok)
        await state.clear()
        await m.answer("🔑 токен обновлён")
        return await show(m, *await rule_view(d["rid"], m.from_user.id))
    await state.update_data(token=tok)
    await state.set_state(AP.rule_source)
    await m.answer("🔑 токен принят\n\n" + SOURCE_HINTS["yamusic"], reply_markup=cancel_kb("ap:rules"))


@router.message(AP.rule_source, F.text)
async def st_source(m: Message, state: FSMContext):
    d = await state.get_data()
    t = d["t"]
    try:
        src, title = sources.normalize(t, m.text)
    except sources.SourceError as e:
        return await m.answer(f"🤔 {e}", reply_markup=cancel_kb("ap:rules"))
    info, preview_keys = "", []
    if t not in ("pool", "ai"):
        wait = await m.answer("проверяю источник… ⏳")
        try:
            if t == "yamusic":
                ids = await media_dl.ym_ids(src, d.get("token", ""))
                if not ids:
                    raise sources.SourceError("там пусто")
                info = f"нашла треков: <b>{len(ids)}</b>"
            else:
                items = await sources.fetch(t, src, 10)
                if not items:
                    raise sources.SourceError("источник пустой")
                preview_keys = [i["key"] for i in items[1:]]
                first = items[0].get("title") or items[0].get("text") or ""
                info = f"нашла записи. свежая: <i>{escape(first[:90])}</i>"
        except Exception as e:
            await wait.delete()
            return await m.answer(f"⚠️ не получилось: {escape(str(e)[:200])}\nпопробуй другую ссылку",
                                  reply_markup=cancel_kb("ap:rules"))
        await wait.delete()

    rid = await store.add_rule(m.from_user.id, d["cid"], t, src, title)
    dflt = TYPE_DEFAULTS.get(t, {})
    cfg = dict(dflt.get("cfg", {}))
    if t == "yamusic":
        cfg["token"] = d.get("token", "")
    if cfg:
        await store.set_cfg(rid, **cfg)
    if "moderation" in dflt:
        await store.set_rule(rid, moderation=dflt["moderation"])
    # новостные: старое считаем прочитанным, публикуем только свежее
    if t in R.TEXT_TYPES:
        for k in preview_keys:
            await store.mark_seen(rid, k)
    await state.clear()
    if t == "pool":
        await state.set_state(AP.pool_add)
        await state.update_data(rid=rid)
        return await m.answer(f"📦 копилка <b>{escape(title)}</b> создана.\n\n" + POOL_HINT,
                              reply_markup=_pool_kb(rid))
    await m.answer(f"✅ {info or 'готово'}\nнастрой под себя 👇")
    await show(m, *await rule_view(rid, m.from_user.id))


# ================= карточка =================
async def rule_view(rid: int, uid: int):
    r = await store.rule(rid, uid)
    c = store.cfg_of(r)
    t = r["type"]
    icon, tname = sources.TYPES.get(t, ("•", t))
    lines = [ui.head(icon, escape(r["title"]), f"{tname} → {escape(r['ch_title'] or '?')} · "
                     + ("🟢 работает" if r["active"] else "⏸ выключен")),
             f"⏰ <b>{R.sched_label(r, c)}</b>"]
    if r["active"]:
        lines.append(f"   следующий: {timeparse.fmt(r['next_run'])}")
    lines.append(f"📦 за раз: <b>{c['per_run']}</b> · {ORDERS[c['order']]}")
    if t == "pool":
        total, left = await store.pool_counts(rid)
        lines.append(f"🗃 в копилке: <b>{total}</b> · осталось: <b>{left}</b>" + (" · 🔁 по кругу" if c["loop"] else ""))
    if t in R.TEXT_TYPES:
        lines.append(f"🧠 ИИ: <b>{engine.AI_MODES[r['ai_mode']]}</b>")
    if t in R.CAPTION_TYPES:
        lines.append(f"💬 подпись: <b>{captions.CAPTION_STYLES[c['caption']]}</b>")
    tg = TAGS[c["tags"]] + (f" + {escape(c['extra_tags'])}" if c["extra_tags"] else "")
    lines.append(f"#️⃣ теги: <b>{tg}</b>")
    lines.append(f"🛡 модерация: <b>{'сначала мне' if r['moderation'] else 'сразу в канал'}</b>")
    if c["template"]:
        lines.append("📝 свой шаблон")
    lines.append(f"📊 выложено: <b>{r['posted']}</b>")
    if t == "pinterest" and "/" in r["source"]:   # волна 77: что видно в доске (из кэша, без запросов)
        from autopost import sources as _src
        hit = _src._board_cache.get(r["source"])
        if hit:
            its = hit[1]
            lines.append(f"📌 в доске: <b>{len(its)}</b> · видео {sum(1 for i in its if i.get('is_video'))}"
                         f" · каруселей {sum(1 for i in its if len(i.get('images') or []) > 1)}")
    if r["last_error"]:   # волна 69: человеческими словами
        lines.append(f"⚠️ <i>{escape(R.human_error(r['last_error']))}</i>"
                     + (f" · сбоев подряд {c['fails']}/{R.FAIL_PAUSE}" if c.get("fails") else ""))
    i = r["id"]
    rows = [
        [("⏸ Выключить" if r["active"] else "▶️ Включить", f"ap:ra:{i}"), ("⚡ Выложить сейчас", f"ap:rrun:{i}")],
        [("⏰ Расписание", f"ap:rs:{i}"), ("🎛 Контент", f"ap:rk:{i}")],
        [("🎨 Оформление", f"ap:ro:{i}"),
         ("🛡 Сначала мне ✅" if r["moderation"] else "🛡 Сначала мне ⬜", f"ap:rmod:{i}")],
    ]
    if t == "pool":
        rows.append([("➕ Пополнить", f"ap:padd:{i}"), ("🗑 Очистить", f"ap:pclr:{i}")])
    if t == "yamusic":
        rows.append([("🔑 Сменить токен", f"ap:rtok:{i}")])
    rows.append([("♻️ Обнулить историю", f"ap:rrst:{i}"), ("👁 Пример", f"ap:oex:{i}")])
    rows.append([("📋 Копия в канал", f"ap:rcp:{i}"), ("🔀 Перенести", f"ap:rmv:{i}")])
    rows.append([("🗑 Удалить", f"ap:rdel:{i}"), ("❔ Помощь", f"ap:rhelp:card:{i}")])
    rows.append([("‹ К каналу", f"ap:ch:{r['chat_id']}")])
    return "\n".join(lines), kb_rows(*rows)


async def _rid(cb: CallbackQuery) -> int | None:
    rid = int(cb.data.rsplit(":", 1)[1])
    if not await store.rule(rid, cb.from_user.id):
        await cb.answer("источник не найден", show_alert=True)
        return None
    return rid


@router.callback_query(F.data.startswith("ap:r:"))
async def cb_rule(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if rid := await _rid(cb):
        await show(cb, *await rule_view(rid, cb.from_user.id))


async def _reschedule(rid: int):
    r = await store.rule(rid)
    ch = await store.channel(r["chat_id"])
    await store.set_rule(rid, next_run=R.next_run(r, store.cfg_of(r), ch))


@router.callback_query(F.data.startswith("ap:ra:"))
async def cb_ractive(cb: CallbackQuery):
    if rid := await _rid(cb):
        r = await store.rule(rid)
        await store.set_rule(rid, active=0 if r["active"] else 1)
        await _reschedule(rid)
        await show(cb, *await rule_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rmod:"))
async def cb_rmod(cb: CallbackQuery):
    if rid := await _rid(cb):
        r = await store.rule(rid)
        await store.set_rule(rid, moderation=0 if r["moderation"] else 1)
        await show(cb, *await rule_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rrun:"))
async def cb_rrun(cb: CallbackQuery, bot: Bot):
    if rid := await _rid(cb):
        await cb.answer("работаю… ⏳")
        r = await store.rule(rid)
        res = await engine.run_rule(bot, r, manual=True)
        if res.startswith("публикую"):
            await engine.publish_due(bot)
        await cb.message.answer(f"⚡ {escape(res)}")
        await show(cb.message, *await rule_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rtok:"))
async def cb_rtok(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_token)
        await state.update_data(rid=rid)
        await show(cb, "пришли новый токен <code>y0_…</code>", cancel_kb(f"ap:r:{rid}"))


@router.callback_query(F.data.startswith("ap:rrst:"))
async def cb_rrst(cb: CallbackQuery):
    if rid := await _rid(cb):
        await show(cb, "<b>♻️ обнулить историю источника?</b>\n\n"
                       "забуду, что уже брала отсюда — смогу снова выложить те же записи. "
                       "копилка начнётся сначала.",
                   kb_rows([("♻️ Да", f"ap:rrstok:{rid}"), ("‹ Нет", f"ap:r:{rid}")]))


@router.callback_query(F.data.startswith("ap:rrstok:"))
async def cb_rrstok(cb: CallbackQuery):
    if rid := await _rid(cb):
        await store.reset_rule_history(rid)
        await cb.answer("♻️ история обнулена", show_alert=True)
        await show(cb, *await rule_view(rid, cb.from_user.id))


async def _pick_channel(cb: CallbackQuery, rid: int, act: str, title: str):
    r = await store.rule(rid)
    chs = [c for c in await store.channels(cb.from_user.id) if act == "cp" or c["chat_id"] != r["chat_id"]]
    if not chs:
        return await cb.answer("нет другого канала — подключи ещё один", show_alert=True)
    rows = [[(c["title"][:30], f"ap:r{act}to:{c['chat_id']}:{rid}")] for c in chs]
    await show(cb, title, kb_rows(*rows, [("‹ Назад", f"ap:r:{rid}")]))


@router.callback_query(F.data.startswith("ap:rcp:"))
async def cb_rcp(cb: CallbackQuery):
    if rid := await _rid(cb):
        await _pick_channel(cb, rid, "cp", "<b>📋 копия источника</b>\nв какой канал? настройки скопирую все")


@router.callback_query(F.data.startswith("ap:rmv:"))
async def cb_rmv(cb: CallbackQuery):
    if rid := await _rid(cb):
        await _pick_channel(cb, rid, "mv", "<b>🔀 перенести источник</b>\nв какой канал?")


@router.callback_query(F.data.startswith("ap:rcpto:") | F.data.startswith("ap:rmvto:"))
async def cb_rto(cb: CallbackQuery):
    rid = await _rid(cb)
    if not rid:
        return
    cid = int(cb.data.split(":")[2])
    if not await store.channel(cid, cb.from_user.id):
        return await cb.answer("канал не найден", show_alert=True)
    if cb.data.startswith("ap:rcpto:"):
        if len(await store.rules(cb.from_user.id)) >= MAX_RULES and not is_owner(cb.from_user.id):
            return await cb.answer(f"максимум {MAX_RULES} источников", show_alert=True)
        new = await store.copy_rule(rid, cid)
        await cb.answer("📋 копия создана")
        await _reschedule(new)
        return await show(cb, *await rule_view(new, cb.from_user.id))
    await store.set_rule(rid, chat_id=cid)
    await _reschedule(rid)
    await cb.answer("🔀 перенесено")
    await show(cb, *await rule_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rdel:"))
async def cb_rdel(cb: CallbackQuery):
    if rid := await _rid(cb):
        await show(cb, "<b>удалить источник?</b>",
                   kb_rows([("🗑 Да", f"ap:rdelok:{rid}"), ("‹ Нет", f"ap:r:{rid}")]))


@router.callback_query(F.data.startswith("ap:rdelok:"))
async def cb_rdelok(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        chat_id = (await store.rule(rid))["chat_id"]
        await store.del_rule(rid)
        from handlers.ap_panel import hub_view
        if await store.channel(chat_id, cb.from_user.id):
            return await show(cb, *await hub_view(chat_id, cb.from_user.id))
        await cb_rules(cb, state)


# ================= ⏰ расписание =================
async def sched_view(rid: int, uid: int):
    r = await store.rule(rid, uid)
    c = store.cfg_of(r)
    mode = c["sched"]
    names = {"interval": "интервал", "times": "своё время", "slots": "слоты канала"}
    text = (f"<b>⏰ расписание</b> · {escape(r['title'])}\n{ui.LINE}\n"
            f"сейчас: <b>{R.sched_label(r, c)}</b>\n"
            f"следующий запуск: {timeparse.fmt(r['next_run']) if r['active'] else '—'}\n\n"
            "<i>режимы: интервал — каждые N; своё время — в заданные часы; "
            "слоты — те же, что у канала</i>")
    rows = [[(f"🔄 Режим: {names[mode]}", f"ap:rsm:{rid}")]]
    if mode == "interval":
        rows.append([(f"⏱ {_every(r['every_min'])}", f"ap:rint:{rid}"), ("✏️ Свой интервал", f"ap:rinx:{rid}")])
    elif mode == "times":
        rows.append([(f"🕐 Время: {' '.join(c['times'])}", f"ap:rtm:{rid}")])
    days = c["days"]
    rows.append([(("✓" if d in days else "·") + DAYS[d], f"ap:rday:{d}:{rid}") for d in range(7)])
    hrs = f"{c['hours'][0]:02d}–{c['hours'][1]:02d}" if c["hours"] else "весь день"
    rows.append([(f"🌗 Часы: {hrs}", f"ap:rhr:{rid}")])
    rows.append([("‹ Назад", f"ap:r:{rid}")])
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("ap:rs:"))
async def cb_rs(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if rid := await _rid(cb):
        await show(cb, *await sched_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rsm:"))
async def cb_rsm(cb: CallbackQuery):
    if rid := await _rid(cb):
        c = store.cfg_of(await store.rule(rid))
        modes = ["interval", "times", "slots"]
        await store.set_cfg(rid, sched=modes[(modes.index(c["sched"]) + 1) % 3])
        await _reschedule(rid)
        await show(cb, *await sched_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rint:"))
async def cb_rint(cb: CallbackQuery):
    if rid := await _rid(cb):
        r = await store.rule(rid)
        cur = INTERVALS.index(r["every_min"]) if r["every_min"] in INTERVALS else -1
        await store.set_rule(rid, every_min=INTERVALS[(cur + 1) % len(INTERVALS)])
        await _reschedule(rid)
        await show(cb, *await sched_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rinx:"))
async def cb_rinx(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_interval)
        await state.update_data(rid=rid)
        await show(cb, "пришли интервал: <code>45м</code> · <code>4ч</code> · <code>2д</code>",
                   cancel_kb(f"ap:rs:{rid}"))


@router.message(AP.rule_interval, F.text)
async def st_rinx(m: Message, state: FSMContext):
    import re
    mm = re.fullmatch(r"\s*(\d+)\s*(м|мин|ч|час|д|дн)?\w*\s*", m.text.lower())
    if not mm:
        return await m.answer("не поняла. пример: <code>90м</code> или <code>4ч</code>")
    n, u = int(mm.group(1)), (mm.group(2) or "м")
    mins = n * (1440 if u.startswith("д") else 60 if u.startswith("ч") else 1)
    if not 10 <= mins <= 10080:
        return await m.answer("от 10 минут до 7 дней")
    rid = (await state.get_data())["rid"]
    await store.set_rule(rid, every_min=mins)
    await _reschedule(rid)
    await state.clear()
    await show(m, *await sched_view(rid, m.from_user.id))


@router.callback_query(F.data.startswith("ap:rtm:"))
async def cb_rtm(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_times)
        await state.update_data(rid=rid)
        await show(cb, "пришли время через пробел:\n<code>9:00 13:00 18:30 22:00</code>",
                   cancel_kb(f"ap:rs:{rid}"))


@router.message(AP.rule_times, F.text)
async def st_rtm(m: Message, state: FSMContext):
    times = timeparse.parse_slots(m.text)
    if not times or len(times) > 24:
        return await m.answer("не поняла. пример: <code>10:00 18:00</code>")
    rid = (await state.get_data())["rid"]
    await store.set_cfg(rid, times=times)
    await _reschedule(rid)
    await state.clear()
    await show(m, *await sched_view(rid, m.from_user.id))


@router.callback_query(F.data.startswith("ap:rday:"))
async def cb_rday(cb: CallbackQuery):
    if rid := await _rid(cb):
        d = int(cb.data.split(":")[2])
        days = list(store.cfg_of(await store.rule(rid))["days"])
        days = [x for x in days if x != d] if d in days else sorted(days + [d])
        if not days:
            return await cb.answer("хотя бы один день", show_alert=True)
        await store.set_cfg(rid, days=days)
        await _reschedule(rid)
        await show(cb, *await sched_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:rhr:"))
async def cb_rhr(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_hours)
        await state.update_data(rid=rid)
        await show(cb, "<b>🌗 часы работы</b>\nв какое время суток выкладывать:\n"
                       "<code>10-22</code> · <code>22-2</code> (через полночь)\n«-» — весь день",
                   cancel_kb(f"ap:rs:{rid}"))


@router.message(AP.rule_hours, F.text)
async def st_rhr(m: Message, state: FSMContext):
    import re
    rid = (await state.get_data())["rid"]
    if m.text.strip() == "-":
        hrs = None
    else:
        mm = re.fullmatch(r"\s*(\d{1,2})\s*[-–—]\s*(\d{1,2})\s*", m.text)
        if not mm or int(mm.group(1)) > 23 or int(mm.group(2)) > 24 or mm.group(1) == mm.group(2):
            return await m.answer("пример: <code>10-22</code>")
        hrs = [int(mm.group(1)), int(mm.group(2)) % 24]
    await store.set_cfg(rid, hours=hrs)
    await _reschedule(rid)
    await state.clear()
    await show(m, *await sched_view(rid, m.from_user.id))


# ================= 🎛 контент =================
async def content_view(rid: int, uid: int):
    r = await store.rule(rid, uid)
    c = store.cfg_of(r)
    t = r["type"]
    inc = ", ".join(f"+{w}" for w in r["include"].split(",") if w)
    exc = ", ".join(f"−{w}" for w in r["exclude"].split(",") if w)
    text = (ui.head("🎛", "Контент", f"{escape(r['title'])} · что и сколько брать") + "\n"
            f"🔎 фильтр: <b>{escape(' '.join(x for x in (inc, exc) if x)) or '—'}</b>")
    rows = [[(f"📦 За раз: {c['per_run']} ›", f"ap:kpr:{rid}"), (f"🔀 {ORDERS[c['order']].split(' (')[0]} ›", f"ap:kor:{rid}")]]
    if t in R.TEXT_TYPES or t == "pinterest":
        mk = c["media_kind"] if r["with_media"] else "none"
        rows.append([(f"🎞 Медиа: {R.MEDIA_KINDS[mk]} ›", f"ap:kmed:{rid}")])
    if t in R.TEXT_TYPES:
        rows.append([(f"📎 Только с картинкой {'✅' if c['only_media'] else '⬜'}", f"ap:kom:{rid}")])
        rows.append([(f"🧠 ИИ: {engine.AI_MODES[r['ai_mode']]} ›", f"ap:kai:{rid}")])
        ml = c["max_len"]
        rows.append([(f"✂️ Длина текста: {ml or 'полностью'} ›", f"ap:kml:{rid}")])
    if t in R.MEDIA_TYPES:
        rows.append([(f"🎬 Формат: {'ссылкой' if c['as_media'] == 'link' else 'файлом'} ›", f"ap:kam:{rid}")])
    if t in R.LOOP_TYPES:
        rows.append([(f"🔁 Всё выложено — по кругу {'✅' if c['loop'] else '⬜'}", f"ap:klp:{rid}")])
    if t not in ("pool", "ai"):
        rows.append([("🔎 Фильтр по словам", f"ap:rflt:{rid}")])
    rows.append([("‹ Назад", f"ap:r:{rid}"), ("❔ Помощь", f"ap:rhelp:content:{rid}")])
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("ap:rk:"))
async def cb_rk(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if rid := await _rid(cb):
        await show(cb, *await content_view(rid, cb.from_user.id))


def _next(seq, cur):
    return seq[(seq.index(cur) + 1) % len(seq)] if cur in seq else seq[0]


async def _cfg_cycle(cb, key, seq, view):
    """Переключатели да/нет — сразу. Всё остальное — через _picker (список с ✓)."""
    if rid := await _rid(cb):
        c = store.cfg_of(await store.rule(rid))
        await store.set_cfg(rid, **{key: _next(seq, c[key])})
        await show(cb, *await view(rid, cb.from_user.id))


# ================= выбор из списка: видно все варианты и текущий =================
def _media_get(r, c):
    return c["media_kind"] if r["with_media"] else "none"


async def _media_set(rid, v):
    await store.set_rule(rid, with_media=0 if v == "none" else 1)
    await store.set_cfg(rid, media_kind=v)


async def _ai_set(rid, v):
    await store.set_rule(rid, ai_mode=v)


# key: (заголовок, пояснение, варианты [(значение, подпись)], откуда читать, куда писать, экран «назад»)
PICKERS = {
    "per_run": ("📦 сколько постов за раз", "столько записей выложу за один запуск по расписанию",
                [(n, f"{n} пост" + ("а" if 1 < n < 5 else "ов" if n >= 5 else "")) for n in PER_RUN], None, None, "rk"),
    "order": ("🔀 порядок", "какие записи брать первыми", list(ORDERS.items()), None, None, "rk"),
    "media_kind": ("🎞 медиа", "что подходит каналу. лишнее пропущу и возьму следующую запись",
                   list(R.MEDIA_KINDS.items()), _media_get, _media_set, "rk"),
    "max_len": ("✂️ длина текста", "длинный текст обрежу аккуратно, по слову",
                [(n, f"до {n} символов" if n else "полностью") for n in MAXLEN], None, None, "rk"),
    "as_media": ("🎬 формат", "видео и аудио: прислать файлом или просто ссылкой",
                 [("auto", "файлом"), ("link", "ссылкой")], None, None, "rk"),
    "ai_mode": ("🧠 ИИ-обработка текста", "что ИИ делает с текстом записи перед публикацией",
                list(R.AI_MODES.items()), lambda r, c: r["ai_mode"], _ai_set, "rk"),
    "caption": ("💬 подпись", "живую подпись пишет ИИ — видит картинку и пишет как человек",
                list(captions.CAPTION_STYLES.items()), None, None, "ro"),
    "tags": ("#️⃣ хэштеги", "какие теги ставить под постом", list(TAGS.items()), None, None, "ro"),
    "reacts": ("❤️ кнопки-реакции", "кнопки под постом, подписчики жмут — счётчик растёт",
               [(i, " ".join(rs) or "без реакций") for i, rs in enumerate(publisher.REACTION_SETS)], None, None, "ro"),
    "link_style": ("🔗 ссылка на источник", "как показать, откуда пост", list(LINK_STYLES.items()), None, None, "ro"),
}
PICK_KEYS = list(PICKERS)


async def picker_view(rid: int, uid: int, key: str):
    title, hint, opts, get, _set, back = PICKERS[key]
    r = await store.rule(rid, uid)
    c = store.cfg_of(r)
    cur = get(r, c) if get else c.get(key)
    rows = [[(("✓ " if v == cur else "") + label, f"ap:ps:{PICK_KEYS.index(key)}:{n}:{rid}")]
            for n, (v, label) in enumerate(opts)]
    rows.append([("‹ Назад", f"ap:{back}:{rid}")])
    return f"<b>{title}</b> · {escape(r['title'])}\n{ui.LINE}\n<i>{hint}</i>\n\nвыбери 👇", kb_rows(*rows)


async def _picker(cb: CallbackQuery, key: str):
    if rid := await _rid(cb):
        await show(cb, *await picker_view(rid, cb.from_user.id, key))


@router.callback_query(F.data.startswith("ap:ps:"))
async def cb_pick_set(cb: CallbackQuery):
    _, _, ki, n, _rid_ = cb.data.split(":")
    rid = await _rid(cb)
    if not rid or not ki.isdigit() or int(ki) >= len(PICK_KEYS):
        return
    key = PICK_KEYS[int(ki)]
    title, _h, opts, _g, setter, back = PICKERS[key]
    if not n.isdigit() or int(n) >= len(opts):
        return await cb.answer()
    v, label = opts[int(n)]
    await (setter(rid, v) if setter else store.set_cfg(rid, **{key: v}))
    await cb.answer(f"✓ {label}")
    view = content_view if back == "rk" else look_view
    await show(cb, *await view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:kpr:"))
async def cb_kpr(cb: CallbackQuery):
    await _picker(cb, "per_run")


@router.callback_query(F.data.startswith("ap:kor:"))
async def cb_kor(cb: CallbackQuery):
    await _picker(cb, "order")


@router.callback_query(F.data.startswith("ap:kom:"))
async def cb_kom(cb: CallbackQuery):
    await _cfg_cycle(cb, "only_media", [False, True], content_view)


@router.callback_query(F.data.startswith("ap:kml:"))
async def cb_kml(cb: CallbackQuery):
    await _picker(cb, "max_len")


@router.callback_query(F.data.startswith("ap:kam:"))
async def cb_kam(cb: CallbackQuery):
    await _picker(cb, "as_media")


@router.callback_query(F.data.startswith("ap:klp:"))
async def cb_klp(cb: CallbackQuery):
    await _cfg_cycle(cb, "loop", [True, False], content_view)


@router.callback_query(F.data.startswith("ap:kmed:"))
async def cb_kmed(cb: CallbackQuery):
    await _picker(cb, "media_kind")


@router.callback_query(F.data.startswith("ap:kai:"))
async def cb_kai(cb: CallbackQuery):
    await _picker(cb, "ai_mode")


@router.callback_query(F.data.startswith("ap:rflt:"))
async def cb_rflt(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_filter)
        await state.update_data(rid=rid)
        await show(cb, "<b>🔎 фильтр по словам</b>\n"
                       "слова через запятую. с минусом — исключить:\n"
                       "<code>игры, аниме, -реклама, -розыгрыш</code>\n\n«-» — сбросить фильтр",
                   cancel_kb(f"ap:rk:{rid}"))


@router.message(AP.rule_filter, F.text)
async def st_rflt(m: Message, state: FSMContext):
    rid = (await state.get_data())["rid"]
    inc, exc = [], []
    if m.text.strip() != "-":
        for w in m.text.split(","):
            w = w.strip()
            if w.startswith(("-", "−")):
                if w[1:].strip():
                    exc.append(w[1:].strip())
            elif w:
                inc.append(w.lstrip("+").strip())
    await store.set_rule(rid, include=",".join(inc)[:500], exclude=",".join(exc)[:500])
    await state.clear()
    await show(m, *await content_view(rid, m.from_user.id))


# ================= 🎨 оформление =================
async def look_view(rid: int, uid: int):
    r = await store.rule(rid, uid)
    c = store.cfg_of(r)
    reacts = publisher.REACTION_SETS[c["reacts"] % len(publisher.REACTION_SETS)]
    tpl = escape(c["template"][:200]) if c["template"] else "<i>по умолчанию</i>"
    text = (ui.head("🎨", "Оформление", f"{escape(r['title'])} · как выглядит пост") + "\n"
            f"📝 шаблон: {tpl}\n"
            f"✍️ подпись: <b>{escape(r['footer']) or '—'}</b>")
    rows = []
    if r["type"] in R.CAPTION_TYPES:
        rows.append([(f"💬 Подпись ИИ: {captions.CAPTION_STYLES[c['caption']]} ›", f"ap:ocp:{rid}")])
    rows += [
        [(f"#️⃣ Теги: {TAGS[c['tags']]} ›", f"ap:otg:{rid}"), ("➕ Свои теги", f"ap:oxt:{rid}")],
        [("📝 Шаблон", f"ap:otp:{rid}"), ("✍️ Подпись внизу", f"ap:rfoot:{rid}")],
        [(f"❤️ Реакции: {' '.join(reacts) or 'нет'} ›", f"ap:orc:{rid}")],
        [(f"🔗 Источник: {LINK_STYLES[c['link_style']]} ›", f"ap:olb:{rid}")],
        [(f"🔕 Без звука {'✅' if c['silent'] else '⬜'}", f"ap:osl:{rid}")],
        [("👁 Пример поста", f"ap:oex:{rid}")],
        [("‹ Назад", f"ap:r:{rid}"), ("❔ Помощь", f"ap:rhelp:look:{rid}")],
    ]
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("ap:ro:"))
async def cb_ro(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if rid := await _rid(cb):
        await show(cb, *await look_view(rid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:otg:"))
async def cb_otg(cb: CallbackQuery):
    await _picker(cb, "tags")


@router.callback_query(F.data.startswith("ap:ocp:"))
async def cb_ocp(cb: CallbackQuery):
    await _picker(cb, "caption")


@router.callback_query(F.data.startswith("ap:orc:"))
async def cb_orc(cb: CallbackQuery):
    await _picker(cb, "reacts")


@router.callback_query(F.data.startswith("ap:olb:"))
async def cb_olb(cb: CallbackQuery):
    await _picker(cb, "link_style")


@router.callback_query(F.data.startswith("ap:osl:"))
async def cb_osl(cb: CallbackQuery):
    await _cfg_cycle(cb, "silent", [False, True], look_view)


@router.callback_query(F.data.startswith("ap:oxt:"))
async def cb_oxt(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_tags)
        await state.update_data(rid=rid)
        await show(cb, "<b>➕ свои теги</b>\nдобавлю к каждому посту:\n<code>#newmusic #rap</code>\n\n«-» — убрать",
                   cancel_kb(f"ap:ro:{rid}"))


@router.message(AP.rule_tags, F.text)
async def st_oxt(m: Message, state: FSMContext):
    rid = (await state.get_data())["rid"]
    await store.set_cfg(rid, extra_tags="" if m.text.strip() == "-" else m.text.strip()[:200])
    await state.clear()
    await show(m, *await look_view(rid, m.from_user.id))


@router.callback_query(F.data.startswith("ap:otp:"))
async def cb_otp(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_template)
        await state.update_data(rid=rid)
        await show(cb, TPL_HELP, cancel_kb(f"ap:ro:{rid}"))


@router.message(AP.rule_template, F.text)
async def st_otp(m: Message, state: FSMContext):
    rid = (await state.get_data())["rid"]
    await store.set_cfg(rid, template="" if m.text.strip() == "-" else m.html_text[:1500])
    await state.clear()
    await show(m, *await look_view(rid, m.from_user.id))


@router.callback_query(F.data.startswith("ap:rfoot:"))
async def cb_rfoot(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.rule_footer)
        await state.update_data(rid=rid)
        await show(cb, "<b>✍️ подпись для постов из этого источника</b>\n"
                       "например: <code>🎧 больше музыки — @mychannel</code>\n\n«-» — убрать",
                   cancel_kb(f"ap:ro:{rid}"))


@router.message(AP.rule_footer, F.text)
async def st_rfoot(m: Message, state: FSMContext):
    rid = (await state.get_data())["rid"]
    await store.set_rule(rid, footer="" if m.text.strip() == "-" else m.text.strip()[:200])
    await state.clear()
    await show(m, *await look_view(rid, m.from_user.id))


SAMPLE = {"key": "sample", "title": "Название записи", "text": "Здесь будет текст записи из источника…",
          "link": "https://example.com", "artist": "Artist Name", "album": "Album", "genre": "rap",
          "image": None}


@router.callback_query(F.data.startswith("ap:oex:"))
async def cb_oex(cb: CallbackQuery, bot: Bot):
    if rid := await _rid(cb):
        r = await store.rule(rid)
        c = store.cfg_of(r)
        rr = {**r, "ai_mode": "none", "id": None}
        await cb.answer("собираю пример…")
        text, buttons = await R.build(rr, c, dict(SAMPLE), [{"type": "photo"}] if r["type"] == "video" else [])
        reacts = publisher.REACTION_SETS[c["reacts"] % len(publisher.REACTION_SETS)]
        post = {"text": text or "<i>(без подписи — только медиа)</i>", "media": [], "buttons": buttons,
                "reactions": reacts, "opts": {}}
        await cb.message.answer("👁 <b>пример оформления</b> <i>(данные выдуманные)</i>")
        await publisher.send(bot, post, cb.from_user.id, await store.channel(r["chat_id"]), preview=True)
        await show(cb.message, *await look_view(rid, cb.from_user.id))


# ================= 📦 копилка =================
POOL_HINT = ("присылай сюда что угодно: треки, фото, видео, альбомы, текст или пересылай посты из других каналов. "
             "каждое сообщение = один будущий пост.\nкогда закончишь — «✓ Готово»")


def _pool_kb(rid):
    return kb_rows([("✓ Готово", f"ap:r:{rid}")])


@router.callback_query(F.data.startswith("ap:padd:"))
async def cb_padd(cb: CallbackQuery, state: FSMContext):
    if rid := await _rid(cb):
        await state.set_state(AP.pool_add)
        await state.update_data(rid=rid)
        await show(cb, "<b>📦 пополняем копилку</b>\n" + POOL_HINT, _pool_kb(rid))


_pool_groups: dict[str, int] = {}
_pool_lock = asyncio.Lock()


@router.message(AP.pool_add)
async def st_pool(m: Message, state: FSMContext):
    from handlers.ap_editor import extract_media
    rid = (await state.get_data())["rid"]
    r = await store.rule(rid, m.from_user.id)
    if not r:
        return await state.clear()
    media = extract_media(m)
    text = m.html_text if (m.text or m.caption) else ""
    if not media and not text:
        return await m.answer("это не сохранить 🤷", reply_markup=_pool_kb(rid))
    gid = m.media_group_id
    async with _pool_lock:
        if gid and gid in _pool_groups:  # часть альбома — добавляем в тот же пост
            pid = _pool_groups[gid]
            p = await store.post(pid)
            p["media"].append(media)
            await store.set_post(pid, media=p["media"][:10],
                                 **({"text": text} if text and not p["text"] else {}))
            return
        pid = await store.new_post(m.from_user.id, text, [media] if media else [], [r["chat_id"]])
        await store.set_post(pid, status="pool")
        await store.pool_add(rid, pid)
        if gid:
            _pool_groups[gid] = pid
    if gid:
        await asyncio.sleep(1.5)
        _pool_groups.pop(gid, None)
        p = await store.post(pid)
        if not publisher.album_ok(p["media"]):
            await store.set_post(pid, media=p["media"][:1])
    total, left = await store.pool_counts(rid)
    await m.answer(f"📦 +1 · в копилке {total}, ждут публикации {left}", reply_markup=_pool_kb(rid))


@router.callback_query(F.data.startswith("ap:pclr:"))
async def cb_pclr(cb: CallbackQuery):
    if rid := await _rid(cb):
        await show(cb, "<b>очистить копилку?</b>",
                   kb_rows([("🗑 Да", f"ap:pclrok:{rid}"), ("‹ Нет", f"ap:r:{rid}")]))


@router.callback_query(F.data.startswith("ap:pclrok:"))
async def cb_pclrok(cb: CallbackQuery):
    if rid := await _rid(cb):
        await store.pool_clear(rid)
        await show(cb, *await rule_view(rid, cb.from_user.id))


# ================= модерация =================
@router.callback_query(F.data == "ap:inbox")
async def cb_inbox(cb: CallbackQuery, bot: Bot):
    items = await store.inbox_pending(cb.from_user.id, 5)
    if not items:
        return await cb.answer("на модерации пусто ✨", show_alert=True)
    await cb.answer()
    for it in items:
        p = await store.post(it["post_id"])
        try:
            await publisher.send(bot, p, cb.from_user.id, preview=True)
            await R.persist_media(p)
        except Exception as e:
            await cb.message.answer(f"⚠️ не показать: {escape(str(e)[:100])}")
        await cb.message.answer("что делаем?", reply_markup=engine.inbox_kb(it["id"]))


async def _inbox(cb: CallbackQuery) -> dict | None:
    iid = int(cb.data.rsplit(":", 1)[1])
    it = await store.inbox_item(iid, cb.from_user.id)
    if not it or it["status"] != "pending":
        await cb.answer("уже обработано", show_alert=True)
        return None
    return it


async def _close(cb: CallbackQuery, text: str):
    try:
        await cb.message.edit_text(text)
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("ib:go:"))
async def cb_ib_go(cb: CallbackQuery, bot: Bot):
    if it := await _inbox(cb):
        await store.set_inbox(it["id"], "approved")
        await store.set_post(it["post_id"], status="queued")
        sid = await store.schedule(it["post_id"], it["chat_id"], time.time() - 1)
        await engine.publish_due(bot)
        s = await store.sched(sid)
        ok = s["status"] in ("sent", "deleted")
        await _close(cb, "✅ опубликовано" if ok else f"⚠️ {escape(s['err'] or 'в очереди')}")
        await cb.answer()


@router.callback_query(F.data.startswith("ib:q:"))
async def cb_ib_q(cb: CallbackQuery):
    if it := await _inbox(cb):
        ch = await store.channel(it["chat_id"])
        if not ch:
            return await cb.answer("канал отключён", show_alert=True)
        busy = await store.busy_times(ch["chat_id"], int(time.time()))
        ts = timeparse.next_slot(json.loads(ch["slots"] or "[]"), busy, ch["jitter"])
        await store.schedule(it["post_id"], ch["chat_id"], ts)
        await store.set_inbox(it["id"], "approved")
        await store.set_post(it["post_id"], status="queued")
        await _close(cb, f"📥 в очереди на {timeparse.fmt(ts)}")
        await cb.answer()


@router.callback_query(F.data.startswith("ib:ed:"))
async def cb_ib_ed(cb: CallbackQuery):
    if it := await _inbox(cb):
        from handlers.ap_editor import card
        await store.set_post(it["post_id"], status="draft")
        await cb.answer()
        await show(cb, *await card(it["post_id"], cb.from_user.id))


@router.callback_query(F.data.startswith("ib:skip:"))
async def cb_ib_skip(cb: CallbackQuery):
    if it := await _inbox(cb):
        await store.set_inbox(it["id"], "skipped")
        await store.set_post(it["post_id"], status="dropped")
        await _close(cb, "⏭ пропущено")
        await cb.answer()


# ================= реакции под постами =================
@router.callback_query(F.data.startswith("rx:"))
async def cb_react(cb: CallbackQuery):
    if not cb.message:
        return await cb.answer()
    idx = int(cb.data[3:])
    chat_id, msg_id = cb.message.chat.id, cb.message.message_id
    post = await store.post_by_msg(chat_id, msg_id)
    if not post or idx >= len(post["reactions"]):
        return await cb.answer()
    added = await store.react(chat_id, msg_id, cb.from_user.id, idx)
    counts = await store.react_counts(chat_id, msg_id)
    try:
        await cb.message.edit_reply_markup(reply_markup=publisher.keyboard(post, counts))
    except TelegramBadRequest:
        pass
    await cb.answer(post["reactions"][idx] if added else "убрано")


# ================= ❔ помощь по источнику =================
RULE_HELP = {
    "card": ("<b>❔ как устроен источник</b>\n"
             "источник сам берёт записи и выкладывает их в канал по расписанию\n\n"
             "⏸/▶️ — выключить или включить\n"
             "⚡ <b>Выложить сейчас</b> — запустить прямо сейчас, не дожидаясь расписания\n"
             "⏰ <b>Расписание</b> — как часто: интервал, точное время, дни и часы\n"
             "🎛 <b>Контент</b> — что и сколько брать: фото/видео, порядок, фильтр по словам\n"
             "🎨 <b>Оформление</b> — как выглядит пост: подпись от ИИ, теги, реакции, шаблон\n"
             "🛡 <b>Сначала мне</b> ✅ — каждый пост сначала придёт тебе на проверку; ⬜ — сразу в канал\n"
             "♻️ <b>Обнулить историю</b> — снова можно брать уже выложенное\n"
             "👁 <b>Пример</b> — покажу, как будет выглядеть пост, ничего не публикуя\n"
             "📋 <b>Копия</b> / 🔀 <b>Перенести</b> — тот же источник в другой канал\n\n"
             "<i>кнопки с «›» открывают список вариантов, ✅/⬜ — включено/выключено</i>"),
    "content": ("<b>❔ контент</b>\n"
                "📦 <b>за раз</b> — сколько постов за один запуск\n"
                "🔀 <b>порядок</b> — новые первыми, случайно или по порядку\n"
                "🎞 <b>медиа</b> — под тип канала: «только видео» пропустит фото и наоборот, "
                "карусели уйдут альбомом\n"
                "📎 <b>только с картинкой</b> — записи без картинки пропускать\n"
                "🧠 <b>ИИ</b> — пересказать или переписать текст записи\n"
                "✂️ <b>длина</b> — обрезать длинный текст\n"
                "🔁 <b>по кругу</b> — когда всё выложено, начать заново\n"
                "🔎 <b>фильтр</b> — <code>аниме, -реклама</code>: брать только со словами, без «минусовых»\n\n"
                "📌 <b>Pinterest</b>: вместо доски можно дать слова для поиска или ссылку на один пин — "
                "похожие найду сама"),
    "look": ("<b>❔ оформление</b>\n"
             "💬 <b>подпись ИИ</b> — Соня смотрит на картинку и пишет короткую живую подпись\n"
             "#️⃣ <b>теги</b> — популярные от ИИ или из данных записи; ➕ свои — добавятся всегда\n"
             "📝 <b>шаблон</b> — свой вид поста с подстановками {title}, {tags}…\n"
             "✍️ <b>подпись внизу</b> — строка в конце каждого поста, например @канал\n"
             "❤️ <b>реакции</b> — кнопки под постом\n"
             "🔗 <b>источник</b> — словом «источник» в тексте, кнопкой или не показывать\n"
             "🔕 <b>без звука</b> — подписчикам без уведомления\n\n"
             "👁 <b>пример поста</b> — посмотри результат до публикации"),
}


@router.callback_query(F.data.startswith("ap:rhelp:"))
async def cb_rhelp(cb: CallbackQuery):
    _, _, sec, _r = cb.data.split(":")
    rid = await _rid(cb)
    if not rid or sec not in RULE_HELP:
        return
    back = {"card": f"ap:r:{rid}", "content": f"ap:rk:{rid}", "look": f"ap:ro:{rid}"}[sec]
    await show(cb, RULE_HELP[sec], kb_rows([("‹ Назад", back)]))
