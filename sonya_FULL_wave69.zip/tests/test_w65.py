"""Волна 65: команды словами («Соня, колесо» → /wheel), обложки-картинки экранов, карточка профиля, новое меню.
python test_w65.py ../sonya full"""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.methods import SendMessage, SendPhoto, EditMessageMedia, EditMessageText, SendDice

G_ID = -100


def all_text():
    return "\n".join(H.texts())


async def main():
    M, bot, dp = await setup()
    from handlers import words, intents

    # ---------- таблица фраз ----------
    cases = {"колесо": ("wheel", ""), "крутани колесо": ("wheel", ""), "гороскоп овен": ("horo", "овен"),
             "мой профиль": ("me", ""), "дуэль 50": ("duel", "50"), "замуть 30m": ("mute", "30m"),
             "розыгрыш кубиком": ("roll", ""), "мои розыгрыши": ("giveaways", ""), "розыгрыш": ("giveaway", ""),
             "подарки": ("gifts", ""), "баланс": ("fund", ""), "соня плюс": ("plus", ""), "мои боты": ("bots", ""),
             "загугли погоду на марсе": ("search", "погоду на марсе"), "помощь!": ("help", "")}
    bad = [k for k, v in cases.items() if words.match(k) != v]
    check("фразы → команды (15 штук)", not bad)
    check("обычная болтовня — не команда", not words.match("как дела") and not words.match("колесо у машины спустило"))
    import ui
    check("в «🗣 Словами» каждая фраза из примеров распознаётся",
          all(words.match(p) or any(rx.match(p) for rx, _k in intents.INTENTS) for p in
              ("меню", "профиль", "что ты помнишь", "соня плюс", "позвать друга", "характер", "мои боты", "отзыв",
               "колесо", "бонус", "игры", "квиз", "блэкджек", "гороскоп овен", "задания", "питомец", "дуэль 50",
               "лотерея", "акинатор", "крокодил", "мафия", "шпион", "правда или действие", "кнб", "дай монетки 100",
               "погода в Казани", "курс", "загугли котики", "мем привет", "qr ссылка", "подарки", "баланс",
               "розыгрыш", "мои розыгрыши", "розыгрыш кубиком", "что я пропустил", "статистика", "пара дня",
               "звезда дня", "дни рождения", "правила", "заметки", "замуть 30m", "размуть", "предупреди", "забань",
               "тишина 23-8", "настройки")))

    # ---------- повтор через диспетчер ----------
    await dp.feed_update(bot, msg("/start", 70, 70))
    before = (await db.get_user(70))["msgs"]
    SENT.clear()
    await dp.feed_update(bot, msg("колесо", 70, 70))
    check("в личке «колесо» → крутит колесо", "Колесо фортуны" in all_text() or "колесо отдыхает" in all_text())
    check("сообщение посчитано один раз (не дважды)", (await db.get_user(70))["msgs"] == before + 1)
    SENT.clear()
    await dp.feed_update(bot, msg("Соня, гороскоп овен", G_ID, 70))
    check("в группе «Соня, гороскоп овен» → гороскоп", "овен" in all_text().lower() or "♈" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("гороскоп овен", G_ID, 70))
    check("в группе без «Соня» — молчу", not SENT)
    SENT.clear()
    await dp.feed_update(bot, msg("Соня, помощь", G_ID, 70))
    check("«Соня, помощь» → помощь со «🗣 Словами»", "что я умею" in all_text() and "Словами" in str([
        getattr(m, "reply_markup", "") for m in SENT]))

    # ---------- /gift: Соня+ снова работает ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/gift", G_ID, 70, reply=reply_to(71, chat_id=G_ID)))
    check("/gift ответом (без названия) — снова «подарить Соню+»", "дарим Соню+" in all_text())

    # ---------- обложки и карточка ----------
    import uikit
    bot.session.middleware(uikit.UiMiddleware())
    config.BANNERS = True
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 70, 70))
    ph = H.sent(SendPhoto)
    check("/start — обложка-картинка с подписью и меню", ph and "хей" in (ph[-1].caption or "")
          and "m:gifts" in str(ph[-1].reply_markup) and "success" in str(ph[-1].reply_markup))
    check("обложка загружена файлом, file_id запомнен", ph and not isinstance(ph[-1].photo, str)
          and await db.kv_get(f"banner:home:{__import__('banners').version('home')}") == "f")
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 72, 72))
    ph = H.sent(SendPhoto)
    check("второй раз — по file_id, без загрузки", ph and ph[-1].photo == "f")
    mid = 100   # сообщение-обложка в моке
    SENT.clear()
    await dp.feed_update(bot, cbq("m:profile", 70, 70, mid))
    media = H.sent(EditMessageMedia) + H.sent(SendPhoto)
    check("профиль — картинка-карточка + подпись", media and "уровень" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("/help", 70, 70))
    check("/help — тоже с обложкой", H.sent(SendPhoto) and "что я умею" in (H.sent(SendPhoto)[-1].caption or ""))
    SENT.clear()
    await dp.feed_update(bot, cbq("m:help:autopost", 70, 70, 300))
    check("длинный раздел (>1024) — обычным текстом", not H.sent(SendPhoto) and "Автопостинг" in all_text())
    # ---------- фон-рисунок: перерисовать, версия, вернуть прошлую ----------
    import banners, io, os, tempfile
    from pathlib import Path
    from PIL import Image
    from handlers import tools
    banners.BG_DIR = Path(tempfile.mkdtemp())

    def jpg(color):
        b = io.BytesIO()
        Image.new("RGB", (1344, 576), color).save(b, "JPEG")
        return b.getvalue()
    pics = [jpg((200, 40, 40)), jpg((40, 200, 40))]

    async def fake_fetch(url):
        check_url.append(url)
        return pics.pop(0)
    check_url = []
    tools.fetch_image = fake_fetch
    v0 = banners.version("home")
    SENT.clear()
    await dp.feed_update(bot, cbq("bn:r:home", 1, 1))
    v1 = banners.version("home")
    check("админ: «🔄 перерисовать» — фон нарисован по промпту с маскотом, версия обложки сменилась",
          banners.bg_path("home").exists() and v1 != v0 and "Sonya" in check_url[0] and H.sent(SendPhoto))
    px = Image.open(io.BytesIO(banners.render("home"))).getpixel((1200, 280))
    check("на обложке — рисунок (справа виден его цвет), слева — тёмная дымка под текст",
          px[0] > 150 and px[1] < 90 and sum(Image.open(io.BytesIO(banners.render("home"))).getpixel((30, 280))) < 200)
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 74, 74))
    ph = H.sent(SendPhoto)
    check("после перерисовки — новая картинка, а не старый file_id", ph and not isinstance(ph[-1].photo, str))
    os.utime(banners.bg_path("home"), (1, 1))   # чтобы версии точно отличались
    await dp.feed_update(bot, cbq("bn:r:home", 1, 1))
    await dp.feed_update(bot, cbq("bn:u:home", 1, 1))
    px = Image.open(banners.bg_path("home")).getpixel((10, 10))
    check("«↩️ вернуть прошлую» — вернулся красный фон", px[0] > 150 and px[1] < 90)
    SENT.clear()
    await dp.feed_update(bot, cbq("bn:home", 70, 70))
    check("обложки — только владельцу", not any("Обложки экранов" in t for t in H.texts()))

    config.BANNERS = False
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 73, 73))
    check("BANNERS=0 — без картинок", not H.sent(SendPhoto) and H.sent(SendMessage))


async def run():
    await main()
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(run())
sys.exit(1 if FAILS else 0)
