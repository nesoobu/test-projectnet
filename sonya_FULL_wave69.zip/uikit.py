"""🎨 Слой оформления: подменяет тексты экранов, кнопки (текст, премиум-иконка, цвет, скрытие)
и добавляет медиа/ссылки к любому сообщению бота — на лету, перед отправкой в Telegram."""
import contextvars
import hashlib
import html
import json
import logging
import re
import time
from collections import OrderedDict

from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import (SendMessage, EditMessageText, EditMessageReplyMarkup, EditMessageMedia,
                             SendPhoto, SendVideo, SendAnimation, DeleteMessage)
from aiogram.types import (InlineKeyboardMarkup, InlineKeyboardButton, InputMediaPhoto, InputMediaVideo,
                           InputMediaAnimation)

import config
import db

log = logging.getLogger("uikit")

NO_UI = contextvars.ContextVar("no_ui", default=False)   # внутри конструктора — без подмен
SCREENS: dict[str, dict] = {}    # k → {"tpl", "media": {"type","id"}, "links": [[t,u]], "sample", "html"}
BTNS: dict[str, dict] = {}       # bkey → {"data","label","text","icon","style","hide"}
EDIT = {"on": False}
SAMPLES: "OrderedDict[str, tuple[str, bool]]" = OrderedDict()
LASTKEY: "OrderedDict[tuple[int, int], str]" = OrderedDict()
MEDIA_MSGS: "OrderedDict[tuple[int, int], bool]" = OrderedDict()
BIDS: dict[str, str] = {}        # короткий id → bkey (для callback_data)
_names: dict[int, tuple] = {}
CAPTION_MAX = 1024
CARD = contextvars.ContextVar("ui_card", default=None)   # волна 65: картинка-карточка для следующего экрана (профиль)
_BANNER_IDS: dict[str, str] = {}
STYLES = {"p": "primary", "s": "success", "d": "danger"}


def _put(od: OrderedDict, k, v, cap: int):
    od[k] = v
    od.move_to_end(k)
    while len(od) > cap:
        od.popitem(last=False)


# ================= ключи =================
def plain(text: str, html_mode: bool = True) -> str:
    t = re.sub(r"<[^>]+>", "", text or "")
    return html.unescape(t) if html_mode else t


def _norm(s: str, name: str | None) -> str:
    if name:
        s = s.replace(name, "{name}")
        first = name.split()[0] if name.split() else ""
        if first and first != name:
            s = s.replace(first, "{name}")
    s = re.sub(r"\d+", "#", s.lower())
    s = re.sub(r"[^\w#{} ]+", " ", s)
    return re.sub(r"\s+", " ", s).strip()[:80]


def key_of(text: str, html_mode: bool = True, name: str | None = None) -> str:
    """Экран узнаётся по первой строке со словами (имя юзера и числа не мешают)."""
    base = ""
    for line in (text or "").strip().split("\n"):
        p = plain(line, html_mode)
        if re.search(r"[^\W\d_]", p):
            base = p
            break
    norm = _norm(base or plain((text or "")[:200], html_mode), name)
    return hashlib.md5(norm.encode()).hexdigest()[:10]


def bkey(b: InlineKeyboardButton) -> str | None:
    if b.callback_data:
        if b.callback_data.startswith("ui:"):
            return None
        d = b.callback_data
    elif b.url:
        d = "u:" + b.url
    else:
        return None
    return d + "|" + re.sub(r"\d+", "#", (b.text or "").strip())


def bid(key: str) -> str:
    h = hashlib.md5(key.encode()).hexdigest()[:10]
    BIDS[h] = key
    return h


def find_bkey(b: InlineKeyboardButton) -> str | None:
    """Ключ кнопки, даже если на ней уже стоит изменённый текст."""
    k = bkey(b)
    if not k or k in BTNS:
        return k
    data = k.split("|", 1)[0]
    label = re.sub(r"\d+", "#", (b.text or "").strip())
    for key, o in BTNS.items():
        if o.get("data") == data and re.sub(r"\d+", "#", o.get("text") or "") == label:
            return key
    return k


# ================= хранение =================
async def load():
    SCREENS.clear()
    BTNS.clear()
    for r in await db.q_all("SELECT kind, key, data FROM ui_over"):
        (SCREENS if r["kind"] == "s" else BTNS)[r["key"]] = json.loads(r["data"])
    for k in BTNS:
        bid(k)


async def save_screen(k: str):
    o = SCREENS.get(k) or {}
    if not (o.get("tpl") or o.get("media") or o.get("links")):
        SCREENS.pop(k, None)
        await db.q_run("DELETE FROM ui_over WHERE kind='s' AND key=?", k)
    else:
        await db.q_run("INSERT OR REPLACE INTO ui_over(kind,key,data) VALUES('s',?,?)", k,
                       json.dumps(o, ensure_ascii=False))


async def save_btn(key: str):
    o = BTNS.get(key) or {}
    if not any(o.get(f) for f in ("text", "icon", "style", "hide")):
        BTNS.pop(key, None)
        await db.q_run("DELETE FROM ui_over WHERE kind='b' AND key=?", key)
    else:
        await db.q_run("INSERT OR REPLACE INTO ui_over(kind,key,data) VALUES('b',?,?)", key,
                       json.dumps(o, ensure_ascii=False))


async def reset_all():
    SCREENS.clear()
    BTNS.clear()
    await db.q_run("DELETE FROM ui_over")


def screen_sample(k: str) -> tuple[str, bool] | None:
    if k in SAMPLES:
        return SAMPLES[k]
    o = SCREENS.get(k)
    if o and o.get("sample"):
        return o["sample"], o.get("html", True)
    return None


# ================= применение =================
def apply_buttons(markup: InlineKeyboardMarkup | None) -> InlineKeyboardMarkup | None:
    if not markup or not BTNS:
        return markup
    rows = []
    for row in markup.inline_keyboard:
        out = []
        for b in row:
            o = BTNS.get(bkey(b) or "")
            if o:
                if o.get("hide"):
                    continue
                upd = {}
                if o.get("text"):
                    upd["text"] = o["text"]
                if o.get("icon"):
                    upd["icon_custom_emoji_id"] = o["icon"]
                if o.get("style"):
                    upd["style"] = o["style"]
                if upd:
                    b = b.model_copy(update=upd)
            out.append(b)
        if out:
            rows.append(out)
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _with_rows(markup, rows: list[list[InlineKeyboardButton]]):
    if not rows:
        return markup
    base = list(markup.inline_keyboard) if markup else []
    return InlineKeyboardMarkup(inline_keyboard=base + rows)


def edit_row(k: str) -> list[InlineKeyboardButton]:
    return [InlineKeyboardButton(text="✏️ Изменить экран", callback_data=f"ui:e:{k}")]


def render(tpl: str, orig: str, html_mode: bool, name: str | None) -> str:
    o = orig if html_mode else html.escape(orig)
    return tpl.replace("{orig}", o).replace("{name}", html.escape(name or "друг"))


def note_name(uid: int, name: str):
    _names[uid] = (name or None, time.time())


async def _name(chat_id) -> str | None:
    if not isinstance(chat_id, int) or chat_id <= 0:
        return None
    hit = _names.get(chat_id)
    if hit and time.time() - hit[1] < 600:
        return hit[0]
    u = await db.get_user(chat_id)
    n = (u or {}).get("name") or None
    if len(_names) > 5000:
        _names.clear()
    _names[chat_id] = (n, time.time())
    return n


def _owner_dm(chat_id) -> bool:
    return EDIT["on"] and isinstance(chat_id, int) and chat_id == config.OWNER_ID


def _is_html(pm) -> bool:
    """None — обычный текст; строка — как указано; Default — у бота по умолчанию HTML."""
    if pm is None:
        return False
    return pm.lower() == "html" if isinstance(pm, str) else True


SEND = {"photo": (SendPhoto, "photo"), "video": (SendVideo, "video"), "animation": (SendAnimation, "animation")}
INPUT = {"photo": InputMediaPhoto, "video": InputMediaVideo, "animation": InputMediaAnimation}
COMMON = ("message_thread_id", "reply_parameters", "disable_notification", "protect_content",
          "business_connection_id", "message_effect_id")


async def with_card(render, coro_fn):
    """Волна 66: следующее сообщение экрана — с картинкой. render — функция без аргументов → JPEG (рисуем в потоке).
    Картинки выключены (BANNERS=0) или рисунок упал — просто текст."""
    import asyncio
    png = None
    if config.BANNERS:
        try:
            png = await asyncio.to_thread(render)
        except Exception as e:
            log.warning("картинка: %s", e)
    tok = CARD.set(png)
    try:
        return await coro_fn()
    finally:
        CARD.reset(tok)


async def _auto_media(text: str):
    """→ (media, имя обложки). Карточка (CARD) важнее обложки раздела."""
    from aiogram.types import BufferedInputFile
    card = CARD.get()
    if card:
        return {"type": "photo", "id": BufferedInputFile(card, "card.jpg")}, None
    import banners
    name = banners.for_text(text)
    if not name:
        return None, None
    ver = banners.version(name)   # перерисовали фон — новая версия, старый file_id не годится
    fid = _BANNER_IDS.get(f"{name}:{ver}") or await db.kv_get(f"banner:{name}:{ver}")
    if fid:
        _BANNER_IDS[f"{name}:{ver}"] = fid
        return {"type": "photo", "id": fid}, None
    import asyncio
    png = await asyncio.to_thread(banners.cached, name)
    return {"type": "photo", "id": BufferedInputFile(png, f"{name}.jpg")}, name


async def _learn_banner(name: str | None, res):
    """Первая загрузка обложки — запоминаем file_id, дальше Telegram отдаёт без загрузки."""
    if not name:
        return
    ph = getattr(res, "photo", None)
    if ph:
        import banners
        ver = banners.version(name)
        _BANNER_IDS[f"{name}:{ver}"] = ph[-1].file_id
        await db.kv_set(f"banner:{name}:{ver}", ph[-1].file_id)


def _send_media(method, media: dict, caption: str, parse_mode, markup):
    cls, field = SEND[media["type"]]
    kw = {f: getattr(method, f) for f in COMMON if getattr(method, f, None) is not None}
    return cls(chat_id=method.chat_id, caption=caption, parse_mode=parse_mode, reply_markup=markup,
               **{field: media["id"]}, **kw)


def _send_text(method, text: str, parse_mode, markup):
    kw = {f: getattr(method, f) for f in COMMON if getattr(method, f, None) is not None}
    return SendMessage(chat_id=method.chat_id, text=text, parse_mode=parse_mode, reply_markup=markup, **kw)


def _remember(res, chat_id, k: str, media: bool):
    mid = getattr(res, "message_id", None)
    if mid is None or not isinstance(chat_id, int):
        return
    _put(LASTKEY, (chat_id, mid), k, 3000)
    if media:
        _put(MEDIA_MSGS, (chat_id, mid), True, 3000)
    else:
        MEDIA_MSGS.pop((chat_id, mid), None)


class UiMiddleware(BaseRequestMiddleware):
    async def __call__(self, make_request, bot, method):
        if NO_UI.get():
            return await make_request(bot, method)
        try:
            if isinstance(method, (SendMessage, EditMessageText)) and not getattr(method, "inline_message_id", None) \
                    and not method.entities and isinstance(method.text, str):
                return await self._screen(make_request, bot, method)
            if isinstance(method, EditMessageReplyMarkup) and not method.inline_message_id:
                k = LASTKEY.get((method.chat_id, method.message_id))
                mk = apply_buttons(method.reply_markup)
                o = SCREENS.get(k or "")
                if o and o.get("links"):
                    mk = _with_rows(mk, _link_rows(o))
                if k and _owner_dm(method.chat_id):
                    mk = _with_rows(mk, [edit_row(k)])
                if mk is not method.reply_markup:
                    return await self._safe(make_request, bot, method, method.model_copy(update={"reply_markup": mk}))
            elif isinstance(getattr(method, "reply_markup", None), InlineKeyboardMarkup) and BTNS:
                mk = apply_buttons(method.reply_markup)
                return await self._safe(make_request, bot, method, method.model_copy(update={"reply_markup": mk}))
        except TelegramBadRequest:
            raise
        except Exception:
            if not isinstance(method, (SendMessage, EditMessageText, EditMessageReplyMarkup)):
                log.exception("uikit")
                return await make_request(bot, method)
            raise
        return await make_request(bot, method)

    @staticmethod
    async def _safe(make_request, bot, orig, new):
        """Если подмена не понравилась Telegram (кривая разметка, премиум-эмодзи без Premium) — шлём как было."""
        try:
            return await make_request(bot, new)
        except TelegramBadRequest as e:
            if "not modified" in str(e).lower():
                raise
            log.warning("uikit: подмена отклонена (%s) — шлю исходное", e)
            return await make_request(bot, orig)

    async def _screen(self, make_request, bot, method):
        chat_id = method.chat_id
        pm = method.parse_mode
        html_mode = _is_html(pm)
        text = method.text
        name = await _name(chat_id) if (SCREENS or EDIT["on"]) else None
        k = key_of(text, html_mode, name)
        _put(SAMPLES, k, (text, html_mode), 500)
        o = SCREENS.get(k) or {}
        new_text, new_pm = text, pm
        if o.get("tpl"):
            new_text, new_pm = render(o["tpl"], text, html_mode, name), "HTML"
        mk = method.reply_markup
        if mk is None or isinstance(mk, InlineKeyboardMarkup):
            mk = apply_buttons(mk)
            if o.get("links"):
                mk = _with_rows(mk, _link_rows(o))
            if _owner_dm(chat_id):
                mk = _with_rows(mk, [edit_row(k)])
        media = o.get("media")
        banner = None
        if not media and config.BANNERS:   # волна 65: своя обложка у главных экранов / карточка профиля
            media, banner = await _auto_media(new_text)
        if media and len(plain(new_text, _is_html(new_pm))) > CAPTION_MAX:
            media, banner = None, None
        changed = new_text is not text or mk is not method.reply_markup or media

        if isinstance(method, SendMessage):
            if media:
                new = _send_media(method, media, new_text, new_pm, mk)
            elif changed:
                new = method.model_copy(update={"text": new_text, "parse_mode": new_pm, "reply_markup": mk})
            else:
                res = await make_request(bot, method)
                _remember(res, chat_id, k, False)
                return res
            res = await self._safe(make_request, bot, method, new)
            _remember(res, chat_id, k, bool(media) and not getattr(res, "text", None))
            await _learn_banner(banner, res)
            return res

        # ---- EditMessageText
        target = (chat_id, method.message_id)
        is_media = target in MEDIA_MSGS
        if media and is_media:
            im = INPUT[media["type"]](media=media["id"], caption=new_text, parse_mode=new_pm)
            new = EditMessageMedia(chat_id=chat_id, message_id=method.message_id, media=im, reply_markup=mk)
            try:
                res = await make_request(bot, new)
            except TelegramBadRequest as e:
                if "not modified" in str(e).lower():
                    raise
                res = await self._replace(make_request, bot, method, media, new_text, new_pm, mk)
            _remember(res, chat_id, k, True)
            await _learn_banner(banner, res)
            return res
        if media or is_media:
            res = await self._replace(make_request, bot, method, media, new_text, new_pm, mk)
            _remember(res, chat_id, k, bool(media))
            await _learn_banner(banner, res)
            return res
        new = method.model_copy(update={"text": new_text, "parse_mode": new_pm, "reply_markup": mk}) \
            if changed else method
        try:
            res = await (self._safe(make_request, bot, method, new) if changed else make_request(bot, method))
        except TelegramBadRequest as e:
            if "no text in the message" not in str(e).lower():
                raise
            res = await self._replace(make_request, bot, method, None, new_text, new_pm, mk)
        _remember(res, chat_id, k, False)
        return res

    async def _replace(self, make_request, bot, method, media, text, pm, mk):
        """Тип сообщения меняется (текст ↔ медиа) — удаляем старое и шлём новое."""
        try:
            await make_request(bot, DeleteMessage(chat_id=method.chat_id, message_id=method.message_id))
        except TelegramBadRequest:
            pass
        src = SendMessage(chat_id=method.chat_id, text=method.text, parse_mode=method.parse_mode,
                          reply_markup=method.reply_markup)
        new = _send_media(src, media, text, pm, mk) if media else _send_text(src, text, pm, mk)
        return await self._safe(make_request, bot, src, new)


def _link_rows(o: dict) -> list[list[InlineKeyboardButton]]:
    return [[InlineKeyboardButton(text=t, url=u)] for t, u in o.get("links") or []]
