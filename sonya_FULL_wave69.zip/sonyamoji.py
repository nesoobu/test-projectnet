"""Волна 68: анимированные премиум-эмодзи Сони (custom emoji). Рисуем сами — PIL + ffmpeg (VP9 с прозрачностью),
как требует Telegram: 100×100, ≤3 с, ≤30 к/с, ≤256 КБ, без звука. Пак создаёт бот (createNewStickerSet,
sticker_type=custom_emoji), владелец пака — тот, кто нажал «создать» в админке.
Единый стиль: фирменный градиент розовый→фиолетовый, белые блики, мягкая тень; рисуем в 4× и уменьшаем (гладкие края)."""
import io
import math
import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFilter, ImageFont

import banners

S = 400            # холст рисования (потом → 100×100)
OUT = 100
FPS, SECONDS = 30, 2
PINK, VIOLET, DEEP = (255, 92, 170), (150, 80, 255), (70, 30, 140)
GOLD, GOLD_D = (255, 205, 70), (210, 140, 20)
WHITE = (255, 255, 255)


def _lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _grad_fill(size, c1, c2) -> Image.Image:
    """Вертикальный градиент на весь холст — заливаем через маску фигуры."""
    g = Image.new("RGB", (1, size))
    for y in range(size):
        g.putpixel((0, y), _lerp(c1, c2, y / (size - 1)))
    return g.resize((size, size))


def _shape(draw_fn, c1=PINK, c2=VIOLET, outline=True) -> Image.Image:
    """Фигура с градиентом и тёмной обводкой (стикерный стиль)."""
    mask = Image.new("L", (S, S), 0)
    draw_fn(ImageDraw.Draw(mask), 255)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    if outline:
        # обводка ~12 px: размытие + порог в разы быстрее MaxFilter(25) при том же виде
        edge = mask.filter(ImageFilter.GaussianBlur(7)).point(lambda v: 255 if v > 8 else v * 30)
        im.paste(Image.new("RGBA", (S, S), DEEP + (255,)), (0, 0), edge)
    im.paste(_grad_fill(S, c1, c2).convert("RGBA"), (0, 0), mask)
    return im


def _shine(im: Image.Image, box, alpha=150):
    """Белый блик-овал."""
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).ellipse(box, fill=(255, 255, 255, alpha))
    im.alpha_composite(layer.filter(ImageFilter.GaussianBlur(6)))


def _star_pts(cx, cy, r1, r2, n=5, rot=-math.pi / 2):
    return [(cx + math.cos(rot + i * math.pi / n) * (r1 if i % 2 == 0 else r2),
             cy + math.sin(rot + i * math.pi / n) * (r1 if i % 2 == 0 else r2)) for i in range(2 * n)]


def _heart_pts(cx, cy, r, steps=60):
    pts = []
    for i in range(steps):
        a = 2 * math.pi * i / steps
        x = 16 * math.sin(a) ** 3
        y = -(13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a))
        pts.append((cx + x * r / 17, cy + y * r / 17))
    return pts


def _transform(im: Image.Image, scale=1.0, angle=0.0, dx=0, dy=0, sx=None, sy=None) -> Image.Image:
    sx, sy = sx or scale, sy or scale
    w, h = max(1, int(S * sx)), max(1, int(S * sy))
    t = im.resize((w, h), Image.LANCZOS)
    if angle:
        t = t.rotate(angle, resample=Image.BICUBIC, expand=True)
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.alpha_composite(t, (int((S - t.width) / 2 + dx), int((S - t.height) / 2 + dy))) if t.width <= S and t.height <= S \
        else out.paste(t.crop(((t.width - S) // 2, (t.height - S) // 2, (t.width + S) // 2, (t.height + S) // 2)),
                       (int(dx), int(dy)))
    return out


def _beat(t):   # «тук-тук» сердца
    return max(math.exp(-((t - 0.1) / 0.06) ** 2), 0.7 * math.exp(-((t - 0.32) / 0.06) ** 2))


# ================= сами эмодзи: f(t) → RGBA S×S, t ∈ [0,1) =================
def heart(t):
    base = _shape(lambda d, f: d.polygon(_heart_pts(S / 2, S / 2 + 10, 150), fill=f))
    _shine(base, [110, 110, 170, 160])
    return _transform(base, 0.9 + 0.12 * _beat(t))


def sparkles(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for cx, cy, r, ph in ((175, 210, 120, 0.0), (300, 110, 62, 0.33), (305, 300, 50, 0.66)):
        k = 0.55 + 0.45 * (0.5 + 0.5 * math.sin(2 * math.pi * (t + ph)))
        rr = r * k
        st = _shape(lambda d, f: d.polygon(_star_pts(cx, cy, rr, rr * 0.28, 4), fill=f), GOLD, PINK)
        im.alpha_composite(st)
    return im


def dice(t):
    e = 0.5 - 0.5 * math.cos(2 * math.pi * t)
    base = _shape(lambda d, f: d.rounded_rectangle([90, 90, 310, 310], radius=50, fill=f), (255, 255, 255), (230, 220, 255))
    d = ImageDraw.Draw(base)
    for x, y in ((140, 140), (200, 200), (260, 260), (260, 140), (140, 260)):
        d.ellipse([x - 22, y - 22, x + 22, y + 22], fill=VIOLET)
    _shine(base, [110, 105, 180, 135], 120)
    return _transform(base, 0.92, angle=360 * e, dy=-40 * math.sin(math.pi * t))


def coin(t):
    c = math.cos(2 * math.pi * t)
    base = _shape(lambda d, f: d.ellipse([70, 70, 330, 330], fill=f), GOLD, GOLD_D)
    d = ImageDraw.Draw(base)
    d.ellipse([110, 110, 290, 290], outline=(255, 235, 150), width=12)
    if c > 0:
        d.text((200, 205), "S", font=banners._font(banners.HEAD_FONT, 150), fill=(255, 245, 200), anchor="mm")
    _shine(base, [100, 95, 170, 140], 140)
    return _transform(base, 0.95, sx=0.95 * max(0.08, abs(c)), sy=0.95)


def gift(t):
    hop = max(0.0, math.sin(math.pi * min(1, max(0, (t - 0.15) / 0.3))))
    shake = math.sin(2 * math.pi * t * 4) * 6 * (1 - hop) * (t < 0.15)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    box = _shape(lambda d, f: d.rounded_rectangle([90, 175, 310, 340], radius=24, fill=f), PINK, VIOLET)
    d = ImageDraw.Draw(box)
    d.rectangle([182, 175, 218, 340], fill=GOLD)
    im.alpha_composite(box)
    lid = _shape(lambda d, f: d.rounded_rectangle([75, 120, 325, 185], radius=20, fill=f), (255, 140, 200), PINK)
    d = ImageDraw.Draw(lid)
    d.rectangle([182, 120, 218, 185], fill=GOLD)
    for side in (-1, 1):   # бант
        d.ellipse([200 + side * 70 - 45, 70, 200 + side * 70 + 45, 125], outline=GOLD, width=18)
    im.alpha_composite(_transform(lid, 1.0, angle=-12 * hop, dy=-60 * hop))
    return _transform(im, 0.95, angle=shake)


def trophy(t):
    def cup(d, f):
        d.pieslice([100, 30, 300, 260], 0, 180, fill=f)
        d.rectangle([100, 90, 300, 145], fill=f)
        d.rectangle([180, 240, 220, 300], fill=f)
        d.rounded_rectangle([120, 295, 280, 345], radius=14, fill=f)
        for side in (-1, 1):
            d.arc([200 + side * 125 - 55, 100, 200 + side * 125 + 55, 210], 0, 360, fill=f, width=22)
    base = _shape(cup, GOLD, GOLD_D)
    band = Image.new("L", (S, S), 0)
    x = -150 + 700 * t
    ImageDraw.Draw(band).polygon([(x, 0), (x + 60, 0), (x - 140, S), (x - 200, S)], fill=200)
    a = base.split()[3]
    shine = Image.new("RGBA", (S, S), (255, 255, 255, 0))
    shine.putalpha(Image.composite(band, Image.new("L", (S, S), 0), a).filter(ImageFilter.GaussianBlur(4)))
    base.alpha_composite(shine)
    return base


def megaphone(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    body = _shape(lambda d, f: (d.polygon([(70, 170), (220, 90), (220, 310), (70, 230)], fill=f),
                                d.rounded_rectangle([40, 165, 95, 235], radius=12, fill=f)))
    _shine(body, [150, 120, 205, 170], 110)
    im.alpha_composite(body)
    d = ImageDraw.Draw(im)
    for i in range(3):
        k = (t * 1.5 - i * 0.2) % 1
        if k < 0.7:
            a = int(255 * (1 - k / 0.7))
            r = 50 + i * 45
            d.arc([235 - r, 200 - r, 235 + r, 200 + r], -45, 45, fill=PINK + (a,), width=16)
    return im


def bolt(t):
    pts = [(230, 40), (110, 220), (195, 220), (165, 360), (295, 165), (210, 165), (250, 40)]
    base = _shape(lambda d, f: d.polygon(pts, fill=f), GOLD, (255, 140, 60))
    glow = base.split()[3].filter(ImageFilter.GaussianBlur(26))
    k = 0.55 + 0.45 * abs(math.sin(2 * math.pi * t * 2))
    g = Image.new("RGBA", (S, S), PINK + (0,))
    g.putalpha(glow.point(lambda v: int(v * k)))
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.alpha_composite(g)
    out.alpha_composite(base)
    return out


def star(t):
    base = _shape(lambda d, f: d.polygon(_star_pts(200, 210, 160, 70), fill=f), GOLD, (255, 150, 60))
    _shine(base, [140, 120, 200, 170], 130)
    return _transform(base, 0.9 + 0.06 * math.sin(2 * math.pi * t), angle=14 * math.sin(2 * math.pi * t))


def gear(t):
    def g(d, f):
        for i in range(8):
            a = i * math.pi / 4
            d.polygon([(200 + math.cos(a - 0.22) * 120, 200 + math.sin(a - 0.22) * 120),
                       (200 + math.cos(a - 0.15) * 170, 200 + math.sin(a - 0.15) * 170),
                       (200 + math.cos(a + 0.15) * 170, 200 + math.sin(a + 0.15) * 170),
                       (200 + math.cos(a + 0.22) * 120, 200 + math.sin(a + 0.22) * 120)], fill=f)
        d.ellipse([60, 60, 340, 340], fill=f)
        d.ellipse([150, 150, 250, 250], fill=0)
    base = _shape(g, (190, 200, 230), VIOLET)
    return _transform(base, 0.92, angle=-360 * t / 4)


def question(t):
    b = abs(math.sin(math.pi * t * 2))
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    base = _shape(lambda d, f: d.text((200, 215), "?", font=banners._font(banners.HEAD_FONT, 330), fill=f, anchor="mm"))
    im.alpha_composite(base)
    squash = 1 - 0.12 * (b < 0.15)
    return _transform(im, 0.95, dy=-45 * b, sx=0.95 / squash, sy=0.95 * squash)


def bubble(t):
    base = _shape(lambda d, f: (d.rounded_rectangle([50, 80, 350, 290], radius=80, fill=f),
                                d.polygon([(110, 270), (90, 350), (180, 285)], fill=f)), (255, 255, 255), (225, 215, 255))
    d = ImageDraw.Draw(base)
    for i in range(3):
        y = 185 - 22 * max(0.0, math.sin(2 * math.pi * (t * 1.5 - i * 0.15)))
        d.ellipse([125 + i * 75 - 24, y - 24, 125 + i * 75 + 24, y + 24], fill=VIOLET)
    return base


def plane(t):
    a = 2 * math.pi * t
    base = _shape(lambda d, f: (d.polygon([(40, 210), (360, 70), (240, 330)], fill=f)), (255, 255, 255), (200, 190, 255))
    d = ImageDraw.Draw(base)
    d.polygon([(360, 70), (150, 230), (175, 320)], fill=(170, 150, 240))
    return _transform(base, 0.8, angle=8 * math.sin(a), dx=30 * math.sin(a), dy=-22 * math.sin(2 * a))


def bulb(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    k = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    d = ImageDraw.Draw(im)
    for i in range(8):
        a = -math.pi + i * math.pi / 7
        r1, r2 = 150, 150 + 40 * k
        d.line([(200 + math.cos(a) * r1, 175 + math.sin(a) * r1), (200 + math.cos(a) * r2, 175 + math.sin(a) * r2)],
               fill=GOLD + (int(120 + 135 * k),), width=16)
    glass = _shape(lambda d2, f: (d2.ellipse([90, 60, 310, 280], fill=f), d2.rectangle([150, 240, 250, 300], fill=f)),
                   _lerp((255, 240, 150), GOLD, 1 - k), GOLD)
    d2 = ImageDraw.Draw(glass)
    d2.rounded_rectangle([145, 295, 255, 350], radius=14, fill=(160, 160, 190))
    _shine(glass, [130, 95, 190, 160], 160)
    im.alpha_composite(glass)
    return im


def _face(t, wink=False):
    """Маскот: Соня — тёмное каре, наушники, румянец; моргает."""
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    hair = _shape(lambda d, f: (d.ellipse([55, 45, 345, 335], fill=f), d.rectangle([55, 190, 345, 330], fill=f)),
                  (60, 50, 110), (30, 26, 60))
    im.alpha_composite(hair)
    face = _shape(lambda d, f: d.ellipse([95, 105, 305, 315], fill=f), (255, 232, 220), (255, 210, 200), outline=False)
    im.alpha_composite(face)
    d = ImageDraw.Draw(im)
    d.polygon([(85, 150), (200, 85), (315, 150), (290, 120), (200, 70), (110, 120)], fill=(45, 38, 90))   # чёлка
    d.pieslice([90, 70, 310, 200], 180, 360, fill=(45, 38, 90))
    blink = 0.08 < (t % 1) < 0.16 or (wink and 0.5 < t < 0.75)
    for i, ex in enumerate((155, 245)):
        if blink and (not wink or i == 1):
            d.arc([ex - 26, 205, ex + 26, 240], 200, 340, fill=(40, 30, 70), width=9)
        else:
            d.ellipse([ex - 22, 192, ex + 22, 245], fill=(60, 40, 110))
            d.ellipse([ex - 9, 200, ex + 3, 214], fill=WHITE)
    for ex in (130, 270):
        d.ellipse([ex - 22, 245, ex + 22, 268], fill=(255, 150, 180, 180))
    d.arc([180, 250, 220, 280], 20, 160, fill=(150, 60, 90), width=7)
    d.arc([40, 30, 360, 330], 200, 340, fill=VIOLET, width=26)   # дужка наушников
    for ex in (52, 348):
        d.rounded_rectangle([ex - 32, 170, ex + 32, 265], radius=22, fill=PINK, outline=DEEP, width=8)
    return _transform(im, 0.95, dy=-8 * math.sin(2 * math.pi * t))


def face(t):
    return _face(t)


def wink(t):
    return _face(t, True)


def fire(t):
    def flame(d, f):
        pts = []
        for i in range(48):
            a = 2 * math.pi * i / 48
            r = 120 + 18 * math.sin(3 * a + 2 * math.pi * t * 2) + 10 * math.sin(5 * a - 2 * math.pi * t * 3)
            y = math.sin(a)
            stretch = 1.6 if y < 0 else 1.0
            pts.append((200 + math.cos(a) * r * (0.8 if y < 0 else 1), 250 + y * r * stretch))
        d.polygon(pts, fill=f)
    base = _shape(flame, (255, 220, 80), (255, 70, 60))
    inner = _shape(lambda d, f: d.ellipse([150, 230, 250, 350], fill=f), (255, 250, 200), (255, 200, 80), outline=False)
    base.alpha_composite(_transform(inner, 1.0, sy=1 + 0.08 * math.sin(2 * math.pi * t * 3)))
    return base


def check(t):
    p = min(1.0, t / 0.45)
    pop = 1 + 0.12 * math.exp(-((t - 0.5) / 0.08) ** 2)
    base = _shape(lambda d, f: d.rounded_rectangle([60, 60, 340, 340], radius=70, fill=f), (110, 230, 140), (40, 170, 90))
    d = ImageDraw.Draw(base)
    pts = [(120, 205), (180, 265), (290, 140)]
    if p > 0:
        seg = p * 2
        a = pts[0]
        b = pts[1] if seg >= 1 else (pts[0][0] + (pts[1][0] - pts[0][0]) * seg, pts[0][1] + (pts[1][1] - pts[0][1]) * seg)
        d.line([a, b], fill=WHITE, width=34, joint="curve")
        if seg > 1:
            k = seg - 1
            c = (pts[1][0] + (pts[2][0] - pts[1][0]) * k, pts[1][1] + (pts[2][1] - pts[1][1]) * k)
            d.line([pts[1], c], fill=WHITE, width=34, joint="curve")
    return _transform(base, 0.92 * pop)


def arrow(t):
    b = abs(math.sin(math.pi * t * 2))
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    tray = _shape(lambda d, f: (d.rounded_rectangle([60, 290, 340, 335], radius=20, fill=f),
                                d.rectangle([60, 240, 100, 320], fill=f), d.rectangle([300, 240, 340, 320], fill=f)),
                  (200, 190, 255), VIOLET)
    im.alpha_composite(tray)
    arr = _shape(lambda d, f: d.polygon([(165, 40), (235, 40), (235, 150), (290, 150), (200, 250), (110, 150),
                                         (165, 150)], fill=f))
    im.alpha_composite(_transform(arr, 1.0, dy=-10 + 30 * b))
    return im


def notes(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for i, (x0, ph) in enumerate(((130, 0.0), (260, 0.5))):
        k = (t + ph) % 1
        y = 260 - 140 * k
        a = int(255 * min(1, (1 - k) * 2.5))
        n = _shape(lambda d, f: (d.ellipse([x0 - 55, y + 20, x0 + 25, y + 85], fill=f), d.rectangle([x0 + 5, y - 110, x0 + 27, y + 55], fill=f),
                                 d.polygon([(x0 + 5, y - 110), (x0 + 85, y - 75), (x0 + 85, y - 40), (x0 + 27, y - 70)], fill=f)),
                   PINK if i == 0 else VIOLET, VIOLET if i == 0 else PINK)
        n.putalpha(n.split()[3].point(lambda v: v * a // 255))
        im.alpha_composite(n)
    return im


def crown(t):
    def c(d, f):
        d.polygon([(60, 300), (60, 130), (130, 210), (200, 90), (270, 210), (340, 130), (340, 300)], fill=f)
        d.rounded_rectangle([55, 285, 345, 335], radius=16, fill=f)
    base = _shape(c, GOLD, GOLD_D)
    d = ImageDraw.Draw(base)
    k = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    for x, col in ((120, PINK), (200, VIOLET), (280, PINK)):
        d.ellipse([x - 20, 290, x + 20, 330], fill=_lerp(col, WHITE, 0.4 * k))
    sp = _shape(lambda d2, f: d2.polygon(_star_pts(300, 80, 55 * k + 10, 14, 4), fill=f), WHITE, GOLD, outline=False)
    base.alpha_composite(sp)
    return _transform(base, 0.92, angle=4 * math.sin(2 * math.pi * t))


# имя → (функция, эмодзи для пака, подпись)
SET = {
    "sonya": (face, "💜", "Соня"), "wink": (wink, "😉", "подмигивает"), "heart": (heart, "💜", "сердечко"),
    "sparkles": (sparkles, "✨", "искры"), "dice": (dice, "🎲", "кубик"), "coin": (coin, "🪙", "монетка"),
    "gift": (gift, "🎁", "подарок"), "trophy": (trophy, "🏆", "кубок"), "megaphone": (megaphone, "📢", "рупор"),
    "bolt": (bolt, "⚡", "молния"), "star": (star, "⭐", "звезда"), "gear": (gear, "⚙", "шестерёнка"),
    "question": (question, "❓", "вопрос"), "bubble": (bubble, "💬", "печатает…"), "plane": (plane, "✈", "самолётик"),
    "bulb": (bulb, "💡", "идея"), "fire": (fire, "🔥", "огонь"), "check": (check, "✅", "готово"),
    "arrow": (arrow, "⬇", "скачать"), "notes": (notes, "🎵", "музыка"), "crown": (crown, "👑", "корона"),
}
# кнопки главного меню → какой эмодзи поставить (callback_data → имя)
MENU = {"g:menu": "dice", "m:tools": "bolt", "ap:home": "megaphone", "gw:list": "gift", "m:gifts": "heart",
        "m:profile": "sonya", "m:top:xp": "trophy", "g:bonus": "coin", "m:plus": "crown", "m:mode": "wink",
        "m:facts": "bulb", "biz:home": "bubble", "m:ref": "plane", "m:help": "question", "m:donate": "star",
        "adm:home": "gear"}


def frames(name: str) -> list[Image.Image]:
    fn = SET[name][0]
    n = FPS * SECONDS
    return [fn(i / n).resize((OUT, OUT), Image.LANCZOS) for i in range(n)]


def webm(name: str) -> bytes:
    """Кадры → WEBM VP9 с альфой (yuva420p). Подбираем качество, чтобы влезть в 256 КБ."""
    tmp = tempfile.mkdtemp(prefix="moji")
    try:
        for i, f in enumerate(frames(name)):
            f.save(os.path.join(tmp, f"{i:03d}.png"))
        out = os.path.join(tmp, "out.webm")
        for crf in (30, 38, 46):
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i",
                            os.path.join(tmp, "%03d.png"), "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
                            "-b:v", "0", "-crf", str(crf), "-an", "-t", str(SECONDS), out],
                           check=True, timeout=120)
            if os.path.getsize(out) <= 250 * 1024:
                break
        with open(out, "rb") as fh:
            return fh.read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def preview_gif(names: list[str], cols: int = 7, cell: int = 120) -> bytes:
    """Превью всех эмодзи сеткой (анимированный GIF на тёмном фоне) — показать перед созданием пака."""
    all_frames = {n: frames(n) for n in names}
    rows = math.ceil(len(names) / cols)
    out = []
    font = banners._font(banners.TEXT_FONT, 15)
    for i in range(FPS * SECONDS):
        im = Image.new("RGB", (cols * cell, rows * (cell + 22)), (24, 22, 36))
        d = ImageDraw.Draw(im)
        for k, n in enumerate(names):
            x, y = (k % cols) * cell, (k // cols) * (cell + 22)
            im.paste(all_frames[n][i], (x + 10, y + 8), all_frames[n][i])
            d.text((x + cell // 2, y + cell + 6), SET[n][2], font=font, fill=(220, 215, 235), anchor="mm")
        out.append(im)
    buf = io.BytesIO()
    out[0].save(buf, "GIF", save_all=True, append_images=out[1::2], duration=1000 // FPS * 2, loop=0, optimize=True)
    return buf.getvalue()
