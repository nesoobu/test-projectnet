"""Автопостинг, волна 17: водяной знак, отсев похожих картинок, контент-план от ИИ."""
import logging
import re
from html import escape

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

import llm
from autopost import store
from handlers.ap_common import show, kb_rows, cancel_kb

router = Router()
log = logging.getLogger("ap_extra")


class APX(StatesGroup):
    watermark = State()


async def _own(cb: CallbackQuery) -> int | None:
    cid = int(cb.data.rsplit(":", 1)[1])
    if not await store.channel(cid, cb.from_user.id):
        await cb.answer("канал не найден", show_alert=True)
        return None
    return cid


async def _settings(target, cid: int):
    from handlers import ap_panel
    await show(target, *await ap_panel.channel_view(cid))


# ================= 💧 водяной знак =================
@router.callback_query(F.data.startswith("ap:x_wm:"))
async def cb_wm(cb: CallbackQuery, state: FSMContext):
    if cid := await _own(cb):
        await state.set_state(APX.watermark)
        await state.update_data(cid=cid)
        await show(cb, "<b>💧 водяной знак</b>\nнапишу этот текст полупрозрачно в углу каждой картинки поста.\n"
                       "пример: <code>@mychannel</code>\n\n«-» — убрать", cancel_kb(f"ap:cs:{cid}"))


@router.message(APX.watermark, F.text)
async def st_wm(m: Message, state: FSMContext):
    cid = (await state.get_data())["cid"]
    text = "" if m.text.strip() == "-" else m.text.strip()[:40]
    await store.set_channel(cid, watermark=text)
    await state.clear()
    await _settings(m, cid)


# ================= 🧬 похожие картинки =================
@router.callback_query(F.data.startswith("ap:x_dup:"))
async def cb_dup(cb: CallbackQuery):
    if cid := await _own(cb):
        c = await store.channel(cid)
        await store.set_channel(cid, dedupe_img=0 if c.get("dedupe_img", 1) else 1)
        await _settings(cb, cid)


# ================= 🗓 контент-план =================
PLAN_SYS = ("Ты контент-менеджер Telegram-канала. Составь контент-план на 7 дней: на каждый день 2 идеи постов "
            "(рубрика + о чём пост одной строкой + формат: текст/картинка/видео/опрос). Учитывай тему канала и что "
            "уже выходило, не повторяйся. Пиши по-русски, коротко, списком по дням (Пн…Вс). Без вступлений.")


async def plan_text(cid: int, owner: int) -> str:
    c = await store.channel(cid)
    import db
    recent = await db.q_all("SELECT p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                            "WHERE s.chat_id=? AND s.status='sent' ORDER BY s.sent_at DESC LIMIT 15", cid)
    rules = await store.rules_of(owner, cid)
    about = [f"Канал: {c['title']}" + (f" (@{c['username']})" if c.get("username") else "")]
    if rules:
        about.append("Автоисточники: " + ", ".join(f"{r['type']}: {r['title']}" for r in rules[:10]))
    snippets = []
    for p in recent:
        t = re.sub(r"<[^>]+>", "", p.get("text") or "")[:80]
        if t:
            snippets.append(t)
    if snippets:
        about.append("Недавние посты: " + " | ".join(snippets[:10]))
    return await llm.ask([{"role": "system", "content": PLAN_SYS}, {"role": "user", "content": "\n".join(about)}],
                         max_tokens=1500, temperature=0.8, feature="plan")


@router.callback_query(F.data.startswith("ap:x_plan:"))
async def cb_plan(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    import limits
    if not await limits.take(cb.from_user.id):
        return await cb.answer("на сегодня ИИ-лимит исчерпан", show_alert=True)
    await cb.answer("думаю над планом…")
    try:
        out = await plan_text(cid, cb.from_user.id)
    except Exception as e:
        log.info("plan: %s", e)
        await limits.give_back(cb.from_user.id)
        return await cb.message.answer("😕 ИИ не ответил, попробуй ещё раз")
    await cb.message.answer(f"🗓 <b>контент-план на неделю</b>\n\n{escape(out[:3800])}",
                            reply_markup=kb_rows([("🔁 Другой план", f"ap:x_plan:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")]))


# ================= 📊 статистика канала =================
WEEKDAYS = "пн вт ср чт пт сб вс".split()


async def stats_data(cid: int, days: int = 30) -> dict:
    """Реакции подписчиков на кнопки Сони под постами → топ постов, лучшие часы и дни (по МСК)."""
    import json
    import time
    import db
    since = int(time.time()) - days * 86400
    rows = await db.q_all("SELECT s.id, s.msg_ids, s.sent_at, p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                          "WHERE s.chat_id=? AND s.status='sent' AND s.sent_at>?", cid, since)
    posts = []
    for r in rows:
        ids = json.loads(r["msg_ids"] or "[]")
        n = 0
        if ids:
            marks = ",".join("?" * len(ids))
            n = (await db.q_one(f"SELECT COUNT(*) AS n FROM ap_reacts WHERE chat_id=? AND msg_id IN ({marks})",
                                cid, *ids))["n"]
        t = time.gmtime(r["sent_at"] + 3 * 3600)
        posts.append({"reacts": n, "hour": t.tm_hour, "wd": t.tm_wday, "msg": ids[-1] if ids else 0,
                      "text": re.sub(r"<[^>]+>", "", r["text"] or "").strip()})
    by_hour, by_wd = {}, {}
    for p in posts:
        by_hour.setdefault(p["hour"], []).append(p["reacts"])
        by_wd.setdefault(p["wd"], []).append(p["reacts"])
    avg = lambda d: sorted(((sum(v) / len(v), k) for k, v in d.items() if len(v) >= 2), reverse=True)
    return {"posts": posts, "total": len(posts), "reacts": sum(p["reacts"] for p in posts),
            "hours": avg(by_hour)[:3], "days": avg(by_wd)[:2],
            "top": sorted((p for p in posts if p["reacts"]), key=lambda p: -p["reacts"])[:5]}


async def stats_text(cid: int) -> str:
    import ui
    c = await store.channel(cid)
    d = await stats_data(cid)
    lines = [ui.head("📊", f"Статистика · {escape(c['title'])}", "за 30 дней, по реакциям на кнопки Сони")]
    lines.append(ui.stats(("📤 постов", d["total"]), ("❤️ реакций", d["reacts"]),
                          ("⚡ в среднем на пост", f"{d['reacts'] / d['total']:.1f}" if d["total"] else "—")))
    if d["top"]:
        top = []
        for i, p in enumerate(d["top"]):
            snip = escape((p["text"] or "без текста")[:40])
            if c.get("username") and p["msg"]:
                snip = f'<a href="https://t.me/{c["username"]}/{p["msg"]}">{snip}</a>'
            top.append(f"{ui.MEDALS[i] if i < 3 else '▫️'} {snip} — <b>{p['reacts']}</b>")
        lines.append("🏆 <b>лучшие посты</b>\n" + ui.quote("\n".join(top)))
    if d["hours"]:
        hrs = " · ".join(f"<b>{h}:00</b> ({a:.1f})" for a, h in d["hours"])
        wds = " · ".join(f"<b>{WEEKDAYS[w]}</b>" for _a, w in d["days"])
        lines.append("🕐 <b>лучшее время</b>\n" + ui.quote(f"часы: {hrs}" + (f"\nдни: {wds}" if wds else "")))
    if not d["reacts"]:
        lines.append(ui.hint("реакций пока нет. включи кнопки-реакции в «🎨 Оформлении» источника или поста — "
                             "по ним я считаю, что заходит"))
    else:
        lines.append(ui.hint("ставь посты на лучшие часы: «⚙️ Настройки» канала → слоты"))
    return "\n".join(lines)


@router.callback_query(F.data.startswith("ap:x_stat:"))
async def cb_stat(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    await show(cb, await stats_text(cid), kb_rows([("🔄", f"ap:x_stat:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")]))


# ================= волна 69: 🩺 проверка канала и 🗓 неделя картинкой =================
@router.callback_query(F.data.startswith("ap:hc:"))
async def cb_health(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    text, kb = await health_view(cb.bot, cid, cb.from_user.id)
    await show(cb, text, kb)


async def health_view(bot, cid: int, uid: int):
    """Одним экраном: могу ли я публиковать в канал, что с каждым источником, упавшие посты."""
    import time
    import db
    import ui
    from autopost import rules as R, sources, timeparse
    ch = await store.channel(cid)
    lines = [ui.head("🩺", "Проверка канала", escape(ch["title"]))]
    try:   # права в канале — самая частая причина «ничего не выходит»
        me = await bot.me()
        mem = await bot.get_chat_member(cid, me.id)
        can = mem.status == "creator" or (mem.status == "administrator"
                                           and getattr(mem, "can_post_messages", None) is not False)
        lines.append("✅ я админ и могу публиковать" if can else "⛔ <b>нет права публиковать</b> — дай его в настройках канала")
    except Exception as e:
        lines.append(f"⛔ <b>не вижу канал</b>: {escape(R.human_error(str(e)))}")
    if ch["paused"]:
        lines.append("⏸ канал на паузе — «▶️ Запустить» в карточке канала")
    rs = await store.rules_of(uid, cid)
    rows_txt = []
    bad = 0
    for r in rs:
        c = store.cfg_of(r)
        icon = sources.TYPES.get(r["type"], ("•",))[0]
        if not r["active"]:
            st = "⏸"
        elif r["last_error"]:
            st, bad = "⚠️", bad + 1
        else:
            st = "🟢"
        line = f"{st} {icon} <b>{escape(r['title'][:24])}</b> · выложено {r['posted']}"
        if r["active"]:
            line += f" · дальше {timeparse.fmt(r['next_run'])}"
        if r["last_error"]:
            line += f"\n      <i>{escape(R.human_error(r['last_error']))}</i>"
            if c.get("fails"):
                line += f" · сбоев подряд {c['fails']}/{R.FAIL_PAUSE}"
        rows_txt.append(line)
    lines.append(ui.quote("\n".join(rows_txt)) if rows_txt else ui.hint("источников нет"))
    week = int(time.time()) - 3 * 86400
    failed = (await db.q_one("SELECT COUNT(*) n FROM ap_schedule WHERE chat_id=? AND status='failed' AND at>?",
                             cid, week))["n"]
    if failed:
        lines.append(f"📛 не вышло постов за 3 дня: <b>{failed}</b> — можно отправить ещё раз")
    if not bad and not failed and rs:
        lines.append(ui.hint("всё в порядке 💚"))
    kb_r = []
    if failed:
        kb_r.append([(f"🔁 Повторить упавшие · {failed}", f"ap:hcfix:{cid}", "success")])
    for r in rs:
        if not r["active"]:
            kb_r.append([(f"▶️ Включить «{r['title'][:20]}»", f"ap:ra:{r['id']}")])
    kb_r.append([("🔄 Обновить", f"ap:hc:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")])
    return "\n".join(lines), kb_rows(*kb_r)


@router.callback_query(F.data.startswith("ap:hcfix:"))
async def cb_health_fix(cb: CallbackQuery):
    """Упавшие посты (сеть, права) — обратно в очередь с интервалом 2 мин, чтобы не залпом."""
    import time
    import db
    cid = await _own(cb)
    if not cid:
        return
    rows = await db.q_all("SELECT id FROM ap_schedule WHERE chat_id=? AND status='failed' AND at>? ORDER BY at",
                          cid, int(time.time()) - 3 * 86400)
    now = int(time.time())
    for i, r in enumerate(rows):
        await db.q_run("UPDATE ap_schedule SET status='queued', err=NULL, at=? WHERE id=?", now + 60 + i * 120, r["id"])
    await cb.answer(f"вернула в очередь: {len(rows)}", show_alert=True)
    text, kb = await health_view(cb.bot, cid, cb.from_user.id)
    await show(cb, text, kb)


@router.callback_query(F.data.startswith("ap:wk:"))
async def cb_week(cb: CallbackQuery):
    """Очередь на 7 дней одной картинкой."""
    import json
    import time
    import ui
    import uikit
    import gameart
    cid = await _own(cb)
    if not cid:
        return
    ch = await store.channel(cid)
    q = await store.queue_of(cb.from_user.id, cid, limit=80)
    posts = []
    for s in q:
        media = json.loads(s.get("pmedia") or "[]")
        kind = media[0].get("type", "photo") if media else "text"
        txt = re.sub(r"<[^>]+>", "", s.get("ptext") or "").strip().split("\n")[0][:40]
        posts.append((s["at"], kind, txt))
    now = int(time.time())
    in_week = [p for p in posts if p[0] < now + 7 * 86400]
    text = (ui.head("🗓", "Неделя", escape(ch["title"])) + "\n"
            + ui.stats(("📅 постов на 7 дней", len(in_week)), ("📦 всего в очереди", len(posts)))
            + "\n" + ui.hint("цвет точки: 🔵 фото · 🔴 видео · 🟢 трек · 🟡 гиф · ⚪ текст. "
                             "источники добавят посты ещё — здесь то, что уже стоит в очереди"))
    kb = kb_rows([("📅 Очередь списком", f"ap:queue:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")])
    title = ch["title"]
    await cb.answer()
    await uikit.with_card(lambda: gameart.week(title, in_week, now), lambda: show(cb, text, kb))
