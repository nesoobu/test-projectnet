"""Волна 65: обложки экранов и карточка профиля.
Как устроена обложка (по гайдам баннеров: один фокус, крупный заголовок, контраст ≥ 4.5:1, ≤ 2 шрифтов):
• фон — ИЛЛЮСТРАЦИЯ с маскотом Соней (рисует pollinations один раз, лежит в data/banners/bg_<раздел>.jpg).
  Героиня справа, слева пусто — там текст. Нет картинки (нет сети/ключа) — запасной фон: градиент + свечение.
• слева тёмная дымка (градиент ~88% → 0%) — белый текст читается на любом рисунке;
• заголовок 1–2 слова — Unbounded ExtraBold, крупно (подбирается по ширине); подпись ≤ 6 слов — Manrope;
• «таблетка» sonya и акцентная черта цвета раздела.
Готовая обложка кэшируется: в Telegram — по file_id (kv banner:<имя>:<версия>), версия меняется вместе с фоном."""
import io
import logging
import math
import os
import random
from functools import lru_cache
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter, ImageFont

log = logging.getLogger("banners")
VER = "2"
W, H = 1280, 560
FONTS = Path(__file__).parent / "assets" / "fonts"
BG_DIR = Path(__file__).parent / "data" / "banners"
HEAD_FONT, TEXT_FONT, TAG_FONT = "Unbounded-ExtraBold.ttf", "Manrope-SemiBold.ttf", "Manrope-Bold.ttf"

MASCOT = ("a cute anime girl named Sonya with a short dark bob haircut, violet eyes, big over-ear headphones "
          "and an oversized hoodie")
STYLE = ("she is on the right third of the frame, the left half is calm dark empty background for text, "
         "cinematic soft rim light, vibrant digital illustration, detailed, high quality, "
         "no text, no letters, no logo, no watermark")
# раздел → (заголовок, подпись, градиент запасного фона, цвет акцента, фигура запасного фона, сцена для рисунка)
THEMES = {
    "home": ("Соня", "болтаю · качаю · рисую · играю", ((24, 16, 52), (126, 34, 110)), (255, 92, 170), "spark",
             "waving hello in a cozy neon-lit bedroom at night with fairy lights, purple and pink palette"),
    "help": ("Что я умею", "просто пиши: «Соня, …»", ((10, 24, 54), (32, 96, 168)), (90, 190, 255), "ring",
             "holding a glowing tablet with floating holographic app icons, deep blue night palette"),
    "games": ("Игры", "монетки · дуэли · колесо · мафия", ((44, 14, 8), (196, 84, 20)), (255, 190, 60), "dice",
              "holding a game controller, floating dice and shiny gold coins around, warm orange arcade lights"),
    "tools": ("Инструменты", "скачать · озвучить · нарисовать", ((6, 36, 40), (16, 128, 120)), (90, 255, 210),
              "bolt", "at a desk with a laptop, floating music notes, paint brushes and video frames, teal palette"),
    "plus": ("Соня+", "без лимитов и очередей", ((38, 26, 6), (170, 120, 20)), (255, 220, 120), "crown",
             "wearing a tiny golden crown, golden sparkles around, luxurious gold and amber palette"),
    "gifts": ("Подарки", "сердечки, мишки и алмазы", ((52, 8, 30), (196, 40, 90)), (255, 130, 170), "heart",
              "hugging a big wrapped gift box with a ribbon, small hearts and a teddy bear around, pink palette"),
    "giveaway": ("Розыгрыши", "честно · с капчей · кубиком", ((10, 40, 20), (40, 150, 80)), (140, 255, 160),
                 "star", "holding a golden ticket, colorful confetti falling, celebration, emerald green palette"),
    "autopost": ("Автопостинг", "каналы ведут себя сами", ((14, 20, 50), (70, 60, 180)), (160, 150, 255), "ring",
                 "surrounded by floating smartphone screens and paper planes, indigo and violet palette"),
}


def _font(name: str, size: int):
    try:
        return ImageFont.truetype(str(FONTS / name), size)
    except OSError:
        try:
            return ImageFont.truetype(str(FONTS / "RussoOne.ttf"), size)
        except OSError:
            return ImageFont.load_default()


def _gradient(c1, c2, w=W, h=H) -> Image.Image:
    small = Image.new("RGB", (64, 32))
    px = small.load()
    for x in range(64):
        for y in range(32):
            t = (x / 63 * 0.7 + y / 31 * 0.3)
            px[x, y] = tuple(int(c1[i] + (c2[i] - c1[i]) * t) for i in range(3))
    return small.resize((w, h), Image.BICUBIC)


def _glow(im: Image.Image, color, rng: random.Random, n=4):
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    for _ in range(n):
        r = rng.randint(140, 320)
        x, y = rng.randint(im.width // 2, im.width + 80), rng.randint(-80, im.height + 40)
        d.ellipse([x - r, y - r, x + r, y + r], fill=color + (rng.randint(50, 95),))
    layer = layer.filter(ImageFilter.GaussianBlur(90))
    im.paste(layer, (0, 0), layer)


def _grain(im: Image.Image, alpha=14):
    noise = Image.effect_noise(im.size, 40).convert("L").point(lambda v: 128 + (v - 128) // 4)
    im.paste(Image.merge("RGB", (noise, noise, noise)), (0, 0), Image.new("L", im.size, alpha))


def _glass(im: Image.Image, box, radius: int, alpha: int, outline=None, width: int = 2):
    """Полупрозрачная «стеклянная» плашка (на RGB с альфой не рисуют — накладываем слой)."""
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).rounded_rectangle(box, radius=radius, fill=(255, 255, 255, alpha),
                                            outline=(outline + (255,)) if outline else None, width=width)
    im.paste(layer, (0, 0), layer)


def _icon(d: ImageDraw.ImageDraw, kind: str, cx: int, cy: int, r: int, col):
    """Крупная полупрозрачная фигура — только на запасном фоне без рисунка."""
    if kind == "ring":
        for k in range(3):
            rr = r - k * 46
            d.ellipse([cx - rr, cy - rr, cx + rr, cy + rr], outline=col, width=10 - k * 2)
    elif kind == "spark":
        for a in range(4):
            ang = a * math.pi / 2
            d.polygon([(cx, cy), (cx + math.cos(ang + 0.2) * r * 0.35, cy + math.sin(ang + 0.2) * r * 0.35),
                       (cx + math.cos(ang) * r, cy + math.sin(ang) * r),
                       (cx + math.cos(ang - 0.2) * r * 0.35, cy + math.sin(ang - 0.2) * r * 0.35)], fill=col)
        d.ellipse([cx - r * 0.18, cy - r * 0.18, cx + r * 0.18, cy + r * 0.18], fill=col)
    elif kind == "dice":
        s = r * 0.8
        d.rounded_rectangle([cx - s, cy - s, cx + s, cy + s], radius=int(s * 0.25), outline=col, width=12)
        for dx, dy in ((-0.45, -0.45), (0, 0), (0.45, 0.45), (0.45, -0.45), (-0.45, 0.45)):
            q = s * 0.13
            d.ellipse([cx + dx * s - q, cy + dy * s - q, cx + dx * s + q, cy + dy * s + q], fill=col)
    elif kind == "bolt":
        d.polygon([(cx + r * 0.15, cy - r), (cx - r * 0.45, cy + r * 0.1), (cx - r * 0.02, cy + r * 0.1),
                   (cx - r * 0.2, cy + r), (cx + r * 0.45, cy - r * 0.15), (cx + r * 0.02, cy - r * 0.15)], fill=col)
    elif kind == "crown":
        d.polygon([(cx - r, cy + r * 0.5), (cx - r, cy - r * 0.4), (cx - r * 0.5, cy + r * 0.05), (cx, cy - r * 0.7),
                   (cx + r * 0.5, cy + r * 0.05), (cx + r, cy - r * 0.4), (cx + r, cy + r * 0.5)], fill=col)
    elif kind == "heart":
        q = r * 0.55
        d.ellipse([cx - r, cy - r * 0.6, cx - r + 2 * q, cy - r * 0.6 + 2 * q], fill=col)
        d.ellipse([cx + r - 2 * q, cy - r * 0.6, cx + r, cy - r * 0.6 + 2 * q], fill=col)
        d.polygon([(cx - r * 0.97, cy - r * 0.05), (cx + r * 0.97, cy - r * 0.05), (cx, cy + r)], fill=col)
    elif kind == "star":
        pts = []
        for i in range(10):
            rr = r if i % 2 == 0 else r * 0.42
            a = -math.pi / 2 + i * math.pi / 5
            pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
        d.polygon(pts, fill=col)


# ================= фон-рисунок =================
def bg_path(name: str) -> Path:
    return BG_DIR / f"bg_{name}.jpg"


def version(name: str) -> str:
    """Версия обложки: меняется, когда перерисовали фон → Telegram получит новую картинку, а не старый file_id."""
    p = bg_path(name)
    return f"{VER}.{int(p.stat().st_mtime)}" if p.exists() else VER


def _cover(img: Image.Image) -> Image.Image:
    """Вписать рисунок «cover»: заполнить кадр, обрезав лишнее (фокус чуть правее центра — там героиня)."""
    k = max(W / img.width, H / img.height)
    img = img.convert("RGB").resize((max(W, round(img.width * k)), max(H, round(img.height * k))), Image.LANCZOS)
    x = min(img.width - W, max(0, int((img.width - W) * 0.6)))
    y = max(0, (img.height - H) // 2)
    return img.crop((x, y, x + W, y + H))


def _scrim(im: Image.Image, tint, busy: bool):
    """Под текстом: размытие рисунка (детали не спорят с буквами) + тёмная дымка слева + виньетка снизу.
    Оттенок раздела, а не чистый чёрный — смотрится мягче. busy — фон-рисунок (на запасном градиенте мягче)."""
    top = 238 if busy else 200
    row = [int(top * min(1.0, max(0.0, 1.25 - x / (W * 0.62))) ** 1.1) for x in range(W)]
    col = [int(130 * max(0.0, (y - H * 0.55) / (H * 0.45)) ** 2) for y in range(H)]
    mask = Image.new("L", (W, H))
    mask.putdata([min(255, max(r, c)) for c in col for r in row])
    if busy:
        im.paste(im.filter(ImageFilter.GaussianBlur(16)), (0, 0), mask)
    im.paste(Image.new("RGB", (W, H), tuple(int(c * 0.3) for c in tint)), (0, 0), mask)


def _fit(text: str, font_name: str, max_w: int, start: int, min_size: int):
    size = start
    while size > min_size:
        f = _font(font_name, size)
        if f.getbbox(text)[2] <= max_w:
            return f
        size -= 4
    return _font(font_name, min_size)


def _shadow_text(im: Image.Image, xy, text, font, fill=(255, 255, 255), anchor="ls", blur=10, alpha=170):
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).text((xy[0] + 3, xy[1] + 5), text, font=font, fill=(0, 0, 0, alpha), anchor=anchor)
    layer = layer.filter(ImageFilter.GaussianBlur(blur))
    im.paste(layer, (0, 0), layer)
    ImageDraw.Draw(im).text(xy, text, font=font, fill=fill, anchor=anchor)


def render(name: str) -> bytes:
    title, sub, (c1, c2), accent, icon, _scene = THEMES[name]
    rng = random.Random(name)
    im = None
    p = bg_path(name)
    if p.exists():
        try:
            im = _cover(Image.open(p))
        except Exception as e:
            log.warning("фон %s битый: %s", name, e)
    busy = im is not None
    if im is None:   # запасной фон: градиент + свечение + фигура
        im = _gradient(c1, c2)
        _glow(im, accent, rng)
        layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
        _icon(ImageDraw.Draw(layer), icon, int(W * 0.8), H // 2, 190, accent + (70,))
        layer = layer.filter(ImageFilter.GaussianBlur(1.2))
        im.paste(layer, (0, 0), layer)
    _scrim(im, c1, busy)
    _grain(im)
    tag = _font(TAG_FONT, 26)
    _glass(im, [72, 64, 72 + 150, 64 + 46], 23, 40, accent)
    ImageDraw.Draw(im).text((72 + 75, 64 + 22), "sonya", font=tag, fill=(255, 255, 255), anchor="mm")
    big = _fit(title, HEAD_FONT, int(W * 0.56), 120, 60)
    _shadow_text(im, (70, 328), title, big)
    small = _fit(sub, TEXT_FONT, int(W * 0.56), 40, 26)
    _shadow_text(im, (74, 398), sub, small, fill=(240, 236, 250), blur=6, alpha=150)
    ImageDraw.Draw(im).rounded_rectangle([74, 436, 74 + 120, 444], radius=4, fill=accent)
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88, optimize=True)
    return buf.getvalue()


@lru_cache(maxsize=32)
def _cached(name: str, ver: str) -> bytes:
    return render(name)


def cached(name: str) -> bytes:
    return _cached(name, version(name))


# ================= рисуем фоны (pollinations, как /draw) =================
def prompt(name: str) -> str:
    return f"{MASCOT}, {THEMES[name][5]}, {STYLE}"


async def draw_bg(name: str, seed: int | None = None) -> bool:
    """Нарисовать фон раздела и положить в data/banners (старый — в _prev). → получилось ли."""
    from urllib.parse import quote
    from handlers import tools
    seed = seed if seed is not None else random.randint(1, 10 ** 6)
    url = (f"https://image.pollinations.ai/prompt/{quote(prompt(name))}?width=1344&height=576&nologo=true"
           f"&seed={seed}&model=flux")
    try:
        data = await tools.fetch_image(url)
        Image.open(io.BytesIO(data)).verify()
    except Exception as e:
        log.info("фон %s не нарисовался: %s", name, e)
        return False
    BG_DIR.mkdir(parents=True, exist_ok=True)
    p = bg_path(name)
    if p.exists():
        os.replace(p, BG_DIR / f"bg_{name}_prev.jpg")
    p.write_bytes(data)
    return True


def restore_prev(name: str) -> bool:
    prev = BG_DIR / f"bg_{name}_prev.jpg"
    if not prev.exists():
        return False
    p = bg_path(name)
    tmp = BG_DIR / f"bg_{name}_tmp.jpg"
    if p.exists():
        os.replace(p, tmp)
    os.replace(prev, p)
    if tmp.exists():
        os.replace(tmp, prev)
    os.utime(p)   # новая версия → новая картинка в Telegram
    return True


async def prepare():
    """При старте Сони: дорисовать фоны, которых ещё нет (по одному, без спешки)."""
    import asyncio
    for i, name in enumerate(THEMES):
        if not bg_path(name).exists():
            await draw_bg(name, seed=1000 + i)
            await asyncio.sleep(3)


# ================= какой экран — какая обложка =================
MATCH = [
    ("🖤 <b>хей,", "home"), ("❔ <b>что я умею</b>", "help"), ("🎮 <b>Игры</b>", "games"),
    ("🛠 <b>Инструменты</b>", "tools"), ("✨ <b>Соня+</b>", "plus"), ("⭐ <b>Звёзды на подарки", "gifts"),
    ("🎁 <b>Подарки друзьям", "gifts"), ("<b>🎁 мои розыгрыши", "giveaway"), ("📢 <b>Автопостинг</b>", "autopost"),
]


def for_text(text: str) -> str | None:
    t = (text or "").lstrip()
    for prefix, name in MATCH:
        if t.startswith(prefix):
            return name
    return None


# ================= карточка профиля =================
def profile_card(name: str, level_n: int, level_title: str, xp: int, start: int, nxt: int,
                 stats: list[tuple[str, str]], plus: bool = False) -> bytes:
    rng = random.Random(name)
    c1, c2 = ((38, 26, 6), (150, 100, 20)) if plus else ((20, 14, 46), (90, 40, 140))
    glow = (255, 215, 110) if plus else (200, 120, 255)
    im = _gradient(c1, c2, 1280, 640)
    _glow(im, glow, rng, 3)
    _grain(im)
    d = ImageDraw.Draw(im)
    d.ellipse([70, 70, 250, 250], fill=glow)
    d.text((160, 162), (name.strip()[:1] or "?").upper(), font=_font(HEAD_FONT, 96), fill=c1, anchor="mm")
    d.text((290, 128), name[:20], font=_fit(name[:20], HEAD_FONT, 900, 60, 34), fill=(255, 255, 255), anchor="lm")
    d.text((292, 205), f"уровень {level_n} · {level_title}" + ("  ·  Соня+" if plus else ""),
           font=_font(TEXT_FONT, 36), fill=(240, 232, 250), anchor="lm")
    x0, y0, x1 = 72, 300, 1208
    _glass(im, [x0, y0, x1, y0 + 34], 17, 40, (255, 255, 255))
    d = ImageDraw.Draw(im)
    frac = 1.0 if not nxt else max(0.03, min(1.0, (xp - start) / max(1, nxt - start)))
    d.rounded_rectangle([x0 + 4, y0 + 4, x0 + 4 + int((x1 - x0 - 8) * frac), y0 + 30], radius=13, fill=glow)
    d.text((x1, y0 + 64), f"{xp} / {nxt} xp" if nxt else f"{xp} xp · максимум", font=_font(TEXT_FONT, 30),
           fill=(235, 230, 245), anchor="rm")
    tiles = [s for s in stats if s[0]][:4]
    tw = (x1 - x0 - 30 * (len(tiles) - 1)) // max(1, len(tiles))
    for i, (label, value) in enumerate(tiles):
        tx = x0 + i * (tw + 30)
        _glass(im, [tx, 420, tx + tw, 580], 28, 26, glow)
        d = ImageDraw.Draw(im)
        d.text((tx + tw // 2, 482), str(value), font=_fit(str(value), HEAD_FONT, tw - 30, 50, 26),
               fill=(255, 255, 255), anchor="mm")
        d.text((tx + tw // 2, 545), label, font=_font(TEXT_FONT, 28), fill=(235, 230, 245), anchor="mm")
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88, optimize=True)
    return buf.getvalue()
