"""Волна 31: видео-инструменты, история, качество, автообновление yt-dlp. Профиль: аргумент 2 (full|dl)."""
import asyncio, os, shutil, subprocess, sys, tempfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import (SendMessage, SendVideo, SendVideoNote, SendAnimation, SendDocument,
                             EditMessageReplyMarkup)

TMP = tempfile.mkdtemp()
VID = os.path.join(TMP, "v.mp4")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=640x360:rate=25:duration=20",
                "-f", "lavfi", "-i", "sine=frequency=300:duration=20", "-c:v", "libx264", "-preset", "ultrafast",
                "-c:a", "aac", "-shortest", VID], check=True)
URL = "https://www.youtube.com/watch?v=abcdefghijk"


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from downloader import core
    from handlers import media, vtools
    import stt
    fmts = [{"height": 360, "vcodec": "avc1", "acodec": "mp4a", "filesize": 5_000_000},
            {"height": 720, "vcodec": "avc1", "acodec": "none", "filesize": 20_000_000},
            {"height": 1080, "vcodec": "avc1", "acodec": "none", "tbr": 4000},
            {"height": 2160, "vcodec": "vp9", "acodec": "none", "filesize": 300_000_000},
            {"vcodec": "none", "acodec": "opus", "filesize": 2_000_000}]
    q = core.qualities(fmts, 60)
    check("качества: 360/720/1080/2160 с размерами (видео+звук)",
          [h for h, _ in q] == [360, 720, 1080, 2160] and q[1][1] == 22_000_000 and q[2][1] == 32_000_000)
    calls = []
    async def dl(url, kind="video", max_h=None, progress=None, **kw):
        calls.append((kind, max_h))
        import uuid
        p = os.path.join(TMP, uuid.uuid4().hex + ".mp4"); shutil.copy(VID, p)
        return {"path": p, "title": "Тест-видео", "duration": 20, "width": 640, "height": max_h or 360}
    async def probe(url):
        return {"title": "Тест-видео", "duration": 20, "collection": False, "is_live": False, "audio_only": False,
                "qualities": q, "thumbnail": "https://i.ytimg.com/vi/x/maxresdefault.jpg", "uploader": "Канал",
                "description": "классное видео #котики #мемы", "views": 1_234_567, "likes": 5400, "comments": 12,
                "date": "20261001"}
    core.download, core.probe = dl, probe
    SENT.clear()
    await dp.feed_update(bot, msg(URL, 60, 60))
    v = H.sent(SendVideo)
    tok = media._token(URL, "youtube", "YouTube")
    check(f"[{P}] видео: «Звук», «Песня», «Ещё»", v and "vt:more:" + tok in str(v[-1].reply_markup)
          and "dl:s:" in str(v[-1].reply_markup))
    check(f"[{P}] файл придержан для инструментов", tok in vtools._keep and os.path.exists(vtools._keep[tok][0]))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:more:{tok}", 60, 60))
    kb = str(H.sent(EditMessageReplyMarkup)[-1].reply_markup)
    check(f"[{P}] меню «Ещё»", all(x in kb for x in ("vt:q:", "vt:doc:", "vt:note:", "vt:gif:", "vt:cut:",
                                                    "vt:info:", "vt:cover:", "vt:txt:", "vt:back:")))
    # качество
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:q:{tok}", 60, 60))
    kb = str(H.sent(SendMessage)[-1].reply_markup)
    check(f"[{P}] качество: 1080p есть, 4K — ⛔", f"vt:qh:1080:{tok}" in kb and "2160p" in kb and "vt:qh:2160" not in kb)
    from handlers import extra
    await extra.grant_plus(60, 1)   # 1080p — с Соней+ (волна 35)
    calls.clear(); SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:qh:1080:{tok}", 60, 60))
    check(f"[{P}] качаю 1080p", calls == [("video", 1080)] and H.sent(SendVideo))
    # без сжатия, кружок, GIF — настоящий ffmpeg
    calls.clear(); SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:doc:{tok}", 60, 60))
    check(f"[{P}] без сжатия — файлом, без повторной загрузки", H.sent(SendDocument) and not calls)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:note:{tok}", 60, 60))
    check(f"[{P}] ⭕ кружок", H.sent(SendVideoNote))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:gif:{tok}", 60, 60))
    check(f"[{P}] 🎞 GIF", H.sent(SendAnimation))
    # обрезка
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:cut:{tok}", 60, 60))
    await dp.feed_update(bot, msg("ну типа", 60, 60))
    check(f"[{P}] обрезка: непонятно — переспрашиваю", any("не поняла" in t for t in texts()))
    SENT.clear()
    await dp.feed_update(bot, msg("0:03-0:08", 60, 60))
    cv = H.sent(SendVideo)
    check(f"[{P}] ✂️ обрезано 0:03–0:08", cv and "0:03–0:08" in cv[-1].caption)
    # инфо и обложка
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:info:{tok}", 60, 60))
    t = texts()[-1]
    check(f"[{P}] ℹ️ инфо: просмотры, лайки, теги", "1.2 млн" in t and "5.4 тыс" in t and "#котики #мемы" in t
          and "01.10.2026" in t)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:cover:{tok}", 60, 60))
    check(f"[{P}] 🖼 обложка файлом", H.sent(SendDocument) and "maxres" in str(H.sent(SendDocument)[-1].document))
    # текст из видео
    async def tr(path): return "привет это длинный текст " * 30
    stt.transcribe = tr
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:txt:{tok}", 60, 60))
    check(f"[{P}] 🗒 текст из видео + «кратко»", any("текст из видео" in x for x in texts())
          and "vt:sum:" in str(H.sent(SendMessage)[-1].reply_markup))
    # кнопки живут после перезапуска (токен в базе)
    await asyncio.sleep(0.05)
    media._tokens.clear()
    rec = await media.get_token(tok)
    check(f"[{P}] ссылка кнопки пережила перезапуск", rec and rec[0] == URL)
    # история
    SENT.clear()
    await dp.feed_update(bot, msg("/history", 60, 60))
    t = texts()[-1]
    check(f"[{P}] 🕘 история", "Тест-видео" in t and f"vh:{tok}:video" in str(H.sent(SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vh:{tok}:video", 60, 60))
    check(f"[{P}] из истории — мгновенно", H.sent(SendVideo) and not calls[1:])
    # 5 ссылок в личке
    calls.clear()
    links = " ".join(f"https://www.youtube.com/watch?v=abcdefghij{i}" for i in range(6))
    await dp.feed_update(bot, msg(links, 61, 61))
    check(f"[{P}] до 5 ссылок за раз", len(calls) == 5)
    check("версии yt-dlp сравниваются", vtools._norm("2026.09.01") == vtools._norm("2026.9.1"))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
