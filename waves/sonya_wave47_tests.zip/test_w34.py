"""Волна 34: «📤 В канал» под скачанным, трек в подписи видео-поста."""
import asyncio, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
from aiogram.methods import SendVideo, SendAudio, SendMessage, EditMessageText, EditMessageCaption
from aiogram.types import Update, CallbackQuery, Message, Chat, User, Video


def cbm(data, uid, message):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data, from_user=User(id=uid, is_bot=False, first_name="Т"),
        message=message))


def vmsg(uid, reply=None, text=None):
    H._uid[0] += 1
    return Message(message_id=H._uid[0], date=datetime.now(), chat=Chat(id=uid, type="private"),
                   video=Video(file_id="VIDX", file_unique_id="v", width=720, height=1280, duration=12),
                   reply_to_message=reply, text=text)


async def main():
    M, bot, dp = await setup()
    from autopost import store, engine
    from downloader import core
    from handlers import comments, music, tochannel
    from downloader import catalog
    await store.add_channel(-100777, 1, "City_N", "cityn")
    async def probe(url): return {"title": "клип", "duration": 12, "collection": False, "is_live": False, "audio_only": False}
    async def dl(url, kind="video", max_h=None, progress=None, **kw): return {"path": "/nonexistent", "title": "клип", "duration": 12}
    core.probe, core.download = probe, dl
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.youtube.com/watch?v=aaaaaaaaaaa", 1, 1))
    check("владелец канала: под видео «📤 В канал»", "tc:go" in str(H.sent(SendVideo)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.youtube.com/watch?v=bbbbbbbbbbb", 60, 60))
    check("у обычного человека кнопки нет", "tc:go" not in str(H.sent(SendVideo)[-1].reply_markup))
    # один канал → сразу «когда?»
    media_msg = vmsg(1)
    SENT.clear()
    await dp.feed_update(bot, cbm("tc:go", 1, media_msg))
    kb = str(H.sent(SendMessage)[-1].reply_markup)
    check("один канал — сразу «когда?»", "tc:now:-100777" in kb and "tc:q:-100777" in kb)
    picker = Message(message_id=500, date=datetime.now(), chat=Chat(id=1, type="private"), text="когда?",
                     reply_to_message=media_msg)
    await dp.feed_update(bot, cbm("tc:now:-100777", 1, picker))
    rows = await store._all("SELECT s.*, p.media FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id")
    check("🚀 сейчас — пост в расписании на сейчас", rows and abs(rows[-1]["at"] - time.time()) < 5
          and "VIDX" in rows[-1]["media"])
    await dp.feed_update(bot, cbm("tc:q:-100777", 1, picker))
    rows = await store._all("SELECT * FROM ap_schedule ORDER BY id")
    check("📅 в очередь — в ближайший слот", rows[-1]["at"] > time.time() + 60)
    await dp.feed_update(bot, cbm("tc:cap:-100777", 1, picker))
    await dp.feed_update(bot, msg("ночной вайб 🌙", 1, 1))
    p = await store._one("SELECT * FROM ap_posts ORDER BY id DESC LIMIT 1")
    check("✏️ с подписью", p["text"] == "ночной вайб 🌙")
    await dp.feed_update(bot, cbm("tc:now:-100777", 2, picker))
    n = len(await store._all("SELECT * FROM ap_schedule"))
    check("чужой канал — нельзя", n == 3)
    # два канала → выбор
    await store.add_channel(-100778, 1, "H9 музыка", "h9")
    SENT.clear()
    await dp.feed_update(bot, cbm("tc:go", 1, media_msg))
    kb = str(H.sent(SendMessage)[-1].reply_markup)
    check("два канала — выбор канала", "tc:ch:-100777" in kb and "tc:ch:-100778" in kb)
    # трек в подписи
    await store.set_channel(-100777, cap_track=1)
    pid = await store.new_post(1, "ночной вайб", [{"type": "video", "src": "VIDX"}], [-100777])
    sid = await store.schedule(pid, -100777, int(time.time()))
    async def rec(bot_, obj): return {"artist": "OXVGEN", "title": "MEMORY", "cover": "", "url": ""}
    comments.recognize_media = rec
    SENT.clear()
    await engine.publish_row(bot, await store.sched(sid))
    await asyncio.sleep(0.2)
    ed = H.sent(EditMessageCaption)
    check("🎶 трек дописан в подпись", ed and ed[-1].caption == "ночной вайб\n\n🎵 OXVGEN — MEMORY")
    await store.set_channel(-100777, cap_track=0)
    pid = await store.new_post(1, "x", [{"type": "video", "src": "VIDX"}], [-100777])
    sid = await store.schedule(pid, -100777, int(time.time()))
    SENT.clear()
    await engine.publish_row(bot, await store.sched(sid))
    await asyncio.sleep(0.2)
    check("выключено — подпись не трогаю", not H.sent(EditMessageCaption))
    # музыка: кнопка под треком
    await catalog.remember([catalog.track("dz", 1, "A", "B", 100)])
    await db.dl_cache_put("audio:dz:1", "audio", "AUD", "A — B")
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:get:dz:1", 1, 1))
    check("под треком тоже «📤 В канал»", "tc:go" in str(H.sent(SendAudio)[-1].reply_markup))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
