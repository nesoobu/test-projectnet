"""Все главные экраны: HTML валиден для Telegram (теги закрыты, только разрешённые), текст ≤ 4096."""
import asyncio, html.parser, re, time
from harness import *  # noqa
import harness as H

ALLOWED = {"b", "i", "u", "s", "code", "pre", "a", "blockquote", "tg-spoiler", "tg-emoji", "strong", "em"}

class V(html.parser.HTMLParser):
    def __init__(self):
        super().__init__(); self.stack = []; self.bad = []
    def handle_starttag(self, t, a):
        if t not in ALLOWED: self.bad.append(t)
        self.stack.append(t)
    def handle_endtag(self, t):
        if not self.stack or self.stack[-1] != t: self.bad.append("/" + t)
        else: self.stack.pop()

def valid(text):
    v = V(); v.feed(text); v.close()
    plain = re.sub(r"<[^>]+>", "", text)
    return not v.bad and not v.stack and len(plain) <= 4096, (v.bad, v.stack)

async def main():
    M, bot, dp = await setup()
    from autopost import store
    from handlers import extra
    await db.touch_user(User(id=1, is_bot=False, first_name="Тим <b>"))
    await db.q_run("UPDATE users SET coins=50, streak=3, refs=2, plus_until=? WHERE id=1", int(time.time()) + 999)
    await store.add_channel(-5, 1, "Канал & <ко>", "ch")
    rid = await store.add_rule(1, -5, "pinterest", "q:авы", "🔎 авы <x>")
    screens = ["m:home", "m:profile", "m:top:xp", "m:top:season_wins", "m:help", "m:tools", "g:menu", "m:plus",
               "m:ref", "m:donate", "m:mode", "m:facts", "m:ach", "adm:home", "ap:home", "ap:help", f"ap:ch:-5",
               f"ap:cs:-5", f"ap:r:{rid}", f"ap:rk:{rid}", f"ap:ro:{rid}", f"ap:kmed:{rid}", f"ap:rhelp:card:{rid}"]
    screens += [f"m:help:{k}" for k in __import__("ui").HELP_SECTIONS]
    for d in screens:
        SENT.clear()
        await dp.feed_update(bot, cbq(d, 1, 1))
        outs = [m for m in SENT if isinstance(m, (H.SendMessage, H.EditMessageText))]
        ok = bool(outs)
        why = "нет ответа"
        for m in outs:
            good, why = valid(m.text)
            ok = ok and good
        check(f"экран {d}: {'ok' if ok else why}", ok)
    SENT.clear()
    await dp.feed_update(bot, msg("/settings", -9, 1))
    t = [m for m in SENT if isinstance(m, H.SendMessage)][-1]
    check("настройки группы: валидно и переключатели ✅/⬜", valid(t.text)[0] and "⬜" in str(t.reply_markup) or "✅" in str(t.reply_markup))
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
