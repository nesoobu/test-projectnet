import asyncio, sys, os, tempfile
p = os.path.join(tempfile.mkdtemp(), "m.db")
async def run(d):
    sys.path.insert(0, d)
    for k in [k for k in list(sys.modules) if k in ("db", "config") or k.startswith("autopost")]: del sys.modules[k]
    import config; config.DB_PATH = p
    import db; db.DB_PATH = p
    from autopost import store
    await db.init(); await store.init()
    return db, store
async def main():
    db, store = await run(sys.argv[1])
    await store.add_channel(-1, 5, "К", "k")
    await db.close(); sys.path.pop(0)
    db, store = await run(sys.argv[2])
    c = await store.channel(-1)
    print("channel kept:", c["title"], "watermark:", repr(c["watermark"]), "dedupe:", c["dedupe_img"])
    await db.close()
asyncio.run(main())
