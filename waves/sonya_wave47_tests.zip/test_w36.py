"""Волна 36: фонд звёзд на подарки, розыгрыши подарков Telegram с выбором победителем."""
import asyncio, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
from aiogram.methods import SendMessage, SendInvoice, SendSticker, AnswerCallbackQuery
from aiogram.types import Update, Message, Chat, User, SuccessfulPayment


def pay(uid, payload, stars):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], message=Message(
        message_id=H._uid[0], date=datetime.now(), chat=Chat(id=uid, type="private"),
        from_user=User(id=uid, is_bot=False, first_name="П"),
        successful_payment=SuccessfulPayment(currency="XTR", total_amount=stars, invoice_payload=payload,
                                             telegram_payment_charge_id=f"c{H._uid[0]}", provider_payment_charge_id="")))


def alerts():
    return [x.text or "" for x in H.sent(AnswerCallbackQuery)]


async def main():
    M, bot, dp = await setup()
    from handlers import gifts, giveaway
    from autopost import store
    G = [{"id": "g15a", "stars": 15, "emoji": "💝", "sticker": "S1"}, {"id": "g15b", "stars": 15, "emoji": "🧸", "sticker": "S2"},
         {"id": "g25", "stars": 25, "emoji": "🌹", "sticker": "S3"}, {"id": "g50", "stars": 50, "emoji": "🎂", "sticker": "S4"}]
    async def cat(bot_): return G
    sent_gifts = []
    async def snd(bot_, uid, gid, text): sent_gifts.append((uid, gid)); return True
    async def bb(bot_): return 1000
    gifts.catalog, gifts.send, gifts.bot_balance = cat, snd, bb
    # ---------- пополнение ----------
    await dp.feed_update(bot, msg("/start", 1, 1))
    SENT.clear()
    await dp.feed_update(bot, cbq("fund:buy:50", 1, 1))
    inv = H.sent(SendInvoice)
    check("пополнение: счёт на 50 ⭐", inv and inv[-1].payload == "fund:50" and inv[-1].currency == "XTR")
    await dp.feed_update(bot, pay(1, "fund:50", 50))
    check("оплата → +50 на подарки", await gifts.balance(1) == 50)
    await dp.feed_update(bot, msg("/fund add 100", 1, 1))
    check("владелец переносит из баланса бота", await gifts.balance(1) == 150)
    SENT.clear()
    await dp.feed_update(bot, msg("/me", 1, 1))
    check("в профиле видно звёзды на подарки", any("на подарки: <b>150</b>" in t for t in texts()))
    # ---------- розыгрыш «на 15 ⭐» ----------
    await store.add_channel(-100777, 1, "City_N", "cityn")
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:stars", 1, 1))
    from aiogram.methods import EditMessageText
    kbs = " ".join(str(getattr(x, "reply_markup", "")) for x in SENT if isinstance(x, (EditMessageText, SendMessage)))
    check("выбор цены подарка: 15/25/50", "gw:ps:15" in kbs and "gw:ps:50" in kbs)
    await dp.feed_update(bot, cbq("gw:ps:15", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:3", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    g = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    check("розыгрыш создан, 45 ⭐ зарезервировано", g["gift_kind"] == "stars" and g["gift_stars"] == 15
          and await gifts.balance(1) == 105)
    # мало звёзд
    await store.add_channel(-100555, 500, "Чужой", None)
    await dp.feed_update(bot, msg("/start", 500, 500))
    await gifts.change(500, 10, "тест")
    await dp.feed_update(bot, msg("/giveaway", 500, 500))
    await dp.feed_update(bot, cbq("gw:pt:stars", 500, 500))
    await dp.feed_update(bot, cbq("gw:ps:15", 500, 500))
    SENT.clear()
    await dp.feed_update(bot, cbq("gw:w:1", 500, 500))
    check("не хватает звёзд — предлагаю пополнить", any("нужно" in t for t in texts())
          and "m:fund" in str(H.sent(SendMessage)[-1].reply_markup))
    # ---------- итоги: 2 участника на 3 места ----------
    for u in (70, 71):
        await dp.feed_update(bot, msg("/start", u, u))
        await db.q_run("INSERT INTO giveaway_users(gid,uid,name) VALUES(?,?,?)", g["id"], u, f"Игрок{u}")
    SENT.clear()
    await giveaway.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"]))
    st = H.sent(SendSticker)
    check("победителям — выбор подарков за 15 ⭐ (стикеры с кнопками)", len(st) == 4
          and "gwc:" in str(st[0].reply_markup) and {s.sticker for s in st} == {"S1", "S2"})
    res = [m for m in H.sent(SendMessage) if m.chat_id == -100777 and "итоги" in m.text]
    check("в канале кнопка «забрать подарок»", res and "start=gwc" in str(res[-1].reply_markup))
    check("за пустое место 15 ⭐ вернулись", await gifts.balance(1) == 120)
    # ---------- выбор подарка ----------
    w = await db.q_one("SELECT * FROM gift_wins WHERE uid=70")
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gwc:{w['id']}:g15b", 71, 71))
    check("чужой приз забрать нельзя", any("не твой" in a for a in alerts()) and not sent_gifts)
    await dp.feed_update(bot, cbq(f"gwc:{w['id']}:g15b", 70, 70))
    check("победитель выбрал — подарок отправлен", sent_gifts == [(70, "g15b")]
          and (await db.q_one("SELECT status FROM gift_wins WHERE id=?", w["id"]))["status"] == "done")
    await dp.feed_update(bot, cbq(f"gwc:{w['id']}:g15a", 70, 70))
    check("второй раз не дарю", len(sent_gifts) == 1 and any("уже вручён" in a for a in alerts()))
    # ---------- /start gwc ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/start gwc", 71, 71))
    check("/start gwc — показываю невыбранный приз", H.sent(SendSticker))
    # ---------- сам дарю через 3 дня ----------
    await db.q_run("UPDATE gift_wins SET ts=? WHERE uid=71", int(time.time()) - 4 * 86400)
    await gifts.auto_claim(bot)
    check("не выбрал за 3 дня — подарила сама", (71, "g15a") in sent_gifts)
    # ---------- конкретный подарок ----------
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:exact", 1, 1))
    await dp.feed_update(bot, cbq("gw:pe:g25", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:1", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    g2 = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    await db.q_run("INSERT INTO giveaway_users(gid,uid,name) VALUES(?,?,?)", g2["id"], 72, "Победитель")
    await dp.feed_update(bot, msg("/start", 72, 72))
    await giveaway.finish(bot, await db.q_one("SELECT * FROM giveaways WHERE id=?", g2["id"]))
    check("конкретный подарок — дарю сразу", (72, "g25") in sent_gifts and await gifts.balance(1) == 95)
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
