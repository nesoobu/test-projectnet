import asyncio
from harness import *  # noqa
import harness as H

async def main():
    M, bot, dp = await setup()
    from autopost import store
    await db.touch_user(User(id=70, is_bot=False, first_name="T"))
    await store.add_channel(-77, 70, "Канал", "ch")
    rid = await store.add_rule(70, -77, "pinterest", "q:авы", "🔎 авы")
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ap:r:{rid}", 70, 70))
    kb = str(H.sent(H.EditMessageText)[-1].reply_markup)
    check("карточка: кнопка помощи и «Сначала мне»", "ap:rhelp:card" in kb and "Сначала мне" in kb)
    await dp.feed_update(bot, cbq(f"ap:rhelp:card:{rid}", 70, 70))
    check("помощь по карточке", "как устроен источник" in H.sent(H.EditMessageText)[-1].text)
    await dp.feed_update(bot, cbq(f"ap:kmed:{rid}", 70, 70))
    m = H.sent(H.EditMessageText)[-1]
    labels = [b.text for r in m.reply_markup.inline_keyboard for b in r]
    check("медиа: список всех вариантов с ✓", labels[:4] == ["✓ фото и видео", "только видео", "только фото", "без медиа"])
    data = [b.callback_data for r in m.reply_markup.inline_keyboard for b in r]
    await dp.feed_update(bot, cbq(data[1], 70, 70))
    r = await store.rule(rid); c = store.cfg_of(r)
    check("выбрано «только видео»", c["media_kind"] == "video" and r["with_media"] == 1)
    check("после выбора — назад в «Контент» с новой подписью", "Медиа: только видео ›" in str(H.sent(H.EditMessageText)[-1].reply_markup))
    await dp.feed_update(bot, cbq(data[3], 70, 70))
    check("«без медиа» выключает медиа", (await store.rule(rid))["with_media"] == 0)
    await dp.feed_update(bot, cbq(f"ap:kpr:{rid}", 70, 70))
    d2 = [b.callback_data for r in H.sent(H.EditMessageText)[-1].reply_markup.inline_keyboard for b in r]
    await dp.feed_update(bot, cbq(d2[2], 70, 70))
    check("за раз: 3", store.cfg_of(await store.rule(rid))["per_run"] == 3)
    await dp.feed_update(bot, cbq(f"ap:orc:{rid}", 70, 70))
    d3 = [b.callback_data for r in H.sent(H.EditMessageText)[-1].reply_markup.inline_keyboard for b in r]
    await dp.feed_update(bot, cbq(d3[2], 70, 70))
    check("реакции: выбран набор 2, назад в «Оформление»", store.cfg_of(await store.rule(rid))["reacts"] == 2
          and "оформление" in H.sent(H.EditMessageText)[-1].text.lower())
    await dp.feed_update(bot, cbq(f"ap:osl:{rid}", 70, 70))
    check("без звука — переключатель ✅", "Без звука ✅" in str(H.sent(H.EditMessageText)[-1].reply_markup))
    await dp.feed_update(bot, cbq(f"ap:ps:99:0:{rid}", 70, 70))
    await dp.feed_update(bot, cbq(f"ap:ps:0:99:{rid}", 70, 70))
    check("кривые кнопки ничего не ломают", store.cfg_of(await store.rule(rid))["per_run"] == 3)
    await dp.feed_update(bot, cbq(f"ap:kpr:{rid}", 71, 71))
    check("чужой источник не открыть", "Сколько" not in (H.sent(H.EditMessageText)[-1].text or "") )
    from handlers import ap_rules as A
    longest = max(len(f"ap:ps:{len(A.PICK_KEYS)}:9:2147483647".encode()), len(f"ap:rhelp:content:2147483647".encode()))
    check("callback_data ≤ 64 байт", longest <= 64)
    for sec in ("content", "look"):
        await dp.feed_update(bot, cbq(f"ap:rhelp:{sec}:{rid}", 70, 70))
    check("помощь по контенту и оформлению", "оформление" in H.sent(H.EditMessageText)[-1].text)
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
