import asyncio, time
from harness import *  # noqa
import harness as H
from aiogram.methods import SendMessageDraft, SetMyDescription, SetMyShortDescription, GetMyDescription, GetMyShortDescription

async def main():
    M, bot, dp = await setup()
    import llm, config
    from handlers import chat, rp
    for i in (60, 61, 62):
        await db.touch_user(User(id=i, is_bot=False, first_name=f"U{i}"))
    # эфемерные ответы в группе
    SENT.clear()
    await dp.feed_update(bot, msg("/bonus", -600, 60, "U60"))
    sm = H.sent(H.SendMessage)[-1]
    check("/bonus в группе — эфемерно для автора", sm.ephemeral_message_parameters and sm.ephemeral_message_parameters.receiver_user_id == 60)
    await dp.feed_update(bot, msg("/me", -600, 60, "U60"))
    check("свой /me в группе — эфемерно", H.sent(H.SendMessage)[-1].ephemeral_message_parameters is not None)
    await dp.feed_update(bot, msg("/me", -600, 60, "U60", reply=reply_to(61, "U61", chat_id=-600)))
    check("чужой профиль — публично", H.sent(H.SendMessage)[-1].ephemeral_message_parameters is None)
    await dp.feed_update(bot, msg("/memory", -600, 60, "U60"))
    check("/memory в группе — только себе", H.sent(H.SendMessage)[-1].ephemeral_message_parameters is not None)
    await dp.feed_update(bot, msg("/bonus", 60, 60))
    check("в личке — обычный ответ", H.sent(H.SendMessage)[-1].ephemeral_message_parameters is None)
    # нативный стриминг
    config.STREAM = True
    chat.DRAFT_EVERY = 0
    chat.VOICE_REPLY_CHANCE = chat.NIGHT_VOICE_CHANCE = 0
    async def st(msgs, **k):
        for p in ["При", "вет, ", "как ", "дела?"]:
            yield p
    llm.stream = st
    SENT.clear()
    await dp.feed_update(bot, msg("хай", 61, 61))
    drafts = H.sent(SendMessageDraft)
    check("стрим: черновики в личке", len(drafts) >= 3 and drafts[0].text == "" and drafts[-1].text.startswith("Привет"))
    check("стрим: черновик один и тот же (анимация)", len({d.draft_id for d in drafts}) == 1)
    final = [m for m in H.sent(H.SendMessage) if m.chat_id == 61]
    check("стрим: финал — настоящее сообщение", final and final[-1].text == "Привет, как дела?")
    check("стрим: без правок сообщений", not H.sent(H.EditMessageText))
    # черновик не поддерживается → правки
    orig = H.Mock._make
    async def nodraft(self, bot_, method):
        if isinstance(method, SendMessageDraft):
            from aiogram.exceptions import TelegramBadRequest
            raise TelegramBadRequest(method=method, message="method not found")
        return await orig(self, bot_, method)
    H.Mock._make = nodraft
    chat.STREAM_FIRST = 3; chat.STREAM_EVERY = 0
    SENT.clear()
    await dp.feed_update(bot, msg("хай", 62, 62))
    check("нет черновиков — старый способ правками", H.sent(H.EditMessageText) and H.sent(H.EditMessageText)[-1].text == "Привет, как дела?")
    H.Mock._make = orig
    config.STREAM = False
    # РП
    SENT.clear()
    await dp.feed_update(bot, msg("обнять крепко", -600, 60, "U60", reply=reply_to(61, "U61", chat_id=-600)))
    t = texts()[-1]
    check("РП: обнимашки с двумя ссылками и комментарием", "🤗" in t and "id=60" in t and "id=61" in t and "крепко" in t)
    SENT.clear()
    await dp.feed_update(bot, msg("обнять", -600, 60, "U60", reply=reply_to(60, "U60", chat_id=-600)))
    check("РП: сам себя — молчим", not [m for m in H.sent(H.SendMessage) if "🤗" in m.text])
    await dp.feed_update(bot, msg("пять", -600, 60, "U60", reply=reply_to(61, "U61", chat_id=-600)))
    check("РП: обычное слово «пять» — не действие", not any("дай пять" in t for t in texts()))
    await db.set_chat_flag(-600, "rp", False)
    SENT.clear()
    await dp.feed_update(bot, msg("кусь", -600, 60, "U60", reply=reply_to(61, "U61", chat_id=-600)))
    check("РП выключено в настройках — тишина", not any("кусь" in t for t in texts()))
    # пара и звезда дня
    await dp.feed_update(bot, msg("hi", -600, 61, "U61"))
    await dp.feed_update(bot, msg("hi", -600, 62, "U62"))
    SENT.clear()
    await dp.feed_update(bot, msg("/pair", -600, 60, "U60"))
    p1 = texts()[-1]
    await dp.feed_update(bot, msg("/pair", -600, 61, "U61"))
    check("пара дня: выбрана и та же весь день", "Пара дня" in p1 and texts()[-1] == p1)
    await dp.feed_update(bot, msg("/hero", -600, 60, "U60"))
    check("звезда дня", "Звезда дня" in texts()[-1])
    await dp.feed_update(bot, msg("/pair", -601, 60, "U60"))
    check("пара: мало людей — честно говорит", "мало активных" in texts()[-1])
    # поделиться
    from handlers import luck
    luck.SPIN = ["🎡"]
    await db.kv_set("wheel:60", "0")
    SENT.clear()
    await dp.feed_update(bot, msg("/wheel", 60, 60))
    kb = [m for m in SENT if getattr(m, "reply_markup", None)][-1].reply_markup
    urls = [b.url for r in kb.inline_keyboard for b in r if b.url]
    check("колесо: кнопка «Похвастаться» со ссылкой и рефкой", urls and "t.me/share/url" in urls[0] and "ref_60" in urls[0])
    await db.q_run("UPDATE users SET bday='01.08' WHERE id=60")
    async def say(model, messages, mt, t, url=None, key=None, extra=None):
        return "всё будет хорошо", 1
    llm._call = say
    SENT.clear()
    await dp.feed_update(bot, msg("/horo", 60, 60))
    check("гороскоп: кнопка «Отправить другу»", "share/url" in str(H.sent(H.SendMessage)[-1].reply_markup))
    # профиль бота
    orig2 = H.Mock._make
    async def desc(self, bot_, method):
        if isinstance(method, GetMyDescription):
            from aiogram.types import BotDescription
            return BotDescription(description="старое")
        if isinstance(method, GetMyShortDescription):
            from aiogram.types import BotShortDescription
            return BotShortDescription(short_description="старое")
        return await orig2(self, bot_, method)
    H.Mock._make = desc
    SENT.clear()
    await dp.feed_update(bot, cbq("adm:bio", 1, 1))
    check("профиль бота: показывает текущее и предложенное", any("предлагаю" in (t or "") for t in texts()))
    await dp.feed_update(bot, cbq("adm:bioset", 1, 1))
    sd = [m for m in SENT if isinstance(m, SetMyDescription)]
    ss = [m for m in SENT if isinstance(m, SetMyShortDescription)]
    check("профиль бота: описание поставлено (≤512/≤120)", sd and ss and len(sd[0].description) <= 512 and len(ss[0].short_description) <= 120)
    H.Mock._make = orig2
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
