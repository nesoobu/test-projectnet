"""Волна 29: музыка как у больших ботов. Профиль: аргумент 2 (full|music)."""
import asyncio, sys
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMessage, EditMessageText, SendAudio, SendPhoto, AnswerInlineQuery
from aiogram.types import Update, InlineQuery, User


def iq(text, uid=90):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], inline_query=InlineQuery(
        id=str(H._uid[0]), from_user=User(id=uid, is_bot=False, first_name="И"), query=text, offset=""))


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from downloader import catalog, core
    from handlers import music, solo
    T = catalog.track
    ozma = [T("ym", 100 + i, "Ozma" if i == 0 else f"Артист {i}", "Эхо" if i == 0 else f"Песня {i}", 179,
              "https://c/x.jpg", "Альбом", 7) for i in range(12)]
    calls = []
    async def ym_search(q, n): calls.append(("ym", q)); return ozma[:n]
    async def ym_fail(q, n): raise RuntimeError("geo")
    async def dz_search(q, n): calls.append(("dz", q)); return [T("dz", 5, "Deezer", "Трек", 100)]
    catalog.ym_search, catalog.dz_search = ym_fail, dz_search
    r = await catalog.search("x", 5)
    check("каталог: Яндекс упал — берём Deezer", r and r[0]["src"] == "dz" and catalog.STATUS["ym"] == "geo")
    catalog.ym_search = ym_search
    # подбор звука на YouTube
    cands = [{"id": "slow", "title": "Ozma - Эхо (slowed + reverb)", "duration": 230, "channel": "x"},
             {"id": "long", "title": "Эхо разбор", "duration": 790, "channel": "y"},
             {"id": "good", "title": "Эхо", "duration": 180, "channel": "Ozma - Topic"}]
    catalog._yt_flat = lambda q, n: cands
    check("подбор: оригинал по длительности, не slowed", await catalog.audio_url(ozma[0]) == "https://youtu.be/good")
    yt = await catalog.yt_search("эхо", 5)
    check("YouTube-запасной: без 13-минутных роликов, «артист - трек» разобран",
          [t["id"] for t in yt] == ["slow", "good"] and yt[0]["artist"] == "Ozma" and yt[1]["artist"] == "Ozma")
    # поиск → нумерованный список
    SENT.clear()
    if P == "music":
        await dp.feed_update(bot, msg("эхо ozma", 91, 91))
    else:
        await dp.feed_update(bot, msg("/find эхо ozma", 91, 91))
    ed = H.sent(EditMessageText)[-1]
    kb = str(ed.reply_markup)
    check(f"[{P}] список: «1. Ozma — Эхо 2:59», номера-кнопки", "<b>1.</b> Ozma — <b>Эхо</b> <i>2:59</i>" in ed.text
          and "mx:get:ym:100" in kb and "'1'" in kb)
    check(f"[{P}] список: 8 на странице и листалка", "mx:get:ym:108" not in kb and "1 / 2" in kb)
    sid = [k for k in music._S][-1]
    SENT.clear()
    await dp.feed_update(bot, cbq(f"ms:{sid}:1", 91, 91))
    check(f"[{P}] вторая страница", "<b>9.</b>" in H.sent(EditMessageText)[-1].text)
    # выбор трека
    got = []
    async def dl(url, kind): got.append(url); return {"path": "/nonexistent.mp3", "title": "yt", "duration": 179}
    async def fb(url, limit=0):
        import io
        from PIL import Image
        b = io.BytesIO(); Image.new("RGB", (600, 600)).save(b, "JPEG"); return b.getvalue()
    core.download, core.fetch_bytes = dl, fb
    from aiogram.types import FSInputFile
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:get:ym:100", 91, 91))
    a = H.sent(SendAudio)
    check(f"[{P}] трек: теги из каталога + обложка", a and a[-1].title == "Эхо" and a[-1].performer == "Ozma"
          and a[-1].thumbnail is not None and got == ["https://youtu.be/good"])
    kb = str(a[-1].reply_markup)
    check(f"[{P}] под треком: текст, ❤️, похожие, артист", all(x in kb for x in ("mx:ly:", "mx:fav:", "mx:sim:", "mx:art:")))
    await db.dl_cache_put("audio:ym:100", "audio", "FID100", "Ozma — Эхо")
    got.clear(); SENT.clear()
    await dp.feed_update(bot, cbq("mx:get:ym:100", 91, 91))
    check(f"[{P}] повторно — из кэша, без скачивания", not got and H.sent(SendAudio)[-1].audio == "FID100")
    # избранное
    await dp.feed_update(bot, cbq("mx:fav:ym:100", 91, 91))
    SENT.clear()
    await dp.feed_update(bot, msg("/my", 91, 91))
    check(f"[{P}] /my — мои треки", any("твои треки" in t and "Эхо" in t for t in texts()))
    await dp.feed_update(bot, cbq("mx:fav:ym:100", 91, 91))
    SENT.clear()
    await dp.feed_update(bot, msg("/my", 91, 91))
    check(f"[{P}] убрала — пусто", any("пока пусто" in t for t in texts()))
    # похожие
    async def sim(t): return ozma[3:6]
    catalog.ym_similar = sim
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:sim:ym:100", 91, 91))
    check(f"[{P}] 🔁 похожие — список", any("похожее на" in t and "Песня 3" in t for t in texts()))
    # чарт
    async def ch(): return ozma[:3]
    catalog.ym_chart = ch
    SENT.clear()
    await dp.feed_update(bot, msg("/top" if P == "music" else "/chart", 91, 91))
    check(f"[{P}] чарт", any("чарт" in t and "Ozma" in t for t in texts()))
    # шазам → карточка с обложкой
    st = await bot.send_message(92, "🎧 слушаю…")
    SENT.clear()
    await music.found_card(st, "Ozma", "Эхо", "https://c/sz.jpg", "https://shazam/1")
    ph = H.sent(SendPhoto)
    check(f"[{P}] шазам: обложка + «Скачать» из каталога", ph and "mx:get:ym:100" in str(ph[-1].reply_markup))
    if P == "full":
        SENT.clear()
        await dp.feed_update(bot, msg("/top", 91, 91))
        check("full: /top — по-прежнему рейтинг, не чарт", not any("что слушают" in t for t in texts()))
        return await done()
    # инлайн
    solo.INLINE_PAUSE = 0
    SENT.clear()
    await dp.feed_update(bot, iq("эхо"))
    res = H.sent(AnswerInlineQuery)[-1].results
    check("music inline: скачанный — сразу аудио, остальные — карточки",
          getattr(res[0], "audio_file_id", None) == "FID100" and res[1].title == "Артист 1 — Песня 1"
          and "start=t_ym_101" in str(res[1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, msg("/start t_ym_101", 93, 93))
    check("music: из инлайн-карточки в бота — сразу трек", H.sent(SendAudio) and H.sent(SendAudio)[-1].performer == "Артист 1")
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 94, 94))
    check("music: на старте кнопки «Чарт» и «Мои треки»", "mx:top" in str(H.sent(SendMessage)[-1].reply_markup))
    await done()


async def done():
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
