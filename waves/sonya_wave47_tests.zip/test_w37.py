"""Волна 37: розыгрыши — спонсоры, билеты за друзей, Premium, итоги по числу, картинка, перевыбор, отмена, бот gw."""
import asyncio, sys, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import (SendMessage, SendPhoto, SendDocument, AnswerCallbackQuery, EditMessageText,
                             EditMessageCaption, SetMyCommands)
from aiogram.types import Update, CallbackQuery, Message, Chat, User


def cbu(data, uid, premium=False, chat_id=None, mid=1):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], callback_query=CallbackQuery(
        id=str(H._uid[0]), chat_instance="x", data=data,
        from_user=User(id=uid, is_bot=False, first_name=f"U{uid}", is_premium=premium),
        message=Message(message_id=mid, date=datetime.now(), text="x",
                        chat=Chat(id=chat_id or uid, type="private" if (chat_id or uid) > 0 else "channel"))))


def alerts():
    return [x.text or "" for x in H.sent(AnswerCallbackQuery)]


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import giveaway, gifts
    from autopost import store
    # ---------- подключение канала прямо из розыгрыша ----------
    await dp.feed_update(bot, msg("/start", 1, 1))
    SENT.clear()
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    check(f"[{P}] нет каналов — объясняю, как подключить", any("добавь меня в канал" in t for t in texts()))
    H.ADMINS.add(1)
    from aiogram.types import MessageOriginChannel
    await dp.feed_update(bot, msg("пост", 1, 1, forward_origin=MessageOriginChannel(
        type="channel", date=datetime.now(), chat=Chat(id=-100777, type="channel", title="City_N"), message_id=5)))
    chs = await store.channels(1)
    check(f"[{P}] канал подключён пересылкой поста", len(chs) == 1)
    cid = chs[0]["chat_id"]
    # ---------- создание: свой приз, 2 победителя, 1 час, все опции ----------
    await dp.feed_update(bot, cbq("gw:pt:text", 1, 1))
    await dp.feed_update(bot, msg("AirPods", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:2", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    await dp.feed_update(bot, cbq("gw:o:ref", 1, 1))
    await dp.feed_update(bot, cbq("gw:o:sp", 1, 1))
    H.ADMINS.add(999)   # бот — админ у спонсора
    await dp.feed_update(bot, msg("-100555", 1, 1))
    await dp.feed_update(bot, msg("готово", 1, 1))
    await dp.feed_update(bot, cbq("gw:o:ph", 1, 1))
    from aiogram.types import PhotoSize
    await dp.feed_update(bot, msg(None, 1, 1, photo=[PhotoSize(file_id="PIC", file_unique_id="p", width=1, height=1)]))
    SENT.clear()
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    ph = H.sent(SendPhoto)
    check(f"[{P}] пост с картинкой, спонсором и билетами", ph and ph[-1].photo == "PIC" and "условия" in ph[-1].caption
          and "+1 билет" in ph[-1].caption and "start=gwr_" in str(ph[-1].reply_markup))
    g = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    # ---------- участие ----------
    H.LEFT.add(10)
    SENT.clear()
    await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", 10))
    check(f"[{P}] не подписан — не пускаю", any("подпишись" in a for a in alerts()))
    H.LEFT.discard(10)
    await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", 10))
    await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", 10))
    check(f"[{P}] вступил, второй раз — «уже участвуешь»", any("в игре" in a for a in alerts())
          and any("уже участвуешь" in a for a in alerts()))
    # друг по ссылке
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwj_{g['id']}_10", 11, 11))
    check(f"[{P}] приглашённый видит розыгрыш и кнопку", f"gw:jb:{g['id']}:10" in str(H.sent(SendMessage)[-1].reply_markup))
    await dp.feed_update(bot, cbu(f"gw:jb:{g['id']}:10", 11))
    t = (await db.q_one("SELECT tickets FROM giveaway_users WHERE gid=? AND uid=10", g["id"]))["tickets"]
    check(f"[{P}] пригласившему +1 билет", t == 2)
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start gwr_{g['id']}", 10, 10))
    check(f"[{P}] /start gwr — мои билеты и ссылка", any("билеты: <b>2</b>" in x and f"gwj_{g['id']}_10" in x for x in texts()))
    for u in (12, 13, 14):
        await dp.feed_update(bot, cbu(f"gw:j:{g['id']}", u))
    # ---------- взвешенный выбор детерминирован по seed ----------
    us = [{"uid": i, "name": str(i), "tickets": 1} for i in range(5)] + [{"uid": 99, "name": "big", "tickets": 50}]
    wins = sum(1 for s in range(200) if giveaway.draw(us, 1, f"s{s}")[0]["uid"] == 99)
    check("больше билетов — чаще побеждает", wins > 150)
    check("seed даёт тот же результат", giveaway.draw(us, 3, "abc") == giveaway.draw(us, 3, "abc"))
    # ---------- итоги ----------
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:end:{g['id']}", 1, 1))
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"])
    docs = H.sent(SendDocument)
    check(f"[{P}] итоги: 2 победителя, seed, CSV участников", len(g["result"].split(",")) == 2 and g["seed"]
          and docs and docs[-1].document.filename.endswith(".csv"))
    rep = [m for m in H.sent(SendMessage) if m.chat_id == 1 and "розыгрыш завершён" in m.text]
    check(f"[{P}] владельцу — кнопки «перевыбрать»", rep and "gw:rr:" in str(rep[-1].reply_markup))
    old = int(g["result"].split(",")[0])
    SENT.clear()
    await dp.feed_update(bot, cbq(f"gw:rr:{g['id']}:{old}", 1, 1))
    g2 = await db.q_one("SELECT * FROM giveaways WHERE id=?", g["id"])
    check(f"[{P}] 🔁 перевыбор: новый победитель, не из прежних", str(old) not in g2["result"].split(",")
          and len(set(g2["result"].split(","))) == 2 and any("перевыбран" in t for t in texts()))
    # ---------- только Premium + итоги по числу участников ----------
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:text", 1, 1))
    await dp.feed_update(bot, msg("стикеры", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:1", 1, 1))
    await dp.feed_update(bot, cbq("gw:mxn:2", 1, 1))
    await dp.feed_update(bot, cbq("gw:o:prem", 1, 1))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    g3 = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    check(f"[{P}] розыгрыш без срока, до 2 участников", g3["ends"] == 0 and g3["max_users"] == 2 and g3["premium_only"] == 1)
    SENT.clear()
    await dp.feed_update(bot, cbu(f"gw:j:{g3['id']}", 20))
    check(f"[{P}] без Premium — нельзя", any("Premium" in a for a in alerts()))
    await dp.feed_update(bot, cbu(f"gw:j:{g3['id']}", 20, premium=True))
    await dp.feed_update(bot, cbu(f"gw:j:{g3['id']}", 21, premium=True))
    await giveaway.tick(bot)
    check(f"[{P}] набралось 2 — итоги сами", (await db.q_one("SELECT status FROM giveaways WHERE id=?", g3["id"]))["status"] == "done")
    # ---------- отмена с возвратом звёзд ----------
    async def cat(b): return [{"id": "g15", "stars": 15, "emoji": "💝", "sticker": "S"}]
    gifts.catalog = cat
    await gifts.change(1, 30, "тест")
    await dp.feed_update(bot, msg("/giveaway", 1, 1))
    await dp.feed_update(bot, cbq("gw:pt:stars", 1, 1))
    await dp.feed_update(bot, cbq("gw:ps:15", 1, 1))
    await dp.feed_update(bot, cbq("gw:w:2", 1, 1))
    await dp.feed_update(bot, cbq("gw:d:3600", 1, 1))
    await dp.feed_update(bot, cbq("gw:go", 1, 1))
    g4 = await db.q_one("SELECT * FROM giveaways ORDER BY id DESC LIMIT 1")
    b_after = await gifts.balance(1)
    await dp.feed_update(bot, cbq(f"gw:cx:{g4['id']}", 1, 1))
    check(f"[{P}] ✖️ отмена — звёзды вернулись", b_after == 0 and await gifts.balance(1) == 30
          and (await db.q_one("SELECT status FROM giveaways WHERE id=?", g4["id"]))["status"] == "cancelled")
    if P == "gw":
        SENT.clear()
        await M.setup_commands(bot)
        cmds = [c.command for m in SENT if isinstance(m, SetMyCommands) for c in m.commands]
        check("gw: свои команды", "giveaway" in cmds and "fund" in cmds and "games" not in cmds)
        SENT.clear()
        await dp.feed_update(bot, msg("/start", 30, 30))
        check("gw: стартовый экран с «Новый розыгрыш»", "gw:newbtn" in str(H.sent(SendMessage)[-1].reply_markup))
        SENT.clear()
        await dp.feed_update(bot, msg("привет", 30, 30))
        check("gw: на текст — подсказка, без ИИ", any("Розыгрыши" in t for t in texts()))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
