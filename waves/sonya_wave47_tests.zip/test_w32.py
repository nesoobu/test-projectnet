"""Волна 32: живой прогресс, очередь, запасной TikTok, журнал, чистка ссылок в группах, 2 ГБ. Профиль: аргумент 2."""
import asyncio, os, subprocess, sys, tempfile, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendVideo, EditMessageText, DeleteMessage, SendMessage


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from downloader import core
    from handlers import media, admin
    # ---------- текст статуса ----------
    check("статус: проценты и шкала", media.progress_text({"pct": 45, "speed": 3 * 1048576, "eta": 12}, "YouTube")
          == "⏬ качаю с YouTube\n▰▰▰▰▱▱▱▱▱▱ 45%\n<i>3.0 МБ/с · ~12 с</i>")
    check("статус: без процентов — мегабайты", "2.0 МБ" in media.progress_text({"pct": None, "done": 2 * 1048576}, "VK"))
    # ---------- очередь в core.download ----------
    started = []
    def slow(url, kind, h, progress=None):
        started.append(url); time.sleep(0.3)
        if progress is not None:
            progress.update(pct=100)
        return {"path": "/nonexistent", "title": url, "duration": 1}
    core._dl_sync = slow
    seen = []
    async def watch():
        for _ in range(10):
            await asyncio.sleep(0.05)
            seen.append(core.WAITING[0])
    await asyncio.gather(*(core.download(f"u{i}", "video") for i in range(4)), watch())
    check("очередь: по двое, остальные ждут", max(seen) == 2 and len(started) == 4 and core.WAITING[0] == 0)
    q = media.progress_text({}, "X")
    check("очередь пустая — статус молчит", q is None)
    # ---------- запасной путь TikTok ----------
    def broken(url, kind, h, progress=None): raise RuntimeError("ERROR: [TikTok] Unable to extract webpage video data")
    core._dl_sync = broken
    fb = []
    async def tf(url, kind): fb.append(kind); return {"path": "/nonexistent", "title": "tt", "duration": 5}
    core.tiktok_fallback = tf
    r = await core.download("https://www.tiktok.com/@a/video/1", "video")
    check("TikTok: yt-dlp упал — tikwm спас", fb == ["video"] and r["title"] == "tt")
    try:
        await core.download("https://www.youtube.com/watch?v=x", "video"); ok = False
    except Exception as e:
        ok = "Unable to extract" in str(e)
    check("не TikTok — честная ошибка", ok and fb == ["video"])
    # ---------- живой статус в чате ----------
    media.LIVE_EVERY = 0.05
    async def probe(url): return {"title": "клип", "duration": 30, "collection": False, "is_live": False, "audio_only": False}
    async def dl(url, kind="video", max_h=None, progress=None, **kw):
        for p in (10, 60, 100):
            progress.update(pct=p, speed=1048576, eta=3); await asyncio.sleep(0.12)
        return {"path": "/nonexistent", "title": "клип", "duration": 30}
    core.probe, core.download = probe, dl
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.youtube.com/watch?v=aaaaaaaaaaa", 70, 70))
    ed = [m.text for m in H.sent(EditMessageText)]
    check(f"[{P}] прогресс в статусе: 10% → 60%", any("10%" in t for t in ed) and any("60%" in t for t in ed)
          and any("отправляю" in t for t in ed) and H.sent(SendVideo))
    rows = await db.q_all("SELECT * FROM dl_log")
    check(f"[{P}] журнал: успех записан", rows and rows[-1]["ok"] == 1 and rows[-1]["platform"] == "youtube")
    # ---------- TikTok: probe упал — всё равно качаем ----------
    async def badprobe(url): from autopost.media_dl import DLError; raise DLError("Unable to extract")
    core.probe = badprobe
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.tiktok.com/@a/video/7", 71, 71))
    check(f"[{P}] TikTok без probe — видео пришло", H.sent(SendVideo))
    # ---------- группа: «по просьбе» и чистка ----------
    core.probe = probe
    await dp.feed_update(bot, msg("/start", -900, 72))
    await db.set_chat_flag(-900, "auto_dl", True)
    await db.set_chat_flag(-900, "dl_clean", True)
    SENT.clear()
    u = msg("https://www.youtube.com/watch?v=bbbbbbbbbbb", -900, 72, name="Аня")
    await dp.feed_update(bot, u)
    v = H.sent(SendVideo)
    check(f"[{P}] группа: подпись «по просьбе Аня»", v and "по просьбе Аня" in v[-1].caption)
    check(f"[{P}] группа: ссылка удалена", any(d.message_id == u.message.message_id for d in H.sent(DeleteMessage)))
    SENT.clear()
    u = msg("смотри https://www.youtube.com/watch?v=ccccccccccc", -900, 72)
    await dp.feed_update(bot, u)
    check(f"[{P}] группа: сообщение с текстом не трогаю", H.sent(SendVideo)
          and not [d for d in H.sent(DeleteMessage) if d.message_id == u.message.message_id])
    text, _ = await media.settings_view(-900)
    check(f"[{P}] настройка в /settings", "Удалять ссылку" in text or "dl_clean" in str(_))
    # ---------- админка: сводка ----------
    for i in range(5):
        await media.log_dl("instagram", False, "нужен вход в аккаунт", 0)
    v = await admin.dls_view()
    check(f"[{P}] админка: instagram 🔴 и частая ошибка", "🔴 <b>instagram</b>" in v and "нужен вход" in v
          and "🟢 <b>youtube</b>" in v)
    SENT.clear()
    await dp.feed_update(bot, msg("/admin", 1, 1))
    check(f"[{P}] в админке кнопка «Скачивания»", "adm:dls" in str(H.sent(SendMessage)[-1].reply_markup))
    await db.close()
    import socket
    srv = socket.socket()
    srv.bind(("127.0.0.1", 0))
    srv.listen()

    def lim(url):
        return subprocess.run([sys.executable, "-c", "import sys; sys.path.insert(0, '.'); from autopost import media_dl;"
                               "print(media_dl.MAX_BYTES // 1048576)"], capture_output=True, text=True,
                              env={**os.environ, "BOT_API_URL": url, "BOT_API_WAIT": "0"}).stdout.strip()
    check("свой Bot API → лимит 2 ГБ", lim(f"http://127.0.0.1:{srv.getsockname()[1]}") == "1990")
    srv.close()
    check("43b: свой Bot API не отвечает → облако, 50 МБ", lim("http://127.0.0.1:1") == "49")
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
