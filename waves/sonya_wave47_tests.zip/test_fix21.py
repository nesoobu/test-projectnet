import asyncio
from harness import *  # noqa

async def main():
    M, bot, dp = await setup()
    from autopost import rules as R, media_dl, sources as S
    vid_called = []
    async def vfrom(item):
        vid_called.append(item.get("key")); return {"type": "video", "src": "/v.mp4"} if item.get("is_video") or item.get("vid") else None
    R._video_from = vfrom
    rule = {"with_media": 1}
    async def res(item, kind):
        try:
            return [m["type"] for m in await R.resolve_media(rule, {"media_kind": kind}, item)]
        except R.SkipItem as e:
            return f"skip:{e}"
    photo = {"key": "p", "image": "x.jpg", "is_video": False, "images": ["x.jpg"]}
    video = {"key": "v", "image": "c.jpg", "is_video": True}
    check("видео-канал: фото-пин пропущен без запросов", await res(photo, "video") == "skip:не видео" and not vid_called)
    check("видео-канал: видео-пин уходит видео", await res(video, "video") == ["video"])
    check("фото-канал: видео-пин пропущен (не обложка)", (await res(video, "photo")).startswith("skip:видео"))
    check("фото-канал: фото-пин — фото", await res(photo, "photo") == ["photo"])
    check("смешанный: видео — видео, фото — фото", await res(video, "all") == ["video"] and await res(dict(photo), "all") == ["photo"])
    # пины с доски (тип заранее неизвестен) — проверка по данным пина
    async def pinv(url):
        return {"videos": {"video_list": {"V_720P": {"url": "a.mp4"}}}}
    media_dl.pinterest_pin = pinv
    board_vid = {"key": "b", "image": "c.jpg", "video_page": "https://www.pinterest.com/pin/7/"}
    check("доска, фото-канал: видео-пин пропущен", (await res(board_vid, "photo")).startswith("skip:видео"))
    async def pinp(url):
        return {"images": {}}
    media_dl.pinterest_pin = pinp
    board_ph = {"key": "b2", "image": "p.jpg", "video_page": "https://www.pinterest.com/pin/8/"}
    check("доска, фото-канал: фото-пин — фото", await res(board_ph, "photo") == ["photo"])
    check("pin_is_video: идея-пин с видео", media_dl.pin_is_video({"story_pin_data": {"pages": [{"blocks": [{"video": {"video_list": {"x": {}}}}]}]}}))
    it = S.pin_item({"id": "1", "images": {"736x": {"url": "u"}}, "videos": {"video_list": {"V": {"url": "m"}}}})
    check("пин из поиска помечен как видео", it["is_video"] is True)
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
