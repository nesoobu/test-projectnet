"""Волна 40: здоровье всех ботов, сторож, бэкап всех баз, рассылка через помощников."""
import asyncio, io, os, sqlite3, tempfile, time, zipfile
from pathlib import Path
from harness import *  # noqa
import harness as H
import config
from aiogram import Bot
from aiogram.methods import SendMessage, SendDocument


def mkdb(path, users, hb):
    c = sqlite3.connect(path)
    c.execute("CREATE TABLE users(id INTEGER, banned INTEGER DEFAULT 0, dls INTEGER DEFAULT 0, joined INTEGER, last_seen INTEGER)")
    c.execute("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT)")
    c.executemany("INSERT INTO users(id) VALUES(?)", [(u,) for u in users])
    c.execute("INSERT INTO kv VALUES('hb', ?)", (str(hb),))
    c.commit(); c.close()


async def main():
    M, bot, dp = await setup()
    import fleet
    base = Path(tempfile.mkdtemp())
    (base / "data").mkdir()
    (base / ".env").write_text("BOT_TOKEN=main\n")
    (base / "dl.env").write_text("BOT_TOKEN=111:aaa\nBOT_PROFILE=dl\nDB_FILE=dl.db\n")
    (base / "gw.env").write_text("BOT_TOKEN=222:bbb\nBOT_PROFILE=gw\nDB_FILE=gw.db\n")
    mkdb(base / "data" / "dl.db", [501, 502], int(time.time()))
    mkdb(base / "data" / "gw.db", [601], int(time.time()) - 3600)
    old = config.BASE
    config.BASE = base
    hs = fleet.helpers()
    check("помощники найдены по *.env", [h["profile"] for h in hs] == ["dl", "gw"] and hs[0]["service"] == "sonya-dl")
    v = await fleet.status_view()
    check("здоровье: скачивалка 🟢, розыгрыши 🔴", "🟢 <b>⬇️ скачивалка</b>" in v and "🔴 <b>🎁 розыгрыши</b>" in v
          and "людей 2" in v)
    SENT.clear()
    await fleet.check_once(bot)
    await fleet.check_once(bot)
    al = [m.text for m in H.sent(SendMessage) if m.chat_id == 1]
    check("сторож: упавший — одна тревога, без спама", len(al) == 1 and "розыгрыши" in al[0] and "systemctl restart sonya-gw" in al[0])
    c = sqlite3.connect(base / "data" / "gw.db"); c.execute("UPDATE kv SET v=? WHERE k='hb'", (str(int(time.time())),)); c.commit(); c.close()
    SENT.clear()
    await fleet.check_once(bot)
    check("сторож: ожил — «снова работает»", any("снова работает" in m.text for m in H.sent(SendMessage)))
    z = zipfile.ZipFile(io.BytesIO(fleet.dump_all()))
    check("бэкап: все базы в одном архиве", {"dl.db", "gw.db", os.path.basename(config.DB_PATH)} <= set(z.namelist()))
    SENT.clear()
    check("бэкап отправлен владельцу", await fleet.send_backup_all(bot) == "ok"
          and H.sent(SendDocument)[-1].document.filename.startswith("all_bots_"))
    # ---------- рассылка через всех ----------
    helper_bots = {}
    def mk(token):
        b = Bot(token, session=H.Mock())
        helper_bots[token] = b
        return b
    fleet.make_bot = mk
    await dp.feed_update(bot, msg("/start", 300, 300))
    await dp.feed_update(bot, msg("/admin", 1, 1))
    await dp.feed_update(bot, cbq("adm:bc", 1, 1))
    SENT.clear()
    await dp.feed_update(bot, msg("🔥 у нас обновление!", 1, 1))
    check("рассылка: вариант «во всех помощниках · 3»", "adm:bcfleet" in str(H.sent(SendMessage)[-1].reply_markup)
          and "· 3" in str(H.sent(SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq("adm:bcfleet", 1, 1))
    to = {m.chat_id for m in H.sent(SendMessage) if m.text == "🔥 у нас обновление!"}
    check("помощники разослали своим людям", {501, 502, 601} <= to)
    rep = [m.text for m in SENT if getattr(m, "text", None) and "готово" in m.text]
    check("отчёт по каждому боту", rep and "скачивалка: ✅ 2" in rep[-1] and "розыгрыши: ✅ 1" in rep[-1])
    config.BASE = old
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
