"""Фикс 32b: YouTube 403 → перебор клиентов плеера."""
import asyncio, sys
from harness import *  # noqa
import config

async def main():
    await db.init()
    from downloader import core
    tried = []
    def dl(url, kind, h, progress=None, client=None):
        tried.append(client)
        if client != ["web_safari"]:
            raise RuntimeError("ERROR: unable to download video data: HTTP Error 403: Forbidden")
        return {"path": "/x", "title": "ok", "duration": 1}
    core._dl_sync = dl
    r = await core.download("https://youtu.be/l0OFeidEzUA?is=Rr5R52Js_6hL01ky", "video")
    check("403 → со второго клиента скачалось", r["title"] == "ok" and tried == [None, ["tv"], ["web_safari"]])
    def never(url, kind, h, progress=None, client=None):
        raise RuntimeError("ERROR: unable to download video data: HTTP Error 403: Forbidden")
    core._dl_sync = never
    try:
        await core.download("https://youtu.be/x", "video"); msg_ = ""
    except Exception as e:
        msg_ = str(e)
    check("все клиенты 403 — понятная подсказка", "Обновить yt-dlp" in msg_)
    tried.clear()
    def vk(url, kind, h, progress=None, client=None):
        tried.append(client); raise RuntimeError("HTTP Error 403: Forbidden")
    core._dl_sync = vk
    try:
        await core.download("https://vk.com/video1_2", "video")
    except Exception:
        pass
    check("не YouTube — клиенты не перебираем", tried == [None])
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
