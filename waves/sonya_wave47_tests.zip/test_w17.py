"""Волна 17: VK, водяной знак, похожие картинки, контент-план, тарифы и подарки, графики, сегменты, подписка."""
import asyncio
import io
import os
import time
from datetime import datetime

from harness import *  # noqa: F401,F403
import harness as H
from aiogram.methods import SendInvoice, SendPhoto, CopyMessage, AnswerCallbackQuery  # noqa: E402
from aiogram.types import BufferedInputFile, SuccessfulPayment, Message as Msg, Chat as Ch  # noqa: E402


def jpeg(color_fn, size=(320, 240), q=90):
    from PIL import Image
    im = Image.new("RGB", size)
    im.putdata([color_fn(x, y) for y in range(size[1]) for x in range(size[0])])
    b = io.BytesIO()
    im.save(b, "JPEG", quality=q)
    return b.getvalue()


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import sources, imgtools, store, rules as R, publisher
    from handlers import extra
    from PIL import Image

    async def say(model, messages, mt, t, url=None, key=None):
        return "Пн: рубрика…", 1
    llm._call = say
    for i in (40, 41, 42, 43):
        await db.touch_user(User(id=i, is_bot=False, first_name=f"U{i}", username=f"user{i}"))

    # ---------- VK ----------
    check("VK: ссылка → домен", sources.normalize("vk", "https://vk.com/mudakoff") == ("mudakoff", "vk/mudakoff"))
    items = sources.vk_items([
        {"id": 1, "owner_id": -5, "is_pinned": 1, "text": "закреп"},
        {"id": 2, "owner_id": -5, "marked_as_ads": 1, "text": "реклама"},
        {"id": 3, "owner_id": -5, "text": "мем дня", "attachments": [{"type": "photo", "photo": {"sizes": [
            {"url": "s.jpg", "width": 100, "height": 100}, {"url": "big.jpg", "width": 1000, "height": 800}]}}]},
        {"id": 4, "owner_id": -5, "text": ""}], 10)
    check("VK: без закрепа, рекламы и пустых; большая картинка",
          len(items) == 1 and items[0]["image"] == "big.jpg" and items[0]["link"] == "https://vk.com/wall-5_3")
    config.VK_TOKEN = ""
    try:
        await sources.fetch("vk", "x", 5)
        check("VK без токена — понятная ошибка", False)
    except sources.SourceError as e:
        check("VK без токена — понятная ошибка", "VK_TOKEN" in str(e))

    # ---------- похожие картинки ----------
    a = jpeg(lambda x, y: (x % 256, y % 256, (x * y) % 256))
    a_small = io.BytesIO()
    Image.open(io.BytesIO(a)).resize((160, 120)).save(a_small, "JPEG", quality=40)
    b = jpeg(lambda x, y: ((255 - x) % 256, (x + y) % 256, 128))
    ha, ha2, hb = imgtools.dhash(a), imgtools.dhash(a_small.getvalue()), imgtools.dhash(b)
    check("dHash: пережатая копия — похожа", imgtools.distance(ha, ha2) <= imgtools.DUP_DIST)
    check("dHash: другая картинка — нет", imgtools.distance(ha, hb) > imgtools.DUP_DIST)
    check("dHash: однотонная — не сравниваем", imgtools.dhash(jpeg(lambda x, y: (50, 50, 50))) is None)
    big = (1 << 64) - 3
    await imgtools.remember(-900, big)
    check("хэш со старшим битом хранится в SQLite", await imgtools.is_dup(-900, big ^ 1))

    # прогон источника: две записи с одной картинкой → вторая отсеяна
    await store.add_channel(-901, 40, "Канал", "chan")
    rid = await store.add_rule(40, -901, "rss", "https://x", "x")
    await store.set_rule(rid, moderation=0)
    await store.set_cfg(rid, per_run=2)
    pa, pa2 = os.path.join(H.TMP, "a.jpg"), os.path.join(H.TMP, "a2.jpg")
    open(pa, "wb").write(a)
    open(pa2, "wb").write(a_small.getvalue())

    async def cands(rule, cfg, want):
        return [{"key": "k1", "text": "один", "image": "u1"}, {"key": "k2", "text": "два", "image": "u2"}]

    async def mat(rule, cfg, it):
        return {"text": it["text"], "media": [{"type": "photo", "src": pa if it["key"] == "k1" else pa2}],
                "buttons": [], "reactions": [], "opts": {}}
    R.candidates, R.materialize = cands, mat
    rule = await store.rule(rid)
    rule["posted"] = 0
    res = await R.run_rule(bot, rule)
    posts = await db.q_all("SELECT text FROM ap_posts WHERE owner_id=40")
    check("источник: похожая картинка отсеяна", [p["text"] for p in posts] == ["один"] and "1" in res)
    await store.set_channel(-901, dedupe_img=0)
    await db.q_run("DELETE FROM ap_hashes")
    await R.run_rule(bot, await store.rule(rid))
    check("отсев выключен — пропускает", len(await db.q_all("SELECT 1 FROM ap_posts WHERE owner_id=40")) == 3)

    # ---------- водяной знак ----------
    wm = imgtools.watermark(a, "@chan")
    check("водяной знак меняет картинку", wm != a and Image.open(io.BytesIO(wm)).size == (320, 240))
    await store.set_channel(-901, watermark="@chan")
    post = {"text": "пост", "media": [{"type": "photo", "src": pa}], "buttons": [], "opts": {}}
    SENT.clear()
    await publisher.send(bot, post, -901, await store.channel(-901))
    ph = H.sent(SendPhoto)
    check("пост ушёл с водяным знаком", ph and isinstance(ph[0].photo, BufferedInputFile))
    check("оригинал в посте не подменён", post["media"][0]["src"] == pa)
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:x_wm:-901", 40, 40))
    await dp.feed_update(bot, msg("@newmark", 40, 40))
    check("водяной знак задаётся из настроек", (await store.channel(-901))["watermark"] == "@newmark")
    await dp.feed_update(bot, cbq("ap:x_dup:-901", 40, 40))
    check("переключатель похожих", (await store.channel(-901))["dedupe_img"] == 1)
    await dp.feed_update(bot, cbq("ap:x_dup:-901", 41, 41))
    check("чужой канал не трогается", (await store.channel(-901))["dedupe_img"] == 1)
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:x_plan:-901", 40, 40))
    check("контент-план", any("контент-план на неделю" in t for t in texts()))

    # ---------- тарифы и подарки ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/plus", 41, 41))
    kb = str(H.sent(H.SendMessage)[-1].reply_markup)
    check("/plus: три тарифа и подарок", "plus:buy:7" in kb and "plus:buy:365" in kb and "plus:gift" in kb)
    await dp.feed_update(bot, cbq("plus:buy:7", 41, 41))
    inv = H.sent(SendInvoice)[-1]
    check("неделя = 29 ⭐", inv.prices[0].amount == 29 and inv.payload == "plus:7")
    await dp.feed_update(bot, cbq("plus:buy", 41, 41))
    check("старая кнопка = месяц 99 ⭐", H.sent(SendInvoice)[-1].prices[0].amount == 99)
    await dp.feed_update(bot, cbq("plus:buy:3", 41, 41))
    check("левый срок не продаётся", len(H.sent(SendInvoice)) == 2)
    SENT.clear()
    await dp.feed_update(bot, msg("/gift", -950, 41, reply=reply_to(42, "U42", chat_id=-950)))
    check("/gift ответом — выбор срока", "gift:42:30" in str(H.sent(H.SendMessage)[-1].reply_markup))
    await dp.feed_update(bot, cbq("gift:42:365", -950, 41))
    inv = H.sent(SendInvoice)[-1]
    check("счёт за подарок — в личку дарителю", inv.chat_id == 41 and inv.payload == "gift:42:365"
          and inv.prices[0].amount == 799)
    await dp.feed_update(bot, msg("/gift @user43", 41, 41))
    check("/gift @username", "gift:43:" in str(H.sent(H.SendMessage)[-1].reply_markup))
    SENT.clear()
    pay = H.Update(update_id=99001, message=Msg(
        message_id=9, date=datetime.now(), chat=Ch(id=41, type="private"),
        from_user=User(id=41, is_bot=False, first_name="Даритель"),
        successful_payment=SuccessfulPayment(currency="XTR", total_amount=799, invoice_payload="gift:42:365",
                                             telegram_payment_charge_id="c1", provider_payment_charge_id="p1")))
    await dp.feed_update(bot, pay)
    check("подарок: получателю Соня+ на год", extra.active(42)
          and (await db.get_user(42))["plus_until"] > time.time() + 360 * 86400)
    check("подарок: получатель уведомлён", any(m.chat_id == 42 and "подарил" in m.text for m in H.sent(H.SendMessage)))
    check("подарок: даритель — без Соня+", not extra.active(41))

    # ---------- лимит каналов без Соня+ ----------
    config.FREE_CHANNELS = 1
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:chadd", 40, 40))
    al = [m for m in SENT if isinstance(m, AnswerCallbackQuery) and m.text]
    check("FREE_CHANNELS: второй канал — только с Соней+", al and "plus" in al[-1].text)
    config.FREE_CHANNELS = 0

    # ---------- графики, воронка, сегменты ----------
    await db.q_run("UPDATE users SET joined=? WHERE id=43", int(time.time()) - 5 * 86400)
    await db.q_run("INSERT OR IGNORE INTO daily_active VALUES(?, 43)", db._day(time.time() - 4 * 86400))
    SENT.clear()
    await dp.feed_update(bot, cbq("adm:charts", 1, 1))
    ph = H.sent(SendPhoto)
    check("графики: картинка с подписью", ph and "липкость" in ph[-1].caption and "воронка" in ph[-1].caption)
    from handlers import admin
    check("воронка: вернувшийся посчитан", "вернулись в первые 2 дня: <b>1" in await admin.funnel_text()
          or "вернулись" in await admin.funnel_text())
    await dp.feed_update(bot, cbq("adm:bc", 1, 1))
    await dp.feed_update(bot, msg("рассылка!", 1, 1))
    check("рассылка: выбор сегмента", "adm:bcgo:plus" in str(H.sent(H.SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq("adm:bcgo:plus", 1, 1))
    got = sorted(m.chat_id for m in H.sent(CopyMessage))
    check("рассылка только с Соней+", got == [42])

    # ---------- обязательная подписка ----------
    config.REQUIRED_CHANNEL = "@sonya_news"
    H.LEFT.add(43)
    SENT.clear()
    await dp.feed_update(bot, msg("привет", 43, 43))
    check("не подписан — просит подписаться", any("подпишись на канал" in t for t in texts())
          and not any(t == "Пн: рубрика…" for t in texts()))
    SENT.clear()
    await dp.feed_update(bot, msg("/start ref_40", 43, 43))
    check("/start пропускается", any("хей" in t for t in texts()))
    await dp.feed_update(bot, msg("соня, привет", -960, 43))
    check("в группе подписку не требуем", True)
    H.LEFT.discard(43)
    SENT.clear()
    await dp.feed_update(bot, cbq("sub:check", 43, 43))
    check("подписался — пускает", any("подписка есть" in t for t in texts()))
    await dp.feed_update(bot, msg("привет", 43, 43))
    check("после подписки ИИ отвечает", any(t == "Пн: рубрика…" for t in texts()))
    config.REQUIRED_CHANNEL = ""

    await db.close()
    print("\nитого провалов:", len(FAILS))


asyncio.run(main())
