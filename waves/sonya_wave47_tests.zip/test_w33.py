"""Волна 33: трек/текст в комментариях канала, живые команды «Сонь, …»."""
import asyncio, os, shutil, subprocess, sys, tempfile
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
from aiogram.methods import SendAudio, SendMessage, SendVideoNote, SendAnimation, SendVideo, SendVoice
from aiogram.types import Update, Message, Chat, User, Video, Audio, Animation

TMP = tempfile.mkdtemp()
VID = os.path.join(TMP, "v.mp4")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=320x240:rate=15:duration=8",
                "-f", "lavfi", "-i", "sine=frequency=300:duration=8", "-c:v", "libx264", "-preset", "ultrafast",
                "-c:a", "aac", "-shortest", VID], check=True)


def fwd(cid, chat=-100888, **kw):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], message=Message(
        message_id=H._uid[0], date=datetime.now(), chat=Chat(id=chat, type="supergroup"),
        sender_chat=Chat(id=cid, type="channel", title="Канал"), is_automatic_forward=True, **kw))


async def main():
    M, bot, dp = await setup()
    from autopost import store
    from downloader import core, catalog
    from handlers import tools, quick, music
    await store.add_channel(-100777, 1, "Канал", "kanal")
    # ---------- настройки ----------
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:cm:track:-100777", 1, 1))
    c = await store.channel(-100777)
    check("настройка «Трек в комменты» включается", c["cm_track"] == 1)
    await dp.feed_update(bot, cbq("ap:cm:track:-100777", 2, 2))
    check("чужой канал не трогают", (await store.channel(-100777))["cm_track"] == 1)
    # ---------- трек под видео ----------
    async def rec(path): return {"artist": "OXVGEN", "title": "MEMORY", "cover": "", "url": ""}
    async def srch(q, n=30): return [catalog.track("dz", 9, "OXVGEN", "MEMORY", 130)]
    async def dl(url, kind="video", max_h=None, progress=None, **kw): return {"path": "/nonexistent", "duration": 130}
    tools.recognize, catalog.search, core.download = rec, srch, dl
    async def murl(t): return "https://youtu.be/x"
    catalog.audio_url = murl
    vid = Video(file_id="V1", file_unique_id="v", width=1, height=1, duration=10, file_size=1000)
    SENT.clear()
    u = fwd(-100777, video=vid, caption="ночной каталка")
    await dp.feed_update(bot, u)
    await asyncio.sleep(0.3)
    a = H.sent(SendAudio)
    check("видео-пост → трек первым комментарием", a and a[-1].performer == "OXVGEN"
          and a[-1].reply_parameters and a[-1].reply_parameters.message_id == u.message.message_id
          and "OXVGEN" in a[-1].caption)
    async def norec(path): return None
    tools.recognize = norec
    SENT.clear()
    await dp.feed_update(bot, fwd(-100777, video=vid))
    await asyncio.sleep(0.3)
    check("не узнала — молчит", not H.sent(SendAudio) and not H.sent(SendMessage))
    SENT.clear()
    await dp.feed_update(bot, fwd(-100555, video=vid))
    await asyncio.sleep(0.3)
    check("чужой канал — молчит", not H.sent(SendAudio))
    # ---------- текст под аудио ----------
    await store.set_channel(-100777, cm_lyrics=1)
    async def lyr(q): return {"artist": "retroyse", "title": "ТИШЕ", "text": "строка раз\nстрока два"}
    async def sim(t): return [catalog.track("dz", 10 + i, "Арт", f"Похожая {i}", 100) for i in range(7)]
    tools.lyrics, catalog.similar = lyr, sim
    SENT.clear()
    au = Audio(file_id="A1", file_unique_id="a", duration=137, performer="retroyse, чертов эфир.", title="ТИШЕ")
    await dp.feed_update(bot, fwd(-100777, audio=au))
    await asyncio.sleep(0.3)
    t = [x.text for x in H.sent(SendMessage)]
    check("аудио-пост → текст и похожее в комментах", t and "строка раз" in t[-1] and "Похожая 4" in t[-1]
          and "Похожая 5" not in t[-1])
    # ---------- живые команды ----------
    async def fetch(bot_, obj, ext):
        p = os.path.join(TMP, os.urandom(4).hex() + ext); shutil.copy(VID, p); return p
    quick._fetch = fetch
    rv = H.reply_to(5, chat_id=-200, video=Video(file_id="V", file_unique_id="v", width=1, height=1, duration=8))
    ra = H.reply_to(5, chat_id=-200, audio=Audio(file_id="A", file_unique_id="a", duration=8, title="Космос",
                                                performer="Скриптонит"))
    SENT.clear()
    await dp.feed_update(bot, msg("Сонь, кружок", -200, 30, reply=rv))
    check("«Сонь, кружок» на видео", H.sent(SendVideoNote))
    SENT.clear()
    await dp.feed_update(bot, msg("сонь сделай гифку", -200, 30, reply=rv))
    check("«сонь сделай гифку»", H.sent(SendAnimation))
    SENT.clear()
    await dp.feed_update(bot, msg("Соня, замедли", -200, 30, reply=ra))
    a = H.sent(SendAudio)
    check("«Соня, замедли» на трек → slowed", a and a[-1].title == "Космос (slowed + reverb)")
    SENT.clear()
    await dp.feed_update(bot, msg("сонь бас", -200, 30, reply=ra))
    check("«сонь бас» → bass boosted", H.sent(SendAudio) and "bass boosted" in H.sent(SendAudio)[-1].title)
    SENT.clear()
    await dp.feed_update(bot, msg("сонь голосовым", -200, 30, reply=ra))
    check("«голосовым»", H.sent(SendVoice))
    SENT.clear()
    await dp.feed_update(bot, msg("Сонь, обрежь 0:02-0:05", -200, 30, reply=rv))
    check("«обрежь 0:02-0:05» на видео", H.sent(SendVideo) and "0:02–0:05" in H.sent(SendVideo)[-1].caption)
    SENT.clear()
    await dp.feed_update(bot, msg("Сонь, кружок", -200, 30))
    check("без ответа — подсказка", any("ответь" in x for x in texts()))
    got = []
    async def fm(m, q): got.append(q)
    music.search = fm
    await dp.feed_update(bot, msg("Сонь, включи oxvgen memory", -200, 30))
    await dp.feed_update(bot, msg("сонь скачай трек скриптонит космос", -200, 30))
    check("«включи …» и «скачай трек …» → поиск музыки", got == ["oxvgen memory", "скриптонит космос"])
    lq = []
    async def sl(m, q): lq.append(q)
    tools.send_lyrics = sl
    await dp.feed_update(bot, msg("Сонь, текст песни скриптонит космос", -200, 30))
    await dp.feed_update(bot, msg("сонь слова", -200, 30, reply=ra))
    check("«текст песни …» и «слова» ответом на трек", lq == ["скриптонит космос", "Скриптонит Космос"])
    SENT.clear()
    await dp.feed_update(bot, msg("сонь текстом", -200, 30))
    check("«текстом» — это расшифровка, не текст песни", len(lq) == 2 and any("расшифруй" in x for x in texts()))
    # «Сонь, скачай ссылка» при выключенном авто-скачивании
    await db.set_chat_flag(-200, "auto_dl", False)
    async def probe(url): return {"title": "клип", "duration": 5, "collection": False, "is_live": False, "audio_only": False}
    async def vdl(url, kind="video", max_h=None, progress=None, **kw):
        p = os.path.join(TMP, os.urandom(4).hex() + ".mp4"); shutil.copy(VID, p)
        return {"path": p, "title": "клип", "duration": 5}
    core.probe, core.download = probe, vdl
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.youtube.com/watch?v=aaaaaaaaaaa", -200, 31))
    check("ссылка без просьбы в группе с выкл. авто — молчу", not H.sent(SendVideo))
    SENT.clear()
    await dp.feed_update(bot, msg("Сонь, скачай https://www.youtube.com/watch?v=aaaaaaaaaaa", -200, 31))
    check("«Сонь, скачай ссылка» — качаю даже так", H.sent(SendVideo))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
