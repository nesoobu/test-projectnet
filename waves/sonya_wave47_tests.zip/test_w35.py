"""Волна 35: монетизация — лимиты, пробная Соня+, подписка, приоритет, HD, доходы."""
import asyncio, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
from aiogram.methods import SendMessage, SendAudio, AnswerCallbackQuery, SendVideo
from aiogram.types import Update, Message, Chat, User, SuccessfulPayment


def pay(uid, payload, stars=99, **kw):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], message=Message(
        message_id=H._uid[0], date=datetime.now(), chat=Chat(id=uid, type="private"),
        from_user=User(id=uid, is_bot=False, first_name="П"),
        successful_payment=SuccessfulPayment(currency="XTR", total_amount=stars, invoice_payload=payload,
                                             telegram_payment_charge_id=f"ch{H._uid[0]}",
                                             provider_payment_charge_id="", **kw)))


async def main():
    M, bot, dp = await setup()
    import premium
    from handlers import extra, music, admin
    from downloader import core, catalog
    await dp.feed_update(bot, msg("/start", 300, 300))
    r = [await premium.allow(300, "fx") for _ in range(4)]
    check("эффекты: 3 бесплатно, 4-й — нет", r == [True, True, True, False])
    check("владелец — без лимитов", all([await premium.allow(1, "fx") for _ in range(5)]))
    # эффекты через кнопку → предложение Сони+
    await catalog.remember([catalog.track("dz", 7, "A", "B", 100)])
    await db.dl_cache_put("audio:dz:7", "audio", "F7", "A — B")
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:fe:slow:dz:7", 300, 300))
    t = texts()
    kb = str(H.sent(SendMessage)[-1].reply_markup)
    check("лимит эффектов → «3 в день», пробная и Соня+", any("3 в день" in x for x in t) and "plus:trial" in kb
          and "m:plus" in kb)
    # пробная
    SENT.clear()
    await dp.feed_update(bot, cbq("plus:trial", 300, 300))
    check("🎁 пробная Соня+ на 3 дня", extra.active(300) and any("3 дня" in x for x in texts()))
    check("с Соней+ эффекты без лимита", await premium.allow(300, "fx"))
    SENT.clear()
    await dp.feed_update(bot, cbq("plus:trial", 300, 300))
    check("второй раз пробную не дают", any("уже был" in (getattr(x, "text", "") or "") for x in H.sent(AnswerCallbackQuery)))
    # экран Соня+: подписка
    extra._sub_link[:] = ["https://t.me/$subtest"]
    SENT.clear()
    await dp.feed_update(bot, msg("/plus", 301, 301))
    kb = str(H.sent(SendMessage)[-1].reply_markup)
    check("/plus: подписка 99⭐/мес и пробная", "https://t.me/$subtest" in kb and "plus:trial" in kb)
    # оплата подписки
    exp = int(time.time()) + 31 * 86400
    await dp.feed_update(bot, pay(301, "plussub", subscription_expiration_date=exp, is_first_recurring=True,
                                  is_recurring=True))
    u = await db.get_user(301)
    d = await db.q_one("SELECT kind FROM donations WHERE user_id=301")
    check("подписка: Соня+ до конца периода, платёж помечен", u["plus_until"] == exp and d["kind"] == "plussub"
          and extra.active(301))
    await dp.feed_update(bot, pay(302, "plus:30"))
    check("обычная покупка помечена «plus»", (await db.q_one("SELECT kind FROM donations WHERE user_id=302"))["kind"] == "plus")
    # HD только с Соней+
    async def probe(url): return {"title": "x", "duration": 10, "collection": False, "is_live": False, "audio_only": False,
                                  "qualities": [(720, 9_000_000), (1080, 20_000_000)]}
    core.probe = probe
    from handlers import media
    tok = media._token("https://www.youtube.com/watch?v=hdhdhdhdhdh", "youtube", "YouTube")
    await dp.feed_update(bot, msg("/start", 303, 303))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:q:{tok}", 303, 303))
    check("качество: 1080p с 💎", "💎 1080p" in str(H.sent(SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"vt:qh:1080:{tok}", 303, 303))
    check("1080p без Сони+ → предложение", any("1080p" in x and "Соней+" in x for x in texts()))
    # подписки на артистов: 3 бесплатно
    for i in range(3):
        await db.q_run("INSERT INTO music_subs VALUES(?,?,?)", 303, str(900 + i), f"Арт{i}")
    await catalog.remember([catalog.track("dz", 8, "Новый", "Трек", 100, artist_id="555")])
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:sub:dz:8", 303, 303))
    check("4-я подписка на артиста → предложение", any("подписки на артистов" in x for x in texts())
          and not await db.q_one("SELECT 1 FROM music_subs WHERE uid=303 AND artist_id='555'"))
    # автопостинг: 1 канал бесплатно
    from autopost import store
    await store.add_channel(-100901, 303, "мой", None)
    await store.add_rule(303, -100901, "rss", "x", "a")
    config.FREE_SOURCES = 1
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:radd:-100901", 303, 303))
    check("FREE_SOURCES=1: второй источник → предложение", any("автоисточники" in x for x in texts()))
    config.FREE_SOURCES = 0
    config.FREE_CHANNELS = 1
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:chadd", 303, 303))
    from aiogram.methods import AnswerCallbackQuery as ACQ
    check("FREE_CHANNELS=1: второй канал — только с Соней+", any("plus" in (x.text or "") for x in H.sent(ACQ)))
    config.FREE_CHANNELS = 0
    # приоритетная очередь
    sem = core._PrioSem(1)
    await sem.acquire()
    order = []
    async def w(name, prio):
        await sem.acquire(prio); order.append(name); await asyncio.sleep(0.01); sem.release()
    t1 = asyncio.create_task(w("обычный", 1)); await asyncio.sleep(0.01)
    t2 = asyncio.create_task(w("соня+", 0)); await asyncio.sleep(0.01)
    sem.release()
    await asyncio.gather(t1, t2)
    check("⚡ Соня+ обгоняет очередь", order == ["соня+", "обычный"])
    # доходы
    v = await admin.money_view()
    check("💰 доходы: сумма, подписка, проба", "198 ⭐" in v and "🔁 подписка" in v and "пробовали" in v)
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
