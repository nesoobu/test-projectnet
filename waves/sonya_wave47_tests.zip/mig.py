import asyncio, sys, os, importlib, tempfile
p = os.path.join(tempfile.mkdtemp(), "m.db")
async def run(dirpath):
    sys.path.insert(0, dirpath)
    for k in [k for k in sys.modules if k in ("db", "config")]: del sys.modules[k]
    import config; config.DB_PATH = p
    import db; db.DB_PATH = p
    await db.init()
    return db
async def main():
    old = await run(sys.argv[1])
    await old.q_run("INSERT INTO users(id,name,joined,last_seen,msgs,coins) VALUES(5,'Тим',1,1,500,777)")
    await old.q_run("INSERT INTO chats(id,title,added) VALUES(-1,'g',1)")
    await old.close(); sys.path.pop(0)
    new = await run(sys.argv[2])
    u = await new.get_user(5)
    print("user kept:", u["msgs"], u["coins"], "new cols:", u["bday"] == "", u["dls"], u["nudge"])
    print("chat bdays flag:", await new.chat_flag(-1, "bdays"))
    print("tables:", sorted(r["name"] for r in await new.q_all("SELECT name FROM sqlite_master WHERE type='table'"))[:20])
    await new.close()
asyncio.run(main())
