import asyncio, sys
from harness import *  # noqa
import harness as H
from aiogram import Dispatcher, Bot
import aiogram

async def fake_poll(self, bot, **kw):
    await asyncio.sleep(1.5)

Dispatcher.start_polling = fake_poll
_orig = Bot.__init__
def init(self, token, session=None, **kw):
    _orig(self, "123:abc", session=H.Mock(), **kw)
Bot.__init__ = init
import main as M
config.BOT_TOKEN = "123:abc"
asyncio.run(M.main())
from aiogram.methods import SetMyCommands
cmds = [m for m in H.SENT if isinstance(m, SetMyCommands)][0].commands
import re
bad = [c.command for c in cmds if not re.fullmatch(r"[a-z0-9_]{1,32}", c.command)]
print("commands:", len(cmds), "bad:", bad, "dupes:", len(cmds) - len({c.command for c in cmds}))
print("smoke ok")
