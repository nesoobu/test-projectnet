"""Волна 45: улучшения новых ботов. Профиль: аргумент 2 (games|grp|stk|anon).
python test_w45.py ../sonya games"""
import asyncio
import io
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "games"
from aiogram.methods import (SendMessage, DeleteMessage, AnswerCallbackQuery, AddStickerToSet, CreateNewStickerSet,
                             SendDocument, RestrictChatMember, EditMessageText)


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    P = config.PROFILE
    M, bot, dp = await setup()
    import profanity
    check("мат ловится, обычные слова — нет", profanity.has_mat("ну ты и с у к а") and profanity.has_mat("иди нахуй")
          and not any(profanity.has_mat(w) for w in ("хлеб", "тебе", "бляха", "небу", "хулиган", "оскорбление")))

    if P == "games":
        from handlers import party
        g = party.Game("mafia", -500, 1, "Чат")
        party.GAMES[-500] = g
        g.players = {1: "A", 2: "B", 3: "C", 4: "D"}
        g.msg_id = 777
        SENT.clear()
        await dp.feed_update(bot, cbq("pt:t", -500, 1, mid=777))
        check("мафия: темп переключается", g.slow and "спокойный" in all_text())
        SENT.clear()
        await dp.feed_update(bot, cbq("pt:t", -500, 3, mid=777))
        check("мафия: темп меняет только хозяин/админ", g.slow)
        g.started, g.alive, g.phase = True, [1, 2, 3], "talk"
        SENT.clear()
        await dp.feed_update(bot, msg("я знаю кто мафия!", -500, 4))
        check("мафия: мёртвый игрок молчит", H.sent(DeleteMessage))
        SENT.clear()
        await dp.feed_update(bot, msg("думаю на B", -500, 2))
        check("мафия: живой днём говорит", not H.sent(DeleteMessage))
        g.phase = "night"
        SENT.clear()
        await dp.feed_update(bot, msg("псс", -500, 2))
        check("мафия: ночью тишина", H.sent(DeleteMessage))
        SENT.clear()
        await dp.feed_update(bot, msg("я просто зритель", -500, 9))
        check("мафия: зрителей не трогаем", not H.sent(DeleteMessage))
        await party.finish(bot, g, "конец", [1, 2], 0)
        SENT.clear()
        await dp.feed_update(bot, msg("/gstats", 1, 1))
        check("статистика: игра и победа записаны", "игр <b>1</b>" in all_text() and "побед <b>1</b>" in all_text())
        await dp.feed_update(bot, msg("/gstats", 4, 4))
        check("статистика: проигравший — 0 побед", "побед <b>0</b>" in all_text())

    if P == "grp":
        from handlers import groupmod, community
        H.ADMINS.clear()
        H.ADMINS.add(70)
        groupmod._admins.clear()
        await db.add_chat(-600, "Чат")
        await db.set_chat_flag(-600, "antimat", True)
        SENT.clear()
        await dp.feed_update(bot, msg("да ты охуел", -600, 71))
        await asyncio.sleep(0.05)   # замечание шлётся фоновой задачей
        check("антимат: удалено и вежливое замечание", H.sent(DeleteMessage) and "без мата" in all_text())
        SENT.clear()
        await dp.feed_update(bot, msg("хороший хлеб сегодня", -600, 71))
        check("антимат: обычный текст не трогаю", not H.sent(DeleteMessage))
        SENT.clear()
        await dp.feed_update(bot, msg("ну бля", -600, 70))
        check("антимат: админов не трогаю", not H.sent(DeleteMessage))
        SENT.clear()
        await dp.feed_update(bot, msg("/settings", -600, 70))
        check("настройки: есть фильтр мата", "gs:antimat" in kbs())
        # «не спам»
        SENT.clear()
        await dp.feed_update(bot, cbq("as:ok:71", -600, 72))
        check("«не спам»: не админ — нельзя", any(isinstance(m, AnswerCallbackQuery) and m.show_alert for m in SENT))
        SENT.clear()
        await dp.feed_update(bot, cbq("as:ok:71", -600, 70))
        check("«не спам»: мут снят, человек в доверенных", H.sent(RestrictChatMember)
              and await db.kv_get("trust:-600:71") == "1")
        # топ
        for _ in range(3):
            await dp.feed_update(bot, msg("привет всем", -600, 73, name="Аня"))
        await dp.feed_update(bot, msg("ку", -600, 74, name="Боря"))
        SENT.clear()
        await dp.feed_update(bot, msg("/top", -600, 74, name="Боря"))
        t = all_text()
        check("/top: самые активные за неделю", "самые активные" in t and t.index("Аня") < t.index("Боря"))

    if P == "stk":
        from handlers import stickers
        from aiogram.types import Sticker, PhotoSize
        from PIL import Image, ImageDraw
        im = Image.new("RGB", (800, 600), (245, 245, 240))
        ImageDraw.Draw(im).ellipse((200, 100, 600, 500), fill="red")
        b = io.BytesIO()
        im.save(b, "JPEG")
        out = Image.open(io.BytesIO(stickers.to_png(b.getvalue(), "sticker", True)))
        check("фон: однотонный вырезан", out.mode == "RGBA" and out.getpixel((2, 2))[3] == 0
              and out.getpixel((out.width // 2, out.height // 2))[3] == 255)
        noise = Image.effect_noise((400, 400), 90).convert("RGB")
        b2 = io.BytesIO()
        noise.save(b2, "JPEG")
        o2 = Image.open(io.BytesIO(stickers.to_png(b2.getvalue(), "sticker", True))).convert("RGBA")
        check("фон: пёстрое фото не портим", o2.getchannel("A").histogram()[0] == 0)
        SENT.clear()
        await dp.feed_update(bot, cbq("stk:cut", 80, 80))
        check("кнопка «вырезать фон» включается", await db.kv_get("stk:cut:80") == "1")
        # текст → стикер-цитата
        SENT.clear()
        await dp.feed_update(bot, msg("я не опаздываю, я эффектно появляюсь", 80, 80))
        tok = [k for k in stickers._msgs][-1]
        check("текст: предлагаю стикер-цитату", f"stk:txt:{tok}" in kbs())
        await dp.feed_update(bot, cbq(f"stk:txt:{tok}", 80, 80))
        SENT.clear()
        await dp.feed_update(bot, cbq("stk:new:sticker", 80, 80))
        mk = H.sent(CreateNewStickerSet)
        check("текст: пак со стикером-цитатой создан", mk and mk[0].stickers[0].emoji_list == ["💬"])
        check("после создания — «поделиться»", "share/url" in kbs())
        # чужой стикер
        foreign = Sticker(file_id="f1", file_unique_id="f", type="regular", width=512, height=512,
                          is_animated=False, is_video=False, set_name="someone_by_x")
        SENT.clear()
        await dp.feed_update(bot, msg(None, 80, 80, sticker=foreign))
        tok = [k for k in stickers._msgs][-1]
        check("чужой стикер: «в мой пак» и «скачать»", f"stk:add:{tok}" in kbs() and f"stk:png:{tok}" in kbs())

        async def fake_download(file_id, destination=None, **kw):
            img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
            img.save(destination, "WEBP")
        bot.download = fake_download
        SENT.clear()
        await dp.feed_update(bot, cbq(f"stk:png:{tok}", 80, 80))
        check("скачать: PNG документом", H.sent(SendDocument))

        async def fake_build(bot_, m, kind):
            from aiogram.types import InputSticker, BufferedInputFile
            return InputSticker(sticker=BufferedInputFile(b"x", "s.png"), format="static", emoji_list=["✨"])
        stickers.build = fake_build
        SENT.clear()
        await dp.feed_update(bot, cbq(f"stk:add:{tok}", 80, 80))
        check("чужой стикер: добавлен в мой пак", H.sent(AddStickerToSet))

    if P == "anon":
        from handlers import anon
        await dp.feed_update(bot, msg("/start", 10, 10))
        SENT.clear()
        await dp.feed_update(bot, cbq("an:set", 10, 10))   # волна 47: обещание и фильтр — в «⚙️ Настройки»
        check("настройки: обещание не раскрывать авторов", "ни за звёзды" in all_text() and "an:mat" in kbs())
        await dp.feed_update(bot, cbq("an:mat", 10, 10))
        check("фильтр мата включается", (await db.q_one("SELECT nomat FROM anon_links WHERE uid=10"))["nomat"] == 1)
        code = anon.code_of(10)
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20))
        check("пишущему: «никогда не раскрываю»", "никогда не раскрываю" in all_text())
        SENT.clear()
        await dp.feed_update(bot, msg("ты бля кто вообще", 20, 20))
        check("мат не доходит, просим переписать", not [m for m in H.sent(SendMessage) if m.chat_id == 10]
              and "перепиши помягче" in all_text())
        SENT.clear()
        await dp.feed_update(bot, msg("ты классная, правда", 20, 20))
        check("после правки — доставлено", [m for m in H.sent(SendMessage) if m.chat_id == 10])

    # антифлуд и повтор — общие для новых ботов
    import middlewares
    th = middlewares.Throttle()
    calls = []

    async def h(e, d):
        calls.append(1)
    for _ in range(12):
        await th(h, msg("спам", 90, 90).message, {})
    check("антифлуд: в личке больше 8 за 4 с — режу", len(calls) == middlewares.Throttle.LIMIT)
    calls.clear()
    for _ in range(12):
        await th(h, msg("чат", -90, 91).message, {})
    check("антифлуд: группы не трогаю", len(calls) == 12)
    from aiogram.exceptions import TelegramRetryAfter
    from aiogram.methods import SendMessage as SM
    n = [0]

    async def flaky(bot_, method):
        n[0] += 1
        if n[0] == 1:
            raise TelegramRetryAfter(method=method, message="flood", retry_after=0)
        return "ok"
    res = await middlewares.RetryAfter()(flaky, bot, SM(chat_id=1, text="x"))
    check("RetryAfter: подождали и отправили", res == "ok" and n[0] == 2)
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
