import asyncio
from harness import *  # noqa
import harness as H

def pin(i, carousel=False, typ="pin"):
    p = {"id": str(i), "type": typ, "grid_title": f"пин {i}", "description": "описание",
         "images": {"236x": {"url": f"https://i.pinimg.com/236x/{i}.jpg"}, "736x": {"url": f"https://i.pinimg.com/736x/{i}.jpg"}}}
    if carousel:
        p["carousel_data"] = {"carousel_slots": [{"id": 1, "images": {"345x": {"url": f"https://i.pinimg.com/345x/{i}a.jpg"}}},
                                                 {"id": 2, "images": {"345x": {"url": f"https://i.pinimg.com/345x/{i}b.jpg"}}}]}
    return p

async def main():
    M, bot, dp = await setup()
    from autopost import sources as S
    n = S.normalize
    check("слова → поиск", n("pinterest", "парные аватарки аниме") == ("q:парные аватарки аниме", "🔎 парные аватарки аниме"))
    check("«поиск: aesthetic»", n("pinterest", "поиск: aesthetic")[0] == "q:aesthetic")
    check("ссылка на пин → похожие", n("pinterest", "https://www.pinterest.com/pin/123456789/")[0] == "rel:123456789")
    check("пин со слагом", n("pinterest", "https://ru.pinterest.com/pin/cute-cat--98765/")[0] == "rel:98765")
    check("доска как раньше", n("pinterest", "https://pinterest.com/user/board") == ("user/board", "board"))
    check("одно латинское слово — профиль как раньше", n("pinterest", "someuser") == ("someuser", "someuser"))
    try:
        n("pinterest", "https://pin.it/abc"); check("pin.it — понятная ошибка", False)
    except S.SourceError:
        check("pin.it — понятная ошибка", True)

    calls = []
    async def api(resource, options):
        calls.append((resource, dict(options)))
        if resource == "BaseSearch":
            page = 2 if options.get("bookmarks") else 1
            return {"resource_response": {"data": {"results": [pin(page * 10 + k) for k in range(3)] + [pin(99, typ="story")]}},
                    "resource": {"options": {"bookmarks": ["BM2" if page == 1 else "-end-"]}}}
        base = int(options["pin"])
        return {"resource_response": {"data": [pin(base * 10 + k, carousel=(k == 0)) for k in range(3)]}}
    S._pin_api = api
    items = await S.fetch("pinterest", "q:авы", 10)
    check("поиск: пины без «историй»", [i["key"] for i in items] == ["pin:10", "pin:11", "pin:12"])
    check("поиск: картинка 736x, ссылка на пин", items[0]["image"].endswith("/736x/10.jpg") and items[0]["link"].endswith("/pin/10/"))
    items2 = await S.fetch("pinterest", "q:авы", 10)
    check("поиск: следующий раз — следующая страница", calls[-1][1].get("bookmarks") == ["BM2"] and items2[0]["key"] == "pin:20")
    await S.fetch("pinterest", "q:авы", 10)
    check("поиск: выдача кончилась — сначала", "bookmarks" not in calls[-1][1])
    from autopost import media_dl
    async def seedpin(url):
        return {"id": "5", "pin_join": {"visual_annotation": ["аниме", "аватарки", "пара"]}, "grid_title": "x"}
    media_dl.pinterest_pin = seedpin
    calls.clear()
    items = await S.fetch("pinterest", "rel:5", 10)
    check("похожие: поиск по словам из пина", calls[-1][0] == "BaseSearch" and calls[-1][1]["query"] == "аниме аватарки пара")
    qs = (await db.kv_get("pinq:5")).split("|")
    check("похожие: снежный ком запросов", qs[0] == "аниме аватарки пара" and "пин" in " ".join(qs[1:]))
    check("ключевые слова без разметки — из доски", S.pin_keywords({"board": {"name": "Парные авы 2026"}}) == "Парные авы 2026")
    check("пустой пин — нет слов", S.pin_keywords({}) == "")
    async def bare(url):
        return {"id": "9"}
    media_dl.pinterest_pin = bare
    try:
        await S.fetch("pinterest", "rel:9", 5); check("пин без слов — понятная ошибка", False)
    except S.SourceError as e:
        check("пин без слов — понятная ошибка", "слова для поиска" in str(e))
    async def empty(resource, options):
        return {"resource_response": {"data": []}}
    S._pin_api = empty
    try:
        await S.fetch("pinterest", "q:ничего", 5); check("пусто — понятная ошибка", False)
    except S.SourceError as e:
        check("пусто — понятная ошибка", "другие слова" in str(e))
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
