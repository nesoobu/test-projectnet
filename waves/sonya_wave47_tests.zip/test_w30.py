"""Волна 30: эффекты, рингтон, голосовым, угадай мелодию, мой вкус, что за песня, релизы. Профиль: аргумент 2."""
import asyncio, datetime as dt, os, shutil, subprocess, sys, tempfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import (SendMessage, EditMessageText, SendAudio, SendPhoto, SendVoice, SendDocument,
                             EditMessageReplyMarkup, AnswerCallbackQuery)

TMP = tempfile.mkdtemp()
SINE = os.path.join(TMP, "sine.mp3")
subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "sine=frequency=440:duration=60",
                "-b:a", "128k", SINE], check=True)


def dur(p):
    out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", p],
                         capture_output=True, text=True).stdout
    return float(out or 0)


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from downloader import catalog, core, audiofx
    from handlers import music, melody, tools
    # ---------- ffmpeg по-настоящему ----------
    if P == "full":
        for k in audiofx.FX:
            out = await audiofx.effect(SINE, k)
            check(f"эффект {k}: файл есть", os.path.getsize(out) > 1000)
            if k == "slow":
                check("slowed длиннее оригинала", dur(out) > 65)
            if k == "fast":
                check("sped up короче", dur(out) < 52)
        mp3, m4r = await audiofx.ringtone(SINE, 5, 35)
        check("рингтон: mp3 30 с и m4r", 29 < dur(mp3) < 31 and os.path.getsize(m4r) > 1000)
        v = await audiofx.voice(SINE, 0, 15)
        check("голосовое: ogg 15 с", 14 < dur(v) < 16)
        check("отрезки: 0:45-1:15, 45 75, плохие", audiofx.parse_span("0:45-1:15") == (45, 75)
              and audiofx.parse_span("с 45 до 75") == (45, 75) and audiofx.parse_span("1:00") is None
              and audiofx.parse_span("2:00-1:00") is None)
        check("ответы в игре", melody.is_right("кажется это memory!", "MEMORY (Slowed)")
              and melody.is_right("бохемиан рапсоди", "Bohemian Rhapsody") is False
              and melody.is_right("bohemian rapsody", "Bohemian Rhapsody") and not melody.is_right("ok", "Космос"))
    # ---------- Яндекс 451 → не спрашиваем 6 часов ----------
    n = []
    async def ym451(q, k): n.append(1); raise RuntimeError("Unavailable For Legal Reasons (451)")
    T = catalog.track
    trk = [T("dz", 500 + i, "OXVGEN", "MEMORY" if i == 0 else f"Song {i}", 130, "", "", 77,
             f"https://p/{i}.mp3") for i in range(6)]
    async def dzs(q, k): return trk[:k]
    catalog.ym_search, catalog.dz_search = ym451, dzs
    await catalog.search("a"); await catalog.search("b")
    check(f"[{P}] Яндекс 451 — второй раз не дёргаем", len(n) == 1)
    # ---------- трек: эффекты ----------
    await catalog.remember(trk)
    await db.dl_cache_put("audio:dz:500", "audio", "F500", "OXVGEN — MEMORY")
    async def src(bot_, key):
        p = audiofx.tmp(".mp3"); shutil.copy(SINE, p); return p
    music._src = src
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:get:dz:500", 95, 95))
    kb = str(H.sent(SendAudio)[-1].reply_markup)
    check(f"[{P}] под треком: эффекты и рингтон", "mx:fx:dz:500" in kb and "mx:ring:dz:500" in kb)
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:fx:dz:500", 95, 95))
    check(f"[{P}] меню эффектов", "mx:fe:slow:dz:500" in str(H.sent(EditMessageReplyMarkup)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:fe:slow:dz:500", 95, 95))
    a = H.sent(SendAudio)
    check(f"[{P}] slowed + reverb прислан", a and a[-1].title == "MEMORY (slowed + reverb)")
    await db.dl_cache_put("fx:slow:dz:500", "slow", "FXF", "x")
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:fe:slow:dz:500", 95, 95))
    check(f"[{P}] эффект второй раз — из кэша", H.sent(SendAudio)[-1].audio == "FXF")
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:fe:voice:dz:500", 95, 95))
    check(f"[{P}] 🎙 голосовым", H.sent(SendVoice))
    # ---------- рингтон ----------
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:ring:dz:500", 95, 95))
    check(f"[{P}] рингтон: спрашиваю отрезок", any("0:45-1:15" in t for t in texts()))
    await dp.feed_update(bot, msg("хз", 95, 95))
    check(f"[{P}] рингтон: непонятно — переспрашиваю", any("не поняла" in t for t in texts()))
    SENT.clear()
    await dp.feed_update(bot, msg("0:05-0:25", 95, 95))
    d = H.sent(SendDocument)
    check(f"[{P}] рингтон: mp3 + m4r", H.sent(SendAudio) and d and d[-1].document.filename.endswith(".m4r"))
    SENT.clear()
    await dp.feed_update(bot, msg("0:05-0:25", 95, 95))
    check(f"[{P}] после рингтона текст — снова обычный", not H.sent(SendDocument))
    # ---------- мой вкус ----------
    for k in ("dz:501", "dz:502"):
        await db.dl_cache_put(f"audio:{k}", "audio", "F" + k, "x")
        await dp.feed_update(bot, cbq(f"mx:get:{k}", 95, 95))
    SENT.clear()
    await dp.feed_update(bot, msg("/taste", 95, 95))
    ph = H.sent(SendPhoto)
    check(f"[{P}] /taste — карточка вкуса", ph and "вкус" in ph[-1].caption and "share/url" in str(ph[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, msg("/taste", 96, 96))
    check(f"[{P}] /taste без треков — подсказка", any("хотя бы 3" in t for t in texts()))
    # ---------- угадай мелодию ----------
    melody.ROUNDS, melody.ROUND_SEC, melody.CLIP_SEC = 2, 2, 3
    async def prev(q="", k=40): return [dict(t) for t in trk]
    catalog.previews = prev
    sine = open(SINE, "rb").read()
    async def fb(url, limit=0): return sine
    core.fetch_bytes = fb
    import random; random.seed(1)
    SENT.clear()
    await dp.feed_update(bot, msg("/melody", -300, 97, name="Аня"))
    for _ in range(50):
        await asyncio.sleep(0.1)
        if H.sent(SendVoice):
            break
    check(f"[{P}] игра: прислан отрывок голосовым", H.sent(SendVoice) and "раунд 1" in H.sent(SendVoice)[-1].caption)
    cur = melody._games[-300]["cur"]
    SENT.clear()
    await dp.feed_update(bot, cbq("mel:hint", -300, 98))
    check(f"[{P}] игра: подсказка", any("OXVGEN" in (getattr(x, "text", "") or "") for x in H.sent(AnswerCallbackQuery)))
    await dp.feed_update(bot, msg("не знаю", -300, 98, name="Боб"))
    await dp.feed_update(bot, msg(cur["title"].lower(), -300, 97, name="Аня"))
    check(f"[{P}] игра: угадала — очко", any("угадал" in t and "Аня" in t for t in texts()))
    for _ in range(100):
        await asyncio.sleep(0.1)
        if any("итоги" in t for t in texts()):
            break
    check(f"[{P}] игра: итоги, Аня первая", any("итоги" in t and "🥇 Аня" in t for t in texts())
          and any("никто не угадал" in t for t in texts()))
    check(f"[{P}] игра закончилась — чат свободен", -300 not in melody._games)
    # ---------- что за песня в видео ----------
    async def dl(url, kind): return {"path": "/nonexistent", "title": "", "duration": 30}
    async def rec(path): return {"artist": "OXVGEN", "title": "MEMORY", "cover": "https://c/1.jpg", "url": ""}
    core.download, tools.recognize = dl, rec
    if P == "music":
        SENT.clear()
        await dp.feed_update(bot, msg("https://www.tiktok.com/@a/video/123", 99, 99))
        check("music: ссылка на видео → что за песня", H.sent(SendPhoto) and "mx:get:dz:500" in str(H.sent(SendPhoto)[-1].reply_markup))
    else:
        from handlers import media
        tok = media._token("https://www.youtube.com/watch?v=x", "youtube", "YouTube")
        SENT.clear()
        await dp.feed_update(bot, cbq(f"dl:s:{tok}", 99, 99))
        check(f"[{P}] кнопка «что за песня» под видео", H.sent(SendPhoto) and "OXVGEN" in H.sent(SendPhoto)[-1].caption)
    # ---------- релизы ----------
    latest = {"id": "A1", "title": "Old", "date": "2020-01-01", "cover": "", "link": "", "type": "album"}
    async def lt(aid): return dict(latest)
    catalog.dz_latest = lt
    SENT.clear()
    await dp.feed_update(bot, cbq("mx:sub:dz:500", 95, 95))
    check(f"[{P}] подписка на артиста", any("OXVGEN" in (getattr(x, "text", "") or "") for x in H.sent(AnswerCallbackQuery)))
    latest.update(id="B2", title="NEW SINGLE", date=dt.date.today().isoformat(), type="single")
    SENT.clear()
    n = await music.check_releases(bot)
    check(f"[{P}] вышел новый сингл — пишу подписчику", n == 1 and any("NEW SINGLE" in t for t in texts()))
    SENT.clear()
    check(f"[{P}] второй раз не повторяю", await music.check_releases(bot) == 0)
    SENT.clear()
    await dp.feed_update(bot, msg("/subs", 95, 95))
    check(f"[{P}] /subs — список с отпиской", "mx:uns:77" in str(H.sent(SendMessage)[-1].reply_markup))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
