import asyncio, json, time
from datetime import datetime
from harness import *  # noqa
import harness as H
from aiogram.methods import DeleteMessage
from aiogram.types import Message as Msg, Chat as Ch

async def main():
    M, bot, dp = await setup()
    import llm
    from handlers import luck, remind, community, extra
    async def say(model, messages, mt, t, url=None, key=None, extra=None):
        return "звёзды шепчут: отдыхай", 1
    llm._call = say
    for i in (90, 91, 92):
        await db.touch_user(User(id=i, is_bot=False, first_name=f"U{i}", username=f"u{i}"))
    # колесо
    luck.SPIN = ["🎡"]
    await db.q_run("UPDATE users SET coins=0 WHERE id=90")
    import random
    random.seed(1)
    await dp.feed_update(bot, cbq("g:wheel", 90, 90))
    u = await db.get_user(90)
    check("колесо: крутится и что-то даёт (или пусто)", any("Колесо фортуны" in (t or "") for t in texts()))
    SENT.clear()
    await dp.feed_update(bot, msg("/wheel", 90, 90))
    check("колесо: второй раз — только через 20 ч", any("колесо отдыхает" in t for t in texts()))
    luck.WHEEL = [(1, "✨ Соня+ на день", 0, 1)]
    await db.kv_set("wheel:91", "0")
    await dp.feed_update(bot, msg("/wheel", 91, 91))
    check("колесо: приз Соня+ выдаётся", extra.active(91))
    # блэкджек
    check("очки: туз считается как 1 при переборе", luck.score(["A♠️", "K♥️", "5♦️"]) == 16 and luck.score(["A♠️", "K♥️"]) == 21)
    await db.q_run("UPDATE users SET coins=100 WHERE id=92")
    luck._deck = lambda: ["5♠️", "6♠️", "10♠️", "9♥️", "7♦️", "2♣️", "K♠️"]  # pop с конца: игрок K,2 · дилер 7,9 · далее 10,6,5
    SENT.clear()
    await dp.feed_update(bot, cbq("bj:new:50", 92, 92))
    check("блэкджек: ставка списана", (await db.get_user(92))["coins"] == 50)
    gid = next(iter(luck._bj))
    luck._bj.clear()  # перезапуск — партия в базе
    await dp.feed_update(bot, cbq(f"bj:h:{gid}", 92, 91))
    check("чужие кнопки не работают", luck._bj.get(gid) and len(luck._bj[gid]["hand"]) == 2)
    await dp.feed_update(bot, cbq(f"bj:h:{gid}", 92, 92))   # +10 → 22 перебор
    check("блэкджек: перебор — ставка проиграна", (await db.get_user(92))["coins"] == 50 and gid not in luck._bj)
    luck._deck = lambda: ["2♠️", "3♠️", "8♥️", "9♦️", "10♣️", "Q♠️"]  # игрок Q,10=20 · дилер 9,8=17
    await dp.feed_update(bot, cbq("bj:new:50", 92, 92))
    gid = next(iter(luck._bj))
    await dp.feed_update(bot, cbq(f"bj:s:{gid}", 92, 92))
    check("блэкджек: 20 против 17 — выигрыш ×2", (await db.get_user(92))["coins"] == 100)
    # гороскоп
    check("знак: 12.05 телец, 25.12 козерог, 10.01 козерог", luck.sign_of("12.05")[1] == "телец"
          and luck.sign_of("25.12")[1] == "козерог" and luck.sign_of("10.01")[1] == "козерог")
    await db.q_run("UPDATE users SET bday='21.03' WHERE id=90")
    SENT.clear()
    await dp.feed_update(bot, msg("/horo", 90, 90))
    check("/horo по ДР: овен", any("овен" in t for t in texts()))
    from handlers import morning
    morning.fact_of_day = lambda: asyncio.sleep(0, "факт")
    from handlers import tools
    async def nowx(*a): raise RuntimeError("off")
    tools.weather = nowx; tools.cbr = nowx
    txt = await morning.compose("Москва", 90)
    check("утренняя рассылка в личке — с гороскопом", "🔮" in txt and "овен" in txt)
    check("в группе — без гороскопа", "🔮" not in await morning.compose("Москва", -5))
    # напоминания
    await db.q_run("INSERT INTO reminders(uid,chat_id,at,text) VALUES(90,90,?,?)", int(time.time()) - 1, "попить воды")
    SENT.clear()
    await remind.tick(bot)
    rem = [m for m in H.sent(H.SendMessage) if "попить воды" in m.text][0]
    kb = str(rem.reply_markup)
    check("напоминание: кнопки 10 мин / час / завтра / готово", all(x in kb for x in (":10", ":60", ":tm", "rm:ok:")))
    rid = (await db.q_one("SELECT id FROM reminders WHERE text='попить воды'"))["id"]
    upd = H.Update(update_id=77001, callback_query=H.CallbackQuery(id="x", chat_instance="x", data=f"rm:snz:{rid}:tm",
            from_user=User(id=90, is_bot=False, first_name="U"),
            message=Msg(message_id=5, date=datetime.now(), chat=Ch(id=90, type="private"), text="⏰ напоминаю: попить воды")))
    await dp.feed_update(bot, upd)
    nxt = await db.q_one("SELECT at FROM reminders WHERE done=0 AND text='попить воды'")
    check("«завтра» — новое напоминание через сутки", nxt and abs(nxt["at"] - time.time() - 86400) < 60)
    await dp.feed_update(bot, cbq(f"rm:snz:{rid}:10", 91, 91))
    check("чужое напоминание не отложить", len(await db.q_all("SELECT 1 FROM reminders WHERE done=0")) == 1)
    # группы: приветствие, уборка, жалоба
    H.ADMINS = {1, 90}
    from handlers import groupmod
    groupmod._admins.clear()
    await dp.feed_update(bot, msg("hi", -800, 90))
    await dp.feed_update(bot, msg("/welcome привет, {name}! это {chat} 🖤", -800, 90))
    check("своё приветствие сохранено", "{name}" in await community.get_welcome(-800))
    await db.set_chat_flag(-800, "clean_service", True)
    SENT.clear()
    join = H.Update(update_id=77002, message=Msg(message_id=6, date=datetime.now(), chat=Ch(id=-800, type="supergroup", title="Чат"),
                    from_user=User(id=93, is_bot=False, first_name="Новенький"),
                    new_chat_members=[User(id=93, is_bot=False, first_name="Новенький")]))
    await dp.feed_update(bot, join)
    check("вход: служебное удалено", H.sent(DeleteMessage))
    check("вход: своё приветствие с именем", any("привет," in t and "Новенький" in t and "Чат" in t for t in texts()))
    SENT.clear()
    left = H.Update(update_id=77003, message=Msg(message_id=7, date=datetime.now(), chat=Ch(id=-800, type="supergroup"),
                    from_user=User(id=93, is_bot=False, first_name="Н"), left_chat_member=User(id=93, is_bot=False, first_name="Н")))
    await dp.feed_update(bot, left)
    check("выход: служебное удалено", H.sent(DeleteMessage))
    SENT.clear()
    await dp.feed_update(bot, msg("/report спам", -1001234, 91, reply=reply_to(93, "Спамер", chat_id=-1001234, text="купи крипту")))
    dm = [m for m in H.sent(H.SendMessage) if m.chat_id == 90]
    check("жалоба: админу в личку со ссылкой", dm and "t.me/c/1234/" in dm[0].text and "купи крипту" in dm[0].text)
    SENT.clear()
    await dp.feed_update(bot, msg("/report", -1001234, 91, reply=reply_to(93, "Спамер", chat_id=-1001234)))
    check("жалоба: не чаще раза в минуту", any("подожди" in t for t in texts()))
    # статистика канала
    from autopost import store
    await store.add_channel(-900, 90, "Канал", "kanal")
    for k, (hour_ago, n) in enumerate([(5, 3), (29, 1), (53, 0)]):
        pid = await store.new_post(90, f"пост {k}", [], [-900], {})
        sid = await db.q_run("INSERT INTO ap_schedule(post_id,chat_id,at,status,msg_ids,sent_at) VALUES(?,?,?,?,?,?)",
                             pid, -900, 0, "sent", json.dumps([100 + k]), int(time.time()) - hour_ago * 3600)
        for u_ in range(n):
            await store.react(-900, 100 + k, 500 + u_, 0)
    SENT.clear()
    await dp.feed_update(bot, cbq("ap:x_stat:-900", 90, 90))
    t = H.sent(H.EditMessageText)[-1].text if H.sent(H.EditMessageText) else texts()[-1]
    check("статистика: всего и реакции", "<b>3</b>" in t and "<b>4</b>" in t)
    check("статистика: лучший пост со ссылкой", "t.me/kanal/100" in t and "пост 0" in t)
    # админ: карточка и выдача
    SENT.clear()
    await dp.feed_update(bot, msg("/user 91", 1, 1))
    check("/user: карточка", any("id 91" in t for t in texts()))
    await db.q_run("UPDATE users SET coins=0 WHERE id=91")
    await dp.feed_update(bot, cbq("adm:g:91:c1000", 1, 1))
    check("выдача +1000 🪙", (await db.get_user(91))["coins"] == 1000)
    await dp.feed_update(bot, msg("/grant 92 plus 30", 1, 1))
    check("/grant plus 30", (await db.get_user(92))["plus_until"] > time.time() + 29 * 86400)
    await dp.feed_update(bot, cbq("adm:g:91:ban", 1, 1))
    check("бан из карточки", (await db.get_user(91))["banned"] == 1)
    await dp.feed_update(bot, msg("/user 92", 90, 90))
    check("/user не для всех", not any("id 92" in t for t in texts()[-1:]))
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
