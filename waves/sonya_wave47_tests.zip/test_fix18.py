import asyncio
from harness import *  # noqa
import harness as H

async def main():
    M, bot, dp = await setup()
    from autopost import media_dl, rules as R
    import llm
    car = {"pinner": {"image_medium_url": "x", "images": {"736x": {"url": "https://i.pinimg.com/736x/avatar.jpg"}}},
           "images": {"736x": {"url": "https://i.pinimg.com/736x/main.jpg"}},
           "carousel_data": {"carousel_slots": [
               {"images": {"736x": {"url": "https://i.pinimg.com/736x/a.jpg"}, "orig": {"url": "https://i.pinimg.com/originals/a.jpg"}}},
               {"images": {"orig": {"url": "https://i.pinimg.com/originals/b.jpg"}}}]}}
    got = media_dl.pinterest_images(car)
    check("карусель: 2 картинки, без аватарки", got == ["https://i.pinimg.com/736x/a.jpg", "https://i.pinimg.com/originals/b.jpg"])
    story = {"story_pin_data": {"pages": [{"blocks": [{"image": {"images": {"736x": {"url": "u1"}}}}]},
                                          {"blocks": [{"image": {"images": {"736x": {"url": "u2"}}}}]}]}}
    check("идея-пин: страницы", media_dl.pinterest_images(story) == ["u1", "u2"])
    check("обычный пин: ничего", media_dl.pinterest_images({"images": {"736x": {"url": "m"}}}) == [])

    async def pin(url):
        return car
    async def novideo(item):
        return None
    media_dl.pinterest_pin = pin
    R._video_from = novideo
    item = {"image": "https://i.pinimg.com/736x/main.jpg", "video_page": "https://www.pinterest.com/pin/123/"}
    media = await R.resolve_media({"with_media": 1}, {"media_kind": "all"}, item)
    check("Pinterest-карусель уходит альбомом", [m["src"] for m in media] == got)
    async def single(url):
        return {"images": {}}
    media_dl.pinterest_pin = single
    media = await R.resolve_media({"with_media": 1}, {"media_kind": "all"}, {"image": "one.jpg", "video_page": "https://www.pinterest.com/pin/5/"})
    check("одиночный пин — одна картинка", [m["src"] for m in media] == ["one.jpg"])

    # зрение: qwen без размышлений; если параметр не принят — без него
    calls = []
    async def call(model, msgs, mt, t, url=None, key=None, extra=None):
        calls.append((model, extra, mt))
        if extra:
            raise llm.LLMError("400 reasoning_effort not supported")
        return "котик", 5
    llm._call = call
    out = await llm.ask_vision("s", "что тут", "http://img")
    check("зрение: модель qwen3.8, размышления выключены", calls[0][0] == "qwen/qwen3.8-27b" and calls[0][1] == {"reasoning_effort": "none"})
    check("зрение: параметр не принят — повтор без него", out == "котик" and calls[1][1] is None and calls[1][2] > 120)
    calls.clear()
    async def call2(model, msgs, mt, t, url=None, key=None, extra=None):
        calls.append(extra)
        return "", 5
    llm._call = call2
    await llm.ask_vision("s", "q", "http://img")
    check("зрение: пустой ответ — второй заход", len(calls) == 2)
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
