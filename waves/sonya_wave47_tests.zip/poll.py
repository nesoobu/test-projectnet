import asyncio, sys, os
sys.path.insert(0, sys.argv[1]); os.chdir(sys.argv[1])
from aiohttp import web
from handlers import tools
hits = []
async def h(req):
    hits.append(str(req.rel_url))
    if "nologo" in req.query or "model" in req.query:
        return web.Response(status=402, text="pay")
    return web.Response(body=b"\xff\xd8img", content_type="image/jpeg")
async def main():
    app = web.Application(); app.router.add_get("/prompt/{p}", h)
    r = web.AppRunner(app); await r.setup(); await web.TCPSite(r, "127.0.0.1", 8765).start()
    data = await tools.fetch_image("http://127.0.0.1:8765/prompt/cat?width=1&nologo=true&seed=1&model=flux")
    print("ok:", data[:2] == b"\xff\xd8", "tries:", len(hits))
    hits.clear()
    try:
        await tools.fetch_image("http://127.0.0.1:8765/prompt/x?model=flux&nologo=true&bad=1".replace("prompt/x", "nope"))
    except RuntimeError as e:
        print("404 ->", e, "tries:", len(hits))
    await r.cleanup()
asyncio.run(main())
