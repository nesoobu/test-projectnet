"""Волна 28: тексты песен, инлайн у помощников, мягкий зов к Соне, экран «Помощники». Профиль: аргумент 2."""
import asyncio, os, sqlite3, sys, tempfile, time
from datetime import datetime
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import AnswerInlineQuery, SendMessage, EditMessageText
from aiogram.types import Update, InlineQuery, User


def iq(text, uid=80):
    H._uid[0] += 1
    return Update(update_id=H._uid[0], inline_query=InlineQuery(
        id=str(H._uid[0]), from_user=User(id=uid, is_bot=False, first_name="И"), query=text, offset=""))


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    from handlers import tools, solo
    from downloader import core, catalog
    async def nosearch(q, n=30): return []
    catalog.search = nosearch
    check("чистка названия", tools.clean_title("Скриптонит - Космос (Official Video) [HD]") == "Скриптонит - Космос")
    # текст песни по кнопке
    async def lyr(q): return {"artist": "Скриптонит", "title": "Космос", "text": "строчка <1>\nстрочка 2"}
    tools.lyrics = lyr
    btn = tools.lyrics_btn("Скриптонит Космос")
    SENT.clear()
    await dp.feed_update(bot, cbq(btn[1], 80, 80))
    t = texts()
    check(f"[{P}] кнопка «Текст песни» присылает текст", any("expandable" in x and "строчка &lt;1&gt;" in x for x in t))
    async def nolyr(q): return None
    tools.lyrics = nolyr
    SENT.clear()
    await dp.feed_update(bot, cbq(tools.lyrics_btn("абв где")[1], 81, 81))
    check(f"[{P}] нет текста — честно говорим", any("не нашла" in x for x in texts()))
    # shazam: под результатом две кнопки
    async def rec(path): return {"title": "Космос", "artist": "Скриптонит", "url": "", "cover": ""}
    tools.recognize = rec
    from aiogram.types import Voice
    SENT.clear()
    await tools.shazam(Message(message_id=5, date=datetime.now(), chat=H.Chat(id=82, type="private"),
                               from_user=User(id=82, is_bot=False, first_name="Ш")).as_(bot), bot,
                       Message(message_id=6, date=datetime.now(), chat=H.Chat(id=82, type="private"),
                               voice=Voice(file_id="v", file_unique_id="v", duration=3)).as_(bot))
    kb = str(H.sent(EditMessageText)[-1].reply_markup)
    check(f"[{P}] shazam: «Скачать» + «Текст песни»", "mx:get:" in kb and "mx:ly:" in kb)

    if P == "full":
        # экран помощников
        tmp = tempfile.mkdtemp()
        os.makedirs(os.path.join(tmp, "data"))
        c = sqlite3.connect(os.path.join(tmp, "data", "dl.db"))
        now = int(time.time())
        c.execute("CREATE TABLE users(id INTEGER, joined INTEGER, last_seen INTEGER, dls INTEGER)")
        c.execute("CREATE TABLE dl_cache(key TEXT)")
        c.executemany("INSERT INTO users VALUES(?,?,?,?)", [(1, now, now, 5), (2, now - 9 * 86400, now - 9 * 86400, 2)])
        c.execute("INSERT INTO dl_cache VALUES('x')"); c.commit(); c.close()
        sqlite3.connect(os.path.join(tmp, "data", "autopost.db")).execute("CREATE TABLE x(a)").connection.close()
        from handlers import admin
        old = config.BASE
        from pathlib import Path
        config.BASE = Path(tmp)
        v = await admin.helpers_view()
        config.BASE = old
        check("помощники: скачивалка с цифрами", "скачивалка" in v and "7" in v and "autopost" not in v)
        SENT.clear()
        await dp.feed_update(bot, msg("/admin", 1, 1))
        check("в админке кнопка «Помощники»", "adm:helpers" in str(H.sent(SendMessage)[-1].reply_markup))
        return await done()

    # ---------- инлайн и deep-link ----------
    if P == "music":
        await db.dl_cache_put("audio:https://youtu.be/a", "audio", "FILE_A", "Скриптонит — Космос (Official)")
        await db.dl_cache_put("audio:https://youtu.be/b", "audio", "FILE_B", "Другое")
        SENT.clear()
        await dp.feed_update(bot, iq("скриптонит космос"))
        a = H.sent(AnswerInlineQuery)[-1]
        check("music inline: трек из кэша, регистр не важен", [r.audio_file_id for r in a.results] == ["FILE_A"])
        check("music inline: кнопка «найти в боте»", a.button and a.button.start_parameter.startswith("q_"))
        got = []
        async def fm(m, q): got.append(q)
        tools.find_music = fm
        await dp.feed_update(bot, msg("/start " + a.button.start_parameter, 83, 83))
        check("music: из инлайна в бота — сразу поиск", got == ["скриптонит космос"])
    else:
        url = "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
        from downloader import links as L
        key = L.find_links(url)[0].url
        await db.dl_cache_put(f"video:{key}", "video", "FILE_V", "клип")
        SENT.clear()
        await dp.feed_update(bot, iq(url))
        a = H.sent(AnswerInlineQuery)[-1]
        check("dl inline: готовое видео из кэша", [getattr(r, "video_file_id", None) for r in a.results] == ["FILE_V"])
        await dp.feed_update(bot, iq("просто текст"))
        check("dl inline: без ссылки — подсказка", not H.sent(AnswerInlineQuery)[-1].results
              and H.sent(AnswerInlineQuery)[-1].button.start_parameter == "go")
        # deep-link → качаем; на 3-м скачивании зовём к Соне
        async def probe(u): return {"title": "клип", "duration": 30}
        core.probe = probe
        await dp.feed_update(bot, msg("/start", 84, 84))
        await db.q_run("UPDATE users SET dls=2 WHERE id=84")
        SENT.clear()
        await dp.feed_update(bot, msg("/start " + a.button.start_parameter, 84, 84))
        t = texts()
        check("dl: из инлайна в бота — сразу качаем", any("качаю твою ссылку" in x for x in t)
              and any(getattr(m, "video", None) == "FILE_V" for m in SENT))
        check("dl: на 3-м скачивании зовём к Соне", any("старшая сестра" in x for x in t))
        SENT.clear()
        await dp.feed_update(bot, msg(url, 84, 84))
        check("dl: на 4-м уже не зовём", not any("старшая сестра" in x for x in texts()))
    await done()


async def done():
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
