"""Проверки волны 14: моки сессии aiogram, временная база, без сети."""
import asyncio
import os
import sys
import tempfile
import time
from datetime import datetime

W = sys.argv[1]
sys.path.insert(0, W)
os.chdir(W)
TMP = tempfile.mkdtemp()

import config  # noqa: E402
config.DB_PATH = os.path.join(TMP, "t.db")
config.OWNER_ID = 1
config.LLM_KEY = "k"
config.AI_DAY_LIMIT = 3
config.AI_DAY_LIMIT_PLUS = 10
import db  # noqa: E402
db.DB_PATH = config.DB_PATH

from aiogram import Bot, Dispatcher  # noqa: E402
from aiogram.client.session.base import BaseSession  # noqa: E402
from aiogram.methods import GetMe, SendMessage, EditMessageText, AnswerInlineQuery, SendDice  # noqa: E402
from aiogram.types import Message, Chat, User, Update, CallbackQuery, InlineQuery, Dice  # noqa: E402

SENT = []


class Mock(BaseSession):
    async def make_request(self, bot, method, timeout=None):
        SENT.append(method)
        if isinstance(method, GetMe):
            return User(id=999, is_bot=True, first_name="Соня", username="Sonya_rubot")
        if isinstance(method, (SendMessage, EditMessageText)):
            cid = method.chat_id
            return Message(message_id=len(SENT) + 100, date=datetime.now(),
                           chat=Chat(id=cid, type="private" if int(cid) > 0 else "supergroup"),
                           text=method.text)
        if isinstance(method, SendDice):
            return Message(message_id=len(SENT) + 100, date=datetime.now(), chat=Chat(id=method.chat_id, type="private"),
                           dice=Dice(emoji="🎲", value=3))
        return True

    async def close(self):
        pass

    async def stream_content(self, *a, **k):
        yield b""


def texts():
    return [getattr(m, "text", None) for m in SENT if isinstance(m, (SendMessage, EditMessageText))]


FAILS = []


def check(name, cond):
    print(("✅" if cond else "❌"), name)
    if not cond:
        FAILS.append(name)


async def main():
    await db.init()
    await db.init()   # повторный init не падает
    from autopost import store as ap_store
    await ap_store.init()
    import llm
    import limits
    import achievements
    from handlers import life, games, party, extra, menu
    import main as M

    bot = Bot("123:abc", session=Mock())
    dp = Dispatcher()
    from middlewares import UserMiddleware
    dp.message.outer_middleware(UserMiddleware())
    dp.callback_query.outer_middleware(UserMiddleware())
    from handlers import groupmod, intents
    dp.include_routers(M.groups, M.design.router, M.admin.router, menu.router, M.donate.router,
                       M.ap_panel.router, M.ap_editor.router, M.ap_rules.router, M.giveaway.router,
                       groupmod.router, M.media.router, games.router, M.tools.router, M.remind.router,
                       extra.router, party.router, M.morning.router, life.router, intents.router,
                       M.social.router, M.chat.router)
    dp.message.outer_middleware(groupmod.GroupGuard())

    uid = 0

    def msg(text, chat_id=50, user_id=50, name="Тим", reply=None):
        nonlocal uid
        uid += 1
        return Update(update_id=uid, message=Message(
            message_id=uid, date=datetime.now(), text=text,
            chat=Chat(id=chat_id, type="private" if chat_id > 0 else "supergroup", title="Чат"),
            from_user=User(id=user_id, is_bot=False, first_name=name), reply_to_message=reply))

    def cbq(data, chat_id=50, user_id=50, mid=1):
        nonlocal uid
        uid += 1
        return Update(update_id=uid, callback_query=CallbackQuery(
            id=str(uid), chat_instance="x", data=data, from_user=User(id=user_id, is_bot=False, first_name="Тим"),
            message=Message(message_id=mid, date=datetime.now(), text="x",
                            chat=Chat(id=chat_id, type="private" if chat_id > 0 else "supergroup"))))

    # ---------- llm: цепочка провайдеров ----------
    config.LLM_URL_2, config.LLM_KEY_2, config.LLM_MODEL_2 = "http://p2", "k2", "m2"
    calls = []

    async def fake_call(model, messages, mt, t, url=None, key=None):
        calls.append(model)
        if model != "m2":
            raise llm.LLMError("429 rate_limit")
        return "привет", 42
    real_call = llm._call
    llm._call = fake_call
    out = await llm.ask([{"role": "user", "content": "x"}], feature="chat")
    check("цепочка: дошли до второго провайдера", out == "привет" and calls == [config.LLM_MODEL, config.LLM_MODEL_FALLBACK, "m2"])
    s = await db.stats()
    check("ai_stats: запрос и токены посчитаны", s["ai_calls"] == 1 and s["ai_tokens"] == 42)

    async def all_fail(*a, **k):
        raise llm.LLMError("500")
    llm._call = all_fail
    try:
        await llm.ask([{"role": "user", "content": "x"}])
        check("всё упало → LLMError", False)
    except llm.LLMError:
        check("всё упало → LLMError", True)
    check("ai_stats: провал посчитан", (await db.stats())["ai_fails"] == 1)
    config.LLM_KEY_2 = ""
    check("без LLM_KEY_2 второй провайдер не в цепочке", len(llm.chain()) == 2)

    # ---------- лимиты ----------
    async def ok_call(model, messages, mt, t, url=None, key=None):
        return "ну привет", 10
    llm._call = ok_call
    for i in range(4):
        await dp.feed_update(bot, msg(f"привет {i}", 77, 77))
    tx = texts()
    check("лимит: 3 ответа, четвёртый — устала", tx.count("ну привет") == 3 and any("выговорилась" in (t or "") or "лимит" in (t or "") or "устал" in (t or "") for t in tx[-1:]))
    check("лимит: реклама Соня+ в отказе", "/plus" in (tx[-1] or ""))
    check("лимит: владелец без лимита", limits.cap(1) == 0)
    extra._plus[78] = time.time() + 1000
    check("лимит: Соня+ = 10", limits.cap(78) == 10)
    llm._call = all_fail
    SENT.clear()
    await dp.feed_update(bot, msg("ещё", 79, 79))
    check("лимит: ошибка ИИ возвращает попытку", await limits.used(79) == 0)
    llm._call = ok_call

    # ---------- инлайн: пауза, пока печатают ----------
    SENT.clear()
    extra.INLINE_PAUSE = 0.2
    iq = lambda i, q: Update(update_id=1000 + i, inline_query=InlineQuery(
        id=f"q{i}", from_user=User(id=80, is_bot=False, first_name="A"), query=q, offset=""))
    await asyncio.gather(dp.feed_update(bot, iq(1, "при")), dp.feed_update(bot, iq(2, "привет")))
    answers = [m for m in SENT if isinstance(m, AnswerInlineQuery)]
    check("инлайн: ответили только на последний запрос", len(answers) == 1 and answers[0].inline_query_id == "q2")
    check("инлайн: списан 1 ИИ-ответ", await limits.used(80) == 1)

    # ---------- дни рождения ----------
    check("parse 12.05", life.parse_bday("12.05") == "12.05")
    check("parse 3 мая", life.parse_bday("3 мая") == "03.05")
    check("parse 29 февраля", life.parse_bday("29 февраля") == "29.02")
    check("parse 31.02 → None", life.parse_bday("31.02") is None)
    check("parse ерунда → None", life.parse_bday("скоро") is None)
    now = datetime(2027, 2, 28, 12, tzinfo=life.persona.MSK)
    check("29.02 в невисокосный = 28-го", life._days_until("29.02", now) == 0)
    SENT.clear()
    await dp.feed_update(bot, msg("соня, у меня др 12 мая", 50, 50))
    u = await db.get_user(50)
    check("фраза «у меня др 12 мая» записала ДР", u["bday"] == "12.05")
    await dp.feed_update(bot, msg("/bday 15.06", 50, 50))
    check("/bday 15.06", (await db.get_user(50))["bday"] == "15.06")
    await dp.feed_update(bot, msg("/bday -", 50, 50))
    check("/bday - стирает", (await db.get_user(50))["bday"] == "")

    # поздравление: ДР сегодня, юзер бывал в группе
    today = datetime.now(life.persona.MSK)
    await db.q_run("UPDATE users SET bday=?, coins=0 WHERE id=50", today.strftime("%d.%m"))
    await dp.feed_update(bot, msg("всем привет", -100, 50))
    SENT.clear()
    await life.congratulate(bot, today)
    u = await db.get_user(50)
    tx = texts()
    check("ДР: +100 🪙 и год отмечен", u["coins"] >= 100 and u["bday_year"] == today.year)
    check("ДР: поздравление в личку", any("🎂" in (t or "") for m, t in zip(SENT, tx) if True) and
          any(isinstance(m, SendMessage) and m.chat_id == 50 and "🎂" in m.text for m in SENT))
    check("ДР: объявление в группе", any(isinstance(m, SendMessage) and m.chat_id == -100 and "день рождения" in m.text
                                         for m in SENT))
    SENT.clear()
    await life.congratulate(bot, today)
    check("ДР: второй раз за год не поздравляет", not SENT)
    await db.set_chat_flag(-100, "bdays", False)
    await dp.feed_update(bot, msg("/bday", -100, 50))
    check("/bday в группе показывает именинников", any("скоро дни рождения" in (t or "") for t in texts()))

    # ---------- достижения ----------
    await db.q_run("UPDATE users SET msgs=150, wins=12, streak=8 WHERE id=60")
    await db.touch_user(User(id=60, is_bot=False, first_name="Аня"))
    await db.q_run("UPDATE users SET msgs=150, wins=12, streak=8, coins=0 WHERE id=60")
    SENT.clear()
    await achievements.check(bot, await db.get_user(60), 60)
    ach_msgs = [m for m in SENT if isinstance(m, SendMessage) and "достижени" in m.text]
    check("достижения: 3 сразу — одним сообщением", len(ach_msgs) == 1 and ach_msgs[0].text.count("🪙") == 3)
    check("достижения: монетки начислены", (await db.get_user(60))["coins"] == 30 + 30 + 50)
    SENT.clear()
    await achievements.check(bot, await db.get_user(60), 60)
    check("достижения: повторно не выдаются", not SENT)
    achievements._have.clear()
    await achievements.check(bot, await db.get_user(60), 60)
    check("достижения: после перезапуска тоже не дублируются", not SENT)
    v = await achievements.view(60)
    check("/ach: прогресс показан", "(150/1000)" in v and "3/16" in v)
    await db.q_run("UPDATE users SET plus_until=? WHERE id=60", int(time.time()) + 100)
    await achievements.check(bot, await db.get_user(60), 60)
    check("достижение «Меценат» за Соню+", "plus" in await achievements.owned(60))
    # из канала — в личку
    SENT.clear()
    await db.q_run("UPDATE users SET msgs=1500 WHERE id=60")
    upd = Update(update_id=5000, callback_query=CallbackQuery(
        id="c", chat_instance="x", data="nothing", from_user=User(id=60, is_bot=False, first_name="Аня"),
        message=Message(message_id=1, date=datetime.now(), text="x", chat=Chat(id=-1009, type="channel"))))
    await dp.feed_update(bot, upd)
    await asyncio.sleep(0.05)
    am = [m for m in SENT if isinstance(m, SendMessage) and "достижени" in m.text]
    check("достижение из канала уходит в личку", am and am[0].chat_id == 60)

    # ---------- игры в базе ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/hangman", 70, 70))
    gid = next(iter(games._hang))
    word = games._hang[gid]["word"]
    games._hang.clear()   # «перезапуск»
    await dp.feed_update(bot, cbq(f"hg:{gid}:{word[0]}", 70, 70))
    g = games._hang.get(gid)
    check("виселица пережила перезапуск", g and word[0] in g["got"])
    games._hang.clear()
    g2 = await games._get("hang", gid, games._hang, ("got", "miss"))
    check("виселица: ход сохранён в базе", word[0] in g2["got"] and isinstance(g2["miss"], set))
    for ch in set(word):
        await dp.feed_update(bot, cbq(f"hg:{gid}:{ch}", 70, 70))
    check("виселица: выигрыш убирает из базы", await db.q_one("SELECT 1 FROM game_state WHERE id=?", f"hang:{gid}") is None)

    async def quiz_stub():
        return "Q?", ["a", "b", "c", "d"], 2, ""
    games.make_quiz = quiz_stub
    await dp.feed_update(bot, msg("/quiz", -200, 71))
    qid = next(iter(games._quiz))
    games._quiz.clear()
    await dp.feed_update(bot, cbq(f"qz:{qid}:0", -200, 71))
    games._quiz.clear()
    await dp.feed_update(bot, cbq(f"qz:{qid}:1", -200, 71))
    q = games._quiz.get(qid)
    check("квиз: попытка запомнена через перезапуск", q is None or 71 in q["tried"])
    await dp.feed_update(bot, cbq(f"qz:{qid}:2", -200, 72))
    check("квиз: верный ответ закрыл вопрос", await db.q_one("SELECT 1 FROM game_state WHERE id=?", f"quiz:{qid}") is None)

    await dp.feed_update(bot, msg("/rps", -200, 71))
    did = next(iter(games._duels))
    games._duels.clear()
    await dp.feed_update(bot, cbq(f"rps:j:{did}", -200, 72))
    games._duels.clear()
    await dp.feed_update(bot, cbq(f"rps:p:{did}:r", -200, 71))
    games._duels.clear()
    await db.q_run("UPDATE users SET coins=0 WHERE id IN (71,72)")
    await dp.feed_update(bot, cbq(f"rps:p:{did}:s", -200, 72))
    check("КНБ-дуэль пережила два перезапуска", (await db.get_user(71))["coins"] == 10)

    # ---------- мафия: перезапуск ----------
    await dp.feed_update(bot, msg("/mafia", -300, 71))
    check("мафия: лобби записано", await db.q_one("SELECT 1 FROM party_live WHERE chat_id=-300"))
    await dp.feed_update(bot, msg("/stopgame", -300, 71))
    check("мафия: стоп убирает запись", not await db.q_one("SELECT 1 FROM party_live WHERE chat_id=-300"))
    await dp.feed_update(bot, msg("/spy", -301, 71))
    party.GAMES.clear()
    SENT.clear()
    await party.recover(bot)
    check("перезапуск: извинилась в чате", any(isinstance(m, SendMessage) and m.chat_id == -301 and "слетела" in m.text
                                               for m in SENT))
    check("перезапуск: запись очищена", not await db.q_all("SELECT 1 FROM party_live"))

    # ---------- /stats ----------
    for i, (u_, t) in enumerate([(81, "пельмени это жизнь"), (82, "пельмени лучше"), (81, "пельмени!"), (83, "ок")]):
        await dp.feed_update(bot, msg(t, -400, u_, name=f"U{u_}"))
    SENT.clear()
    await dp.feed_update(bot, msg("/stats", -400, 81))
    st = texts()[-1]
    check("/stats: болтуны и часы", "болтуны недели" in st and "пик в" in st and "▁" in st or "█" in st)
    check("/stats: слово недели", "пельмени" in st)
    await dp.feed_update(bot, msg("/stats", 81, 81))
    check("/stats в личке — подсказка", "для групп" in texts()[-1])

    # ---------- пишет первой ----------
    await db.q_run("UPDATE users SET last_seen=?, last_nudge=0, nudge=1 WHERE id=50", int(time.time()) - 4 * 86400)
    await db.add_history(50, 50, "user", "привет")
    SENT.clear()
    await life.nudge(bot)
    nm = [m for m in SENT if isinstance(m, SendMessage) and m.chat_id == 50]
    check("nudge: написала первой с кнопкой", nm and nm[0].reply_markup is not None)
    SENT.clear()
    await life.nudge(bot)
    check("nudge: не чаще раза в неделю", not [m for m in SENT if isinstance(m, SendMessage)])
    await dp.feed_update(bot, cbq("ndg:off", 50, 50))
    check("nudge: кнопка выключает", (await db.get_user(50))["nudge"] == 0)
    await dp.feed_update(bot, msg("/nudge", 50, 50))
    check("/nudge включает обратно", (await db.get_user(50))["nudge"] == 1)

    # ---------- профиль и админка ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/me", 60, 60))
    p = texts()[-1]
    check("профиль: достижения и лимит ИИ", "достижения" in p and "ИИ сегодня" in p)
    await dp.feed_update(bot, cbq("m:profile", 60, 60))
    await dp.feed_update(bot, cbq("m:bday", 60, 60))
    await dp.feed_update(bot, cbq("m:ach", 60, 60))
    await dp.feed_update(bot, msg("/admin", 1, 1))
    check("админка: строка ИИ", any("ИИ сегодня" in (t or "") for t in texts()))
    await dp.feed_update(bot, cbq("adm:aistat", 1, 1))
    check("админка: расход ИИ", any("расход ИИ" in (t or "") for t in texts()))
    await dp.feed_update(bot, msg("/settings", -400, 1))
    check("настройки: флаг ДР", any("Поздравлять" in str(m.reply_markup) for m in SENT if isinstance(m, SendMessage)))

    # ---------- уборка ----------
    await db.cleanup(30)
    llm._call = real_call
    await db.close()
    print("\nитого провалов:", len(FAILS))


asyncio.run(main())
