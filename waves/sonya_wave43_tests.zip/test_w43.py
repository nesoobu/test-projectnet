"""Волна 43: свой Bot API — лимиты, переезд (logOut), чистка кэша.
python test_w43.py ../sonya"""
import asyncio
import os
import sys
import tempfile
import time
from pathlib import Path

CODE = Path(sys.argv[1] if len(sys.argv) > 1 else "../sonya").resolve()
TMP = Path(tempfile.mkdtemp())
os.environ.update(BOT_API_URL="http://127.0.0.1:8081/", BOT_API_DIR=str(TMP / "tgapi"), BOT_TOKEN="123:abc")
os.environ.pop("TG_SEND_MB", None)
os.environ.pop("TG_GET_MB", None)
sys.path.insert(0, str(CODE))

import config  # noqa: E402
import tgapi  # noqa: E402

config.BASE = TMP
(TMP / "data").mkdir()
ok = 0


def check(cond, name):
    global ok
    assert cond, name
    ok += 1
    print("✓", name)


# лимиты
check(config.BOT_API_URL == "http://127.0.0.1:8081", "url без хвостового /")
check(config.TG_SEND_MAX == 1990 * 1024 * 1024 and config.mb(config.TG_SEND_MAX) == "2 ГБ", "отправка до 2 ГБ")
check(config.TG_GET_MAX == 500 * 1024 * 1024, "скачивание из TG до 500 МБ")
check(config.mb(49 * 1024 * 1024) == "50 МБ" and config.mb(20 * 1024 * 1024) == "20 МБ", "подписи облачных лимитов")
from autopost import media_dl  # noqa: E402
check(media_dl.MAX_BYTES == config.TG_SEND_MAX and media_dl.LIM == "2 ГБ", "media_dl берёт лимит из config")
import ui  # noqa: E402
check("файлы до 2 ГБ" in ui.HELP_SECTIONS["tools"][1], "в /help — файлы до 2 ГБ")
check(all(len(t) <= 4096 for _b, t in ui.HELP_SECTIONS.values()), "разделы помощи ≤ 4096")

# чистка: старые файлы — в мусор, служебные базы сервера — не трогаем
bd = TMP / "tgapi" / "123:abc"
(bd / "videos").mkdir(parents=True)
old, new, binlog = bd / "videos" / "a.mp4", bd / "videos" / "b.mp4", bd / "td.binlog"
for f in (old, new, binlog):
    f.write_bytes(b"x")
past = time.time() - tgapi.KEEP_SEC - 60
os.utime(old, (past, past))
os.utime(binlog, (past, past))
check(tgapi.clean() == 1 and not old.exists() and new.exists() and binlog.exists(), "чистка кэша Bot API")
check("свой, до 2 ГБ" in tgapi.status(), "статус в админке")

# переезд: logOut из облака один раз, потом ждём свой сервер
CALLS = []


class FakeSession:
    async def close(self):
        pass


class FakeBot:
    fail_me = 0

    def __init__(self, token, session=None, **kw):
        self.where = "local" if session else "cloud"
        self.session = FakeSession()

    async def log_out(self):
        CALLS.append(("logout", self.where))
        return True

    async def get_me(self):
        CALLS.append(("me", self.where))
        if FakeBot.fail_me:
            FakeBot.fail_me -= 1
            raise ConnectionError("down")


tgapi.Bot = FakeBot


async def no_sleep(_s):
    pass


tgapi.asyncio.sleep = no_sleep


async def run():
    FakeBot.fail_me = 2
    await tgapi.prepare("123:abc")
    check(CALLS == [("logout", "cloud"), ("me", "local"), ("me", "local"), ("me", "local")],
          "первый старт: logOut из облака и ожидание своего сервера")
    check(tgapi._marker("123:abc").exists(), "метка переезда")
    CALLS.clear()
    await tgapi.prepare("123:abc")
    check(CALLS == [("me", "local")], "второй старт: без logOut")
    # откат в облако
    CALLS.clear()
    config.BOT_API_URL = ""
    await tgapi.prepare("123:abc")
    check(CALLS == [("logout", "local")] and not tgapi._marker("123:abc").exists(), "откат: logOut из своего сервера")
    CALLS.clear()
    await tgapi.prepare("123:abc")
    check(CALLS == [], "облако без метки — ничего не делаем")
    check(tgapi.session() is None and tgapi.clean() == 0, "без BOT_API_URL — облако, чистки нет")


asyncio.run(run())
print(f"OK {ok}")
