"""Волна 48: анонимки — прочитано / прочитать всё, счётчик переходов, «раскрыться» по желанию, редактор сторис.
BOT_PROFILE=anon python test_w48.py ../sonya"""
import asyncio
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "anon"
from aiogram.methods import SendMessage, SendPhoto, EditMessageMedia, EditMessageReplyMarkup, EditMessageText
from aiogram.types import PhotoSize


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    from handlers import anon
    await dp.feed_update(bot, msg("/start", 10, 10, name="Тим"))
    code = anon.code_of(10)
    for u in (20, 21):
        await dp.feed_update(bot, msg(f"/start a_{code}", u, u))
        await dp.feed_update(bot, msg(f"вопрос от {u}", u, u))
    await dp.feed_update(bot, msg(f"/start a_{code}", 10, 10))   # свой переход не считаем
    check("👀 переходы по ссылке считаются (без своих)", await db.kv_get("an:visits:10") == "2")
    SENT.clear()
    await dp.feed_update(bot, cbq("an:back", 10, 10))
    check("главная: переходы и новые", "👀 2 переходов" in all_text() and "🔵 2 новых" in all_text())
    r = await db.q_one("SELECT * FROM anon_msgs WHERE from_uid=20")
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:sn:{r['id']}", 10, 10))
    check("👁 прочитано без ответа", (await db.q_one("SELECT seen FROM anon_msgs WHERE id=?", r["id"]))["seen"] == 1
          and "✓ прочитано" in str(H.sent(EditMessageReplyMarkup)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq("an:inbox", 10, 10))
    check("входящие: «прочитать всё», новых 1", "an:sall" in kbs() and "новых: 1" in all_text())
    await dp.feed_update(bot, cbq("an:sall", 10, 10))
    check("✅ прочитать всё", (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=10 AND seen=0"))["n"] == 0)
    SENT.clear()
    await dp.feed_update(bot, cbq("an:back", 10, 10))
    check("после — новых нет", "новых" not in all_text())
    # ---- раскрыться — только сам ----
    r21 = await db.q_one("SELECT * FROM anon_msgs WHERE from_uid=21")
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:rv:{r21['id']}", 20, 20))
    check("чужое сообщение раскрыть нельзя", "не нашла" in str([getattr(m, "text", "") for m in SENT]))
    await dp.feed_update(bot, cbq(f"an:rv:{r21['id']}", 21, 21, name="Боря"))
    check("раскрыться — сначала подтверждение", "точно раскрыться" in all_text())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:rvy:{r21['id']}", 21, 21, name="Боря"))
    to_owner = [m.text for m in H.sent(SendMessage, 10)]
    check("получатель узнал имя — по желанию автора", to_owner and "Боря" in to_owner[-1] and "tg://user?id=21" in to_owner[-1])
    mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", r21["mask_id"])
    check("маска подписана именем", mk["label"] == "Боря")
    # ---- редактор сторис ----
    SENT.clear()
    await dp.feed_update(bot, cbq("an:cards", 10, 10))
    ph = H.sent(SendPhoto)
    check("сторис: картинка + кнопки редактора", ph and all(k in str(ph[-1].reply_markup)
                                                           for k in ("an:sc:bg", "an:sc:font", "an:sc:box", "an:sc:photo")))
    for act in ("font", "font", "box", "bg", "topic"):
        await dp.feed_update(bot, cbq(f"an:sc:{act}", 10, 10))
    st = await anon.story_style(10)
    check("стиль меняется и сохраняется", st["font"] == "caveat" and st["box"] == "glass" and st["bg"] == 1
          and st["topic"] == "rate")
    check("правка — той же картинкой (без новых сообщений)", len(H.sent(EditMessageMedia)) == 5)
    await dp.feed_update(bot, cbq("an:sc:text", 10, 10))
    SENT.clear()
    await dp.feed_update(bot, msg("спроси меня про что угодно", 10, 10))
    check("свой текст", (await anon.story_style(10))["text"] == "спроси меня про что угодно" and H.sent(SendPhoto))
    await dp.feed_update(bot, cbq("an:sc:photo", 10, 10))
    SENT.clear()
    await dp.feed_update(bot, msg(None, 10, 10, photo=[PhotoSize(file_id="bg1", file_unique_id="b", width=1, height=1)]))
    check("своё фото фоном", (await anon.story_style(10))["bg"] == "photo"
          and await db.kv_get("an:sphoto:10") == "bg1" and H.sent(SendPhoto))
    SENT.clear()
    await dp.feed_update(bot, cbq("an:sc:done", 10, 10))
    check("готово — кнопки убраны", H.sent(EditMessageReplyMarkup))
    # все шрифты рисуются
    from handlers import anoncards
    ok = True
    for k in anoncards.FONT_KEYS:
        try:
            anoncards.ask_card("задай мне вопрос", "https://t.me/x", "bot", style={"font": k, "box": "glass", "bg": 2})
        except Exception as e:
            ok = False
            print("font", k, e)
    check("все 8 шрифтов рисуют карточку", ok)
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
