"""Волна 51: умное вырезание фона нейросетью U²-Net (u2netp, 4.5 МБ, CPU).
Запускается ОТДЕЛЬНЫМ процессом на каждую картинку — onnxruntime не висит в памяти бота.
python bgcut.py <in> <out.png> [модель]  → PNG с прозрачным фоном. Код возврата 0 — ок.
Ставится по желанию: pip install onnxruntime + файл модели data/models/u2netp.onnx (команда в HANDOFF)."""
import sys
from pathlib import Path

MODEL = Path(__file__).resolve().parent / "data" / "models" / "u2netp.onnx"
SIDE = 320


def cut(src: str, dst: str, model: str = str(MODEL)):
    import numpy as np
    import onnxruntime as ort
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(src)).convert("RGB")
    im.thumbnail((1024, 1024), Image.LANCZOS)
    x = np.asarray(im.resize((SIDE, SIDE), Image.LANCZOS), dtype=np.float32)
    x = x / max(float(x.max()), 1e-6)
    x = (x - np.array([0.485, 0.456, 0.406], dtype=np.float32)) / np.array([0.229, 0.224, 0.225], dtype=np.float32)
    x = x.transpose(2, 0, 1)[None].astype(np.float32)
    opts = ort.SessionOptions()
    opts.intra_op_num_threads = 1          # сервер маленький — не душим соседей
    opts.enable_cpu_mem_arena = False      # без арены пик памяти в разы ниже
    opts.enable_mem_pattern = False
    s = ort.InferenceSession(model, opts, providers=["CPUExecutionProvider"])
    pred = s.run(None, {s.get_inputs()[0].name: x})[0][0, 0]
    pred = (pred - pred.min()) / max(float(pred.max() - pred.min()), 1e-6)
    mask = Image.fromarray((pred * 255).astype("uint8")).resize(im.size, Image.LANCZOS)
    out = im.convert("RGBA")
    out.putalpha(mask)
    out.save(dst, "PNG")


if __name__ == "__main__":
    cut(sys.argv[1], sys.argv[2], *(sys.argv[3:4]))
