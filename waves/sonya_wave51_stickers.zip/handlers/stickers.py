"""Волна 44: 🧩 стикеры и эмодзи-паки из картинок (BOT_PROFILE=stk).
Кидаешь картинку — она становится стикером или эмодзи в твоём паке. Паки создаёт сам бот (Bot API),
имя пака кончается на _by_<бот>. Бесплатно: 1 пак, 30 штук, в названии — подпись бота.
С Соней+: паков без лимита, до предела Telegram, видео-стикеры без лимита, копия чужого пака, чистое название.

Волна 51 («богатый» стикер-бот, по отзывам на fStikBot/Sticker.ly и правилам core.telegram.org/stickers):
• после добавления присылаю сам стикер с карточкой: 😀 эмодзи · ✂️ без фона/↩️ с фоном · ⬅️ первым · 🖼 обложка · 🗑
• ✂️ умное вырезание фона нейросетью (bgcut.py, отдельный процесс — память бота не растёт); нет модели или
  мало памяти — вырезаю однотонный фон как раньше. всегда белая обводка, как у наклейки
• подпись к картинке → надпись на стикере (мем-стиль) + ключевые слова для поиска; эмодзи из подписи — привязка
• альбом → все картинки разом, одним сообщением-прогрессом
• ⭕ кружок → круглый видео-стикер с прозрачными углами; видео 3–10 с ускоряю до 3 с, а не обрезаю
• 📦 экран пака: прогресс до предела, витрина-картинка, обложка, переименовать, удалить пак (с подтверждением)
• 📦 «весь пак себе» из чужого стикера (Соня+) — копия по file_id, без перекодирования и потери качества
• карточки живут в kv (stk:card:<tok>) — кнопки не «устаревают» после перезапуска бота"""
import asyncio
import importlib.util
import io
import json
import logging
import os
import re
import secrets
import shutil
import sys
import time
import unicodedata
import uuid
from collections import defaultdict
from dataclasses import dataclass, asdict
from html import escape
from pathlib import Path
from urllib.parse import quote as quote_url

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile, InputSticker

import config
import db
import premium
import ui
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("stickers")
TG_MAX = {"emoji": 200, "sticker": 120}          # предел Telegram на пак
KIND_ICON = {"emoji": "🧩", "sticker": "🖼"}
KIND_NAME = {"emoji": "эмодзи", "sticker": "стикеров"}
KIND_ONE = {"emoji": "эмодзи", "sticker": "стикеры"}
DEFAULT_EMOJI = "✨"
VIDEO_LIMIT = {"emoji": 64 * 1024, "sticker": 256 * 1024}
EMOJIS = ["😂", "😍", "🥰", "😎", "🤔", "😭", "😡", "🥺", "👍", "🔥", "❤️", "🎉", "😴", "🤡", "💀", "✨"]
ALBUM_WAIT = 1.5                                  # сколько ждём остальные картинки альбома
SMART_MIN_MB = int(os.getenv("STK_SMART_MIN_MB", "320") or 320)   # меньше свободной памяти — умный фон не запускаю
BGCUT = Path(__file__).resolve().parent.parent / "bgcut.py"
CAPTION_FONT = Path(__file__).resolve().parent.parent / "assets" / "fonts" / "RussoOne.ttf"
_locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
_smart_lock = asyncio.Lock()                      # нейросеть — строго по одной картинке за раз
_pending: dict[int, list[Message]] = {}           # картинки, пришедшие до выбора типа пака
_albums: dict[str, list[Message]] = {}
_msgs: dict[str, Message] = {}                    # токен → сообщение (чужой стикер / текст для цитаты)


def _keep(m: Message) -> str:
    tok = secrets.token_hex(5)
    if len(_msgs) > 500:
        _msgs.pop(next(iter(_msgs)))
    _msgs[tok] = m
    return tok


# ================= база =================
async def packs_of(uid: int) -> list[dict]:
    return await db.q_all("SELECT * FROM sticker_packs WHERE uid=? ORDER BY id", uid)


async def pack(uid: int, pid) -> dict | None:
    try:
        return await db.q_one("SELECT * FROM sticker_packs WHERE id=? AND uid=?", int(pid), uid)
    except (TypeError, ValueError):
        return None


async def current(uid: int) -> dict | None:
    pid = await db.kv_get(f"stk:cur:{uid}")
    return await pack(uid, pid) if pid else None


def pack_url(p: dict) -> str:
    return f"https://t.me/{'addemoji' if p['kind'] == 'emoji' else 'addstickers'}/{p['name']}"


def share_url(p: dict) -> str:
    return ("https://t.me/share/url?url=" + quote_url(pack_url(p))
            + "&text=" + quote_url("смотри, какой пак я сделал 😏"))


def bar(n: int, mx: int, width: int = 10) -> str:
    k = min(width, round(width * n / mx)) if mx else 0
    return "▰" * k + "▱" * (width - k)


def limit_of(uid: int, p: dict) -> int:
    return TG_MAX[p["kind"]] if premium.plus(uid) else min(TG_MAX[p["kind"]], premium.COUNT["stk_items"])


async def full_title(bot: Bot, uid: int, title: str) -> str:
    """Без Сони+ в названии пака — подпись бота: паки ходят по рукам и приводят людей."""
    if premium.plus(uid):
        return title[:64]
    me = await bot.me()
    tail = f" · @{me.username}"
    return title[:64 - len(tail)] + tail


def _is_emoji(ch: str) -> bool:
    return ord(ch) > 0x2000 and unicodedata.category(ch) in ("So", "Sk")


def pick_emoji(text: str | None) -> str:
    for ch in text or "":
        if _is_emoji(ch):
            return ch
    return DEFAULT_EMOJI


def emojis_in(text: str | None) -> list[str]:
    """Все эмодзи из текста (для «своих» эмодзи к стикеру), до 20 — предел Telegram."""
    out = []
    for ch in text or "":
        if _is_emoji(ch) and ch not in out:
            out.append(ch)
    return out[:20]


def caption_text(caption: str | None) -> str:
    """Подпись без эмодзи — её пишу на стикере."""
    t = "".join(ch for ch in caption or "" if not _is_emoji(ch))
    return re.sub(r"\s+", " ", t.replace("️", "").replace("‍", "")).strip()[:80]


def keywords_of(text: str) -> list[str]:
    """Ключевые слова для поиска стикера: слова подписи, в сумме до 64 символов (правило Telegram)."""
    out, total = [], 0
    for w in re.findall(r"[\wёЁ]{3,}", text.lower()):
        if w not in out and total + len(w) <= 64 and len(out) < 20:
            out.append(w)
            total += len(w)
    return out


# ================= источник стикера =================
@dataclass
class Src:
    what: str                  # image | video | text
    file_id: str = ""
    caption: str = ""
    text: str = ""
    author: str = ""
    emoji: str = ""            # эмодзи чужого стикера
    sticker: bool = False      # пришёл готовый стикер — фон не трогаю
    round: bool = False        # кружок → круглый видео-стикер
    size: int = 0
    dur: int = 0


def src_of(m: Message) -> Src | None:
    if m.text and not m.text.startswith("/"):
        return Src("text", text=m.text[:300], author=m.from_user.first_name or "я")
    cap = m.caption or ""
    if m.photo:
        p = m.photo[-1]
        return Src("image", p.file_id, cap, size=p.file_size or 0)
    if m.sticker:
        if m.sticker.is_animated:
            return None
        return Src("video" if m.sticker.is_video else "image", m.sticker.file_id, emoji=m.sticker.emoji or "",
                   sticker=True, size=m.sticker.file_size or 0)
    if m.video_note:
        return Src("video", m.video_note.file_id, round=True, size=m.video_note.file_size or 0,
                   dur=m.video_note.duration or 0)
    for obj in (m.animation, m.video):
        if obj:
            return Src("video", obj.file_id, cap, size=obj.file_size or 0, dur=obj.duration or 0)
    if m.document:
        mime = m.document.mime_type or ""
        if mime.startswith(("image/", "video/")):
            return Src("image" if mime.startswith("image/") else "video", m.document.file_id, cap,
                       size=m.document.file_size or 0)
    return None


def media_of(m: Message):
    s = src_of(m)
    return (s.what, s) if s else None


# ================= картинки =================
def cut_flat(im):
    """Однотонный фон → прозрачный (заливка от углов). Мало или почти всё вырезалось — (im, False)."""
    from PIL import Image, ImageDraw
    im = im.convert("RGBA")
    im.thumbnail((480, 480), Image.LANCZOS)            # заливка на питоне — сначала уменьшаем
    inner = im.copy()
    w, h = inner.size
    for xy in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        if inner.getpixel(xy)[3] > 0:
            ImageDraw.floodfill(inner, xy, (0, 0, 0, 0), thresh=40)
    gone = inner.getchannel("A").histogram()[0] / (w * h)
    if gone < 0.03 or gone > 0.92:
        return im, False
    return inner, True


def outline(im, width: int = 0):
    """Белая обводка и мягкая тень по контуру — как у вырезанной наклейки."""
    from PIL import Image, ImageFilter
    im = im.convert("RGBA")
    width = width or max(6, round(max(im.size) / 45))
    pad = width * 2 + 4
    work = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0))
    work.paste(im, (pad, pad))
    alpha = work.getchannel("A").point(lambda a: 255 if a > 40 else 0)
    ring = alpha.filter(ImageFilter.MaxFilter(width * 2 + 1)).filter(ImageFilter.GaussianBlur(1))
    shadow = ring.filter(ImageFilter.GaussianBlur(width)).point(lambda a: int(a * 0.35))
    out = Image.new("RGBA", work.size, (0, 0, 0, 0))
    out.paste(Image.new("RGBA", work.size, (0, 0, 0, 255)), (0, 3), shadow)
    out.paste(Image.new("RGBA", work.size, (255, 255, 255, 255)), (0, 0), ring)
    out.alpha_composite(work)
    return out.crop(out.getbbox() or (0, 0, out.width, out.height))


def cut_bg(im):
    """Совместимость (волна 45): однотонный фон + обводка. Возвращает (картинка, вырезали?)."""
    cut, ok = cut_flat(im)
    return (outline(cut), True) if ok else (im.convert("RGBA"), False)


def apply_smart(im, cutout: bytes):
    """Маска от нейросети: мягкие края, слабый мусор убираю. Плохая маска — None."""
    from PIL import Image
    mask = Image.open(io.BytesIO(cutout)).convert("RGBA").getchannel("A").resize(im.size, Image.LANCZOS)
    mask = mask.point(lambda a: 0 if a < 30 else min(255, int(a * 1.15)))
    fg = 1 - mask.histogram()[0] / (im.width * im.height)
    if fg < 0.03 or fg > 0.97:
        return None
    out = im.convert("RGBA")
    out.putalpha(mask)
    return out.crop(mask.getbbox() or (0, 0, im.width, im.height))


def draw_caption(im, text: str):
    """Надпись внизу стикера: белые буквы с чёрной обводкой, кегль подбираю под ширину."""
    from PIL import Image, ImageDraw, ImageFont
    from handlers.tools import _wrap, _font
    im = im.convert("RGBA")
    k = 512 / max(im.width, im.height)
    im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
    W = 512
    d0 = ImageDraw.Draw(im)
    for size in (64, 56, 48, 42, 36, 30):
        try:
            f = ImageFont.truetype(str(CAPTION_FONT), size)
        except OSError:
            f = _font(size, True)
        lines = _wrap(d0, text, f, W - 40)
        if len(lines) <= 3:
            break
    lines = lines[:3]
    lh = int(size * 1.18)
    block = lh * len(lines) + 16
    canvas = Image.new("RGBA", (W, im.height + block // 2 + 8), (0, 0, 0, 0))
    canvas.paste(im, ((W - im.width) // 2, 0), im)
    d = ImageDraw.Draw(canvas)
    y = canvas.height - block
    sw = max(3, size // 10)
    for ln in lines:
        w = d.textlength(ln, font=f)
        d.text(((W - w) / 2, y), ln, font=f, fill=(255, 255, 255), stroke_width=sw, stroke_fill=(0, 0, 0))
        y += lh
    return canvas


def to_png(data: bytes, kind: str, cut: bool = False, text: str = "", smart: bytes | None = None) -> bytes:
    """Статичный стикер: сторона 512 (эмодзи — ровно 100×100 с прозрачными полями), PNG до 512 КБ.
    smart — PNG с маской от нейросети (если есть), иначе при cut — однотонный фон."""
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert("RGBA")
    if cut:
        done = apply_smart(im, smart) if smart else None
        if done is None:
            done, ok = cut_flat(im)
            done = done if ok else None
        if done is not None:
            im = outline(done)
    if text and kind == "sticker":
        im = draw_caption(im, text)
    if kind == "emoji":
        im.thumbnail((100, 100), Image.LANCZOS)
        canvas = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
        canvas.paste(im, ((100 - im.width) // 2, (100 - im.height) // 2))
        im = canvas
    else:
        k = 512 / max(im.width, im.height)
        im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
    out = io.BytesIO()
    im.save(out, "PNG", optimize=True)
    if out.tell() > 512 * 1024:
        out = io.BytesIO()
        im.save(out, "WEBP", quality=85)
    return out.getvalue()


def smart_ready() -> bool:
    """Умный фон можно: есть модель, onnxruntime и хватает свободной памяти (пик ~250 МБ)."""
    try:
        import bgcut
        if not bgcut.MODEL.exists() or importlib.util.find_spec("onnxruntime") is None:
            return False
        with open("/proc/meminfo") as f:
            avail = next((int(x.split()[1]) for x in f if x.startswith("MemAvailable")), 0)
        return avail // 1024 >= SMART_MIN_MB
    except Exception:
        return False


async def smart_cut(data: bytes) -> bytes | None:
    """Нейросеть в отдельном процессе: память освобождается сразу после картинки."""
    if not smart_ready():
        return None
    from autopost import media_dl
    media_dl._dir()
    src = str(media_dl.DL / uuid.uuid4().hex)
    dst = src + ".png"
    async with _smart_lock:
        try:
            with open(src, "wb") as f:
                f.write(data)
            proc = await asyncio.create_subprocess_exec(sys.executable, "-I", str(BGCUT), src, dst,
                                                        stdout=asyncio.subprocess.DEVNULL,
                                                        stderr=asyncio.subprocess.DEVNULL)
            try:
                await asyncio.wait_for(proc.wait(), 60)
            except asyncio.TimeoutError:
                proc.kill()
                return None
            if proc.returncode == 0 and os.path.exists(dst):
                with open(dst, "rb") as f:
                    return f.read()
        except Exception as e:
            log.info("smart cut: %s", e)
        finally:
            for p in (src, dst):
                try:
                    os.unlink(p)
                except OSError:
                    pass
    return None


# ================= видео =================
async def to_webm(src: str, kind: str, round_: bool = False, dur: int = 0) -> bytes:
    """Видео-стикер: WEBM VP9, до 3 с, 30 к/с, без звука, сторона 512 (эмодзи 100×100), в лимит по размеру.
    3–10 с — ускоряю до 3 с (обрезка теряет смысл ролика); кружок — круг с прозрачными углами."""
    if not shutil.which("ffmpeg"):
        raise RuntimeError("на сервере нет ffmpeg")
    side = 100 if kind == "emoji" else 512
    vf = f"setpts={3 / dur:.3f}*PTS," if 3 < dur <= 10 else ""
    vf += f"scale={side}:{side}:force_original_aspect_ratio=decrease,fps=30"
    if kind == "emoji":
        vf += f",pad={side}:{side}:(ow-iw)/2:(oh-ih)/2:color=black@0"
    if round_:
        vf += (",format=yuva420p,geq=lum='p(X,Y)':cb='cb(X,Y)':cr='cr(X,Y)'"
               ":a='if(lte(hypot(X-W/2,Y-H/2),W/2-2),255,0)'")
    out = src + ".webm"
    try:
        for br in (("200k", "100k", "50k") if kind == "emoji" else ("700k", "400k", "220k", "120k")):
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-loglevel", "error", "-i", src, "-t", "3", "-an", "-vf", vf,
                "-c:v", "libvpx-vp9", "-b:v", br, "-pix_fmt", "yuva420p", "-f", "webm", out,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            try:
                await asyncio.wait_for(proc.wait(), 120)
            except asyncio.TimeoutError:
                proc.kill()
                raise RuntimeError("видео слишком долго перекодируется")
            if proc.returncode != 0:
                raise RuntimeError("не смогла перекодировать видео")
            if os.path.getsize(out) <= VIDEO_LIMIT[kind]:
                with open(out, "rb") as f:
                    return f.read()
        raise RuntimeError("видео не влезает в лимит Telegram — попробуй короче или проще")
    finally:
        for p in (src, out):
            try:
                os.unlink(p)
            except OSError:
                pass


# ================= сборка стикера =================
async def build_src(bot: Bot, s: Src, kind: str, cut: bool, uid: int = 0) -> InputSticker:
    if s.what == "text":   # волна 45: текст → стикер-цитата
        if kind == "emoji":
            raise RuntimeError("текст-стикеры делаю в паке стикеров, в эмодзи 100×100 текст не прочитать — /new")
        from handlers import tools
        q = await asyncio.to_thread(tools.quote_image, s.text, s.author, None)
        data = await asyncio.to_thread(to_png, q, kind)
        return InputSticker(sticker=BufferedInputFile(data, "s.png"), format="static", emoji_list=["💬"],
                            keywords=keywords_of(s.text)[:5] or None)
    if s.size > config.TG_GET_MAX:
        raise RuntimeError(f"файл больше {config.mb(config.TG_GET_MAX)}")
    emoji = s.emoji or pick_emoji(s.caption)
    text = caption_text(s.caption)
    kw = keywords_of(text) or None
    if s.what == "image":
        buf = io.BytesIO()
        await bot.download(s.file_id, destination=buf)
        raw = buf.getvalue()
        cut = cut and not s.sticker
        smart = None
        if cut and smart_ready() and (not uid or await premium.allow(uid, "stk_cut")):
            smart = await smart_cut(raw)
        data = await asyncio.to_thread(to_png, raw, kind, cut, text, smart)
        return InputSticker(sticker=BufferedInputFile(data, "s.png"), format="static", emoji_list=[emoji],
                            keywords=kw)
    from autopost import media_dl
    media_dl._dir()
    path = str(media_dl.DL / uuid.uuid4().hex)
    await bot.download(s.file_id, destination=path)
    data = await to_webm(path, kind, s.round, s.dur)
    return InputSticker(sticker=BufferedInputFile(data, "s.webm"), format="video", emoji_list=[emoji], keywords=kw)


async def build(bot: Bot, m: Message, kind: str) -> InputSticker:
    s = src_of(m)
    if not s:
        raise RuntimeError("анимированные .tgs не умею — пришли картинку, GIF или видео")
    cut = bool(await db.kv_get(f"stk:cut:{m.from_user.id}"))
    return await build_src(bot, s, kind, cut, m.from_user.id)


# ================= карточка стикера =================
async def card_new(uid: int, p: dict, st, src: Src | None, cut: bool) -> str:
    tok = secrets.token_hex(5)
    rec = {"u": uid, "p": p["id"], "f": st.file_id, "q": st.file_unique_id,
           "ce": getattr(st, "custom_emoji_id", "") or "", "e": getattr(st, "emoji", "") or "",
           "v": bool(getattr(st, "is_video", False)), "s": asdict(src) if src else None, "c": cut}
    await db.kv_set(f"stk:card:{tok}", json.dumps(rec, ensure_ascii=False))
    return tok


async def card_get(tok: str, uid: int) -> dict | None:
    raw = await db.kv_get(f"stk:card:{tok}")
    if not raw:
        return None
    rec = json.loads(raw)
    return rec if rec.get("u") == uid else None


async def card_kb(rec: dict, tok: str, uid: int):
    p = await pack(uid, rec["p"])
    s = rec.get("s")
    row1 = [(f"😀 {rec.get('e') or DEFAULT_EMOJI}", f"stk:c:em:{tok}")]
    if s and s.get("what") == "image" and not s.get("sticker"):
        row1.append(("↩️ С фоном", f"stk:c:bg:{tok}") if rec.get("c") else ("✂️ Без фона", f"stk:c:bg:{tok}"))
    row1.append(("🗑", f"stk:c:rm:{tok}", "danger"))
    rows = [row1, [("⬅️ Первым", f"stk:c:up:{tok}"), ("🖼 Обложкой", f"stk:c:cv:{tok}")]]
    if p:
        rows.append([(f"{KIND_ICON[p['kind']]} {p['title'][:22]} · {p['n']}/{limit_of(uid, p)}", f"stk:p:{p['id']}"),
                     ("🔗", pack_url(p))])
    return kb_rows(*rows)


async def _set_of(bot: Bot, name: str):
    try:
        ss = await bot.get_sticker_set(name=name)
        return ss if getattr(ss, "stickers", None) is not None else None
    except Exception as e:
        log.info("get_sticker_set %s: %s", name, e)
        return None


async def _last_sticker(bot: Bot, name: str):
    ss = await _set_of(bot, name)
    return ss.stickers[-1] if ss and ss.stickers else None


async def send_card(m: Message, bot: Bot, uid: int, p: dict, src: Src | None, cut: bool, st=None):
    """Присылаю сам стикер с кнопками. Не нашёлся (Telegram ещё не обновил пак) — текстом."""
    st = st or await _last_sticker(bot, p["name"])
    p = await pack(uid, p["id"]) or p
    if not st:
        return await m.answer(f"✅ добавила в «{escape(p['title'])}» — {p['n']}/{limit_of(uid, p)}",
                              reply_markup=kb_rows([(f"{KIND_ICON[p['kind']]} Открыть пак", pack_url(p)),
                                                    ("📦 Пак", f"stk:p:{p['id']}")]))
    tok = await card_new(uid, p, st, src, cut)
    rec = await card_get(tok, uid)
    await bot.send_sticker(m.chat.id, st.file_id, reply_markup=await card_kb(rec, tok, uid))


# ================= добавление =================
async def _limit(m: Message, uid: int, feat: str):
    await premium.upsell(m, uid, feat)


async def _video_ok(m: Message, uid: int) -> bool:
    if premium.plus(uid):
        return True
    if not await premium.allow(uid, "stk_video"):
        await _limit(m, uid, "stk_video")
        return False
    return True


def kind_kb():
    return kb_rows([("🖼 Пак стикеров", "stk:new:sticker", "success"), ("🧩 Пак эмодзи", "stk:new:emoji", "success")])


async def add_media(m: Message, bot: Bot, kind_for_new: str | None = None):
    uid = m.from_user.id
    s = src_of(m)
    if not s:
        return await m.reply("анимированные стикеры (.tgs) не умею — пришли картинку, GIF или видео")
    async with _locks[uid]:
        p = None if kind_for_new else await current(uid)
        if not p:
            kind = kind_for_new or await db.kv_get(f"stk:want:{uid}")
            if not kind:
                _pending[uid] = [m]
                return await m.reply("что делаем из этого?", reply_markup=kind_kb())
            if s.what == "video" and not await _video_ok(m, uid):
                return
            return await _create(m, bot, uid, kind)
        if p["n"] >= TG_MAX[p["kind"]]:
            return await m.reply(f"в паке уже {p['n']} — это предел Telegram. начни новый: /new")
        if p["n"] >= premium.COUNT["stk_items"] and not premium.plus(uid):
            return await _limit(m, uid, "stk_items")
        if s.what == "video" and not await _video_ok(m, uid):
            return
        st = await m.reply("⏳ делаю…" if s.what != "video" else "⏳ перекодирую видео — секунд 10…")
        try:
            sticker = await build(bot, m, p["kind"])
            await bot.add_sticker_to_set(user_id=uid, name=p["name"], sticker=sticker)
        except (TelegramBadRequest, RuntimeError) as e:
            return await st.edit_text(f"😕 не вышло: {escape(str(e)[:150])}")
        await db.q_run("UPDATE sticker_packs SET n=n+1 WHERE id=?", p["id"])
        try:
            await st.delete()
        except Exception:
            pass
        await send_card(m, bot, uid, p, s, bool(await db.kv_get(f"stk:cut:{uid}")))


async def _create(m: Message, bot: Bot, uid: int, kind: str):
    if len(await packs_of(uid)) >= premium.COUNT["stk_packs"] and not premium.plus(uid):
        return await _limit(m, uid, "stk_packs")
    me = await bot.me()
    name = f"s{uid}_{secrets.token_hex(3)}_by_{me.username}"
    title = f"{m.from_user.first_name or 'мои'} — {KIND_ONE[kind]}"
    st = await m.reply("⏳ создаю пак…")
    try:
        sticker = await build(bot, m, kind)
        await bot.create_new_sticker_set(user_id=uid, name=name, title=await full_title(bot, uid, title),
                                         stickers=[sticker],
                                         sticker_type="custom_emoji" if kind == "emoji" else "regular")
    except (TelegramBadRequest, RuntimeError) as e:
        return await st.edit_text(f"😕 не вышло создать пак: {escape(str(e)[:150])}")
    pid = await db.q_run("INSERT INTO sticker_packs(uid, name, title, kind, n, ts) VALUES(?,?,?,?,1,?)",
                         uid, name, title, kind, int(time.time()))
    await db.kv_set(f"stk:cur:{uid}", str(pid))
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:want:{uid}")
    note = ("\n" + ui.hint("эмодзи из пака видят все, а ставить их в сообщения могут владельцы Telegram Premium")
            if kind == "emoji" else "")
    p = {"id": pid, "kind": kind, "name": name, "title": title, "n": 1}
    await st.edit_text("🎉 <b>пак готов!</b> присылай ещё — добавлю туда же\n"
                       + ui.hint("картинки, альбомы, GIF, кружки, текст — всё станет стикерами") + note,
                       reply_markup=kb_rows([(f"{KIND_ICON[kind]} Открыть пак", pack_url(p)),
                                             ("📤 Поделиться", share_url(p))],
                                            [("✏️ Название", f"stk:ren:{pid}"), ("📦 Пак", f"stk:p:{pid}")]))


# ================= альбомы =================
async def _album_later(key: str, bot: Bot):
    await asyncio.sleep(ALBUM_WAIT)
    msgs = _albums.pop(key, [])
    if msgs:
        await add_many(msgs, bot)


async def add_many(msgs: list[Message], bot: Bot, kind_for_new: str | None = None):
    """Несколько картинок разом: одно сообщение-прогресс, в конце — итог с кнопками пака."""
    first = msgs[0]
    uid = first.from_user.id
    if len(msgs) == 1:
        return await add_media(first, bot, kind_for_new)
    p = None if kind_for_new else await current(uid)
    if not p:
        kind = kind_for_new or await db.kv_get(f"stk:want:{uid}")
        if not kind:
            _pending[uid] = msgs
            return await first.reply(f"что делаем из этих {len(msgs)}?", reply_markup=kind_kb())
        await add_media(first, bot, kind)   # первую — в новый пак, остальные — следом
        msgs = msgs[1:]
        p = await current(uid)
        if not p:
            return
    ok = bad = 0
    st = await first.answer(f"⏳ добавляю {len(msgs)}… {bar(0, len(msgs))}")
    async with _locks[uid]:
        for i, m in enumerate(msgs, 1):
            p = await pack(uid, p["id"])
            if p["n"] >= limit_of(uid, p):
                break
            s = src_of(m)
            if not s or (s.what == "video" and not premium.plus(uid)):
                bad += 1
                continue
            try:
                sticker = await build(bot, m, p["kind"])
                await bot.add_sticker_to_set(user_id=uid, name=p["name"], sticker=sticker)
                await db.q_run("UPDATE sticker_packs SET n=n+1 WHERE id=?", p["id"])
                ok += 1
            except (TelegramBadRequest, RuntimeError) as e:
                log.info("album: %s", e)
                bad += 1
            try:
                await st.edit_text(f"⏳ добавляю {i}/{len(msgs)} {bar(i, len(msgs))}")
            except Exception:
                pass
    p = await pack(uid, p["id"])
    text = f"✅ добавила {ok} в «{escape(p['title'])}» · {p['n']}/{limit_of(uid, p)}"
    if bad:
        text += "\n" + ui.hint(f"не вышло: {bad} (видео в альбоме — с Соней+, .tgs не умею)")
    if p["n"] >= limit_of(uid, p) and ok + bad < len(msgs):
        text += "\n" + ui.hint("пак заполнен — остальное не влезло")
    await st.edit_text(text, reply_markup=kb_rows([(f"{KIND_ICON[p['kind']]} Открыть пак", pack_url(p)),
                                                   ("📤 Поделиться", share_url(p))],
                                                  [("📦 Пак", f"stk:p:{p['id']}")]))


# ================= входящие стикеры и медиа =================
async def _own(uid: int, set_name: str | None) -> dict | None:
    if not set_name:
        return None
    return await db.q_one("SELECT * FROM sticker_packs WHERE uid=? AND name=?", uid, set_name)


async def own_card(m: Message, uid: int, p: dict, st):
    tok = await card_new(uid, p, st, None, False)
    await m.reply("🧩 это из твоего пака — что сделать?",
                  reply_markup=await card_kb(await card_get(tok, uid), tok, uid))


@router.message(F.chat.type == "private", F.sticker)
async def on_sticker(m: Message, bot: Bot):
    uid = m.from_user.id
    p = await _own(uid, m.sticker.set_name)
    if p:   # свой — карточка с действиями
        return await own_card(m, uid, p, m.sticker)
    tok = _keep(m)   # волна 45: чужой стикер — в свой пак или скачать картинкой
    rows = [[("➕ В мой пак", f"stk:add:{tok}", "success")]]
    if m.sticker.set_name:
        rows[0].append(("📦 Весь пак себе", f"stk:cp:{tok}"))
    if not m.sticker.is_animated:
        rows.append([("📥 Скачать", f"stk:png:{tok}")])
    await m.reply("что делаем с этим стикером?", reply_markup=kb_rows(*rows))


@router.callback_query(F.data.startswith("stk:add:"))
async def cb_add(cb: CallbackQuery, bot: Bot):
    m = _msgs.get(cb.data.split(":")[2])
    if not m or m.from_user.id != cb.from_user.id:
        return await cb.answer("кнопка устарела — пришли ещё раз", show_alert=True)
    await cb.answer()
    await add_media(m, bot)


@router.callback_query(F.data.startswith("stk:png:"))
async def cb_png(cb: CallbackQuery, bot: Bot):
    m = _msgs.get(cb.data.split(":")[2])
    if not m or not m.sticker:
        return await cb.answer("кнопка устарела — пришли стикер ещё раз", show_alert=True)
    await cb.answer("качаю…")
    buf = io.BytesIO()
    await bot.download(m.sticker.file_id, destination=buf)
    if m.sticker.is_video:
        return await cb.message.answer_document(BufferedInputFile(buf.getvalue(), "sticker.webm"))

    def _conv(raw: bytes) -> bytes:
        from PIL import Image
        out = io.BytesIO()
        Image.open(io.BytesIO(raw)).save(out, "PNG")
        return out.getvalue()
    try:
        png = await asyncio.to_thread(_conv, buf.getvalue())
    except Exception:
        return await cb.message.answer("😕 не смогла открыть этот стикер")
    await cb.message.answer_document(BufferedInputFile(png, "sticker.png"), caption="📥 держи — с прозрачным фоном")


@router.message(F.chat.type == "private", F.photo | F.animation | F.video | F.document | F.video_note)
async def on_media(m: Message, bot: Bot):
    if m.media_group_id:   # альбом — собираю все картинки и добавляю разом
        key = f"{m.from_user.id}:{m.media_group_id}"
        lst = _albums.setdefault(key, [])
        lst.append(m)
        if len(lst) == 1:
            asyncio.create_task(_album_later(key, bot))
        return
    await add_media(m, bot)


# ================= копия чужого пака (Соня+) =================
def _fmt(st) -> str:
    return "animated" if st.is_animated else "video" if st.is_video else "static"


@router.callback_query(F.data.startswith("stk:cp:"))
async def cb_copy(cb: CallbackQuery, bot: Bot):
    m = _msgs.get(cb.data.split(":")[2])
    uid = cb.from_user.id
    if not m or not m.sticker or m.from_user.id != uid:
        return await cb.answer("кнопка устарела — пришли стикер ещё раз", show_alert=True)
    if not premium.plus(uid):
        await cb.answer()
        return await premium.upsell(cb.message, uid, "stk_copy")
    ss = await _set_of(bot, m.sticker.set_name)
    if not ss or not ss.stickers:
        return await cb.answer("не вижу этот пак", show_alert=True)
    if ss.sticker_type == "mask":
        return await cb.answer("маски не копирую", show_alert=True)
    await cb.answer()
    kind = "emoji" if ss.sticker_type == "custom_emoji" else "sticker"
    items = [InputSticker(sticker=s.file_id, format=_fmt(s), emoji_list=[s.emoji or DEFAULT_EMOJI])
             for s in ss.stickers[:TG_MAX[kind]]]
    me = await bot.me()
    name = f"s{uid}_{secrets.token_hex(3)}_by_{me.username}"
    title = (ss.title or "копия")[:64]
    st = await cb.message.answer(f"⏳ копирую «{escape(title)}» — {len(items)} шт…")
    try:
        await bot.create_new_sticker_set(user_id=uid, name=name, title=title, stickers=items[:50],
                                         sticker_type="custom_emoji" if kind == "emoji" else "regular")
    except TelegramBadRequest as e:
        return await st.edit_text(f"😕 не вышло: {escape(str(e)[:150])}")
    n = min(50, len(items))
    for i, it in enumerate(items[50:], 51):
        try:
            await bot.add_sticker_to_set(user_id=uid, name=name, sticker=it)
            n += 1
        except TelegramBadRequest:
            continue
        if i % 10 == 0:
            try:
                await st.edit_text(f"⏳ копирую {i}/{len(items)} {bar(i, len(items))}")
            except Exception:
                pass
    pid = await db.q_run("INSERT INTO sticker_packs(uid, name, title, kind, n, ts) VALUES(?,?,?,?,?,?)",
                         uid, name, title, kind, n, int(time.time()))
    await db.kv_set(f"stk:cur:{uid}", str(pid))
    p = {"id": pid, "kind": kind, "name": name, "title": title, "n": n}
    await st.edit_text(f"📦 <b>готово!</b> «{escape(title)}» теперь твой — {n} шт\n"
                       + ui.hint("можешь дополнять своими картинками, переименовать и менять порядок"),
                       reply_markup=kb_rows([(f"{KIND_ICON[kind]} Открыть пак", pack_url(p)),
                                             ("📦 Пак", f"stk:p:{pid}")]))


# ================= действия карточки =================
@router.callback_query(F.data.startswith("stk:c:"))
async def cb_card(cb: CallbackQuery, bot: Bot):
    _, _, act, tok = cb.data.split(":", 3)
    uid = cb.from_user.id
    rec = await card_get(tok, uid)
    p = await pack(uid, rec["p"]) if rec else None
    if not rec or not p:
        return await cb.answer("стикер не найден — пришли его мне ещё раз", show_alert=True)
    if act == "em":   # выбор эмодзи
        rows, row = [], []
        for i, e in enumerate(EMOJIS):
            row.append((e, f"stk:c:e{i}:{tok}"))
            if len(row) == 8:
                rows.append(row)
                row = []
        rows.append([("✍️ Свои", f"stk:c:ew:{tok}"), ("‹ Назад", f"stk:c:bk:{tok}")])
        await cb.answer("к какому эмодзи привязать?")
        return await cb.message.edit_reply_markup(reply_markup=kb_rows(*rows))
    if act == "bk":
        await cb.answer()
        return await cb.message.edit_reply_markup(reply_markup=await card_kb(rec, tok, uid))
    if act == "ew":
        await db.kv_set(f"stk:emo:{uid}", tok)
        return await cb.answer("пришли одним сообщением эмодзи — до 20 штук", show_alert=True)
    if act.startswith("e") and act[1:].isdigit():
        i = int(act[1:])
        if i >= len(EMOJIS):
            return await cb.answer()
        return await _set_emoji(cb, bot, rec, tok, [EMOJIS[i]])
    if act == "rm":
        try:
            await bot.delete_sticker_from_set(sticker=rec["f"])
        except TelegramBadRequest as e:
            return await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
        await db.q_run("UPDATE sticker_packs SET n=MAX(0, n-1) WHERE id=?", p["id"])
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:card:{tok}")
        await cb.answer("🗑 убрала из пака — в Telegram обновится за пару минут", show_alert=True)
        try:
            await cb.message.delete()
        except TelegramBadRequest:
            pass
        return
    if act == "up":
        try:
            await bot.set_sticker_position_in_set(sticker=rec["f"], position=0)
        except TelegramBadRequest as e:
            return await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
        return await cb.answer("⬅️ теперь он первый в паке")
    if act == "cv":
        return await _cover(cb, bot, rec, p)
    if act == "bg":
        return await _toggle_bg(cb, bot, rec, tok, p)
    await cb.answer()


async def _set_emoji(target, bot: Bot, rec: dict, tok: str, emo: list[str]):
    uid = rec["u"]
    try:
        await bot.set_sticker_emoji_list(sticker=rec["f"], emoji_list=emo)
    except TelegramBadRequest as e:
        if isinstance(target, CallbackQuery):
            return await target.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
        return await target.reply(f"😕 не вышло: {escape(str(e)[:150])}")
    rec["e"] = emo[0]
    await db.kv_set(f"stk:card:{tok}", json.dumps(rec, ensure_ascii=False))
    if isinstance(target, CallbackQuery):
        await target.answer(f"привязала к {''.join(emo)}")
        try:
            await target.message.edit_reply_markup(reply_markup=await card_kb(rec, tok, uid))
        except TelegramBadRequest:
            pass
    else:
        await target.reply(f"😀 привязала к {''.join(emo)}")


async def _cover(cb: CallbackQuery, bot: Bot, rec: dict, p: dict):
    uid = cb.from_user.id
    try:
        if p["kind"] == "emoji":
            if not rec.get("ce"):
                return await cb.answer("не вижу id эмодзи — пришли его мне ещё раз", show_alert=True)
            await bot.set_custom_emoji_sticker_set_thumbnail(name=p["name"], custom_emoji_id=rec["ce"])
        else:
            if rec.get("v"):
                return await cb.answer("обложку делаю из картинки — видео-стикер не подойдёт", show_alert=True)
            buf = io.BytesIO()
            await bot.download(rec["f"], destination=buf)
            data = await asyncio.to_thread(to_png, buf.getvalue(), "emoji")   # 100×100 — размер обложки
            await bot.set_sticker_set_thumbnail(name=p["name"], user_id=uid, format="static",
                                                thumbnail=BufferedInputFile(data, "thumb.png"))
    except TelegramBadRequest as e:
        return await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
    await cb.answer("🖼 теперь это обложка пака — в Telegram обновится за пару минут", show_alert=True)


async def _toggle_bg(cb: CallbackQuery, bot: Bot, rec: dict, tok: str, p: dict):
    """Заменяю стикер в паке на версию без фона (или обратно) — на том же месте."""
    uid = cb.from_user.id
    if not rec.get("s"):
        return await cb.answer("исходник не сохранился — пришли картинку ещё раз", show_alert=True)
    s = Src(**rec["s"])
    cut = not rec.get("c")
    await cb.answer("✂️ вырезаю фон…" if cut else "↩️ возвращаю фон…")
    ss = await _set_of(bot, p["name"])
    idx = next((i for i, x in enumerate(ss.stickers if ss else []) if x.file_unique_id == rec["q"]), -1)
    try:
        sticker = await build_src(bot, s, p["kind"], cut, uid)
        sticker = sticker.model_copy(update={"emoji_list": [rec.get("e") or sticker.emoji_list[0]]})
        await bot.replace_sticker_in_set(user_id=uid, name=p["name"], old_sticker=rec["f"], sticker=sticker)
    except (TelegramBadRequest, RuntimeError) as e:
        return await cb.message.answer(f"😕 не вышло: {escape(str(e)[:150])}")
    ss = await _set_of(bot, p["name"])
    stickers = ss.stickers if ss else []
    new = stickers[idx] if 0 <= idx < len(stickers) else (stickers[-1] if stickers else None)
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:card:{tok}")
    await send_card(cb.message, bot, uid, p, s, cut, st=new)


# ================= экраны: главная, паки, пак =================
HELP_TEXT = ui.quote("1. выбери пак: 🖼 стикеры или 🧩 эмодзи\n2. кидай картинки, альбомы, GIF, кружки или текст\n"
                     "3. открой пак по ссылке и добавь себе 🎉\n"
                     "✂️ вырежу фон нейросетью и обведу белым, как наклейку\n"
                     "✍️ подпись к картинке — напишу её на стикере · 😀 эмодзи в подписи — привяжу\n"
                     "⭕ кружок → круглый видео-стикер · 🎬 видео до 10 с ускорю до 3 с\n"
                     "💬 текст → стикер-цитата · 📥 чужой стикер → в твой пак, картинкой или весь пак\n"
                     "🃏 под каждым стикером: эмодзи, без фона, первым, обложка, удалить") + "\n" + ui.hint(
    f"🆓 {premium.COUNT['stk_packs']} пак до {premium.COUNT['stk_items']} штук · умный фон "
    f"{premium.DAILY['stk_cut']} в день · видео {premium.DAILY['stk_video']} в день\n"
    "💎 Соня+: без лимитов, весь чужой пак себе, без подписи бота")


async def home_view(uid: int):
    p = await current(uid)
    ps = await packs_of(uid)
    text = ui.head("🧩", "Стикеры и эмодзи", "кидай картинку, альбом, GIF, кружок или текст")
    if p:
        mx = limit_of(uid, p)
        text += f"\n📌 добавляю в <b>{escape(p['title'])}</b>\n{bar(p['n'], mx)} {p['n']}/{mx}"
    if ps:
        text += "\n" + ui.hint(f"📦 паков: {len(ps)} · стикеров: {sum(x['n'] for x in ps)}")
    return text, await start_kb(uid)


async def start_screen(m: Message, uid: int):
    """Волна 47: коротко. Подробности — один раз, при первом заходе (кнопка «❔» — всегда)."""
    from handlers import anon
    text, kb = await home_view(uid)
    if await anon.first_time(uid, "stk_intro"):
        text += "\n" + HELP_TEXT
    await m.answer(text, reply_markup=kb)


async def start_kb(uid: int):
    cut = bool(await db.kv_get(f"stk:cut:{uid}"))
    rows = [[("🖼 Пак стикеров", "stk:new:sticker", "success"), ("🧩 Пак эмодзи", "stk:new:emoji", "success")],
            [(f"{ui.tog(cut)} ✂️ Фон", "stk:cut"), ("📦 Мои паки", "stk:list"), ("❔", "stk:help")]]
    if config.MAIN_BOT:
        rows.append([("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}")])
    return kb_rows(*rows)


@router.callback_query(F.data == "stk:home")
async def cb_home(cb: CallbackQuery):
    await show(cb, *await home_view(cb.from_user.id))


@router.message(Command("new"))
async def cmd_new(m: Message):
    await m.answer("какой пак начнём?", reply_markup=kind_kb())


@router.callback_query(F.data.startswith("stk:new:"))
async def cb_new(cb: CallbackQuery, bot: Bot):
    kind = cb.data.split(":")[2]
    uid = cb.from_user.id
    if kind not in TG_MAX:
        return await cb.answer()
    if len(await packs_of(uid)) >= premium.COUNT["stk_packs"] and not premium.plus(uid):
        await cb.answer()
        return await premium.upsell(cb.message, uid, "stk_packs")
    pending = _pending.pop(uid, None)
    if pending:
        await cb.answer()
        return await add_many(pending, bot, kind_for_new=kind)
    await db.kv_set(f"stk:want:{uid}", kind)
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:cur:{uid}")
    await show(cb, f"{KIND_ICON[kind]} <b>новый пак {KIND_NAME[kind]}</b>\n"
                   + ui.hint("присылай первую картинку — из неё создам пак. можно сразу альбомом"),
               kb_rows([("‹ Назад", "stk:home")]))


@router.message(Command("packs"))
async def cmd_packs(m: Message):
    text, kb = await packs_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "stk:list")
async def cb_list(cb: CallbackQuery):
    await show(cb, *await packs_view(cb.from_user.id))


async def packs_view(uid: int):
    ps = await packs_of(uid)
    if not ps:
        return "📦 паков пока нет — пришли картинку 🙂", kind_kb()
    cur = await current(uid)
    rows = []
    for p in ps:
        mark = "📌 " if cur and cur["id"] == p["id"] else ""
        rows.append([(f"{mark}{KIND_ICON[p['kind']]} {p['title'][:30]} · {p['n']}", f"stk:p:{p['id']}"),
                     ("🔗", pack_url(p))])
    rows.append([("➕ Новый пак", "stk:newm", "success"), ("‹ Назад", "stk:home")])
    return ("📦 <b>твои паки</b>\n" + ui.hint("📌 — сюда добавляю новые · нажми на пак — настройки, 🔗 — открыть"),
            kb_rows(*rows))


@router.callback_query(F.data == "stk:newm")
async def cb_newm(cb: CallbackQuery):
    await show(cb, "какой пак начнём?", kind_kb())


async def pack_view(uid: int, p: dict):
    cur = await current(uid)
    here = bool(cur and cur["id"] == p["id"])
    mx = limit_of(uid, p)
    text = (ui.head(KIND_ICON[p["kind"]], escape(p["title"]), f"пак {KIND_NAME[p['kind']]}")
            + f"\n{bar(p['n'], mx)} <b>{p['n']}</b> из {mx}"
            + ("\n📌 сюда добавляю новые" if here else ""))
    if not premium.plus(uid) and mx < TG_MAX[p["kind"]]:
        text += "\n" + ui.hint(f"💎 с Соней+ — до {TG_MAX[p['kind']]} и без подписи бота в названии")
    rows = [[(f"{KIND_ICON[p['kind']]} Открыть", pack_url(p)), ("📤 Поделиться", share_url(p))],
            [("✅ Добавляю сюда" if here else "📌 Добавлять сюда", f"stk:use:{p['id']}"),
             ("👀 Витрина", f"stk:v:{p['id']}")],
            [("✏️ Название", f"stk:ren:{p['id']}"), ("🗑 Удалить пак", f"stk:pd:{p['id']}", "danger")],
            [("‹ Мои паки", "stk:list")]]
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("stk:p:"))
async def cb_pack(cb: CallbackQuery):
    p = await pack(cb.from_user.id, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    await show(cb, *await pack_view(cb.from_user.id, p))


@router.callback_query(F.data.startswith("stk:use:"))
async def cb_use(cb: CallbackQuery):
    p = await pack(cb.from_user.id, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    await db.kv_set(f"stk:cur:{cb.from_user.id}", str(p["id"]))
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:want:{cb.from_user.id}")
    await show(cb, *await pack_view(cb.from_user.id, p))


@router.callback_query(F.data.startswith("stk:pd:"))
async def cb_pack_del(cb: CallbackQuery):
    p = await pack(cb.from_user.id, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    await show(cb, f"🗑 <b>удалить «{escape(p['title'])}»?</b>\n"
                   + ui.hint("пак пропадёт у всех, кто его добавил. вернуть нельзя"),
               kb_rows([("🗑 Да, удалить", f"stk:pdy:{p['id']}", "danger"), ("Отмена", f"stk:p:{p['id']}")]))


@router.callback_query(F.data.startswith("stk:pdy:"))
async def cb_pack_del_yes(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    p = await pack(uid, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    try:
        await bot.delete_sticker_set(name=p["name"])
    except TelegramBadRequest as e:
        if "STICKERSET_INVALID" not in str(e):   # уже удалён в Telegram — просто чистим у себя
            return await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
    await db.q_run("DELETE FROM sticker_packs WHERE id=?", p["id"])
    if await db.kv_get(f"stk:cur:{uid}") == str(p["id"]):
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:cur:{uid}")
    await show(cb, *await packs_view(uid))


@router.callback_query(F.data.startswith("stk:ren:"))
async def cb_ren(cb: CallbackQuery):
    p = await pack(cb.from_user.id, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    await db.kv_set(f"stk:ren:{cb.from_user.id}", str(p["id"]))
    await cb.answer("✏️ напиши новое название пака", show_alert=True)


# ================= витрина =================
def showcase(title: str, tiles: list[bytes], footer: str) -> bytes:
    """Картинка-витрина пака: градиент, название, сетка стикеров 4×N, подпись. Для сторис и чатов."""
    from PIL import Image, ImageDraw
    from handlers import anoncards
    cols, W, cell, top = 4, 1080, 240, 230
    rows_n = (max(1, len(tiles)) + cols - 1) // cols
    H = top + rows_n * cell + 170
    st = {"bg": sum(map(ord, title)) % len(anoncards.THEMES), "font": "comfortaa"}
    im, _ = anoncards._bg(st)
    im = im.crop((0, 0, W, min(H, anoncards.H))).resize((W, H))
    d = ImageDraw.Draw(im, "RGBA")
    d.rounded_rectangle((40, top - 30, W - 40, top + rows_n * cell + 30), 48, fill=(255, 255, 255, 46),
                        outline=(255, 255, 255, 110), width=3)
    anoncards._shadow_center(d, 80, title[:26], anoncards.font(st, 72))
    for i, raw in enumerate(tiles):
        try:
            t = Image.open(io.BytesIO(raw)).convert("RGBA")
        except Exception:
            continue
        t.thumbnail((cell - 30, cell - 30), Image.LANCZOS)
        x = 60 + (i % cols) * cell + (cell - t.width) // 2
        y = top + (i // cols) * cell + (cell - t.height) // 2
        im.paste(t, (x, y), t)
    anoncards._shadow_center(d, H - 115, footer, anoncards.font({"font": "classic"}, 38, False))
    out = io.BytesIO()
    im.convert("RGB").save(out, "JPEG", quality=92)
    return out.getvalue()


@router.callback_query(F.data.startswith("stk:v:"))
async def cb_showcase(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    p = await pack(uid, cb.data.split(":")[2])
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    ss = await _set_of(bot, p["name"])
    if not ss or not ss.stickers:
        return await cb.answer("пак пока пустой или Telegram его ещё не обновил", show_alert=True)
    await cb.answer("🎨 собираю витрину…")
    tiles = []
    for s in ss.stickers[:12]:
        fid = (s.thumbnail.file_id if s.thumbnail else None) if (s.is_video or s.is_animated) else s.file_id
        if not fid:
            continue
        buf = io.BytesIO()
        try:
            await bot.download(fid, destination=buf)
            tiles.append(buf.getvalue())
        except Exception:
            continue
    me = await bot.me()
    img = await asyncio.to_thread(showcase, p["title"], tiles, f"{len(ss.stickers)} шт · @{me.username}")
    await cb.message.answer_photo(BufferedInputFile(img, "pack.jpg"),
                                  caption=f"{KIND_ICON[p['kind']]} <b>{escape(p['title'])}</b>",
                                  reply_markup=kb_rows([(f"{KIND_ICON[p['kind']]} Добавить пак", pack_url(p)),
                                                        ("📤 Поделиться", share_url(p))]))


# ================= текст =================
@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def on_text(m: Message, bot: Bot):
    uid = m.from_user.id
    pid = await db.kv_get(f"stk:ren:{uid}")
    if pid:
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:ren:{uid}")
        p = await pack(uid, pid)
        if p:
            title = m.text.strip()[:60]
            try:
                await bot.set_sticker_set_title(name=p["name"], title=await full_title(bot, uid, title))
            except TelegramBadRequest as e:
                return await m.reply(f"😕 не вышло: {escape(str(e)[:150])}")
            await db.q_run("UPDATE sticker_packs SET title=? WHERE id=?", title, p["id"])
            p["title"] = title
            text, kb = await pack_view(uid, p)
            return await m.answer(f"✏️ теперь пак называется «{escape(title)}»\n\n" + text, reply_markup=kb)
    tok = await db.kv_get(f"stk:emo:{uid}")
    if tok:   # свои эмодзи к стикеру
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:emo:{uid}")
        emo = emojis_in(m.text)
        rec = await card_get(tok, uid)
        if emo and rec:
            return await _set_emoji(m, bot, rec, tok, emo)
    for e in m.entities or []:   # своё эмодзи из пака — карточка с действиями
        if e.type == "custom_emoji" and e.custom_emoji_id:
            try:
                st = (await bot.get_custom_emoji_stickers(custom_emoji_ids=[e.custom_emoji_id]))[0]
            except (TelegramBadRequest, IndexError, TypeError):
                break
            p = await _own(uid, st.set_name)
            if p:
                return await own_card(m, uid, p, st)
            break
    tok = _keep(m)   # волна 45: любой текст можно превратить в стикер-цитату
    await m.reply("💬 сделать из этого текста стикер-цитату?",
                  reply_markup=kb_rows([("💬 Да, в стикер", f"stk:txt:{tok}", "success"),
                                        ("❔ Как пользоваться", "stk:help")]))


@router.callback_query(F.data.startswith("stk:txt:"))
async def cb_txt(cb: CallbackQuery, bot: Bot):
    m = _msgs.pop(cb.data.split(":")[2], None)
    if not m or m.from_user.id != cb.from_user.id:
        return await cb.answer("кнопка устарела — напиши текст ещё раз", show_alert=True)
    await cb.answer()
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass
    await add_media(m, bot)


@router.callback_query(F.data == "stk:help")
async def cb_help(cb: CallbackQuery):
    await show(cb, "🧩 <b>как это работает</b>\n" + HELP_TEXT, kb_rows([("‹ Назад", "stk:home")]))


@router.callback_query(F.data == "stk:cut")
async def cb_cut(cb: CallbackQuery):
    key = f"stk:cut:{cb.from_user.id}"
    on = not await db.kv_get(key)
    if on:
        await db.kv_set(key, "1")
    else:
        await db.q_run("DELETE FROM kv WHERE k=?", key)
    await cb.answer("✂️ буду вырезать фон и обводить белым, как наклейку" if on else "фон оставляю как есть",
                    show_alert=True)
    try:
        await cb.message.edit_reply_markup(reply_markup=await start_kb(cb.from_user.id))
    except TelegramBadRequest:
        pass
