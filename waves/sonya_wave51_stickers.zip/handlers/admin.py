import asyncio
import logging
from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message
from aiogram.exceptions import TelegramForbiddenError, TelegramRetryAfter

import time
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery

import config
import tgapi
import db
import ui
from autopost import store as ap_store, timeparse
from handlers.ap_common import show, kb_rows

STARTED = time.time()

router = Router()
log = logging.getLogger("admin")
owner = F.from_user.id == config.OWNER_ID


class Adm(StatesGroup):
    broadcast = State()


async def admin_view():
    s = await db.stats()
    g = await ap_store.global_counts()
    text = (
        ui.head("⚙️", "Админка Сони", "всё под контролем")
        + "\n" + ui.stats(("👥 юзеров", f"{s['total']}  (+{s['new']} за сутки)"), ("🟢 активны за сутки", s["active"]),
                          ("💬 групп", s["chats"]), ("⭐ донатов", s["stars"]))
        + "\n" + ui.stats(("🧠 ИИ сегодня", f"{s['ai_calls']} запросов · {s['ai_tokens'] // 1000}k токенов"
                            + (f" · ❌ {s['ai_fails']}" if s["ai_fails"] else "")))
        + "\n" + ui.stats(("📢 каналов", g["channels"]), ("🤖 источников", f"{g['active']}/{g['rules']}"),
                          ("📤 постов за сутки", g["sent24"]), ("📅 в очереди", g["queue"]),
                          ("⚠️ источников с ошибками", g["errors"]) if g["errors"] else ("", ""))
    )
    kb = kb_rows(
        [("🔄 Обновить", "adm:home"), ("📣 Рассылка", "adm:bc")],
        [("👥 Юзеры", "adm:users"), ("🚫 Баны", "adm:bans")],
        [("📢 Все каналы", "adm:chs"), (f"⚠️ Ошибки · {g['errors']}" if g["errors"] else "⚠️ Ошибки", "adm:errs")],
        [("🧠 Проверить ИИ", "adm:ai"), ("📈 Расход ИИ", "adm:aistat")],
        [("📊 Графики и воронка", "adm:charts"), ("🗂 Сервер", "adm:srv")],
        [("📝 Профиль бота", "adm:bio"), ("📥 Скачивания", "adm:dls")],
        [("🤝 Помощники", "adm:helpers"), ("💰 Доходы", "adm:money")] if config.PROFILE == "full" else [],
        [("🩺 Здоровье ботов", "adm:fleet")] if config.PROFILE == "full" else [],
        [("📢 Мой автопостинг", "ap:home"), ("🎨 Интерфейс", "ui:home")],
    )
    return text, kb


BACK = [("‹ Админка", "adm:home")]


@router.message(Command("admin"), owner)
async def cmd_admin(m: Message, state: FSMContext):
    await state.clear()
    await show(m, *await admin_view())


@router.callback_query(F.data == "adm:home", owner)
async def cb_adm(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, *await admin_view())


@router.callback_query(F.data == "adm:users", owner)
async def cb_users(cb: CallbackQuery):
    us = await db.users_recent(15)
    lines = ["<b>👥 последние активные</b>", ui.LINE]
    for u in us:
        tag = f" @{u['username']}" if u["username"] else ""
        ban = " 🚫" if u["banned"] else ""
        lines.append(f"• {ui.esc(u['name'])}{ui.esc(tag)} · <code>{u['id']}</code> · 💬{u['msgs']} · "
                     f"{timeparse.fmt(u['last_seen'])}{ban}")
    lines.append("\n<i>/user id или @ник — карточка с выдачей 🪙 и Соня+ · /ban id · /unban id</i>")
    await show(cb, "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:bans", owner)
async def cb_bans(cb: CallbackQuery):
    us = await db.users_banned()
    text = "<b>🚫 баны</b>\n" + ui.LINE + ("\n<i>никого</i>" if not us else "")
    rows = [[(f"✅ разбанить {u['name'][:20]}", f"adm:unban:{u['id']}")] for u in us]
    await show(cb, text, kb_rows(*rows, BACK))


@router.callback_query(F.data.startswith("adm:unban:"), owner)
async def cb_unban(cb: CallbackQuery):
    await db.set_banned(int(cb.data.split(":")[2]), False)
    await cb_bans(cb)


@router.callback_query(F.data == "adm:chs", owner)
async def cb_all_ch(cb: CallbackQuery):
    chs = await ap_store.all_channels()
    lines = ["<b>📢 все каналы</b>", ui.LINE]
    if not chs:
        lines.append("<i>пусто</i>")
    for c in chs:
        st = "⏸" if c["paused"] else "🟢"
        lines.append(f"{st} {ui.esc(c['title'][:30])} · 🤖{c['nrules']} · владелец <code>{c['owner_id']}</code>")
    await show(cb, "\n".join(lines[:60]), kb_rows(BACK))


@router.callback_query(F.data == "adm:errs", owner)
async def cb_all_errs(cb: CallbackQuery):
    rs = await ap_store.errors_of(None)
    lines = ["<b>⚠️ ошибки источников</b>", ui.LINE]
    if not rs:
        lines.append("<i>всё чисто ✨</i>")
    for r in rs[:25]:
        lines.append(f"• <b>{ui.esc(r['title'][:25])}</b> ({r['type']}) → {ui.esc((r['ch_title'] or '?')[:20])}\n"
                     f"   <i>{ui.esc(r['last_error'][:120])}</i>")
    await show(cb, "\n".join(lines), kb_rows(BACK))


def draw_chart(days: list[str], dau: list[int], new: list[int]) -> bytes:
    """Столбики — активные за день, линия — новые."""
    import io
    from PIL import Image, ImageDraw
    from handlers.tools import _font
    W, H, pad = 900, 460, 50
    im = Image.new("RGB", (W, H), (22, 22, 28))
    d = ImageDraw.Draw(im)
    top = max(dau + new + [1])
    n = len(days)
    bw = (W - 2 * pad) / max(1, n)
    f, fs = _font(16), _font(13)
    d.text((pad, 14), "активные за день (столбики) · новые (линия)", font=f, fill=(220, 220, 230))
    pts = []
    for i, (a, b) in enumerate(zip(dau, new)):
        x = pad + i * bw
        y = H - pad - (H - 2 * pad - 20) * a / top
        d.rectangle([x + 2, y, x + bw - 2, H - pad], fill=(140, 110, 250))
        pts.append((x + bw / 2, H - pad - (H - 2 * pad - 20) * b / top))
        if i % 5 == 0 or i == n - 1:
            d.text((x, H - pad + 6), days[i][5:], font=fs, fill=(160, 160, 170))
    if len(pts) > 1:
        d.line(pts, fill=(255, 190, 80), width=3)
    d.text((W - pad - 60, 14), f"макс {top}", font=fs, fill=(160, 160, 170))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


async def funnel_text() -> str:
    now = int(time.time())
    since = now - 30 * 86400
    users = await db.q_all("SELECT id, joined FROM users WHERE joined>?", since)
    n = len(users)
    if not n:
        return "<i>за 30 дней новых нет</i>"
    back = week = paid = 0
    for u in users:
        d0 = db._day(u["joined"])
        rows = await db.q_all("SELECT day FROM daily_active WHERE uid=? AND day>?", u["id"], d0)
        days = sorted(r["day"] for r in rows)
        if days and days[0] <= db._day(u["joined"] + 2 * 86400):
            back += 1
        if days and days[-1] >= db._day(u["joined"] + 7 * 86400):
            week += 1
    paid = (await db.q_one("SELECT COUNT(DISTINCT user_id) AS n FROM donations WHERE user_id IN "
                           "(SELECT id FROM users WHERE joined>?)", since))["n"]
    pct = lambda x: f"{x} ({round(x / n * 100)}%)"
    return (f"<b>🔻 воронка новичков за 30 дней</b>\n"
            f"👋 пришли: <b>{n}</b>\n↩️ вернулись в первые 2 дня: <b>{pct(back)}</b>\n"
            f"📅 активны через неделю: <b>{pct(week)}</b>\n⭐ платили: <b>{pct(paid)}</b>")


@router.callback_query(F.data == "adm:charts", owner)
async def cb_charts(cb: CallbackQuery):
    from aiogram.types import BufferedInputFile
    await cb.answer("рисую…")
    now = int(time.time())
    days = [db._day(now - i * 86400) for i in range(29, -1, -1)]
    dau_rows = {r["day"]: r["n"] for r in await db.q_all(
        "SELECT day, COUNT(*) AS n FROM daily_active WHERE day>=? GROUP BY day", days[0])}
    new_rows = {}
    for r in await db.q_all("SELECT joined FROM users WHERE joined>?", now - 31 * 86400):
        k = db._day(r["joined"])
        new_rows[k] = new_rows.get(k, 0) + 1
    dau = [dau_rows.get(d, 0) for d in days]
    new = [new_rows.get(d, 0) for d in days]
    wau = (await db.q_one("SELECT COUNT(DISTINCT uid) AS n FROM daily_active WHERE day>=?", days[-7]))["n"]
    mau = (await db.q_one("SELECT COUNT(DISTINCT uid) AS n FROM daily_active WHERE day>=?", days[0]))["n"]
    stick = round(dau[-1] / mau * 100) if mau else 0
    png = await asyncio.to_thread(draw_chart, days, dau, new)
    cap = (f"📊 сегодня: <b>{dau[-1]}</b> · за неделю: <b>{wau}</b> · за месяц: <b>{mau}</b>\n"
           f"липкость (DAU/MAU): <b>{stick}%</b> · новых за 30 дн.: <b>{sum(new)}</b>\n\n" + await funnel_text())
    await cb.message.answer_photo(BufferedInputFile(png, "chart.png"), caption=cap[:1024],
                                  reply_markup=kb_rows(BACK))


@router.callback_query(F.data == "adm:aistat", owner)
async def cb_aistat(cb: CallbackQuery):
    import llm as _llm
    rows = await db.q_all("SELECT day, SUM(calls) AS c, SUM(tokens) AS t, SUM(fails) AS f FROM ai_stats "
                          "GROUP BY day ORDER BY day DESC LIMIT 7")
    feats = await db.q_all("SELECT feature, calls, tokens FROM ai_stats WHERE day=? ORDER BY tokens DESC", db._day())
    lines = ["<b>📈 расход ИИ</b>", ui.LINE, "<b>по дням</b>"]
    lines += [f"{r['day'][5:]} · {r['c']} запр. · {r['t'] // 1000}k ток." + (f" · ❌{r['f']}" if r["f"] else "")
              for r in rows] or ["<i>пусто</i>"]
    if feats:
        lines += ["", "<b>сегодня по фичам</b>"]
        lines += [f"• {ui.esc(r['feature'])}: {r['calls']} · {r['tokens'] // 1000}k" for r in feats]
    lim = config.AI_DAY_LIMIT
    if lim:
        hit = await db.q_one("SELECT COUNT(*) AS n FROM ai_usage WHERE day=? AND n>=?", db._day(), lim)
        lines += ["", f"лимит {lim}/день (Соня+ {config.AI_DAY_LIMIT_PLUS or '∞'}) · упёрлись сегодня: <b>{hit['n']}</b>"]
    chain = " → ".join(m for _u, _k, m in _llm.chain())
    lines += ["", f"<i>цепочка: {ui.esc(chain)}</i>"]
    await show(cb, "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:ai", owner)
async def cb_ai(cb: CallbackQuery):
    await cb.answer("проверяю…")
    import llm as _llm
    res = []
    t0 = time.time()
    try:
        out = await _llm.ask([{"role": "user", "content": "Ответь одним словом: ок"}], max_tokens=300)
        res.append(f"✅ текст ({config.LLM_MODEL}): «{ui.esc(out[:30])}» за {time.time() - t0:.1f}с")
    except Exception as e:
        res.append(f"❌ текст: <code>{ui.esc(str(e)[:150])}</code>")
    t0 = time.time()
    try:
        out = await _llm.ask_vision("Опиши картинку двумя словами.", "что тут?",
                                    "https://upload.wikimedia.org/wikipedia/commons/3/3a/Cat03.jpg")
        res.append(f"✅ зрение ({config.LLM_VISION_MODEL}): «{ui.esc(out[:40])}» за {time.time() - t0:.1f}с")
    except Exception as e:
        res.append(f"⚠️ зрение: <code>{ui.esc(str(e)[:150])}</code>\n<i>подписи будут по контексту, без картинки</i>")
    await show(cb.message, "<b>🧠 проверка ИИ</b>\n" + ui.LINE + "\n" + "\n".join(res), kb_rows(BACK))


def _size(path) -> int:
    import os
    total = 0
    for root, _, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


@router.callback_query(F.data == "adm:srv", owner)
async def cb_srv(cb: CallbackQuery):
    import shutil
    try:
        import yt_dlp
        ytv = yt_dlp.version.__version__
    except Exception:
        ytv = "не установлен"
    du = shutil.disk_usage(str(config.BASE))
    data = _size(config.BASE / "data") / 1024 / 1024
    lines = [
        "<b>🗂 сервер</b>", ui.LINE,
        f"💾 диск: свободно <b>{du.free / 1024**3:.1f} ГБ</b> из {du.total / 1024**3:.1f}",
        f"🗃 данные сони: <b>{data:.1f} МБ</b>",
        f"⏱ работаю: <b>{(time.time() - STARTED) / 3600:.1f} ч</b>",
        f"🎬 yt-dlp: <b>{ytv}</b> · ffmpeg: <b>{'есть' if shutil.which('ffmpeg') else 'нет'}</b>",
        f"📦 Bot API: <b>{tgapi.status()}</b>",
        "",
        "💾 бэкап базы приходит тебе каждый день в 04:00.",
        "<b>восстановить:</b> закинь файл в /root и выполни:",
        "<code>systemctl stop sonya</code>",
        "<code>gunzip -c /root/ФАЙЛ.db.gz &gt; /home/sonya/sonya/data/sonya.db</code>",
        "<code>chown sonya:sonya /home/sonya/sonya/data/sonya.db; systemctl start sonya</code>",
    ]
    await show(cb, "\n".join(lines), kb_rows([("💾 Бэкап сейчас", "adm:bak"), ("⬆️ Обновить yt-dlp", "adm:ytup")],
                                                [("🧪 Проверить музыку", "adm:mus")], BACK))


@router.callback_query(F.data == "adm:mus", owner)
async def cb_mus(cb: CallbackQuery):
    from downloader import catalog
    await cb.answer("проверяю каталоги…")
    rows = await catalog.diag()
    text = (ui.head("🧪", "Музыкальные каталоги", "поиск «oxvgen memory»") + "\n"
            + "\n".join(f"<b>{t}</b>: {r}" for t, r in rows) + "\n\n"
            + ui.hint("ищу по порядку: Яндекс → Deezer → YouTube. хватает одного ✅. "
                      "звук всегда берётся с YouTube — подбираю по длительности"))
    await show(cb, text, kb_rows([("🔄 Ещё раз", "adm:mus")], [("‹ Сервер", "adm:srv")]))


async def dls_view(days: int = 7) -> str:
    since = int(time.time()) - days * 86400
    rows = await db.q_all("SELECT platform, SUM(ok) ok, COUNT(*) n, AVG(CASE WHEN ok=1 THEN sec END) sec "
                          "FROM dl_log WHERE ts>? GROUP BY platform ORDER BY n DESC", since)
    lines = [ui.head("📥", "Скачивания", f"за {days} дн. · что качают и что сломалось"), ""]
    if not rows:
        return "\n".join(lines + [ui.quote("пока пусто — данные копятся с волны 32")])
    tot_ok = sum(r["ok"] or 0 for r in rows)
    tot = sum(r["n"] for r in rows)
    lines.append(ui.stats(("всего", tot), ("✅ успешно", f"{tot_ok * 100 // tot}%")))
    lines.append("")
    for r in rows:
        ok, n = r["ok"] or 0, r["n"]
        rate = ok * 100 // n
        icon = "🟢" if rate >= 85 else "🟡" if rate >= 60 else "🔴"
        sec = f" · ~{r['sec']:.0f} с" if r["sec"] else ""
        lines.append(f"{icon} <b>{ui.esc(r['platform'])}</b> — {n} шт · {rate}%{sec}")
    errs = await db.q_all("SELECT platform, err, COUNT(*) n FROM dl_log WHERE ts>? AND ok=0 "
                          "GROUP BY platform, err ORDER BY n DESC LIMIT 6", since)
    if errs:
        lines += ["", "<b>частые ошибки</b>"]
        lines += [f"• {ui.esc(e['platform'])}: <i>{ui.esc(e['err'][:70])}</i> ×{e['n']}" for e in errs]
    lines += ["", ui.hint("🔴 у платформы — скорее всего, сломался yt-dlp: «🗂 Сервер» → «⬆️ Обновить yt-dlp»")]
    return "\n".join(lines)


@router.callback_query(F.data == "adm:dls", owner)
async def cb_dls(cb: CallbackQuery):
    await show(cb, await dls_view(), kb_rows([("🔄 Обновить", "adm:dls")], BACK))


KIND_NAMES = {"plus": "✨ Соня+", "plussub": "🔁 подписка", "gift": "🎁 подарки", "donate": "🖤 донаты", "": "прочее"}


async def money_view() -> str:
    import premium
    now = int(time.time())
    one = lambda r: (r or {}).get("n") or 0  # noqa: E731

    async def stars(since: int) -> int:
        return one(await db.q_one("SELECT SUM(stars) n FROM donations WHERE ts>?", since))
    lines = [ui.head("💰", "Доходы", "звёзды Telegram"), ""]
    lines.append(ui.stats(("сегодня", f"{await stars(now - 86400)} ⭐"), ("7 дней", f"{await stars(now - 7 * 86400)} ⭐"),
                          ("30 дней", f"{await stars(now - 30 * 86400)} ⭐"), ("всего", f"{await stars(0)} ⭐")))
    kinds = await db.q_all("SELECT kind, SUM(stars) s, COUNT(*) n FROM donations WHERE ts>? GROUP BY kind "
                           "ORDER BY s DESC", now - 30 * 86400)
    if kinds:
        lines += ["", "<b>за 30 дней</b>"] + [f"• {KIND_NAMES.get(k['kind'], k['kind'])}: {k['s']} ⭐ · {k['n']} шт"
                                               for k in kinds]
    active = one(await db.q_one("SELECT COUNT(*) n FROM users WHERE plus_until>? AND id!=?", now, config.OWNER_ID))
    trials = one(await db.q_one("SELECT COUNT(*) n FROM users WHERE plus_trial>0"))
    paid_after = one(await db.q_one(
        "SELECT COUNT(DISTINCT u.id) n FROM users u JOIN donations d ON d.user_id=u.id "
        "WHERE u.plus_trial>0 AND d.ts>u.plus_trial AND d.kind IN ('plus','plussub')"))
    lines += ["", ui.stats(("✨ Соня+ сейчас", active), ("🎁 пробовали", trials),
                           ("💳 купили после пробы", f"{paid_after} ({paid_after * 100 // trials if trials else 0}%)"))]
    hits = await db.q_all("SELECT feat, COUNT(*) n FROM feat_usage WHERE day=? GROUP BY feat", db._day())
    hit = {h["feat"]: h["n"] for h in hits}
    if hit:
        lines.append(ui.stats(*[(premium.NAMES.get(f, f)[:18], n) for f, n in hit.items()]))
        lines.append(ui.hint("сколько людей сегодня пользовались платными лимитами — это твоя аудитория для Сони+"))
    top = await db.q_all("SELECT d.user_id, u.name, SUM(d.stars) s FROM donations d LEFT JOIN users u ON u.id=d.user_id "
                         "GROUP BY d.user_id ORDER BY s DESC LIMIT 5")
    if top:
        lines += ["", "<b>топ поддержавших</b>"] + [f"{i}. {ui.esc(t['name'] or str(t['user_id']))} — {t['s']} ⭐"
                                                     for i, t in enumerate(top, 1)]
    lines += ["", ui.hint("вывод звёзд — в @BotFather → бот → «Баланс», через Fragment; "
                          "звёзды становятся доступны к выводу через 21 день после оплаты")]
    return "\n".join(lines)


@router.callback_query(F.data == "adm:money", owner)
async def cb_money(cb: CallbackQuery):
    await show(cb, await money_view(), kb_rows([("🔄 Обновить", "adm:money")], BACK))


HELPER_NAMES = {"dl.db": "⬇️ скачивалка", "music.db": "🎵 музыка"}


def helper_stats(path) -> dict | None:
    """Чужая база помощника — только чтение, чтобы не мешать его процессу."""
    import sqlite3
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True, timeout=3)
    except sqlite3.Error:
        return None
    try:
        cols = {r[1] for r in c.execute("PRAGMA table_info(users)")}
        if "dls" not in cols:
            return None
        now = int(time.time())
        one = lambda sql, *a: c.execute(sql, a).fetchone()[0] or 0  # noqa: E731
        return {"users": one("SELECT COUNT(*) FROM users"),
                "new24": one("SELECT COUNT(*) FROM users WHERE joined>?", now - 86400),
                "act24": one("SELECT COUNT(*) FROM users WHERE last_seen>?", now - 86400),
                "act7": one("SELECT COUNT(*) FROM users WHERE last_seen>?", now - 7 * 86400),
                "dls": one("SELECT SUM(dls) FROM users"),
                "cache": one("SELECT COUNT(*) FROM dl_cache") if c.execute(
                    "SELECT 1 FROM sqlite_master WHERE name='dl_cache'").fetchone() else 0}
    except sqlite3.Error:
        return None
    finally:
        c.close()


async def helpers_view() -> str:
    import asyncio
    from pathlib import Path
    main = Path(config.DB_PATH).resolve()
    lines = [ui.head("🤝", "Боты-помощники", "узкие боты на твоём коде"), ""]
    found = 0
    for p in sorted((config.BASE / "data").glob("*.db")):
        if p.resolve() == main:
            continue
        st = await asyncio.to_thread(helper_stats, p)
        if not st:
            continue
        found += 1
        lines.append(f"<b>{HELPER_NAMES.get(p.name, p.stem)}</b> · <code>{p.name}</code>")
        lines.append(ui.stats(("👥 всего", st["users"]), ("🆕 за сутки", st["new24"]),
                              ("🔥 активны 24ч", st["act24"]), ("📅 за неделю", st["act7"]),
                              ("⬇️ скачиваний", st["dls"]), ("🗃 в кэше", st["cache"])))
        lines.append("")
    if not found:
        lines.append(ui.quote("пока ни одного не нашла в data/ — запусти по инструкции волны 27"))
    lines.append(ui.hint("цифры из их баз в data/ · 🆕 растёт — значит, их находят в поиске"))
    return "\n".join(lines)


@router.callback_query(F.data == "adm:helpers", owner)
async def cb_helpers(cb: CallbackQuery):
    await show(cb, await helpers_view(), kb_rows([("🔄 Обновить", "adm:helpers")], BACK))


@router.callback_query(F.data == "adm:ytup", owner)
async def cb_ytup(cb: CallbackQuery):
    """TikTok, Instagram и YouTube часто ломают загрузку — свежий yt-dlp обычно чинит."""
    import sys
    await cb.answer("обновляю, это до минуты…")
    proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "pip", "install", "-U", "--quiet", "yt-dlp",
                                                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), 180)
    except asyncio.TimeoutError:
        proc.kill()
        out = b"timeout"
    if proc.returncode == 0:
        text = ("⬆️ <b>yt-dlp обновлён</b>\nчтобы новая версия заработала, перезапусти Соню:\n"
                "<code>systemctl restart sonya</code>")
    else:
        text = ("😕 не вышло обновить отсюда (скорее всего, папка с venv защищена). выполни на сервере:\n"
                f"<code>{ui.esc(sys.executable)} -m pip install -U yt-dlp</code>\n<code>systemctl restart sonya</code>\n\n"
                f"<i>{ui.esc(out.decode(errors='ignore')[-300:])}</i>")
    await cb.message.answer(text)


@router.callback_query(F.data == "adm:bak", owner)
async def cb_backup(cb: CallbackQuery, bot: Bot):
    import system
    await cb.answer("собираю бэкап…")
    res = await system.send_backup(bot, cb.from_user.id)
    if res != "ok":
        await cb.message.answer(f"⚠️ {res}")


@router.message(Command("backup"), owner)
async def cmd_backup(m: Message, bot: Bot):
    import system
    res = await system.send_backup(bot, m.from_user.id)
    if res != "ok":
        await m.answer(f"⚠️ {res}")


@router.callback_query(F.data == "adm:bc", owner)
async def cb_bc(cb: CallbackQuery, state: FSMContext):
    await state.set_state(Adm.broadcast)
    await show(cb, "<b>📣 рассылка</b>\nпришли сообщение (текст, фото, видео — что угодно), "
                   "покажу превью и спрошу подтверждение", kb_rows([("✖️ Отмена", "adm:home")]))


SEGMENTS = {"all": "👥 всем", "active": "🟢 активным 7 дн.", "plus": "✨ с Соней+", "free": "🆓 без Соня+",
            "groups": "💬 в группы"}


async def segment_ids(seg: str) -> list[int]:
    now = int(time.time())
    if seg == "active":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND last_seen>?", now - 7 * 86400)]
    if seg == "plus":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND plus_until>?", now)]
    if seg == "free":
        return [r["id"] for r in await db.q_all("SELECT id FROM users WHERE banned=0 AND plus_until<=?", now)]
    if seg == "groups":
        return [r["id"] for r in await db.q_all("SELECT id FROM chats")]
    return await db.all_user_ids()


@router.message(Adm.broadcast, owner)
async def st_bc(m: Message, state: FSMContext):
    obj = (m.photo[-1] if m.photo else None) or m.video or m.animation
    await state.update_data(src_chat=m.chat.id, src_id=m.message_id, html=m.html_text or "",
                            mfid=obj.file_id if obj else "", mkind="photo" if m.photo else "video" if m.video
                            else "animation" if m.animation else "", msize=getattr(obj, "file_size", 0) if obj else 0)
    rows = [[(f"{name} · {len(await segment_ids(k))}", f"adm:bcgo:{k}")] for k, name in SEGMENTS.items()]
    if config.PROFILE == "full":
        import fleet
        hs = fleet.helpers()
        if hs:
            n = sum(len(fleet.users_of(h["db"])) for h in hs)
            rows.append([(f"🤖 + во всех помощниках · {n}", "adm:bcfleet")])
    await m.answer("👆 так увидят. кому отправляем?", reply_markup=kb_rows(*rows, [("✖️ Отмена", "adm:home")]))


@router.callback_query(F.data.startswith("adm:bcgo"), owner)
async def cb_bcgo(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    await state.clear()
    if not d.get("src_id"):
        return await cb.answer("нечего рассылать", show_alert=True)
    seg = cb.data.split(":")[2] if cb.data.count(":") >= 2 else "all"
    ids = await segment_ids(seg if seg in SEGMENTS else "all")
    await cb.message.edit_text(f"📣 рассылка ({SEGMENTS.get(seg, 'всем')}) на {len(ids)}…")
    ok, fail = await _broadcast(bot, d["src_chat"], d["src_id"], ids)
    await show(cb.message, f"📣 готово: ✅ {ok} · ❌ {fail}", kb_rows(BACK))


@router.callback_query(F.data == "adm:bcfleet", owner)
async def cb_bcfleet(cb: CallbackQuery, state: FSMContext, bot: Bot):
    """Сначала всем в Соне, потом каждому помощнику — от его имени. Медиа перезаливаю (file_id у ботов разные)."""
    import fleet
    d = await state.get_data()
    await state.clear()
    if not d.get("src_id"):
        return await cb.answer("нечего рассылать", show_alert=True)
    if d.get("msize", 0) > 20 * 1024 * 1024:
        return await cb.answer("файл больше 20 МБ — для помощников не скачать", show_alert=True)
    await cb.answer("поехали…")
    await cb.message.edit_text("📣 рассылка во все боты… пришлю отчёт")
    lines = []
    ok, fail = await _broadcast(bot, d["src_chat"], d["src_id"], await segment_ids("all"))
    lines.append(f"🖤 Соня: ✅ {ok} · ❌ {fail}")
    content = {"text": d.get("html", ""), "kind": d.get("mkind", ""), "data": b""}
    if content["kind"]:
        import io
        buf = io.BytesIO()
        await bot.download(d["mfid"], destination=buf)
        content["data"] = buf.getvalue()
    for h in fleet.helpers():
        try:
            o, f = await fleet.broadcast_helper(h, content)
            lines.append(f"{h['name']}: ✅ {o} · ❌ {f}")
        except Exception as e:
            lines.append(f"{h['name']}: ⚠️ {ui.esc(str(e)[:80])}")
    await show(cb.message, "📣 <b>рассылка во все боты — готово</b>\n" + "\n".join(lines), kb_rows(BACK))


@router.callback_query(F.data == "adm:fleet", owner)
async def cb_fleet(cb: CallbackQuery):
    import fleet
    await cb.answer()
    await show(cb, await fleet.status_view(),
               kb_rows([("🔄 Обновить", "adm:fleet"), ("💾 Бэкап всех баз", "adm:fbak")], BACK))


@router.callback_query(F.data == "adm:fbak", owner)
async def cb_fbak(cb: CallbackQuery, bot: Bot):
    import fleet
    await cb.answer("собираю архив…")
    res = await fleet.send_backup_all(bot, cb.from_user.id)
    if res != "ok":
        await cb.message.answer(f"⚠️ {res}")


async def _broadcast(bot: Bot, chat_id: int, msg_id: int, ids: list[int]) -> tuple[int, int]:
    ok = fail = 0
    for uid in ids:
        try:
            await bot.copy_message(uid, chat_id, msg_id)
            ok += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await bot.copy_message(uid, chat_id, msg_id)
                ok += 1
            except Exception:
                fail += 1
        except Exception:
            fail += 1
        await asyncio.sleep(0.05)
    return ok, fail


def _target(m: Message, args: str | None) -> int | None:
    if m.reply_to_message:
        return m.reply_to_message.from_user.id
    a = (args or "").strip()
    return int(a) if a.lstrip("-").isdigit() else None


@router.message(Command("ban"), owner, F.chat.type == "private")
async def cmd_ban(m: Message, command: CommandObject):
    uid = _target(m, command.args)
    if not uid or uid == config.OWNER_ID:
        return await m.answer("кого? ответь на сообщение или дай id")
    await db.set_banned(uid, True)
    await m.answer(f"🚫 <code>{uid}</code> в бане")


@router.message(Command("unban"), owner, F.chat.type == "private")
async def cmd_unban(m: Message, command: CommandObject):
    uid = _target(m, command.args)
    if not uid:
        return await m.answer("кого? ответь на сообщение или дай id")
    await db.set_banned(uid, False)
    await m.answer(f"✅ <code>{uid}</code> разбанен")


@router.message(Command("ai"), F.chat.type.in_({"group", "supergroup"}))
async def cmd_ai(m: Message, command: CommandObject, bot: Bot):
    if m.from_user.id != config.OWNER_ID:
        mem = await bot.get_chat_member(m.chat.id, m.from_user.id)
        if mem.status not in ("administrator", "creator"):
            return
    arg = (command.args or "").strip().lower()
    if arg not in ("on", "off"):
        state = "вкл" if await db.chat_ai_on(m.chat.id) else "выкл"
        return await m.answer(f"болтовня сони здесь: <b>{state}</b>\n/ai on · /ai off")
    await db.set_chat_ai(m.chat.id, arg == "on")
    await m.answer("ок, я тут 🖤" if arg == "on" else "ладно, молчу 🤐")


@router.message(Command("broadcast"), owner)
async def cmd_broadcast(m: Message, bot: Bot):
    src = m.reply_to_message
    if not src:
        return await m.answer("ответь этой командой на сообщение, которое разослать")
    ids = await db.all_user_ids()
    status = await m.answer(f"📣 рассылка на {len(ids)}…")
    ok = fail = 0
    for uid in ids:
        try:
            await src.copy_to(uid)
            ok += 1
        except TelegramRetryAfter as e:
            await asyncio.sleep(e.retry_after)
            try:
                await src.copy_to(uid)
                ok += 1
            except Exception:
                fail += 1
        except TelegramForbiddenError:
            fail += 1
        except Exception as e:
            log.warning("broadcast %s: %s", uid, e)
            fail += 1
        await asyncio.sleep(0.05)
    await status.edit_text(f"📣 готово: ✅ {ok} · ❌ {fail}")


# ================= 👤 карточка юзера и выдача =================
async def _find_user(m: Message, arg: str) -> dict | None:
    if m.reply_to_message and m.reply_to_message.from_user:
        return await db.get_user(m.reply_to_message.from_user.id)
    a = (arg or "").strip()
    if a.startswith("@"):
        return await db.q_one("SELECT * FROM users WHERE lower(username)=?", a[1:].lower())
    if a.lstrip("-").isdigit():
        return await db.get_user(int(a))
    return None


async def user_card(uid: int):
    u = await db.get_user(uid)
    if not u:
        return "не нашла такого", kb_rows(BACK)
    donated = await db.user_donated(uid)
    plus = (u.get("plus_until") or 0) > time.time()
    text = (ui.head("👤", ui.esc(u["name"]), (f"@{ui.esc(u['username'])} · " if u["username"] else "") + f"id {uid}")
            + "\n" + ui.stats(("📅 с нами с", timeparse.fmt(u["joined"])), ("👀 был(а)", timeparse.fmt(u["last_seen"])),
                              ("💬 сообщений", u["msgs"]), ("🪙 монетки", u.get("coins", 0)),
                              ("✨ Соня+", f"до {timeparse.fmt(u['plus_until'])}" if plus else "нет"),
                              ("⭐ донатил", donated), ("👥 привёл", u.get("refs") or 0),
                              ("🎂 ДР", u.get("bday") or "—"), ("🚫 бан", "да" if u["banned"] else "нет")))
    kb = kb_rows([("+100 🪙", f"adm:g:{uid}:c100"), ("+1000 🪙", f"adm:g:{uid}:c1000")],
                 [("✨ +7 дней", f"adm:g:{uid}:p7"), ("✨ +30 дней", f"adm:g:{uid}:p30")],
                 [("✅ Разбанить" if u["banned"] else "🚫 Забанить", f"adm:g:{uid}:ban")],
                 BACK)
    return text, kb


@router.message(Command("user", "юзер"), owner)
async def cmd_user(m: Message, command: CommandObject):
    u = await _find_user(m, command.args)
    if not u:
        return await m.answer("👤 <code>/user 123456</code> · <code>/user @username</code> · или ответом на сообщение")
    text, kb = await user_card(u["id"])
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("adm:g:"), owner)
async def cb_grant(cb: CallbackQuery):
    _, _, uid, what = cb.data.split(":")
    uid = int(uid)
    if not await db.get_user(uid):
        return await cb.answer("нет такого", show_alert=True)
    if what.startswith("c"):
        await db.add_coins(uid, int(what[1:]))
        note = f"+{what[1:]} 🪙"
    elif what.startswith("p"):
        from handlers import extra
        await extra.grant_plus(uid, int(what[1:]))
        note = f"✨ Соня+ +{what[1:]} дн."
    else:
        u = await db.get_user(uid)
        await db.set_banned(uid, not u["banned"])
        note = "разбанен" if u["banned"] else "забанен"
    await cb.answer(f"готово: {note}")
    await show(cb, *await user_card(uid))


@router.message(Command("grant"), owner)
async def cmd_grant(m: Message, command: CommandObject):
    """/grant 123 coins 500 · /grant @user plus 30"""
    parts = (command.args or "").split()
    if len(parts) < 3 or parts[1] not in ("coins", "plus") or not parts[2].isdigit():
        return await m.answer("🎁 <code>/grant 123456 coins 500</code> · <code>/grant @user plus 30</code>")
    u = await _find_user(m, parts[0])
    if not u:
        return await m.answer("не нашла такого юзера")
    n = int(parts[2])
    if parts[1] == "coins":
        await db.add_coins(u["id"], n)
        note = f"+{n} 🪙"
    else:
        from handlers import extra
        await extra.grant_plus(u["id"], n)
        note = f"✨ Соня+ на {n} дн."
    await m.answer(f"🎁 {ui.esc(u['name'])}: {note}")


# ================= 📝 профиль бота (то, что видят в каталоге и до /start) =================
BOT_SHORT = "Соня — ИИ-подруга с характером: болтает, качает видео, рисует, играет и ведёт твои каналы 🖤"
BOT_DESC = ("хей, я соня 🖤 альтушка с сарказмом и памятью\n\n"
            "💬 болтаю как живая и помню, что ты рассказывал\n"
            "⬇️ качаю видео и музыку: TikTok, YouTube, Insta, Pinterest\n"
            "🎙 расшифрую голосовые · 🎨 нарисую · 🗣 озвучу · 👀 посмотрю фото\n"
            "🎮 игры на монетки, питомец, колесо фортуны, блэкджек\n"
            "👥 в группах: мафия, шпион, крокодил, РП-команды, модерация\n"
            "📢 сама веду каналы по расписанию\n\n"
            "жми «Старт» и просто напиши мне 👇")


BIO = {
    "grp": ("Помощник для групп: голосовые в текст, капча, антиспам, варны и муты 🛡",
            "🛡 добавь меня в группу и дай админку\n\n"
            "🎙 голосовые и кружки — сразу превращаю в текст\n"
            "🛡 капча для новичков, антифлуд, ссылки только у админов\n"
            "⚠️ варны, муты, баны · 📜 правила · 📝 заметки · 🌙 ночная тишина · 🤬 фильтр мата\n"
            "🧾 /summary — что вы пропустили · 🏆 /top — самые активные\n\nбесплатно, без обязательных подписок"),
    "stk": ("Сделаю стикеры и эмодзи-пак из твоих картинок за пару секунд 🧩",
            "🧩 пришли картинку, альбом, GIF или кружок — получишь свой пак стикеров\n\n"
            "✂️ вырежу фон нейросетью и обведу белым, как наклейку\n"
            "✍️ подпись к картинке — напишу её на стикере · 💬 стикер из текста\n"
            "⭕ кружок → круглый видео-стикер · 🎬 GIF и видео → видео-стикеры\n"
            "😀 эмодзи, порядок, обложка — кнопками под каждым стикером · 👀 витрина пака\n"
            "📥 скачаю любой стикер картинкой · 📦 весь чужой пак себе — с Соней+\n\nбесплатно, без рекламы и водяных знаков"),
    "dl": ("Скачаю видео и музыку из TikTok, YouTube, Instagram, Pinterest, VK — без водяных знаков и рекламы ⬇️",
           "⬇️ просто кинь ссылку — пришлю видео или mp3\n\n"
           "TikTok (и фото-карусели) · YouTube и Shorts · Instagram Reels · Pinterest · VK · RuTube · X · Reddit · "
           "Likee · Threads · Twitch · Дзен\n🎧 SoundCloud, Spotify, Яндекс Музыка → mp3\n"
           "🎙 голосовые и кружки → текст\n\nбыстро, бесплатно, работает и в группах"),
    "music": ("Найду любую песню по названию или строчке и узнаю, что играет в видео 🎵",
              "🎵 напиши название или строчку из песни — пришлю mp3\n"
              "🎧 пришли голосовое, видео или кружок — скажу, что за трек\n"
              "🔗 Spotify, Яндекс Музыка, SoundCloud — скачаю по ссылке\n\nбесплатно и без рекламы"),
    "games": ("Игры для чата: мафия, крокодил, викторина, угадай мелодию, дуэли и питомцы 🎮",
              "🎮 добавь меня в беседу — и скучно не будет\n\n"
              "🕵️ мафия и шпион с ролями в личку · 🐊 крокодил по картинке · ❓ викторины\n"
              "🎵 угадай мелодию на скорость · ⚔️ дуэли · 🎡 колесо фортуны · 🃏 блэкджек\n"
              "🐣 питомец · 💍 браки · 🤗 РП: обнять, кусь, дай пять\n\nбесплатно"),
    "anon": ("Анонимные вопросы: получи ссылку — друзья напишут тебе анонимно 💌",
             "💌 получи свою ссылку и кинь её в сторис или био\n\n"
             "🤫 тебе пишут анонимно — текст, голосовые, фото\n↩️ отвечаешь, не зная автора\n"
             "🎭 у каждого анонима своя маска — видно, кто пишет снова; сгорает через 12 ч тишины\n"
             "🎲 анонимный чат со случайным собеседником по темам\n"
             "🚫 блок и жалоба на тех, кто грубит\n\nбесплатно"),
    "gw": ("Розыгрыши в твоём канале: проверка подписки, спонсоры, билеты за друзей и подарки Telegram 🎁",
           "🎁 запусти розыгрыш в своём канале за минуту\n\n"
           "✅ проверка подписки на канал и спонсоров\n🎟 билеты за приглашённых друзей\n"
           "⭐ подарки Telegram победителям — они сами выбирают\n🏁 итоги по времени или числу участников\n"
           "🔍 честный выбор с проверкой и список участников\n\nбесплатно"),
}


def _bio() -> tuple[str, str]:
    return BIO.get(config.PROFILE, (BOT_SHORT, BOT_DESC))


@router.callback_query(F.data == "adm:bio", owner)
async def cb_bio(cb: CallbackQuery, bot: Bot):
    try:
        cur_s = (await bot.get_my_short_description()).short_description or "—"
        cur_d = (await bot.get_my_description()).description or "—"
    except Exception:
        cur_s = cur_d = "?"
    text = (ui.head("📝", "Профиль бота", "это видят в поиске, каталогах и до нажатия «Старт»")
            + "\n<b>сейчас — коротко:</b>\n" + ui.quote(ui.esc(cur_s))
            + "\n<b>сейчас — описание:</b>\n" + ui.quote(ui.esc(cur_d), expandable=True)
            + "\n<b>предлагаю:</b>\n" + ui.quote(ui.esc(_bio()[0])) + "\n" + ui.quote(ui.esc(_bio()[1]), expandable=True))
    await show(cb, text, kb_rows([("✅ Поставить предложенное", "adm:bioset")], BACK))


@router.callback_query(F.data == "adm:bioset", owner)
async def cb_bioset(cb: CallbackQuery, bot: Bot):
    try:
        short, desc = _bio()
        await bot.set_my_short_description(short_description=short)
        await bot.set_my_description(description=desc)
        await cb.answer("готово! открой профиль Сони — там новое описание", show_alert=True)
    except Exception as e:
        await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
