"""Волна 42: анонимки — темы ссылок, картинки для сторис, карточка ответа, входящие."""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "anon"
from aiogram.methods import SendMessage, SendPhoto, CopyMessage


async def main():
    M, bot, dp = await setup()
    from handlers import anon
    await dp.feed_update(bot, msg("/start", 10, 10))
    code = anon.code_of(10)
    SENT.clear()
    await dp.feed_update(bot, cbq("an:cards", 10, 10))
    check("темы картинок: 6 штук", str(H.sent(SendMessage)[-1].reply_markup).count("an:card:") == 6)
    SENT.clear()
    await dp.feed_update(bot, cbq("an:card:rate", 10, 10))
    ph = H.sent(SendPhoto)
    check("картинка для сторис со ссылкой на тему", ph and f"a_{code}_rate" in ph[-1].caption)
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start a_{code}_rate", 20, 20))
    check("по ссылке темы — «оцени меня»", any("оцени меня" in m.text for m in H.sent(SendMessage)))
    SENT.clear()
    await dp.feed_update(bot, msg("твёрдая 9 из 10", 20, 20))
    head = [m.text for m in H.sent(SendMessage) if m.chat_id == 10]
    check("получатель видит тему", head and "оцени меня" in head[-1])
    r = await db.q_one("SELECT * FROM anon_msgs ORDER BY id DESC LIMIT 1")
    check("тема и текст сохранены", r["topic"] == "rate" and r["qtext"] == "твёрдая 9 из 10")
    await dp.feed_update(bot, msg(f"/start a_{code}", 21, 21))
    await dp.feed_update(bot, msg("что ты любишь?", 21, 21))
    SENT.clear()
    await dp.feed_update(bot, msg("/inbox", 10, 10))
    t = H.sent(SendMessage)[-1]
    check("📥 входящие: оба без ответа, кнопки ответить", "⏳" in t.text and str(t.reply_markup).count("an:re:") == 2)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:re:{r['id']}", 10, 10))
    await dp.feed_update(bot, msg("спасибо 🥹", 10, 10))
    check("после ответа — «вопрос и ответ в сторис»", f"an:ac:{r['id']}" in str(H.sent(SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:ac:{r['id']}", 10, 10))
    check("🖼 карточка ответа", H.sent(SendPhoto) and f"a_{code}" in H.sent(SendPhoto)[-1].caption)
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:ac:{r['id']}", 30, 30))
    check("чужую карточку не сделать", not H.sent(SendPhoto))
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
