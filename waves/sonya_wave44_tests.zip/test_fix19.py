import asyncio, io, sys, os
from harness import *  # noqa
import harness as H

async def main():
    M, bot, dp = await setup()
    import llm
    from aiohttp import web
    from PIL import Image
    b = io.BytesIO(); Image.new("RGB", (3000, 2000), "red").save(b, "JPEG")
    async def h(req):
        if "User-Agent" not in req.headers or "Mozilla" not in req.headers["User-Agent"]:
            return web.Response(status=403)
        return web.Response(body=b.getvalue(), content_type="image/jpeg")
    app = web.Application(); app.router.add_get("/a.jpg", h)
    r = web.AppRunner(app); await r.setup(); await web.TCPSite(r, "127.0.0.1", 8766).start()
    seen = []
    async def call(model, msgs, mt, t, url=None, key=None, extra=None):
        seen.append(msgs[1]["content"][1]["image_url"]["url"]); return "красное", 3
    llm._call = call
    out = await llm.ask_vision("s", "q", "http://127.0.0.1:8766/a.jpg")
    d = seen[0]
    import base64
    im = Image.open(io.BytesIO(base64.b64decode(d.split(",", 1)[1])))
    check("зрение: картинка уходит data:URL, ужата до 1024", d.startswith("data:image/jpeg;base64,") and max(im.size) == 1024)
    seen.clear()
    await llm.ask_vision("s", "q", "http://127.0.0.1:8766/none.jpg")
    check("не скачалась — отдаём ссылку как есть", seen[0] == "http://127.0.0.1:8766/none.jpg")
    seen.clear()
    await llm.ask_vision("s", "q", "data:image/jpeg;base64,AAA")
    check("data:URL не трогаем", seen[0] == "data:image/jpeg;base64,AAA")
    await r.cleanup()
    # меню команд
    from aiogram.methods import SetMyCommands, DeleteMyCommands
    SENT.clear()
    await M.setup_commands(bot)
    sets = H.sent(SetMyCommands) if False else [m for m in SENT if isinstance(m, SetMyCommands)]
    dels = [m for m in SENT if isinstance(m, DeleteMyCommands)]
    check("старые списки стёрты, в т.ч. ru", len(dels) >= 16 and any(d.language_code == "ru" for d in dels))
    kinds = {type(m.scope).__name__: len(m.commands) for m in sets}
    check("свои списки: личка, группы, админы, владелец", kinds.get("BotCommandScopeAllPrivateChats") == 17
          and kinds.get("BotCommandScopeAllGroupChats") == 18 and kinds.get("BotCommandScopeChat") == 21)
    import re
    allc = [c.command for m in sets for c in m.commands]
    check("имена команд валидны", all(re.fullmatch(r"[a-z0-9_]{1,32}", c) for c in allc))
    # все команды из меню реально обрабатываются
    import inspect, glob
    src = "".join(open(f, encoding="utf-8").read() for f in glob.glob("handlers/*.py"))
    missing = [c for c in set(allc) if f'"{c}"' not in src]
    check(f"у всех команд есть обработчик {missing}", not missing)
    await db.close()
    print("\nитого провалов:", len(FAILS))
asyncio.run(main())
