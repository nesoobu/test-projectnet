"""💌 Анонимные вопросы: у каждого своя ссылка → друзья пишут анонимно → отвечаешь, не зная, кто это.
Защита: блок отправителя, жалоба, фильтр угроз, лимит частоты, «не принимать сообщения»."""
import hashlib
import logging
import re
import time
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("anon")
RATE = (5, 60)            # не больше 5 сообщений в минуту от одного человека
_writing: dict[int, tuple] = {}               # отправитель → (кому, когда начал, тема, id анонимки-родителя)
_labeling: dict[int, int] = {}                # получатель → id маски, которую подписывает
_replying: dict[int, tuple[int, float]] = {}   # получатель → (id анонимки, когда нажал «ответить»)
_sent: dict[int, list[float]] = {}
TOPICS = {"q": "задай мне анонимный вопрос", "rate": "оцени меня от 1 до 10", "conf": "признайся мне в чём-нибудь",
          "think": "что ты обо мне думаешь?", "nh": "я никогда не…", "advice": "дай мне совет"}
TOPIC_ICON = {"q": "❓", "rate": "⭐", "conf": "💘", "think": "💭", "nh": "🙊", "advice": "💡"}
# волна 46: маски — «прилагательное + зверь», своя у каждой пары «получатель — аноним»
MASK_ADJ = ["Хитрый", "Сонный", "Тихий", "Весёлый", "Загадочный", "Смелый", "Ленивый", "Добрый", "Быстрый",
            "Мудрый", "Робкий", "Дерзкий", "Нежный", "Важный", "Шустрый", "Мечтательный", "Озорной", "Грустный",
            "Сладкий", "Звёздный"]
MASK_ANIMAL = ["🦊 Лис", "🐼 Панда", "🦉 Сова", "🐺 Волк", "🐱 Кот", "🐰 Заяц", "🐻 Медведь", "🦝 Енот",
               "🐧 Пингвин", "🦔 Ёж", "🐨 Коала", "🦁 Лев", "🐯 Тигр", "🐸 Лягушонок", "🐙 Осьминог", "🦄 Единорог"]
BAD = re.compile(r"(убью|убить тебя|зарежу|сдохни|выпились|самоубий|твой адрес|найду тебя|слив|интим фото)", re.I)


# ================= маски =================
def _mask_text(adj: str, animal: str) -> str:
    emoji, name = animal.split(" ", 1)
    if name in ("Панда", "Сова", "Коала"):   # женский род: Хитрый → Хитрая, Тихий → Тихая, Озорной → Озорная
        adj = adj[:-2] + "ая"
    return f"{emoji} {adj} {name}"


async def mask_of(owner: int, sender: int) -> dict:
    """Маска анонима у этого получателя: создаётся один раз и остаётся навсегда."""
    r = await db.q_one("SELECT * FROM anon_masks WHERE owner=? AND sender=?", owner, sender)
    if r:
        return r
    import random
    used = {x["mask"] for x in await db.q_all("SELECT mask FROM anon_masks WHERE owner=?", owner)}
    free = [_mask_text(a, b) for a in MASK_ADJ for b in MASK_ANIMAL]
    free = [x for x in free if x not in used]
    if free:
        mask = random.choice(free)
    else:   # больше 320 анонимов у одного человека — добавляем номер
        n = 2
        base = _mask_text(random.choice(MASK_ADJ), random.choice(MASK_ANIMAL))
        while f"{base} {n}" in used:
            n += 1
        mask = f"{base} {n}"
    await db.q_run("INSERT OR IGNORE INTO anon_masks(owner, sender, mask) VALUES(?,?,?)", owner, sender, mask)
    return await db.q_one("SELECT * FROM anon_masks WHERE owner=? AND sender=?", owner, sender)


def mask_name(mk: dict) -> str:
    return mk["mask"] + (f" · «{mk['label']}»" if mk.get("label") else "")


async def name_of(uid: int) -> str:
    u = await db.get_user(uid) or {}
    return u.get("name") or "получатель"


# ================= ссылка =================
def code_of(uid: int) -> str:
    return hashlib.sha256(f"anon|{uid}|{config.BOT_TOKEN[:12]}".encode()).hexdigest()[:10]


async def ensure_link(uid: int) -> str:
    code = code_of(uid)
    await db.q_run("INSERT OR IGNORE INTO anon_links(uid, code, open) VALUES(?,?,1)", uid, code)
    return code


async def owner_of(code: str) -> dict | None:
    return await db.q_one("SELECT * FROM anon_links WHERE code=?", code)


async def home(m: Message, bot: Bot, uid: int):
    code = await ensure_link(uid)
    me = await bot.me()
    link = f"https://t.me/{me.username}?start=a_{code}"
    row = await db.q_one("SELECT open, nomat FROM anon_links WHERE uid=?", uid)
    got = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=?", uid))["n"]
    ans = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=? AND answered=1", uid))["n"]
    share = ("https://t.me/share/url?url=" + quote(link) + "&text=" + quote("задай мне анонимный вопрос 👀"))
    text = (ui.head("💌", "Анонимные вопросы", "тебе пишут — ты не знаешь кто")
            + "\n" + ui.quote(f"твоя ссылка:\n<code>{link}</code>")
            + "\n" + ui.hint("кинь её в сторис, био или чат — и жди вопросов 👀\n"
                             "🔒 авторов не раскрываю никому — ни за звёзды, ни за деньги, даже тебе")
            + "\n" + ui.stats(("📬 получено", got), ("💬 отвечено", ans),
                              ("📭 приём", "включён" if (row or {}).get("open", 1) else "выключен")))
    kb = kb_rows([("🎨 Картинка для сторис", "an:cards"), ("📤 Поделиться", share)],
                 [(f"📥 Входящие · {got - ans} без ответа" if got - ans else "📥 Входящие", "an:inbox")],
                 [("📴 Не принимать" if (row or {}).get("open", 1) else "📬 Принимать снова", "an:toggle"),
                  ("🚫 Блокировки", "an:blocks")],
                 [(f"{ui.tog((row or {}).get('nomat', 0))} 🤬 Не принимать мат", "an:mat")],
                 [("🎲 Анонимный чат со случайным человеком", "ch:menu")])
    await m.answer(text, reply_markup=kb)


@router.message(Command("link", "ссылка"))
async def cmd_link(m: Message, bot: Bot):
    await home(m, bot, m.from_user.id)


@router.callback_query(F.data == "an:home")
async def cb_home(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    await home(cb.message, bot, cb.from_user.id)


@router.callback_query(F.data == "an:toggle")
async def cb_toggle(cb: CallbackQuery, bot: Bot):
    await ensure_link(cb.from_user.id)
    await db.q_run("UPDATE anon_links SET open=1-open WHERE uid=?", cb.from_user.id)
    r = await db.q_one("SELECT open FROM anon_links WHERE uid=?", cb.from_user.id)
    await cb.answer("принимаю сообщения 📬" if r["open"] else "больше не принимаю 📴", show_alert=True)


@router.callback_query(F.data == "an:mat")
async def cb_mat(cb: CallbackQuery, bot: Bot):
    """Волна 45: фильтр грубостей — сообщения с матом не доходят, автора просят переписать."""
    await ensure_link(cb.from_user.id)
    await db.q_run("UPDATE anon_links SET nomat=1-nomat WHERE uid=?", cb.from_user.id)
    r = await db.q_one("SELECT nomat FROM anon_links WHERE uid=?", cb.from_user.id)
    await cb.answer("🤬 сообщения с матом больше не дойдут до тебя" if r["nomat"] else "фильтр мата выключен",
                    show_alert=True)
    try:
        await cb.message.delete()
    except Exception:
        pass
    await home(cb.message, bot, cb.from_user.id)


# ================= написать анонимно =================
async def start_writing(m: Message, bot: Bot, code: str, uid: int | None = None, topic: str = "q",
                        parent: int = 0) -> bool:
    uid = uid or m.from_user.id
    topic = topic if topic in TOPICS else "q"
    from handlers import anonchat
    if uid in anonchat.PAIRS:
        await m.answer("ты сейчас в анонимном чате — сначала /stop, потом пиши по ссылке")
        return True
    o = await owner_of(code)
    if not o:
        await m.answer("🤔 ссылка не работает — попроси новую")
        return True
    if o["uid"] == uid:
        await m.answer("это твоя же ссылка 🙃 кинь её друзьям")
        return True
    if not o["open"]:
        await m.answer("📴 этот человек сейчас не принимает анонимные сообщения")
        return True
    if await db.q_one("SELECT 1 FROM anon_blocks WHERE owner=? AND sender=?", o["uid"], uid):
        await m.answer("🚫 получатель ограничил тебе сообщения")
        return True
    _writing[uid] = (o["uid"], time.time(), topic, parent)
    if parent:
        head = f"↩️ <b>ответ {escape(await name_of(o['uid']))}</b> — напиши, отправлю в вашу переписку"
    else:
        head = (f"{TOPIC_ICON[topic]} <b>{TOPICS[topic]}</b>" if topic != "q"
                else f"✍️ <b>напиши анонимное сообщение для {escape(await name_of(o['uid']))}</b>")
    await m.answer(head + "\nтекст, фото, голосовое, кружок или стикер — он не узнает, кто ты 🤫\n"
                   "<i>🔒 я никогда не раскрываю авторов — ни за звёзды, ни за деньги</i>",
                   reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    return True


def writing(m: Message) -> bool:
    w = _writing.get(m.from_user.id) if m.from_user else None
    return bool(w and time.time() - w[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def replying(m: Message) -> bool:
    r = _replying.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def _too_fast(uid: int) -> bool:
    now = time.time()
    q = [t for t in _sent.get(uid, []) if now - t < RATE[1]]
    _sent[uid] = q
    if len(q) >= RATE[0]:
        return True
    q.append(now)
    return False


@router.callback_query(F.data == "an:cancel")
async def cb_cancel(cb: CallbackQuery):
    _writing.pop(cb.from_user.id, None)
    _replying.pop(cb.from_user.id, None)
    _labeling.pop(cb.from_user.id, None)
    await cb.answer("отменила")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass


def _kb_for_owner(mid: int):
    return kb_rows([("↩️ Ответить", f"an:re:{mid}"), ("🚫 Заблокировать", f"an:bl:{mid}")],
                   [("⚠️ Пожаловаться", f"an:rep:{mid}")])


@router.message(writing)
async def on_write(m: Message, bot: Bot):
    to, ts, topic, parent = _writing.pop(m.from_user.id)
    if _too_fast(m.from_user.id):
        return await m.answer("⏳ слишком быстро — подожди минутку")
    if m.text and BAD.search(m.text):
        return await m.answer("🚫 такое не передам. угрозы и травля — не сюда")
    body = m.text or m.caption or ""
    if body:
        import profanity
        r = await db.q_one("SELECT nomat FROM anon_links WHERE uid=?", to)
        if r and r["nomat"] and profanity.has_mat(body):
            _writing[m.from_user.id] = (to, ts, topic, parent)   # даём переписать
            return await m.answer("🙊 этот человек не принимает сообщения с матом — перепиши помягче, я жду",
                                  reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    q = (m.text or m.caption or "")[:1000]
    mk = await mask_of(to, m.from_user.id)
    par = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND to_uid=? AND from_uid=?", parent, to,
                         m.from_user.id) if parent else None
    mid = await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, ts, answered, topic, qtext, src_mid, parent) "
                         "VALUES(?,?,?,0,?,?,?,?)", to, m.from_user.id, int(time.time()), topic, q, m.message_id,
                         parent if par else 0)
    # у получателя: продолжение ветки — ответом на его прошлый ответ
    reply_to = (par or {}).get("ans_mid") or None
    head = (f"💬 <b>{escape(mask_name(mk))}</b> продолжает переписку" if par
            else f"💌 <b>новое анонимное сообщение</b> от <b>{escape(mask_name(mk))}</b>"
            + (f"\n{TOPIC_ICON[topic]} <i>{TOPICS[topic]}</i>" if topic != "q" else ""))
    try:
        await bot.send_message(to, head, reply_to_message_id=reply_to, allow_sending_without_reply=True)
        cp = await bot.copy_message(to, m.chat.id, m.message_id, reply_markup=_kb_for_owner(mid))
        await db.q_run("UPDATE anon_msgs SET dlv_mid=? WHERE id=?", getattr(cp, "message_id", 0) or 0, mid)
    except Exception as e:
        log.info("deliver: %s", e)
        return await m.answer("😕 не смогла доставить — возможно, человек заблокировал бота")
    code = code_of(to)
    await m.answer(f"✅ отправлено анонимно! у {escape(await name_of(to))} ты — <b>{escape(mk['mask'])}</b> 🤫\n"
                   + ui.hint("эта маска твоя только у этого человека. ответ придёт сюда — прямо на твоё сообщение"),
                   reply_markup=kb_rows([("✍️ Написать ещё", f"an:more:{code}")], [("💌 Хочу свою ссылку", "an:home")]))


@router.callback_query(F.data.startswith("an:more:"))
async def cb_more(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    code, _, topic = cb.data[8:].partition("_")
    await start_writing(cb.message, bot, code, cb.from_user.id, topic or "q")


# ================= ответ, блок, жалоба =================
async def _msg(cb: CallbackQuery) -> dict | None:
    mid = int(cb.data.rsplit(":", 1)[1])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND to_uid=?", mid, cb.from_user.id)
    if not r:
        await cb.answer("сообщение не найдено", show_alert=True)
    return r


@router.callback_query(F.data.startswith("an:re:"))
async def cb_reply(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    _replying[cb.from_user.id] = (r["id"], time.time())
    await cb.answer()
    await cb.message.reply("↩️ напиши ответ — отправлю анонимному автору (он тоже не узнает, кто ты, "
                           "если не скажешь сам)", reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))


@router.message(replying)
async def on_reply(m: Message, bot: Bot):
    mid, _ = _replying.pop(m.from_user.id)
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=?", mid)
    if not r:
        return await m.answer("сообщение устарело")
    who = escape(await name_of(r["to_uid"]))
    try:   # волна 46: ответ приходит реплаем на сообщение автора и с именем — сразу понятно, кто и на что
        await bot.send_message(r["from_uid"], f"💬 <b>{who}</b> ответил(а) на твоё сообщение 👆",
                               reply_to_message_id=r.get("src_mid") or None, allow_sending_without_reply=True)
        await bot.copy_message(r["from_uid"], m.chat.id, m.message_id,
                               reply_markup=kb_rows([(f"↩️ Ответить {who}", f"an:fu:{mid}")],
                                                    [("✍️ Новое сообщение", f"an:more:{code_of(r['to_uid'])}")]))
    except Exception as e:
        log.info("reply: %s", e)
        return await m.answer("😕 автор недоступен — наверное, заблокировал бота")
    await db.q_run("UPDATE anon_msgs SET answered=1, atext=?, ans_mid=? WHERE id=?",
                   (m.text or m.caption or "")[:1000], m.message_id, mid)
    await m.answer("✅ ответ отправлен", reply_markup=kb_rows([("🖼 Вопрос и ответ — в сторис", f"an:ac:{mid}")])
                   if m.text and r.get("qtext") else None)


@router.callback_query(F.data.startswith("an:fu:"))
async def cb_followup(cb: CallbackQuery, bot: Bot):
    """Волна 46: аноним отвечает на ответ — сообщение ляжет в ту же ветку у получателя."""
    mid = int(cb.data.split(":")[2])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND from_uid=?", mid, cb.from_user.id)
    if not r:
        return await cb.answer("переписка не найдена", show_alert=True)
    await cb.answer()
    await start_writing(cb.message, bot, code_of(r["to_uid"]), cb.from_user.id, r.get("topic") or "q", parent=mid)


@router.callback_query(F.data.startswith("an:bl:"))
async def cb_block(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("🚫 автор больше не сможет тебе писать", show_alert=True)


@router.callback_query(F.data == "an:blocks")
async def cb_blocks(cb: CallbackQuery):
    n = (await db.q_one("SELECT COUNT(*) n FROM anon_blocks WHERE owner=?", cb.from_user.id))["n"]
    await cb.answer()
    await cb.message.answer(f"🚫 заблокировано авторов: <b>{n}</b>",
                            reply_markup=kb_rows([("🔓 Разблокировать всех", "an:unblock")]) if n else None)


@router.callback_query(F.data == "an:unblock")
async def cb_unblock(cb: CallbackQuery):
    await db.q_run("DELETE FROM anon_blocks WHERE owner=?", cb.from_user.id)
    await cb.answer("разблокировала всех", show_alert=True)


@router.callback_query(F.data.startswith("an:rep:"))
async def cb_report(cb: CallbackQuery, bot: Bot):
    """Жалоба уходит владельцу бота — только он видит автора, чтобы забанить за травлю."""
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("⚠️ жалоба отправлена, автор заблокирован", show_alert=True)
    if config.OWNER_ID:
        try:
            await bot.send_message(config.OWNER_ID, f"⚠️ <b>жалоба на анонимку</b> #{r['id']}\n"
                                                    f"автор: <code>{r['from_uid']}</code> → получатель <code>{r['to_uid']}</code>\n"
                                                    f"забанить автора: <code>/ban {r['from_uid']}</code>")
            await bot.copy_message(config.OWNER_ID, cb.message.chat.id, cb.message.message_id)
        except Exception:
            pass


async def deep_link(m: Message, bot: Bot, arg: str) -> bool:
    if arg.startswith("a_"):
        code, _, topic = arg[2:].partition("_")
        return await start_writing(m, bot, code, topic=topic or "q")
    return False


# ================= 🎨 карточки для сторис =================
@router.callback_query(F.data == "an:cards")
async def cb_cards(cb: CallbackQuery):
    await cb.answer()
    rows = [[(f"{TOPIC_ICON[k]} {v}", f"an:card:{k}")] for k, v in TOPICS.items()]
    await cb.message.answer("🎨 <b>какую картинку для сторис?</b>\n"
                            + ui.hint("на картинке — тема и QR на твою ссылку; ссылку добавь стикером «ссылка» в сторис"),
                            reply_markup=kb_rows(*rows))


@router.callback_query(F.data.startswith("an:card:"))
async def cb_card(cb: CallbackQuery, bot: Bot):
    import asyncio
    import random
    from aiogram.types import BufferedInputFile
    from handlers import anoncards
    topic = cb.data[8:]
    if topic not in TOPICS:
        return await cb.answer()
    await cb.answer("рисую…")
    code = await ensure_link(cb.from_user.id)
    me = await bot.me()
    link = f"https://t.me/{me.username}?start=a_{code}" + (f"_{topic}" if topic != "q" else "")
    png = await asyncio.to_thread(anoncards.ask_card, TOPICS[topic], link, me.username or "", random.randrange(5))
    await cb.message.answer_photo(BufferedInputFile(png, "story.png"),
                                  caption=f"{TOPIC_ICON[topic]} картинка для сторис готова!\n"
                                          f"добавь в сторис стикер «ссылка» с этой ссылкой:\n<code>{link}</code>")


@router.callback_query(F.data.startswith("an:ac:"))
async def cb_answer_card(cb: CallbackQuery, bot: Bot):
    import asyncio
    from aiogram.types import BufferedInputFile
    from handlers import anoncards
    r = await _msg(cb)
    if not r:
        return
    await cb.answer("рисую…")
    me = await bot.me()
    png = await asyncio.to_thread(anoncards.answer_card, r.get("qtext") or "", r.get("atext") or "",
                                  me.username or "")
    code = await ensure_link(cb.from_user.id)
    await cb.message.answer_photo(BufferedInputFile(png, "answer.png"),
                                  caption=f"🖼 выкладывай в сторис и добавь ссылку:\n"
                                          f"<code>https://t.me/{me.username}?start=a_{code}</code>")


# ================= 📥 входящие — по маскам =================
async def inbox_view(uid: int):
    rows = await db.q_all("SELECT from_uid, COUNT(*) n, SUM(answered=0) waiting, MAX(id) last FROM anon_msgs "
                          "WHERE to_uid=? GROUP BY from_uid ORDER BY last DESC LIMIT 12", uid)
    if not rows:
        return "📥 <b>входящие пусты</b>\n" + ui.hint("кинь ссылку в сторис — вопросы придут сюда"), None
    lines = ["📥 <b>кто тебе пишет</b>", ui.hint("у каждого анонима своя маска — по ней видно, что это тот же человек"), ""]
    btns = []
    for r in rows:
        mk = await mask_of(uid, r["from_uid"])
        wait = f" · ⏳ {r['waiting']} без ответа" if r["waiting"] else ""
        lines.append(f"{escape(mask_name(mk))} — {r['n']} сообщ.{wait}")
        btns.append([(f"{mk['mask']}" + (" ⏳" if r["waiting"] else ""), f"an:th:{mk['id']}")])
    return "\n".join(lines), kb_rows(*btns)


async def _mask_by_id(cb: CallbackQuery) -> dict | None:
    mk = await db.q_one("SELECT * FROM anon_masks WHERE id=? AND owner=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not mk:
        await cb.answer("не нашла", show_alert=True)
    return mk


@router.callback_query(F.data.startswith("an:th:"))
async def cb_thread(cb: CallbackQuery):
    mk = await _mask_by_id(cb)
    if not mk:
        return
    await cb.answer()
    rows = await db.q_all("SELECT * FROM anon_msgs WHERE to_uid=? AND from_uid=? ORDER BY id DESC LIMIT 8",
                          cb.from_user.id, mk["sender"])
    lines = [f"<b>{escape(mask_name(mk))}</b> · переписка", ""]
    for r in reversed(rows):
        lines.append(f"{mk['mask'].split()[0]} <i>{escape((r.get('qtext') or 'медиа')[:120])}</i>")
        if r["answered"]:
            lines.append(f"↩️ ты: {escape((r.get('atext') or 'медиа')[:120])}")
    last_wait = next((r for r in rows if not r["answered"]), None)
    kb = []
    if last_wait:
        kb.append([("↩️ Ответить на последнее", f"an:re:{last_wait['id']}")])
    kb.append([("✏️ Подписать", f"an:lb:{mk['id']}"), ("🚫 Заблокировать", f"an:bm:{mk['id']}")])
    await cb.message.answer("\n".join(lines), reply_markup=kb_rows(*kb))


@router.callback_query(F.data.startswith("an:lb:"))
async def cb_label(cb: CallbackQuery):
    mk = await _mask_by_id(cb)
    if not mk:
        return
    _labeling[cb.from_user.id] = mk["id"]
    await cb.answer()
    await cb.message.answer(f"✏️ как подписать {escape(mk['mask'])}? например: «тот, с работы». "
                            "подпись видишь только ты. «-» — убрать", reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))


def labeling(m: Message) -> bool:
    return bool(m.from_user and m.from_user.id in _labeling and m.chat.type == "private" and m.text
                and not m.text.startswith("/"))


@router.message(labeling)
async def on_label(m: Message):
    mid = _labeling.pop(m.from_user.id)
    label = "" if m.text.strip() == "-" else m.text.strip()[:30]
    await db.q_run("UPDATE anon_masks SET label=? WHERE id=? AND owner=?", label, mid, m.from_user.id)
    mk = await db.q_one("SELECT * FROM anon_masks WHERE id=?", mid)
    await m.answer(f"✅ теперь это {escape(mask_name(mk))}" if label else f"✅ подпись убрана: {escape(mk['mask'])}")


@router.callback_query(F.data.startswith("an:bm:"))
async def cb_block_mask(cb: CallbackQuery):
    mk = await _mask_by_id(cb)
    if not mk:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, mk["sender"], int(time.time()))
    await cb.answer(f"🚫 {mk['mask']} больше не сможет тебе писать", show_alert=True)


@router.message(Command("inbox", "входящие"))
async def cmd_inbox(m: Message):
    text, kb = await inbox_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "an:inbox")
async def cb_inbox(cb: CallbackQuery):
    await cb.answer()
    text, kb = await inbox_view(cb.from_user.id)
    await cb.message.answer(text, reply_markup=kb)
