"""🎨 Картинки для сторис: «задай мне вопрос» с QR и «вопрос → ответ». 1080×1920, градиент, без эмодзи (шрифт их не рисует)."""
import io

THEMES = [((255, 94, 98), (255, 153, 102)), ((106, 17, 203), (37, 117, 252)), ((17, 153, 142), (56, 239, 125)),
          ((252, 70, 107), (63, 94, 251)), ((40, 40, 60), (120, 60, 140))]
W, H = 1080, 1920


def _bg(theme: int):
    from PIL import Image, ImageDraw
    a, b = THEMES[theme % len(THEMES)]
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):
        k = y / H
        d.line([(0, y), (W, y)], fill=tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(3)))
    return im, d


def _box(d, xy, r=48, fill=(255, 255, 255)):
    d.rounded_rectangle(xy, r, fill=fill)


def _center(d, y, text, font, fill, width=W):
    w = d.textlength(text, font=font)
    d.text(((width - w) / 2, y), text, font=font, fill=fill)


def ask_card(prompt: str, link: str, bot_name: str, theme: int = 0) -> bytes:
    """Карточка-приглашение: тема крупно + QR + «ссылка в профиле»."""
    from handlers.tools import _font, _wrap
    im, d = _bg(theme)
    _box(d, (90, 420, W - 90, 1080))
    f = _font(76, True)
    lines = _wrap(d, prompt, f, W - 280)[:4]
    y = 750 - len(lines) * 50
    for ln in lines:
        _center(d, y, ln, f, (30, 30, 40))
        y += 100
    try:
        import qrcode
        q = qrcode.QRCode(box_size=10, border=2)
        q.add_data(link)
        q.make(fit=True)
        qi = q.make_image(fill_color="black", back_color="white").convert("RGB").resize((420, 420))
        _box(d, (W / 2 - 240, 1180, W / 2 + 240, 1660), 36)
        im.paste(qi, (int(W / 2 - 210), 1210))
    except Exception:
        pass
    _center(d, 1720, "анонимно · отвечаю всем", _font(44), (255, 255, 255))
    _center(d, 1790, f"@{bot_name}", _font(44, True), (255, 255, 255))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


def answer_card(question: str, answer: str, bot_name: str, theme: int = 1) -> bytes:
    """Карточка «вопрос → ответ» для сторис."""
    from handlers.tools import _font, _wrap
    im, d = _bg(theme)
    fq, fa = _font(54, True), _font(52)
    ql = _wrap(d, question or "(медиа-сообщение)", fq, W - 300)[:7]
    al = _wrap(d, answer, fa, W - 300)[:9]
    top = 360
    qh = 120 + len(ql) * 70
    _box(d, (90, top, W - 90, top + qh))
    d.text((150, top + 40), "АНОНИМНЫЙ ВОПРОС", font=_font(34, True), fill=(150, 150, 170))
    y = top + 100
    for ln in ql:
        d.text((150, y), ln, font=fq, fill=(30, 30, 40))
        y += 70
    top2 = top + qh + 60
    ah = 80 + len(al) * 68
    _box(d, (90, top2, W - 90, top2 + ah), fill=(30, 30, 45))
    y = top2 + 40
    for ln in al:
        d.text((150, y), ln, font=fa, fill=(255, 255, 255))
        y += 68
    _center(d, H - 200, "задай мне вопрос — ссылка в профиле", _font(44), (255, 255, 255))
    _center(d, H - 130, f"@{bot_name}", _font(44, True), (255, 255, 255))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()
