"""Волна 44: 🛡 помощник для групп (BOT_PROFILE=grp) — модерация + расшифровка голосовых в одном боте.
Модерация, капча, правила, заметки, /summary — из groupmod/community; здесь — голосовые с лимитом,
приветствие без ИИ и экран в личке. С Соней+ у любого админа: голосовые без лимита, ИИ-антиспам, итоги дня."""
import logging
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message

import config
import db
import premium
import ui
from handlers import media, community
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("grp")
GROUPS = {"group", "supergroup"}
FREE_VOICE_SEC = 5 * 60          # без Сони+ — голосовые до 5 мин
PLUS_FLAGS = {"antispam", "daily_sum"}   # эти переключатели работают только с Соней+
FLAGS = [("auto_voice", "📝 Расшифровка голосовых и кружков"), ("captcha", "🛡 Капча для новичков"),
         ("antiflood", "🚫 Антифлуд (мут на 5 мин)"), ("antilink", "🔗 Ссылки только у админов"),
         ("greet", "👋 Приветствие новичков"), ("clean_service", "🧹 Удалять «вошёл / вышел»"),
         ("antispam", "💎 ИИ-антиспам для новичков"), ("daily_sum", "💎 Итоги дня в 23:00")]
ADMIN_RIGHTS = "delete_messages+restrict_members+pin_messages+invite_users"


def add_url(username: str) -> str:
    return f"https://t.me/{username}?startgroup=grp&admin={ADMIN_RIGHTS}"


# ================= голосовые =================
async def _upsell_once(m: Message, bot: Bot, text: str):
    """В группе предлагаем Соню+ не чаще раза в день, чтобы не спамить."""
    key = f"grp_up:{m.chat.id}:{db._day()}"
    if m.chat.type in GROUPS:
        if await db.kv_get(key):
            return
        await db.kv_set(key, "1")
    await m.reply(text + "\n" + ui.hint(f"✨ Соня+ у любого админа — без лимита для всей группы. "
                                        f"одна Соня+ на все боты @{config.MAIN_BOT}"),
                  reply_markup=await premium.upsell_kb(m.from_user.id))


async def transcribe(m: Message, bot: Bot, target: Message, quiet: bool):
    obj = target.voice or target.video_note or target.audio or target.video
    if not obj:
        return await m.reply("ответь /text на голосовое, кружок, аудио или видео")
    is_plus = await premium.chat_plus(bot, m.chat)
    dur = getattr(obj, "duration", 0) or 0
    if not is_plus and dur > FREE_VOICE_SEC:
        return await _upsell_once(m, bot, f"🎙 запись {dur // 60} мин — бесплатно расшифровываю до "
                                          f"{FREE_VOICE_SEC // 60} мин")
    if not await premium.allow(m.chat.id, "stt", is_plus):
        return await _upsell_once(m, bot, f"⏳ {premium.DAILY['stt']} расшифровок в день бесплатно — "
                                          "на сегодня всё, завтра снова")
    return await media.transcribe_message(m, bot, target, quiet=quiet)


@router.message(F.voice | F.video_note)
async def on_voice(m: Message, bot: Bot):
    if m.chat.type in GROUPS and not await db.chat_flag(m.chat.id, "auto_voice"):
        return
    await transcribe(m, bot, m, quiet=m.chat.type in GROUPS)


@router.message(Command("text"))
async def cmd_text(m: Message, bot: Bot):
    if not m.reply_to_message:
        return await m.reply("ответь <b>/text</b> на голосовое, кружок, аудио или видео — расшифрую")
    await transcribe(m, bot, m.reply_to_message, quiet=False)


@router.message(F.chat.type == "private", F.audio | F.video)
async def on_audio_dm(m: Message, bot: Bot):
    await transcribe(m, bot, m, quiet=False)


router.callback_query(F.data.startswith("vt:sum:"))(media.cb_sum)   # «✨ Кратко» под длинной расшифровкой


# ================= настройки группы =================
async def settings_view(chat_id: int, bot: Bot):
    rows, on_n = [], 0
    for flag, name in FLAGS:
        v = await db.chat_flag(chat_id, flag)
        on_n += bool(v)
        rows.append([(f"{ui.tog(v)} {name}", f"gs:{flag}")])
    text = (ui.head("⚙️", "Помощник в этой группе", f"включено {on_n} из {len(FLAGS)} · нажми, чтобы переключить")
            + "\n" + ui.hint("менять могут админы. дай мне права «удалять сообщения» и «блокировать». "
                             "💎 — с Соней+ у любого админа группы"))
    return text, kb_rows(*rows)


@router.message(Command("settings"), F.chat.type.in_(GROUPS))
async def cmd_settings(m: Message, bot: Bot):
    await db.add_chat(m.chat.id, m.chat.title or "")
    if not await media._is_admin(bot, m.chat.id, m.from_user.id):
        return await m.reply("настройки — только для админов группы")
    text, kb = await settings_view(m.chat.id, bot)
    await m.reply(text, reply_markup=kb)


@router.callback_query(F.data.startswith("gs:"))
async def cb_gs(cb, bot: Bot):
    flag = cb.data[3:]
    if flag not in dict(FLAGS) or not cb.message:
        return await cb.answer()
    chat = cb.message.chat
    if not await media._is_admin(bot, chat.id, cb.from_user.id):
        return await cb.answer("только для админов", show_alert=True)
    cur = await db.chat_flag(chat.id, flag)
    if not cur and flag in PLUS_FLAGS and not await premium.chat_plus(bot, chat):
        return await cb.answer(f"💎 это с Соней+ у любого админа группы — оформить у @{config.MAIN_BOT}",
                               show_alert=True)
    await db.set_chat_flag(chat.id, flag, not cur)
    text, kb = await settings_view(chat.id, bot)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:
        pass
    await cb.answer("включено" if not cur else "выключено")


# ================= вход в группу и новички =================
@router.message(F.new_chat_members)
async def on_join(m: Message, bot: Bot):
    me = await bot.me()
    if any(u.id == me.id for u in m.new_chat_members):
        await db.add_chat(m.chat.id, m.chat.title or "")
        return await m.answer(
            "👋 я помощник этой группы\n"
            "• 🎙 голосовые и кружки — сразу превращаю в текст\n"
            "• 🛡 капча, антифлуд, антиссылки, варны и муты\n"
            "• 📜 /rules · 📝 #заметки · 🌙 /quiet — ночная тишина · 🚨 /report\n"
            "• 🧾 /summary — что вы пропустили\n"
            "админы: /settings — что включить. дайте мне админку — без неё модерация не работает")
    await community.clean_service(m)
    if not await db.chat_flag(m.chat.id, "greet"):
        return
    humans = [u for u in m.new_chat_members if not u.is_bot]
    if not humans:
        return
    kb = community.rules_kb() if await community.get_rules(m.chat.id) else None
    custom = await community.get_welcome(m.chat.id)
    if custom:
        return await m.answer(community.render_welcome(custom, humans, m.chat.title or ""), reply_markup=kb)
    names = ", ".join(escape(u.first_name) for u in humans)
    await m.answer(f"👋 {names}, добро пожаловать в «{escape(m.chat.title or 'чат')}»!", reply_markup=kb)


# ================= ИИ-функции — только с Соней+ (проверяем и после включения: плюс мог кончиться) =================
async def ai_allowed(bot: Bot, chat_id: int) -> bool:
    if config.PROFILE != "grp":
        return True
    from aiogram.types import Chat
    return await premium.chat_plus(bot, Chat(id=chat_id, type="supergroup"))


# ================= личка =================
async def start_screen(m: Message, bot: Bot):
    me = await bot.me()
    text = (ui.head("🛡", "Помощник для групп", "модерация и голосовые в текст — в одном боте")
            + "\n" + ui.quote("🎙 голосовые и кружки → текст прямо в чате, длинные — ещё и кратко\n"
                              "🛡 капча для новичков · антифлуд · ссылки только у админов\n"
                              "⚠️ /warn · 🤐 /mute · 🚫 /ban · 📜 /rules · 👋 /welcome\n"
                              "📝 #заметки · 🌙 /quiet — ночная тишина · 🚨 /report — жалоба админам\n"
                              "🧾 /summary — что вы пропустили · 🌍 /tr — перевод")
            + "\n" + ui.quote(f"🆓 бесплатно: {premium.DAILY['stt']} расшифровок в день на чат, до "
                              f"{FREE_VOICE_SEC // 60} мин\n"
                              "💎 с Соней+ у любого админа: без лимита, до 15 мин, 🤖 ИИ-антиспам, 🌙 итоги дня")
            + "\n" + ui.hint("в личке тоже расшифрую — просто пришли голосовое"))
    rows = [[("➕ Добавить в группу", add_url(me.username or ""))]]
    if config.MAIN_BOT:
        rows.append([("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}")])
    await m.answer(text, reply_markup=kb_rows(*rows))


_hint_cd: dict[int, float] = {}


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def dm_text(m: Message, bot: Bot):
    if time.time() - _hint_cd.get(m.from_user.id, 0) < 30:
        return
    _hint_cd[m.from_user.id] = time.time()
    await start_screen(m, bot)
