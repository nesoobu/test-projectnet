"""Группы, волна 16: правила, заметки (#теги), ночная тишина, итоги дня, ИИ-антиспам."""
import asyncio
import json
import logging
import re
import time
from datetime import datetime
from html import escape

from aiogram import Router, F, Bot, BaseMiddleware
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, ChatPermissions

import db
import llm
import persona
from handlers.ap_common import kb_rows
from handlers.groupmod import is_admin, NO_RIGHTS

router = Router()
log = logging.getLogger("community")
GROUPS = {"group", "supergroup"}


async def _admin_only(m: Message, bot: Bot) -> bool:
    if m.chat.type not in GROUPS:
        await m.reply("это работает в группах 🙂")
        return False
    if not await is_admin(bot, m.chat.id, m.from_user.id):
        await m.reply("это могут только админы чата")
        return False
    return True


# ================= 📜 правила =================
async def get_rules(chat_id: int) -> str:
    r = await db.q_one("SELECT rules FROM chats WHERE id=?", chat_id)
    return (r or {}).get("rules") or ""


@router.message(Command("rules", "правила"))
async def cmd_rules(m: Message, bot: Bot, command: CommandObject):
    if m.chat.type not in GROUPS:
        return await m.reply("📜 правила бывают у групп. админ задаёт: <code>/rules текст</code>")
    arg = (command.args or "").strip()
    if arg:
        if not await _admin_only(m, bot):
            return
        if arg in ("-", "удалить"):
            await db.q_run("UPDATE chats SET rules='' WHERE id=?", m.chat.id)
            return await m.reply("📜 правила удалены")
        await db.q_run("UPDATE chats SET rules=? WHERE id=?", arg[:3500], m.chat.id)
        return await m.reply("📜 правила сохранены. новички увидят кнопку в приветствии")
    rules = await get_rules(m.chat.id)
    await m.reply(f"📜 <b>правила чата</b>\n\n{escape(rules)}" if rules else
                  "📜 правил пока нет. админ может задать: <code>/rules текст</code>")


@router.callback_query(F.data == "cm:rules")
async def cb_rules(cb: CallbackQuery):
    rules = await get_rules(cb.message.chat.id)
    if not rules:
        return await cb.answer("правил нет — живём по совести 😌", show_alert=True)
    if len(rules) <= 190:
        return await cb.answer(rules, show_alert=True)
    await cb.answer()
    await cb.message.answer(f"📜 <b>правила чата</b>\n\n{escape(rules)}")


def rules_kb():
    return kb_rows([("📜 Правила чата", "cm:rules")])


# ================= 👋 своё приветствие и уборка =================
async def get_welcome(chat_id: int) -> str:
    r = await db.q_one("SELECT welcome FROM chats WHERE id=?", chat_id)
    return (r or {}).get("welcome") or ""


def render_welcome(tpl: str, users: list, chat_title: str) -> str:
    names = ", ".join(f'<a href="tg://user?id={u.id}">{escape(u.first_name or "гость")}</a>' for u in users)
    return escape(tpl).replace("{name}", names).replace("{chat}", escape(chat_title))


@router.message(Command("welcome", "приветствие"))
async def cmd_welcome(m: Message, bot: Bot, command: CommandObject):
    if not await _admin_only(m, bot):
        return
    arg = (command.args or "").strip()
    if not arg:
        cur = await get_welcome(m.chat.id)
        return await m.reply("👋 <b>приветствие новичков</b>\n"
                             + (f"сейчас:\n<blockquote>{escape(cur)}</blockquote>\n" if cur else "сейчас: придумываю сама (ИИ)\n")
                             + "задать: <code>/welcome привет, {name}! добро пожаловать в {chat} 🖤</code>\n"
                               "<code>/welcome -</code> — снова придумывать самой")
    if arg in ("-", "сброс"):
        await db.q_run("UPDATE chats SET welcome='' WHERE id=?", m.chat.id)
        return await m.reply("👋 ок, снова приветствую сама")
    await db.q_run("UPDATE chats SET welcome=? WHERE id=?", arg[:1000], m.chat.id)
    await m.reply("👋 сохранила. так увидят новички:\n\n"
                  + render_welcome(arg[:1000], [m.from_user], m.chat.title or ""))


async def clean_service(m: Message):
    """Удалить служебное «X вошёл / вышел», если админы включили уборку."""
    if m.chat.type in GROUPS and await db.chat_flag(m.chat.id, "clean_service"):
        try:
            await m.delete()
        except TelegramBadRequest:
            pass


@router.message(F.left_chat_member)
async def on_left(m: Message):
    await clean_service(m)


# ================= 🚨 жалоба админам =================
_report_cd: dict[int, float] = {}


@router.message(Command("report", "жалоба"))
async def cmd_report(m: Message, bot: Bot, command: CommandObject):
    if m.chat.type not in GROUPS:
        return await m.reply("🚨 жалобы работают в группах: ответь /report на сообщение-нарушителя")
    if not m.reply_to_message:
        return await m.reply("🚨 ответь <code>/report</code> на сообщение, на которое жалуешься")
    if time.time() - _report_cd.get(m.from_user.id, 0) < 60:
        return await m.reply("подожди минутку перед следующей жалобой")
    _report_cd[m.from_user.id] = time.time()
    from handlers.groupmod import admins_of
    target = m.reply_to_message
    cid = str(m.chat.id).removeprefix("-100")
    link = f"https://t.me/c/{cid}/{target.message_id}" if str(m.chat.id).startswith("-100") else ""
    who = escape(target.from_user.first_name if target.from_user else "?")
    reason = escape((command.args or "").strip()[:200]) or "без комментария"
    text = (f"🚨 <b>жалоба</b> в «{escape(m.chat.title or '')}»\n"
            f"на: <b>{who}</b> · от: {escape(m.from_user.first_name or '?')}\n"
            f"причина: {reason}\n"
            f"<blockquote>{escape((target.text or target.caption or '[медиа]')[:300])}</blockquote>"
            + (f"\n<a href=\"{link}\">перейти к сообщению</a>" if link else ""))
    sent = 0
    for aid in await admins_of(bot, m.chat.id):
        if aid == m.from_user.id:
            continue
        try:
            await bot.send_message(aid, text, disable_web_page_preview=True)
            sent += 1
        except Exception:
            pass
    if sent:
        return await m.reply("🚨 жалоба отправлена админам")
    tags = [f'<a href="tg://user?id={aid}">админ</a>' for aid in list(await admins_of(bot, m.chat.id))[:5]]
    await m.reply("🚨 " + (", ".join(tags) + " — гляньте, пожалуйста 👆" if tags else "жалоба принята, но админов не вижу"))


# ================= 📝 заметки =================
NOTE_RE = re.compile(r"^#([\wа-яё-]{2,30})\s*$", re.I)


@router.message(Command("note", "заметка"))
async def cmd_note(m: Message, bot: Bot, command: CommandObject):
    if not await _admin_only(m, bot):
        return
    parts = (command.args or "").split(maxsplit=1)
    if not parts:
        return await m.reply("📝 <code>/note правила текст</code> — сохранить (или ответом на сообщение)\n"
                             "потом любой пишет <b>#правила</b> — я пришлю текст\n/notes — список · /delnote имя")
    name = parts[0].lstrip("#").lower()[:30]
    text = parts[1] if len(parts) > 1 else ""
    if not text and m.reply_to_message:
        text = m.reply_to_message.html_text or ""
    if not text:
        return await m.reply("а текст? <code>/note имя текст</code> или ответом на сообщение")
    await db.q_run("INSERT OR REPLACE INTO notes VALUES(?,?,?)", m.chat.id, name, text[:3500])
    await m.reply(f"📝 сохранила. вызов: <b>#{escape(name)}</b>")


@router.message(Command("notes", "заметки"))
async def cmd_notes(m: Message):
    rows = await db.q_all("SELECT name FROM notes WHERE chat_id=? ORDER BY name", m.chat.id)
    if not rows:
        return await m.reply("📝 заметок нет. админ добавляет: <code>/note имя текст</code>")
    await m.reply("📝 <b>заметки чата</b>\n" + " ".join(f"#{escape(r['name'])}" for r in rows))


@router.message(Command("delnote"))
async def cmd_delnote(m: Message, bot: Bot, command: CommandObject):
    if not await _admin_only(m, bot):
        return
    name = (command.args or "").strip().lstrip("#").lower()
    await db.q_run("DELETE FROM notes WHERE chat_id=? AND name=?", m.chat.id, name)
    await m.reply(f"🗑 #{escape(name)} удалена")


async def _note_call(m: Message) -> bool | dict:
    if m.chat.type not in GROUPS or not m.text or not m.text.startswith("#"):
        return False
    mt = NOTE_RE.match(m.text.strip())
    if not mt:
        return False
    r = await db.q_one("SELECT text FROM notes WHERE chat_id=? AND name=?", m.chat.id, mt.group(1).lower())
    return {"note": r["text"]} if r else False


@router.message(_note_call)
async def on_note(m: Message, note: str):
    try:
        await (m.reply_to_message or m).reply(note)
    except TelegramBadRequest:
        await m.reply(note, parse_mode=None)


# ================= 🌙 ночная тишина =================
def parse_quiet(s: str) -> tuple[int, int] | None:
    mt = re.match(r"^\s*(\d{1,2})(?::00)?\s*[-–—]\s*(\d{1,2})(?::00)?\s*$", s or "")
    if not mt:
        return None
    a, b = int(mt.group(1)), int(mt.group(2))
    return (a, b) if 0 <= a < 24 and 0 <= b < 24 and a != b else None


def in_quiet(hour: int, a: int, b: int) -> bool:
    return a <= hour < b if a < b else hour >= a or hour < b


@router.message(Command("quiet", "тишина"))
async def cmd_quiet(m: Message, bot: Bot, command: CommandObject):
    if not await _admin_only(m, bot):
        return
    arg = (command.args or "").strip().lower()
    if arg in ("off", "выкл", "-"):
        await db.q_run("UPDATE chats SET quiet='' WHERE id=?", m.chat.id)
        if await db.kv_get(f"quiet_perm:{m.chat.id}"):
            await _open(bot, m.chat.id, announce=False)
        return await m.reply("🌙 ночная тишина выключена")
    q = parse_quiet(arg)
    if not q:
        r = await db.q_one("SELECT quiet FROM chats WHERE id=?", m.chat.id)
        cur = (r or {}).get("quiet") or "выкл"
        return await m.reply("🌙 <b>ночная тишина</b> — ночью писать могут только админы\n"
                             f"сейчас: <b>{escape(cur)}</b>\n<code>/quiet 23-8</code> — включить · "
                             "<code>/quiet off</code> — выключить\n<i>нужно право «блокировать участников»</i>")
    await db.q_run("UPDATE chats SET quiet=? WHERE id=?", f"{q[0]}-{q[1]}", m.chat.id)
    await m.reply(f"🌙 договорились: с {q[0]}:00 до {q[1]}:00 по мск в чате тихо (кроме админов)")


async def _close(bot: Bot, chat_id: int, b: int):
    chat = await bot.get_chat(chat_id)
    perms = chat.permissions.model_dump(exclude_none=True) if chat.permissions else {}
    await bot.set_chat_permissions(chat_id, NO_RIGHTS)
    await db.kv_set(f"quiet_perm:{chat_id}", json.dumps(perms))
    await bot.send_message(chat_id, f"🌙 ночной режим: чат закрыт до {b}:00. спокойной ночи 😴")


async def _open(bot: Bot, chat_id: int, announce: bool = True):
    saved = await db.kv_get(f"quiet_perm:{chat_id}")
    perms = ChatPermissions(**json.loads(saved)) if saved and saved != "{}" else ChatPermissions(
        can_send_messages=True, can_send_audios=True, can_send_documents=True, can_send_photos=True,
        can_send_videos=True, can_send_video_notes=True, can_send_voice_notes=True, can_send_polls=True,
        can_send_other_messages=True, can_add_web_page_previews=True)
    await bot.set_chat_permissions(chat_id, perms)
    await db.q_run("DELETE FROM kv WHERE k=?", f"quiet_perm:{chat_id}")
    if announce:
        await bot.send_message(chat_id, "☀️ доброе утро! чат снова открыт")


async def quiet_tick(bot: Bot, hour: int):
    rows = await db.q_all("SELECT id, quiet FROM chats WHERE quiet!=''")
    for r in rows:
        q = parse_quiet(r["quiet"])
        if not q:
            continue
        closed = bool(await db.kv_get(f"quiet_perm:{r['id']}"))
        try:
            if in_quiet(hour, *q) and not closed:
                await _close(bot, r["id"], q[1])
            elif not in_quiet(hour, *q) and closed:
                await _open(bot, r["id"])
        except TelegramBadRequest as e:
            log.info("quiet %s: %s", r["id"], e)
    # тишину выключили, а чат остался закрытым — открыть
    for r in await db.q_all("SELECT k FROM kv WHERE k LIKE 'quiet_perm:%'"):
        cid = int(r["k"].split(":")[1])
        row = await db.q_one("SELECT quiet FROM chats WHERE id=?", cid)
        if not row or not row["quiet"]:
            try:
                await _open(bot, cid, announce=False)
            except TelegramBadRequest:
                await db.q_run("DELETE FROM kv WHERE k=?", r["k"])


# ================= 🧾 итоги дня =================
DAILY_HOUR = 23


async def daily_summaries(bot: Bot):
    from handlers import groupmod
    rows = await db.q_all("SELECT id FROM chats WHERE daily_sum=1")
    since = int(time.time()) - 86400
    for r in rows:
        logs = await db.q_all("SELECT name, text FROM chat_log WHERE chat_id=? AND ts>? ORDER BY id", r["id"], since)
        if len(logs) < 20:
            continue
        from handlers import grp
        if not await grp.ai_allowed(bot, r["id"]):   # помощник для групп: итоги — с Соней+
            continue
        try:
            out = await groupmod.summarize(logs, "Ты Соня. Подведи итоги дня в чате: 4–7 пунктов, с именами, живо и "
                                                 "с иронией, по-русски. В конце — «герой дня» одной строкой.")
            await bot.send_message(r["id"], f"🌙 <b>итоги дня</b>\n\n{escape(out)}")
        except Exception as e:
            log.info("daily %s: %s", r["id"], e)
        await asyncio.sleep(1)


# ================= 🛡 ИИ-антиспам =================
SPAM_HINT = re.compile(r"(https?://|t\.me/|@\w{4,}|заработ|доход|прибыл|инвест|крипт|usdt|казино|ставк|"
                       r"бесплатн|подпишись|переходи|пиши в лс|в личку|удалённ|без вложений|\$|₽|руб)", re.I)
NEWBIE_MSGS = 5
SPAM_MUTE = 86400


async def is_newbie(chat_id: int, uid: int) -> bool:
    r = await db.q_one("SELECT COALESCE(SUM(n),0) AS s FROM chat_daily WHERE chat_id=? AND uid=?", chat_id, uid)
    return (r["s"] if r else 0) <= NEWBIE_MSGS


async def looks_spam(text: str) -> bool:
    out = await llm.ask([{"role": "system", "content":
                          "Ты модератор чата. Это сообщение спам/скам/реклама (заработок, крипта, казино, "
                          "«пиши в лс», продажа, сомнительные ссылки)? Ответь одним словом: SPAM или OK."},
                         {"role": "user", "content": text[:1500]}], max_tokens=200, temperature=0, feature="antispam")
    return "SPAM" in out.upper()


class AntiSpam(BaseMiddleware):
    """Новички (до 5 сообщений): подозрительное сообщение → ИИ проверяет → спам удаляем, автора в мут на сутки."""

    async def __call__(self, handler, event, data):
        if (isinstance(event, Message) and event.chat.type in GROUPS and event.from_user
                and not event.from_user.is_bot):
            text = event.text or event.caption or ""
            if text and SPAM_HINT.search(text):
                try:
                    if await self._spam(event, data["bot"], text):
                        return
                except Exception as e:
                    log.info("antispam: %s", e)
        return await handler(event, data)

    async def _spam(self, m: Message, bot: Bot, text: str) -> bool:
        r = await db.q_one("SELECT antispam FROM chats WHERE id=?", m.chat.id)
        if not r or not r["antispam"] or not await is_newbie(m.chat.id, m.from_user.id):
            return False
        if await is_admin(bot, m.chat.id, m.from_user.id):
            return False
        from handlers import grp
        if not await grp.ai_allowed(bot, m.chat.id) or not await looks_spam(text):   # помощник: ИИ — с Соней+
            return False
        try:
            await m.delete()
            await bot.restrict_chat_member(m.chat.id, m.from_user.id, NO_RIGHTS, until_date=int(time.time()) + SPAM_MUTE)
        except TelegramBadRequest as e:
            log.info("antispam act: %s", e)
        await bot.send_message(m.chat.id, f"🛡 убрала спам от {escape(m.from_user.first_name or 'гостя')} — "
                                          "мут на сутки. если ошиблась, админ снимет: /unmute")
        return True


# ================= фоновый цикл =================
async def loop(bot: Bot):
    last_daily = ""
    while True:
        try:
            now = datetime.now(persona.MSK)
            await quiet_tick(bot, now.hour)
            day = now.strftime("%Y-%m-%d")
            if now.hour == DAILY_HOUR and last_daily != day:
                last_daily = day
                await daily_summaries(bot)
        except Exception:
            log.exception("community loop")
        await asyncio.sleep(60)
