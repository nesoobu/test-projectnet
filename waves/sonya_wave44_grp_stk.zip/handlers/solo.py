"""Узкие боты на том же коде (BOT_PROFILE в окружении): ⬇️ dl — только скачивание, 🎵 music — только музыка.
Их задача — находиться в поиске Telegram по своим словам и приводить людей к основной Соне."""
import asyncio
import hashlib
import logging
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandStart
from aiogram.types import (Message, InlineQuery, InlineQueryResultsButton, InlineQueryResultCachedVideo,
                           InlineQueryResultCachedAudio, InlineQueryResultCachedPhoto)

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("solo")


def _main_btn():
    return ("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}") if config.MAIN_BOT else None


TEXTS = {
    "dl": (ui.head("⬇️", "Скачаю видео и музыку", "без водяных знаков и рекламы")
           + "\n" + ui.quote("просто кинь ссылку 👇\n"
                             "TikTok · YouTube и Shorts · Instagram Reels · Pinterest · VK · RuTube · X · Reddit · "
                             "Likee · Threads · Twitch · Дзен\n"
                             "🎧 SoundCloud, Spotify, Яндекс Музыка — пришлю mp3\n"
                             "🖼 фото-карусели TikTok и Pinterest — альбомом\n"
                             "можно сразу до 5 ссылок одним сообщением")
           + "\n" + ui.quote("🛠 под каждым видео: 📺 качество до 1080p · 📦 без сжатия · ⭕ кружок · 🎞 GIF · "
                             "✂️ обрезка · ℹ️ просмотры и описание · 🖼 обложка · 🗒 текст из видео · "
                             "🔎 что за песня\n🕘 /history — всё, что ты качал")
           + "\n" + ui.quote("🚫 без рекламы и без обязательных подписок")
           + "\n" + ui.hint("ещё: голосовые и кружки → текст · работаю и в группах · "
                             "в любом чате: <code>@бот ссылка</code> — пришлю уже скачанное")),
    "games": (ui.head("🎮", "Игры для чата", "добавь меня в беседу — и поехали")
              + "\n" + ui.quote("🕵️ /mafia — мафия, роли в личку · 🕶 /spy — шпион\n"
                                "🐊 /croc — крокодил по картинке · ❓ /quiz — викторина\n"
                                "🎵 /melody — угадай мелодию на скорость · 🎭 /pd — правда или действие\n"
                                "⚔️ /duel — дуэль · 🎡 /wheel — колесо · 🃏 /bj — блэкджек · 🎲 /dice\n"
                                "🐣 /pet — питомец · 💍 /marry — брак · 💞 /pair — пара дня\n"
                                "🤗 «обнять», «кусь», «дай пять» ответом на сообщение")
              + "\n" + ui.hint("в группе дай мне админку — тогда смогу вести игры и считать очки · 🎁 /bonus каждый день")),
    "anon": (ui.head("💌", "Анонимные вопросы", "тебе пишут — ты не знаешь кто")
             + "\n" + ui.quote("1. жми «💌 Моя ссылка»\n2. кинь её в сторис, био или чат\n"
                               "3. друзья пишут анонимно — ты отвечаешь, не зная, кто это 🤫")
             + "\n" + ui.quote("🎨 картинки для сторис с QR · 🎭 темы: «оцени меня», «признайся», "
                               "«что ты обо мне думаешь», «я никогда не»\n🖼 вопрос и ответ одной картинкой · 📥 входящие")
             + "\n" + ui.hint("🚫 грубиянов можно заблокировать одной кнопкой")),
    "gw": (ui.head("🎁", "Розыгрыши в твоём канале", "честно, с проверкой подписки и подарками")
           + "\n" + ui.quote("1. добавь меня в канал админом\n2. жми «🎁 Новый розыгрыш»\n"
                             "3. я опубликую пост, соберу участников и сама выберу победителей")
           + "\n" + ui.quote("✅ подписка на канал и до 5 спонсоров · ⭐ только Premium\n"
                             "🎟 билеты за друзей · 🖼 картинка · 🏁 итоги по времени или числу участников\n"
                             "🎁 призы — подарки Telegram: победитель сам выбирает (/fund)\n"
                             "🛡 капча и отсев ботов · 🚀 билеты за буст канала · 🎬 картинка, видео или GIF\n"
                             "⏰ победитель подтверждает приз — иначе перевыбор\n"
                             "🔁 перевыбор победителя · 📄 список участников\n"
                             "🔐 хэш итогов публикуется заранее — победителя нельзя подкрутить (/check)\n"
                             "🥇 разные призы по местам · 📅 отложенный старт · 🔁 повтор · 📈 прирост подписчиков")
           + "\n" + ui.hint("всё бесплатно — платишь только за подарки, если разыгрываешь их")),
    "music": (ui.head("🎵", "Найду любую песню", "и узнаю, что играет")
              + "\n" + ui.quote("✍️ напиши название или строчку из песни — пришлю mp3\n"
                                "🎙 пришли голосовое, кружок или видео — скажу, что за трек (как Shazam)\n"
                                "🔗 ссылка на Spotify, Яндекс Музыку, SoundCloud — скачаю\n"
                                "🎬 ссылка на TikTok, Reels, Shorts — скажу, что за песня в видео\n"
                                "📝 под треком — текст, ❤️ в мои, 🔁 похожие, 🎛 slowed / sped up / 8D / bass, "
                                "✂️ рингтон, 🎙 голосовым\n"
                                "🔥 /top — чарт · ❤️ /my — твои треки · 🔔 /subs — новые релизы артистов\n"
                                "🎮 /melody — угадай мелодию (в группах — на скорость!) · 📊 /taste — твой вкус")
              + "\n" + ui.hint("просто напиши, например: «скриптонит космос» · "
                               "в любом чате: <code>@бот название</code> — кину трек прямо туда")),
}


async def _start_text(m: Message, bot: Bot) -> tuple[str, object]:
    text = TEXTS.get(config.PROFILE, "")
    if config.MAIN_BOT:
        text += f"\n\n🖤 <i>а поболтать, поиграть и порисовать — у @{config.MAIN_BOT}</i>"
    btn = _main_btn()
    rows = [[("🔥 Чарт", "mx:top"), ("❤️ Мои треки", "mx:my")],
            [("🎮 Угадай мелодию", "mel:again"), ("📊 Мой вкус", "mx:taste")]] if config.PROFILE == "music" else []
    if config.PROFILE == "gw":
        rows = [[("🎁 Новый розыгрыш", "gw:newbtn")], [("📋 Мои розыгрыши", "gw:list"), ("⭐ Звёзды", "m:fund")]]
    if config.PROFILE == "games":
        me = await bot.me()
        rows = [[("➕ Добавить в беседу", f"https://t.me/{me.username}?startgroup=games")],
                [("🎮 Все игры", "g:menu"), ("🎁 Бонус", "g:bonus")], [("👤 Профиль", "m:profile"), ("🏆 Топ", "m:top:xp")]]
    if config.PROFILE == "anon":
        rows = [[("💌 Моя ссылка", "an:home")]]
    if btn:
        rows.append([btn])
    return text, (kb_rows(*rows) if rows else None)


@router.message(CommandStart())
@router.message(Command("help", "menu"))
async def solo_start(m: Message, bot: Bot):
    arg = ((m.text or "").split(maxsplit=1) + [""])[1].strip()
    if arg.startswith("q_") and await _from_inline(m, bot, arg[2:]):
        return
    if config.PROFILE == "grp":
        from handlers import grp
        return await grp.start_screen(m, bot)
    if config.PROFILE == "stk":
        from handlers import stickers
        return await stickers.start_screen(m, m.from_user.id)
    if config.PROFILE == "anon" and not arg:
        from handlers import anon
        await m.answer(TEXTS["anon"])
        return await anon.home(m, bot, m.from_user.id)
    if arg.startswith("a_") and config.PROFILE == "anon":
        from handlers import anon
        if await anon.deep_link(m, bot, arg):
            return
    if arg.startswith(("gwr_", "gwj_", "gwcap_", "gwcf_")):
        from handlers import giveaway
        if await giveaway.deep_link(m, bot, arg):
            return
    if arg == "gwc":
        from handlers import gifts
        wins = await gifts.pending_for(m.from_user.id)
        for w in wins:
            await gifts.offer(bot, w, m.chat.id)
        if wins:
            return
    if arg == "taste" and config.PROFILE == "music":
        from handlers import melody
        return await melody.taste(m, bot, m.from_user.id, m.from_user.first_name or "я")
    if arg.startswith("t_") and len(arg) > 5:   # t_ym_123 — трек из инлайна
        from handlers import music
        return await music.send_track(m, bot, f"{arg[2:4]}:{arg[5:]}", m.from_user.id)
    text, kb = await _start_text(m, bot)
    await m.answer(text, reply_markup=kb)


# ---------- мягко зовём к Соне: один раз на 3-м скачивании и ещё раз на 30-м ----------
NUDGE_AT = (3, 30)


async def nudge(m: Message, uid: int):
    if not config.MAIN_BOT:
        return
    u = await db.get_user(uid)
    if not u or u.get("dls") not in NUDGE_AT:
        return
    try:
        await m.answer("🖤 нравится, как я качаю? у меня есть старшая сестра — "
                       f"@{config.MAIN_BOT}: болтает, рисует, играет в группах и тоже качает видео.",
                       reply_markup=kb_rows([_main_btn()]))
    except Exception as e:
        log.info("nudge: %s", e)


# ---------- инлайн: @бот ссылка / @бот название ----------
async def _park(kind: str, value: str) -> str:
    """Запрос не влезает в start-параметр (64 символа) — кладём в kv, отдаём короткий ключ."""
    tok = hashlib.md5(f"{kind}|{value}".encode()).hexdigest()[:12]
    await db.kv_set(f"iq:{tok}", f"{kind}|{value}")
    return "q_" + tok


async def _from_inline(m: Message, bot: Bot, tok: str) -> bool:
    raw = await db.kv_get(f"iq:{tok}")
    if "|" not in raw:
        return False
    kind, value = raw.split("|", 1)
    if kind == "dl":
        from downloader import links as L
        from handlers import media
        found = L.find_links(value)
        if not found:
            return False
        await m.answer("⬇️ качаю твою ссылку…")
        await media.handle_link(m, bot, found[0])
        return True
    if kind == "f":
        from handlers import tools
        await tools.find_music(m, value)
        return True
    return False


def _words(q: str) -> list[str]:
    return [w for w in q.casefold().split() if len(w) > 1]


async def _cached_audio(q: str, n: int = 20) -> list[dict]:
    ws = _words(q)
    if not ws:
        return []
    rows = await db.q_all("SELECT key, file_id, title FROM dl_cache WHERE type='audio' AND title!='' "
                          "ORDER BY ts DESC LIMIT 3000")
    return [r for r in rows if all(w in r["title"].casefold() for w in ws)][:n]


def _rid(*parts) -> str:
    return hashlib.md5("|".join(map(str, parts)).encode()).hexdigest()


_typing: dict[int, str] = {}
INLINE_PAUSE = 0.7


async def _music_results(q: InlineQuery, text: str) -> list:
    """Уже скачанные — сразу аудио; остальные — карточка с обложкой и кнопкой «скачать» (ведёт в бота)."""
    from aiogram.types import (InlineQueryResultArticle, InputTextMessageContent, InlineKeyboardMarkup,
                               InlineKeyboardButton)
    from downloader import catalog
    results, seen = [], set()
    try:
        found = await asyncio.wait_for(catalog.search(text, 15), 8)
    except Exception as e:
        log.info("inline catalog: %s", e)
        found = []
    me = await q.bot.me()
    for t in found:
        c = await db.dl_cache_get(f"audio:{t['key']}")
        if c:
            results.append(InlineQueryResultCachedAudio(id=_rid("a", t["key"]), audio_file_id=c["file_id"]))
            seen.add(c["file_id"])
            continue
        d = catalog.mmss(t["dur"])
        results.append(InlineQueryResultArticle(
            id=_rid("t", t["key"]), title=catalog.name(t)[:60],
            description=" · ".join(x for x in (d, t["album"][:40], "жми — пришлю ссылку на трек") if x),
            thumbnail_url=t["cover"] or None,
            input_message_content=InputTextMessageContent(
                message_text=f"🎵 <b>{escape(t['artist'])}</b> — {escape(t['title'])}" + (f" · {d}" if d else ""),
                parse_mode="HTML"),
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(
                text="⬇️ Скачать трек", url=f"https://t.me/{me.username}?start=t_{t['src']}_{t['id']}")]])))
    for r in await _cached_audio(text, 10):   # старый кэш (скачанное по ссылкам и до волны 29)
        if r["file_id"] not in seen:
            results.append(InlineQueryResultCachedAudio(id=_rid("a", r["key"]), audio_file_id=r["file_id"]))
    return results[:30]


@router.inline_query()
async def solo_inline(q: InlineQuery):
    text = (q.query or "").strip()
    results, button = [], None
    if config.PROFILE == "dl":
        from downloader import links as L
        found = L.find_links(text)
        if not found:
            button = InlineQueryResultsButton(text="⬇️ вставь ссылку на видео — или открой бота", start_parameter="go")
        else:
            url = found[0].url
            for kind in ("video", "audio", "photo"):
                c = await db.dl_cache_get(f"{kind}:{url}")
                if not c:
                    continue
                rid = _rid(kind, url)
                if c["type"] == "video":
                    results.append(InlineQueryResultCachedVideo(id=rid, video_file_id=c["file_id"],
                                                                title=f"🎬 {c['title'] or found[0].label}"[:60]))
                elif c["type"] == "audio":
                    results.append(InlineQueryResultCachedAudio(id=rid, audio_file_id=c["file_id"]))
                else:
                    results.append(InlineQueryResultCachedPhoto(id=rid, photo_file_id=c["file_id"]))
            button = InlineQueryResultsButton(
                text="⬇️ скачать в боте" if not results else "⬇️ открыть в боте",
                start_parameter=await _park("dl", url))
    elif config.PROFILE == "music":
        if len(text) < 2:
            button = InlineQueryResultsButton(text="🎵 напиши название песни", start_parameter="go")
        else:
            _typing[q.from_user.id] = q.id
            await asyncio.sleep(INLINE_PAUSE)
            if _typing.get(q.from_user.id) != q.id:
                return   # человек ещё печатает
            results = await _music_results(q, text)
            button = InlineQueryResultsButton(text=f"🔎 все результаты «{text[:25]}» в боте",
                                              start_parameter=await _park("f", text[:100]))
    await q.answer(results, cache_time=5, is_personal=True, button=button)


# ---------- музыка: любой текст — поиск, любой звук — «что играет» ----------
def _music(_m: Message) -> bool:
    return config.PROFILE == "music"


def _no_links(m: Message) -> bool:
    from downloader import links as L
    return not L.find_links(m.text or "")   # со ссылкой — пусть идёт дальше, в скачивание


@router.message(F.chat.type == "private", F.voice | F.audio | F.video | F.video_note, _music)
async def music_shazam(m: Message, bot: Bot):
    from handlers import tools
    await tools.shazam(m, bot, m)


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"), _no_links)
async def private_text(m: Message, bot: Bot):
    if config.PROFILE == "music":
        from handlers import tools
        return await tools.find_music(m, m.text.strip()[:100])
    text, kb = await _start_text(m, bot)
    if config.PROFILE in ("gw", "games", "anon"):
        return await m.answer(text, reply_markup=kb)
    await m.answer("👀 кинь ссылку на видео — скачаю.\n\n" + text, reply_markup=kb)


# ---------- «‹ Меню» в узких ботах ведёт на их стартовый экран, а не в меню Сони ----------
def _own_menu(_cb) -> bool:
    return config.PROFILE in ("games", "anon", "gw")


@router.callback_query(F.data == "m:home", _own_menu)
async def cb_home(cb, bot: Bot):
    text, kb = await _start_text(cb.message, bot)
    await cb.answer()
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:
        await cb.message.answer(text, reply_markup=kb)
