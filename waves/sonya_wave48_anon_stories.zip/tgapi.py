"""Волна 43: свой сервер Bot API (telegram-bot-api --local) — файлы до 2 ГБ.

BOT_API_URL пусто — обычный api.telegram.org. Задан — все боты ходят через свой сервер:
при первом запуске бот сам выходит из облака (logOut), при откате — из своего сервера.
"""
import asyncio
import logging
import os
import time
from pathlib import Path

from aiogram import Bot
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode

import config

log = logging.getLogger("tgapi")
# что сервер складывает в папку бота; служебные td.binlog / db.sqlite не трогаем
FILE_DIRS = ("documents", "videos", "video_notes", "voice", "music", "photos", "animations",
             "stickers", "thumbnails", "profile_photos", "temp")
KEEP_SEC = 3 * 3600


def session():
    """Сессия для Bot(): свой сервер или None (облако)."""
    if not config.BOT_API_URL:
        return None
    from aiogram.client.session.aiohttp import AiohttpSession
    from aiogram.client.telegram import TelegramAPIServer
    return AiohttpSession(api=TelegramAPIServer.from_base(config.BOT_API_URL, is_local=True), timeout=900)


def make_bot(token: str) -> Bot:
    return Bot(token, session=session(), default=DefaultBotProperties(parse_mode=ParseMode.HTML))


def _marker(token: str) -> Path:
    return config.BASE / "data" / f"botapi_{token.split(':')[0]}.moved"


async def prepare(token: str):
    """Перед стартом: переезд в свой сервер (или обратно). Порядок важен (43b): сначала убеждаемся,
    что свой сервер отвечает, и только потом выходим из облака — иначе бот останется ни там, ни там."""
    mk = _marker(token)
    if config.BOT_API_URL:
        if mk.exists():
            return
        bot = make_bot(token)
        try:
            await bot.get_me()   # свой сервер сам логинит бота — облако пока не трогаем
        except Exception as e:
            log.warning("свой Bot API не пустил бота (%s) — остаюсь в облаке", e)
            config.BOT_API_DOWN, config.BOT_API_URL = config.BOT_API_URL, ""
            return
        finally:
            await bot.session.close()
        cloud = Bot(token)
        try:
            await cloud.log_out()
            log.info("вышла из облачного Bot API — переезжаю на %s", config.BOT_API_URL)
            mk.write_text(config.BOT_API_URL)
        except Exception as e:
            # уже вышли раньше — Telegram отвечает ошибкой; запоминаем, чтобы не дёргать каждый раз
            if "logged out" in str(e).lower() or "unauthorized" in str(e).lower():
                mk.write_text(config.BOT_API_URL)
            log.warning("logOut из облака: %s", e)
        finally:
            await cloud.session.close()
    elif mk.exists() and not config.BOT_API_DOWN:   # откат в облако: выходим из своего сервера
        url = mk.read_text().strip()
        from aiogram.client.session.aiohttp import AiohttpSession
        from aiogram.client.telegram import TelegramAPIServer
        local = Bot(token, session=AiohttpSession(api=TelegramAPIServer.from_base(url, is_local=True)))
        try:
            await local.log_out()
            log.info("вышла из своего Bot API — облако пустит через 10 минут")
        except Exception as e:
            log.warning("logOut из своего сервера: %s", e)
        finally:
            await local.session.close()
        mk.unlink(missing_ok=True)


def clean(now: float | None = None) -> int:
    """Удаляет файлы, которые сервер скачал для ботов, старше KEEP_SEC. Возвращает сколько удалено."""
    root = Path(config.BOT_API_DIR)
    if not config.BOT_API_URL or not root.is_dir():
        return 0
    now = now or time.time()
    n = 0
    for bot_dir in root.iterdir():
        if not bot_dir.is_dir():
            continue
        for sub in FILE_DIRS:
            d = bot_dir / sub
            if not d.is_dir():
                continue
            for f in d.iterdir():
                try:
                    if f.is_file() and now - f.stat().st_mtime > KEEP_SEC:
                        f.unlink()
                        n += 1
                except OSError:
                    pass
    return n


async def clean_loop():
    while True:
        try:
            n = await asyncio.to_thread(clean)
            if n:
                log.info("чистка Bot API: удалено файлов %d", n)
        except Exception as e:
            log.warning("чистка Bot API: %s", e)
        await asyncio.sleep(3600)


def status() -> str:
    """Строчка для «Сервер» в админке."""
    if config.BOT_API_DOWN:
        return "⚠️ свой не отвечает — облако (50 МБ)"
    if not config.BOT_API_URL:
        return "облако (50 МБ)"
    root = Path(config.BOT_API_DIR)
    size = 0
    if root.is_dir():
        for p, _d, fs in os.walk(root):
            for f in fs:
                try:
                    size += os.path.getsize(os.path.join(p, f))
                except OSError:
                    pass
    return f"свой, до {config.mb(config.TG_SEND_MAX)} · кэш {size / 1024 / 1024:.0f} МБ"
