"""Скачивание медиа: yt-dlp (видео/аудио с YouTube, SoundCloud, RuTube, VK…) и Яндекс Музыка."""
import asyncio
import logging
import os
import random
import re
import shutil
import time
import uuid
from pathlib import Path

import config

log = logging.getLogger("media_dl")
DL = config.BASE / "data" / "dl"
# лимит Bot API на отправку файла — 50 МБ; со своим сервером Bot API (BOT_API_URL) — 2 ГБ
MAX_BYTES = config.TG_SEND_MAX
LIM = config.mb(MAX_BYTES)


class DLError(Exception):
    pass


def _dir() -> Path:
    DL.mkdir(parents=True, exist_ok=True)
    return DL


def cleanup(hours: int = 72):
    if not DL.exists():
        return
    edge = time.time() - hours * 3600
    for f in DL.iterdir():
        try:
            if f.stat().st_mtime < edge:
                f.unlink()
        except OSError:
            pass


# ================= yt-dlp =================
def normalize_url(raw: str, kind: str) -> str:
    raw = raw.strip()
    if raw.startswith("@"):
        raw = f"https://www.youtube.com/{raw}"
    if not re.match(r"^https?://", raw):
        raw = "https://" + raw
    # канал ютуба без вкладки → видео (или шортсы, если просили)
    m = re.match(r"^(https?://(?:www\.|m\.)?youtube\.com/(?:@[\w.-]+|channel/[\w-]+|c/[\w.-]+))/?$", raw)
    if m:
        raw = m.group(1) + "/videos"
    m = re.match(r"^(https?://(?:www\.)?soundcloud\.com/[\w-]+)/?$", raw)
    if m and kind == "audio":
        raw = m.group(1) + "/tracks"
    return raw


def _ydl(opts: dict):
    import yt_dlp
    base = {"quiet": True, "no_warnings": True, "noplaylist": False, "socket_timeout": 30,
            "retries": 2, "ignoreerrors": False}
    base.update(opts)
    return yt_dlp.YoutubeDL(base)


def _list_sync(url: str, limit: int) -> list[dict]:
    with _ydl({"extract_flat": "in_playlist", "playlistend": limit}) as y:
        info = y.extract_info(url, download=False)
    if not info:
        raise DLError("пусто")
    entries = info.get("entries") or [info]
    out = []
    for e in entries:
        if not e:
            continue
        link = e.get("url") or e.get("webpage_url") or ""
        if link and not link.startswith("http"):
            link = f"https://www.youtube.com/watch?v={e.get('id')}"
        out.append({
            "key": str(e.get("id") or link),
            "title": e.get("title") or "",
            "text": "",
            "link": link,
            "image": None,
            "artist": e.get("uploader") or e.get("channel") or info.get("uploader") or "",
            "duration": e.get("duration"),
        })
    return out[:limit]


async def ytdlp_list(url: str, limit: int = 15) -> list[dict]:
    try:
        return await asyncio.to_thread(_list_sync, url, limit)
    except DLError:
        raise
    except Exception as e:
        msg = str(e).split("\n")[0]
        raise DLError(re.sub(r"^ERROR:\s*", "", msg)[:200])


def _has_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg"))


def _dl_sync(url: str, kind: str) -> dict:
    stem = str(_dir() / uuid.uuid4().hex)
    ff = _has_ffmpeg()
    if kind == "audio":
        opts = {"format": "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio/best",
                "outtmpl": stem + ".%(ext)s", "noplaylist": True, "max_filesize": MAX_BYTES}
        if ff:
            opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3",
                                       "preferredquality": "192"}]
    else:
        # беззвучные видео (Pinterest, гифки) — только видеодорожка, поэтому bv* без ba в запасе
        fmt = ("bv*[height<=720][ext=mp4]+ba[ext=m4a]/bv*[height<=720]+ba/b[height<=720][ext=mp4]/"
               "b[height<=720]/bv*[height<=720][ext=mp4]/bv*[height<=720]/b*"
               if ff else "b[height<=720][ext=mp4]/b[ext=mp4]/b*[ext=mp4]/b*")
        opts = {"format": fmt, "outtmpl": stem + ".%(ext)s", "noplaylist": True,
                "merge_output_format": "mp4", "max_filesize": MAX_BYTES}
    with _ydl(opts) as y:
        info = y.extract_info(url, download=True)
    files = sorted(Path(stem).parent.glob(Path(stem).name + ".*"))
    files = [f for f in files if f.suffix not in (".part", ".ytdl")]
    if not files:
        raise DLError(f"файл не скачался (возможно, больше {LIM})")
    path = files[-1]
    if path.stat().st_size > MAX_BYTES:
        path.unlink(missing_ok=True)
        raise DLError(f"файл больше {LIM} — телеграм не примет")
    return {
        "path": str(path),
        "title": info.get("track") or info.get("title") or "",
        "performer": info.get("artist") or info.get("uploader") or "",
        "duration": int(info.get("duration") or 0),
        "width": info.get("width"),
        "height": info.get("height"),
        "genre": info.get("genre") or "",
    }


async def ytdlp_download(url: str, kind: str) -> dict:
    try:
        return await asyncio.to_thread(_dl_sync, url, kind)
    except DLError:
        raise
    except Exception as e:
        msg = str(e).split("\n")[0]
        raise DLError(re.sub(r"^ERROR:\s*", "", msg)[:200])


# ================= Яндекс Музыка =================
def ym_parse(raw: str) -> str:
    """ссылка/слово → source: likes | playlist:USER:KIND | album:ID | artist:ID | chart"""
    raw = raw.strip()
    low = raw.lower()
    if low in ("likes", "лайки", "мои лайки", "мне нравится"):
        return "likes"
    if low in ("chart", "чарт"):
        return "chart"
    m = re.search(r"/users/([^/]+)/playlists/(\d+)", raw)
    if m:
        return f"playlist:{m.group(1)}:{m.group(2)}"
    m = re.search(r"/album/(\d+)(?:/track/\d+)?", raw)
    if m:
        return f"album:{m.group(1)}"
    m = re.search(r"/artist/(\d+)", raw)
    if m:
        return f"artist:{m.group(1)}"
    raise DLError("не поняла. пришли «лайки», «чарт» или ссылку на плейлист/альбом/артиста")


def ym_title(src: str) -> str:
    kind = src.split(":")[0]
    return {"likes": "мои лайки", "chart": "чарт", "playlist": "плейлист",
            "album": "альбом", "artist": "артист"}[kind] + (f" {src.split(':')[-1]}" if ":" in src else "")


async def _ym_client(token: str):
    from yandex_music import ClientAsync
    if not token:
        raise DLError("нужен токен Яндекс Музыки (y0_…)")
    try:
        return await ClientAsync(token).init()
    except Exception as e:
        raise DLError(f"токен не подошёл: {str(e)[:100]}")


async def ym_ids(src: str, token: str) -> list[str]:
    """Список id треков источника (дёшево, без метаданных)."""
    c = await _ym_client(token)
    kind = src.split(":")[0]
    try:
        if kind == "likes":
            tl = await c.users_likes_tracks()
            return [str(t.track_id) for t in (tl.tracks if tl else [])]
        if kind == "chart":
            ch = await c.chart("russia")
            return [str(t.track_id) for t in ch.chart.tracks] if ch and ch.chart else []
        if kind == "playlist":
            _, user, pk = src.split(":")
            pl = await c.users_playlists(int(pk), user)
            shorts = await pl.fetch_tracks_async()
            return [str(t.track_id) for t in shorts]
        if kind == "album":
            al = await c.albums_with_tracks(int(src.split(":")[1]))
            return [f"{t.id}:{al.id}" for vol in (al.volumes or []) for t in vol]
        if kind == "artist":
            out = []
            for page in range(5):
                ids = await c.artists_track_ids(int(src.split(":")[1]), page=page, page_size=100)
                if not ids:
                    break
                out += [str(i) for i in ids]
            return out
    except DLError:
        raise
    except Exception as e:
        raise DLError(f"яндекс: {str(e)[:150]}")
    raise DLError("неизвестный источник")


async def ym_meta(track_ids: list[str], token: str) -> list[dict]:
    c = await _ym_client(token)
    tracks = await c.tracks(track_ids)
    out = []
    for t in tracks:
        if not t or t.available is False:
            continue
        album = t.albums[0] if t.albums else None
        out.append({
            "key": str(t.track_id),
            "title": t.title or "",
            "text": "",
            "artist": ", ".join(t.artists_name()) if t.artists else "",
            "album": album.title if album else "",
            "genre": (album.genre or "") if album else "",
            "link": f"https://music.yandex.ru/album/{album.id}/track/{t.id}" if album else "",
            "image": None,
            "duration": int((t.duration_ms or 0) / 1000),
        })
    return out


async def ym_download(track_id: str, token: str) -> dict:
    c = await _ym_client(token)
    tracks = await c.tracks([track_id])
    if not tracks:
        raise DLError("трек не найден")
    t = tracks[0]
    stem = str(_dir() / uuid.uuid4().hex)
    try:
        await t.download_async(stem + ".mp3", codec="mp3", bitrate_in_kbps=192)
    except Exception as e:
        raise DLError(f"не скачался: {str(e)[:120]}")
    thumb = None
    try:
        await t.download_cover_async(stem + ".jpg", size="200x200")
        thumb = stem + ".jpg"
    except Exception:
        pass
    return {"path": stem + ".mp3", "title": t.title or "",
            "performer": ", ".join(t.artists_name()) if t.artists else "",
            "duration": int((t.duration_ms or 0) / 1000), "thumb": thumb}


def pick(ids: list, order: str, n: int) -> list:
    if order == "random":
        ids = ids[:]
        random.shuffle(ids)
        return ids
    if order == "old":
        return list(reversed(ids))
    return ids


# ================= прямые ссылки =================
async def download_direct(url: str, suffix: str = ".mp4") -> str:
    """Качает файл по прямой ссылке с лимитом MAX_BYTES → локальный путь."""
    import aiohttp
    path = str(_dir() / (uuid.uuid4().hex + suffix))
    ua = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/124.0 Safari/537.36"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120), headers=ua) as s:
            async with s.get(url) as r:
                if r.status != 200:
                    raise DLError(f"файл не отдаётся ({r.status})")
                size = int(r.headers.get("Content-Length") or 0)
                if size > MAX_BYTES:
                    raise DLError(f"файл больше {LIM}")
                got = 0
                with open(path, "wb") as f:
                    async for chunk in r.content.iter_chunked(1 << 16):
                        got += len(chunk)
                        if got > MAX_BYTES:
                            raise DLError(f"файл больше {LIM}")
                        f.write(chunk)
    except DLError:
        Path(path).unlink(missing_ok=True)
        raise
    except Exception as e:
        Path(path).unlink(missing_ok=True)
        raise DLError(f"не скачался: {str(e)[:120]}")
    return path


# ================= Pinterest напрямую =================
_pin_cache: dict[str, tuple[float, dict]] = {}


async def pinterest_pin(pin_url: str) -> dict:
    """Данные пина через внутренний API Pinterest (как делает yt-dlp). Кэш на 10 минут."""
    import json as _json
    import time as _time
    import aiohttp
    m = re.search(r"/pin/(\d+)", pin_url)
    if not m:
        raise DLError("не ссылка на пин")
    pid = m.group(1)
    hit = _pin_cache.get(pid)
    if hit and _time.time() - hit[0] < 600:
        return hit[1]
    q = _json.dumps({"options": {"field_set_key": "unauth_react_main_pin", "id": pid}})
    hdr = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) Chrome/124.0 Safari/537.36",
           "X-Pinterest-PWS-Handler": "www/[username].js", "Accept": "application/json"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=30), headers=hdr) as s:
            async with s.get("https://www.pinterest.com/resource/PinResource/get/", params={"data": q}) as r:
                data = await r.json(content_type=None)
    except Exception as e:
        raise DLError(f"pinterest api: {str(e)[:100]}")
    pin = ((data or {}).get("resource_response") or {}).get("data") or {}
    if len(_pin_cache) > 500:
        _pin_cache.clear()
    _pin_cache[pid] = (_time.time(), pin)
    return pin


def _best_img(images: dict) -> str | None:
    for k in ("736x", "orig", "originals", "474x"):
        u = (images or {}).get(k)
        if isinstance(u, dict) and u.get("url"):
            return u["url"]
    for k, u in (images or {}).items():   # другой размер (у слотов карусели бывает один, любой) → берём 736x
        if isinstance(u, dict) and u.get("url"):
            return re.sub(r"/\d+x\d*/", "/736x/", u["url"], count=1)
    return None


def pin_is_video(pin: dict) -> bool:
    if (pin.get("videos") or {}).get("video_list"):
        return True
    for page in ((pin.get("story_pin_data") or {}).get("pages") or []):
        for block in page.get("blocks") or []:
            if ((block or {}).get("video") or {}).get("video_list"):
                return True
    return False


def best_pin_image(images: dict | None) -> str | None:
    return _best_img(images or {})


def _imgs_in(node, out: list):
    """Все картинки внутри узла: словари {"images": {"736x": {"url": …}}}."""
    if isinstance(node, dict):
        u = _best_img(node.get("images")) if isinstance(node.get("images"), dict) else None
        if u:
            out.append(u)
        for k, v in node.items():
            if k != "images":
                _imgs_in(v, out)
    elif isinstance(node, list):
        for v in node:
            _imgs_in(v, out)


def pinterest_images(pin: dict) -> list[str]:
    """Все картинки пина: карусель (парные аватарки и т.п.) или страницы идея-пина. Одна — значит не альбом.
    Смотрим только узлы карусели и story_pin_data — аватарки автора и обложки досок не цепляем."""
    urls: list[str] = []
    for k, v in pin.items():
        if "carousel" in k.lower():
            _imgs_in(v, urls)
    if len(urls) < 2:
        urls = []
        for page in ((pin.get("story_pin_data") or {}).get("pages") or []):
            _imgs_in(page.get("blocks") or [], urls)
    seen, out = set(), []
    for u in urls:
        key = re.sub(r"/(?:\d+x|orig|originals)/", "/", u)   # один кадр в разных размерах — одна картинка
        if key not in seen:
            seen.add(key)
            out.append(u)
    return out[:10]


async def pinterest_video(pin_url: str) -> dict:
    """Видео пина через внутренний API Pinterest (как делает yt-dlp), mp4 качаем напрямую."""
    pin = await pinterest_pin(pin_url)
    vlist = (pin.get("videos") or {}).get("video_list") or {}
    if not vlist:
        for page in ((pin.get("story_pin_data") or {}).get("pages") or []):
            for block in page.get("blocks") or []:
                vl = ((block or {}).get("video") or {}).get("video_list")
                if vl:
                    vlist = vl
                    break
            if vlist:
                break
    if not vlist:
        raise DLError("это не видео-пин")
    mp4 = [(v.get("width") or 0, v) for v in vlist.values()
           if isinstance(v, dict) and str(v.get("url", "")).split("?")[0].endswith(".mp4")]
    if not mp4:
        raise DLError("только HLS")  # пусть добьёт yt-dlp
    mp4.sort(key=lambda x: x[0])
    good = [v for w, v in mp4 if w <= 1280] or [mp4[0][1]]
    best = good[-1]
    path = await download_direct(best["url"], ".mp4")
    return {"path": path, "duration": int((best.get("duration") or 0) / 1000),
            "width": best.get("width"), "height": best.get("height")}
