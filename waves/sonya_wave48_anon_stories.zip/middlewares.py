import asyncio
import logging
import time

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
import db

log = logging.getLogger("mw")


def _night() -> bool:
    return 3 <= time.gmtime(time.time() + 3 * 3600).tm_hour < 5   # 3–5 утра по МСК


class UserMiddleware(BaseMiddleware):
    """Регистрирует юзера, начисляет xp, отсекает забаненных, проверяет достижения."""

    async def __call__(self, handler, event, data):
        u = getattr(event, "from_user", None)
        if u is None or u.is_bot:
            return await handler(event, data)
        if isinstance(event, (Message, CallbackQuery)):
            user = await db.touch_user(u, count=isinstance(event, Message))
            import uikit
            uikit.note_name(u.id, (u.full_name or "")[:64])
            if user and user["banned"]:
                return
            data["user"] = user
            import config
            if user and config.PROFILE == "full":
                chat = event.chat if isinstance(event, Message) else (event.message and event.message.chat)
                where = chat.id if chat and chat.type != "channel" else None   # из канала — в личку
                asyncio.create_task(_achievements(data["bot"], user, where,
                                                  isinstance(event, Message) and _night()))
        if isinstance(event, Message) and event.chat.type in ("group", "supergroup"):
            await db.add_chat(event.chat.id, event.chat.title or "")
            await db.track_group(event.chat.id, u.id)
        return await handler(event, data)


async def _achievements(bot, user: dict, chat_id: int | None, night: bool):
    import achievements
    try:
        await achievements.check(bot, user, chat_id, night)
    except Exception as e:
        log.info("achievements: %s", e)


# ================= волна 45: антифлуд и повтор при «слишком часто» =================
class Throttle(BaseMiddleware):
    """В личке и на кнопках: больше LIMIT апдейтов за WINDOW секунд от одного человека — молча пропускаем,
    один раз предупредив. Группы не трогаем: там модерация должна видеть всё (антифлуд у неё свой)."""
    LIMIT, WINDOW, WARN_GAP = 8, 4.0, 30

    def __init__(self):
        self.hits: dict[int, list[float]] = {}
        self.warned: dict[int, float] = {}

    async def __call__(self, handler, event, data):
        u = getattr(event, "from_user", None)
        chat = getattr(event, "chat", None) or getattr(getattr(event, "message", None), "chat", None)
        if not u or (chat and chat.type != "private" and not isinstance(event, CallbackQuery)):
            return await handler(event, data)
        now = time.time()
        q = [t for t in self.hits.get(u.id, []) if now - t < self.WINDOW]
        q.append(now)
        self.hits[u.id] = q
        if len(self.hits) > 5000:   # не копим память
            self.hits = {k: v for k, v in self.hits.items() if now - v[-1] < self.WINDOW}
        if len(q) <= self.LIMIT:
            return await handler(event, data)
        if now - self.warned.get(u.id, 0) > self.WARN_GAP:
            self.warned[u.id] = now
            try:
                if isinstance(event, CallbackQuery):
                    await event.answer("⏳ помедленнее — не успеваю 🙃")
                else:
                    await event.answer("⏳ помедленнее — не успеваю 🙃")
            except Exception:
                pass
        return None


from aiogram.client.session.middlewares.base import BaseRequestMiddleware  # noqa: E402


class RetryAfter(BaseRequestMiddleware):
    """Telegram ответил «слишком часто, подожди N секунд» — ждём и пробуем ещё раз (до 2 раз, если ждать ≤ 15 с).
    Так советуют мейнтейнеры aiogram: повтор в сессии, а не try/except вокруг каждой отправки."""
    MAX_WAIT, TRIES = 15, 2

    async def __call__(self, make_request, bot, method):
        from aiogram.exceptions import TelegramRetryAfter
        for i in range(self.TRIES + 1):
            try:
                return await make_request(bot, method)
            except TelegramRetryAfter as e:
                if i == self.TRIES or e.retry_after > self.MAX_WAIT:
                    raise
                log.info("retry_after %s с на %s", e.retry_after, type(method).__name__)
                await asyncio.sleep(e.retry_after + 0.5)
