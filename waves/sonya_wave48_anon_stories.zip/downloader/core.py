"""Скачивание по ссылке: проба, видео, звук, поиск трека, Pinterest."""
import asyncio
import html
import logging
import os
import re
import shutil
import time
import uuid
from pathlib import Path

import aiohttp

import config
from autopost import media_dl
from autopost.media_dl import DLError, MAX_BYTES

log = logging.getLogger("dl")
UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0 Safari/537.36", "Accept-Language": "ru,en;q=0.8"}
COOKIES = os.getenv("YTDLP_COOKIES", "")  # путь к cookies.txt (нужен для Instagram/18+)
class _PrioSem:
    """Семафор с приоритетом: Соня+ встаёт в начало очереди."""

    def __init__(self, n: int):
        self.n, self.q, self.seq = n, [], 0

    def locked(self) -> bool:
        return self.n <= 0

    async def acquire(self, prio: int = 1):
        import heapq
        if self.n > 0 and not self.q:
            self.n -= 1
            return
        fut = asyncio.get_running_loop().create_future()
        self.seq += 1
        heapq.heappush(self.q, (prio, self.seq, fut))
        try:
            await fut
        except asyncio.CancelledError:
            if fut.done() and not fut.cancelled():
                self.release()   # место уже выдали, а нас отменили — отдаём дальше
            raise

    def release(self):
        import heapq
        while self.q:
            _, _, fut = heapq.heappop(self.q)
            if not fut.done():
                fut.set_result(None)
                return
        self.n += 1


_sem = _PrioSem(int(os.getenv("DL_PARALLEL", "2")))   # сколько загрузок одновременно
WAITING = [0]                             # сколько ждут своей очереди


def _opts(extra: dict) -> dict:
    o = {"quiet": True, "no_warnings": True, "noplaylist": True, "socket_timeout": 30, "retries": 2,
         "http_headers": UA}
    if COOKIES and Path(COOKIES).exists():
        o["cookiefile"] = COOKIES
    o.update(extra)
    return o


def _clean_err(e: Exception) -> str:
    msg = re.sub(r"^ERROR:\s*(\[[^\]]+\]\s*)?([\w-]+:\s*)?", "", str(e).split("\n")[0])
    low = msg.lower()
    if "login" in low or "log in" in low or "cookies" in low or "sign in" in low:
        return "нужен вход в аккаунт (приватное или 18+)"
    if "private" in low:
        return "это приватное видео"
    if "unavailable" in low or "not available" in low or "404" in low:
        return "видео недоступно или удалено"
    if "geo" in low or "451" in low or "country" in low:
        return "недоступно в стране сервера"
    if "unsupported url" in low:
        return "такую ссылку не умею"
    return msg[:150]


# ================= проба =================
def _probe_sync(url: str) -> dict:
    import yt_dlp
    with yt_dlp.YoutubeDL(_opts({"skip_download": True})) as y:
        info = y.extract_info(url, download=False)
    if info.get("_type") == "playlist" or info.get("entries"):
        entries = [e for e in (info.get("entries") or []) if e]
        if len(entries) == 1:
            info = entries[0]
        else:
            return {"collection": True, "title": info.get("title") or "", "count": len(entries)}
    fmts = info.get("formats") or []
    has_video = any((f.get("vcodec") or "none") != "none" for f in fmts) or bool(info.get("width"))
    return {
        "qualities": qualities(fmts, int(info.get("duration") or 0)),
        "thumbnail": info.get("thumbnail") or "",
        "description": info.get("description") or "",
        "views": info.get("view_count"), "likes": info.get("like_count"),
        "comments": info.get("comment_count"), "date": info.get("upload_date") or "",
        "collection": False,
        "title": info.get("title") or "",
        "uploader": info.get("uploader") or info.get("channel") or "",
        "duration": int(info.get("duration") or 0),
        "is_live": bool(info.get("is_live")),
        "audio_only": not has_video,
        "webpage_url": info.get("webpage_url") or url,
    }


def qualities(fmts: list, dur: int) -> list[tuple[int, int]]:
    """[(высота, примерный размер в байтах)] — что реально есть у видео, по возрастанию."""
    best_audio = max([f.get("filesize") or f.get("filesize_approx") or 0 for f in fmts
                      if (f.get("vcodec") or "none") == "none" and (f.get("acodec") or "none") != "none"] or [0])
    out: dict[int, int] = {}
    for f in fmts:
        h = f.get("height")
        if not h or (f.get("vcodec") or "none") == "none" or h < 240:
            continue
        size = f.get("filesize") or f.get("filesize_approx") or (
            int((f.get("tbr") or 0) * 1000 / 8 * dur) if f.get("tbr") and dur else 0)
        if (f.get("acodec") or "none") == "none":
            size += best_audio
        h = min((x for x in (240, 360, 480, 720, 1080, 1440, 2160) if x >= h), default=h)
        if size and (h not in out or size < out[h]):
            out[h] = size
        elif h not in out:
            out[h] = 0
    return sorted(out.items())


async def probe(url: str) -> dict:
    try:
        return await asyncio.to_thread(_probe_sync, url)
    except Exception as e:
        raise DLError(_clean_err(e))


# ================= загрузка =================
def _hook(progress: dict | None):
    def h(d):
        if progress is None or d.get("status") != "downloading":
            return
        total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
        done = d.get("downloaded_bytes") or 0
        progress.update(pct=int(done * 100 / total) if total else None, speed=d.get("speed") or 0,
                        eta=d.get("eta"), done=done, total=total)
    return h


# YouTube режет сервера ошибкой 403 — пробуем по очереди других «клиентов» плеера
YT_CLIENTS = [["tv"], ["web_safari"], ["mweb"], ["android_vr"], ["ios"]]


def _is_yt(url: str) -> bool:
    return any(x in url for x in ("youtube.com", "youtu.be", "ytsearch"))


def _dl_sync(url: str, kind: str, max_h: int, progress: dict | None = None, client: list | None = None) -> dict:
    import yt_dlp
    stem = str(media_dl._dir() / uuid.uuid4().hex)
    ff = bool(shutil.which("ffmpeg"))
    if kind == "audio":
        o = {"format": "bestaudio[ext=m4a]/bestaudio[ext=mp3]/bestaudio/best", "outtmpl": stem + ".%(ext)s",
             "max_filesize": MAX_BYTES}
        if ff:
            o["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192"}]
    else:
        h = max_h
        fmt = (f"bv*[height<={h}][ext=mp4]+ba[ext=m4a]/bv*[height<={h}]+ba/b[height<={h}][ext=mp4]/"
               f"b[height<={h}]/bv*[height<={h}][ext=mp4]/bv*[height<={h}]/b*[height<={h}]/b*"
               if ff else f"b[height<={h}][ext=mp4]/b[ext=mp4]/b*[ext=mp4]/b*")
        o = {"format": fmt, "outtmpl": stem + ".%(ext)s", "merge_output_format": "mp4",
             "max_filesize": MAX_BYTES}
    o["progress_hooks"] = [_hook(progress)]
    if client:
        o["extractor_args"] = {"youtube": {"player_client": client}}
    else:
        o["concurrent_fragment_downloads"] = 4   # YouTube и HLS качаются кусками — параллельно быстрее
    with yt_dlp.YoutubeDL(_opts(o)) as y:
        info = y.extract_info(url, download=True)
    files = [f for f in Path(stem).parent.glob(Path(stem).name + ".*") if f.suffix not in (".part", ".ytdl")]
    if not files:
        raise DLError("too_big")
    path = max(files, key=lambda f: f.stat().st_mtime)
    if path.stat().st_size > MAX_BYTES:
        path.unlink(missing_ok=True)
        raise DLError("too_big")
    return {"path": str(path), "title": info.get("track") or info.get("title") or "",
            "performer": info.get("artist") or info.get("uploader") or "",
            "duration": int(info.get("duration") or 0), "width": info.get("width"), "height": info.get("height")}


async def download(url: str, kind: str = "video", max_h: int | None = None, progress: dict | None = None,
                   priority: bool = False) -> dict:
    """Видео ≤720p (если не влезает в лимит — 480p, потом 360p) или звук mp3. max_h — выбранное качество.
    progress — словарь, куда пишем проценты/скорость (для живого статуса). TikTok упал — пробуем tikwm."""
    WAITING[0] += 1
    try:
        await _sem.acquire(0 if priority else 1)
    finally:
        WAITING[0] -= 1
    try:
        heights = ([max_h] if max_h else [720, 480, 360]) if kind == "video" else [0]
        last = None
        for h in heights:
            try:
                return await asyncio.to_thread(_dl_sync, url, kind, h, progress)
            except DLError as e:
                last = e
                if str(e) != "too_big":
                    break
            except Exception as e:
                last = DLError(_clean_err(e))
                break
        if _is_yt(url) and "403" in str(last):
            for client in YT_CLIENTS:
                try:
                    log.info("youtube 403 → пробую клиент %s", client)
                    return await asyncio.to_thread(_dl_sync, url, kind, max_h or 720, progress, client)
                except Exception as e:
                    log.info("client %s: %s", client, str(e)[:120])
            last = DLError("YouTube не пускает сервер (403). нажми в админке «⬆️ Обновить yt-dlp» — обычно помогает")
        if "tiktok.com" in url and str(last) != "too_big":
            try:
                return await tiktok_fallback(url, kind)
            except Exception as e:
                log.info("tikwm fallback: %s", e)
        lim = f"{MAX_BYTES // 1024 // 1024 + 1} МБ"
        raise DLError(f"файл больше {lim} — телеграм не даст отправить" if str(last) == "too_big" else str(last))
    finally:
        _sem.release()


async def tiktok_fallback(url: str, kind: str) -> dict:
    """Запасной путь, когда yt-dlp сломался на TikTok: tikwm отдаёт ссылку без водяного знака."""
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25), headers=UA) as s:
        async with s.get("https://www.tikwm.com/api/", params={"url": url, "hd": "1"}) as r:
            d = await r.json(content_type=None)
    data = (d or {}).get("data") or {}
    src = (data.get("music") if kind == "audio" else data.get("hdplay") or data.get("play"))
    if (d or {}).get("code") != 0 or not src:
        raise DLError("tikwm не отдал видео")
    if src.startswith("/"):
        src = "https://www.tikwm.com" + src
    raw = await fetch_bytes(src, min(MAX_BYTES, 300 * 1024 * 1024))   # tikwm — в память
    path = str(media_dl._dir() / (uuid.uuid4().hex + (".mp3" if kind == "audio" else ".mp4")))
    with open(path, "wb") as f:
        f.write(raw)
    author = (data.get("author") or {}).get("nickname") or ""
    return {"path": path, "title": data.get("title") or "", "performer": author,
            "duration": int(data.get("duration") or 0), "width": None, "height": None}


# ================= музыка из Spotify/Яндекса/Apple → ищем на YouTube =================
async def _og(url: str) -> dict:
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20), headers=UA) as s:
        async with s.get(url) as r:
            body = await r.text(errors="ignore")
    out = {}
    for k in ("og:title", "og:description", "music:musician_description"):
        m = re.search(rf'<meta[^>]+(?:property|name)="{k}"[^>]+content="([^"]*)"', body) or \
            re.search(rf'<meta[^>]+content="([^"]*)"[^>]+(?:property|name)="{k}"', body)
        if m:
            out[k] = html.unescape(m.group(1))
    return out


async def music_query(url: str, platform: str) -> str:
    try:
        og = await _og(url)
    except Exception as e:
        raise DLError(f"страница не открылась: {str(e)[:80]}")
    title = og.get("og:title", "")
    desc = og.get("og:description", "")
    if platform == "spotify":
        # «Song · Artist» или description «Artist · Song · Song · 2023»
        artist = desc.split("·")[0].strip() if "·" in desc else ""
        q = f"{artist} {title}".strip()
    elif platform == "yamusic":
        # «Трек — Артист. Слушать онлайн на Яндекс Музыке»
        q = re.sub(r"\.?\s*(Слушать|Listen).*$", "", title).replace("—", " ")
    else:
        q = title.replace(" - Single", "")
    q = re.sub(r"\s+", " ", q).strip()
    if len(q) < 3:
        raise DLError("не поняла, что за трек")
    return q


async def music_search(url: str, platform: str) -> dict:
    q = await music_query(url, platform)
    f = await download(f"ytsearch1:{q} audio", "audio")
    f["query"] = q
    return f


# ================= Pinterest =================
async def resolve_redirect(url: str) -> str:
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=15), headers=UA) as s:
        async with s.get(url, allow_redirects=True) as r:
            return str(r.url)


async def pinterest(url: str) -> dict:
    """→ {"type": "video", path…} или {"type": "photo", "url": …}"""
    if "pin.it/" in url:
        try:
            url = await resolve_redirect(url)
        except Exception as e:
            raise DLError(f"короткая ссылка не открылась: {str(e)[:60]}")
    try:
        f = await media_dl.pinterest_video(url)
        return {"type": "video", **f}
    except DLError as e:
        if "не видео" not in str(e):
            try:
                f = await download(url, "video")
                return {"type": "video", **f}
            except DLError:
                pass
    img = await pinterest_image(url)
    if not img:
        raise DLError("не нашла ни видео, ни картинки в пине")
    return {"type": "photo", "url": img}


async def pinterest_image(url: str) -> str | None:
    import json as _json
    m = re.search(r"/pin/(\d+)", url)
    if not m:
        return None
    q = _json.dumps({"options": {"field_set_key": "unauth_react_main_pin", "id": m.group(1)}})
    hdr = {**UA, "X-Pinterest-PWS-Handler": "www/[username].js"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20), headers=hdr) as s:
            async with s.get("https://www.pinterest.com/resource/PinResource/get/", params={"data": q}) as r:
                data = await r.json(content_type=None)
        imgs = (((data or {}).get("resource_response") or {}).get("data") or {}).get("images") or {}
        for k in ("orig", "736x", "474x"):
            if imgs.get(k, {}).get("url"):
                return imgs[k]["url"]
    except Exception as e:
        log.info("pin image: %s", e)
    return None


def remove(path: str | None):
    if path:
        try:
            os.unlink(path)
        except OSError:
            pass


# ================= TikTok: фото-карусели (yt-dlp их не умеет) =================
TT_MAX_PHOTOS = 30


def _tt_from_page(body: str) -> dict | None:
    """Карусель со страницы TikTok: JSON __UNIVERSAL_DATA_FOR_REHYDRATION__ → imagePost."""
    import json as _json
    m = re.search(r'<script[^>]+id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>(.*?)</script>', body, re.S)
    if not m:
        return None
    try:
        data = _json.loads(m.group(1))
    except ValueError:
        return None
    found = {}

    def walk(node):
        if isinstance(node, dict):
            if "imagePost" in node and isinstance(node["imagePost"], dict) and not found:
                found["post"] = node
            for v in node.values():
                walk(v)
        elif isinstance(node, list):
            for v in node:
                walk(v)
    walk(data)
    post = found.get("post")
    if not post:
        return None
    imgs = []
    for im in post["imagePost"].get("images") or []:
        urls = ((im or {}).get("imageURL") or {}).get("urlList") or []
        if urls:
            imgs.append(urls[0])
    music = ((post.get("music") or {}).get("playUrl")) or None
    return {"images": imgs, "music": music, "title": post.get("desc") or ""} if imgs else None


async def tiktok_photos(url: str) -> dict:
    """→ {"images": [url…], "music": url|None, "title": str}. Сначала tikwm API, потом страница TikTok."""
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=25), headers=UA) as s:
        try:
            async with s.get("https://www.tikwm.com/api/", params={"url": url, "hd": "1"}) as r:
                d = await r.json(content_type=None)
            data = (d or {}).get("data") or {}
            if (d or {}).get("code") == 0 and data.get("images"):
                return {"images": data["images"][:TT_MAX_PHOTOS], "music": data.get("music") or None,
                        "title": data.get("title") or ""}
        except Exception as e:
            log.info("tikwm: %s", e)
        try:
            async with s.get(url, allow_redirects=True) as r:
                body = await r.text(errors="ignore")
            got = _tt_from_page(body)
            if got:
                got["images"] = got["images"][:TT_MAX_PHOTOS]
                return got
        except Exception as e:
            log.info("tiktok page: %s", e)
    raise DLError("не смогла достать фото из TikTok — попробуй позже")


async def fetch_bytes(url: str, limit: int = 20 * 1024 * 1024) -> bytes:
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=40), headers=UA) as s:
        async with s.get(url) as r:
            if r.status != 200:
                raise DLError(f"файл не отдался ({r.status})")
            data = await r.read()
    if len(data) > limit:
        raise DLError("файл слишком большой")
    return data
