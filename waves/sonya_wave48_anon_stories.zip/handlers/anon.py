"""💌 Анонимные вопросы: у каждого своя ссылка → друзья пишут анонимно → отвечаешь, не зная, кто это.
Защита: блок отправителя, жалоба, фильтр угроз, лимит частоты, «не принимать сообщения»."""
import hashlib
import os
import logging
import re
import time
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("anon")
RATE = (5, 60)            # не больше 5 сообщений в минуту от одного человека
_writing: dict[int, tuple] = {}               # отправитель → (кому, когда начал, тема, id анонимки-родителя)
_labeling: dict[int, int] = {}                # получатель → id маски, которую подписывает
_replying: dict[int, tuple[int, float]] = {}   # получатель → (id анонимки, когда нажал «ответить»)
_sent: dict[int, list[float]] = {}
TOPICS = {"q": "задай мне анонимный вопрос", "rate": "оцени меня от 1 до 10", "conf": "признайся мне в чём-нибудь",
          "think": "что ты обо мне думаешь?", "nh": "я никогда не…", "advice": "дай мне совет"}
TOPIC_ICON = {"q": "❓", "rate": "⭐", "conf": "💘", "think": "💭", "nh": "🙊", "advice": "💡"}
# волна 46: маски — «прилагательное + зверь», своя у каждой пары «получатель — аноним»
MASK_ADJ = ["Хитрый", "Сонный", "Тихий", "Весёлый", "Загадочный", "Смелый", "Ленивый", "Добрый", "Быстрый",
            "Мудрый", "Робкий", "Дерзкий", "Нежный", "Важный", "Шустрый", "Мечтательный", "Озорной", "Грустный",
            "Сладкий", "Звёздный"]
MASK_ANIMAL = ["🦊 Лис", "🐼 Панда", "🦉 Сова", "🐺 Волк", "🐱 Кот", "🐰 Заяц", "🐻 Медведь", "🦝 Енот",
               "🐧 Пингвин", "🦔 Ёж", "🐨 Коала", "🦁 Лев", "🐯 Тигр", "🐸 Лягушонок", "🐙 Осьминог", "🦄 Единорог"]
BAD = re.compile(r"(убью|убить тебя|зарежу|сдохни|выпились|самоубий|твой адрес|найду тебя|слив|интим фото)", re.I)


# ================= маски =================
def _mask_text(adj: str, animal: str) -> str:
    emoji, name = animal.split(" ", 1)
    if name in ("Панда", "Сова", "Коала"):   # женский род: Хитрый → Хитрая, Тихий → Тихая, Озорной → Озорная
        adj = adj[:-2] + "ая"
    return f"{emoji} {adj} {name}"


MASK_TTL = int(float(os.getenv("ANON_MASK_HOURS", "2") or 2) * 3600)   # волна 46b: тишина дольше — маска сгорает
MASK_COOLDOWN = 7 * 86400                                              # сгоревшую маску неделю не раздаём другим


async def mask_of(owner: int, sender: int, keep_id: int = 0) -> dict:
    """Маска анонима у этого получателя. Живёт, пока они общаются; после MASK_TTL тишины — новая.
    keep_id — продолжение старой ветки: человек сам отвечает в ней, возвращаем ту же маску."""
    now = int(time.time())
    if keep_id:
        r = await db.q_one("SELECT * FROM anon_masks2 WHERE id=? AND owner=? AND sender=?", keep_id, owner, sender)
        if r:
            await db.q_run("UPDATE anon_masks2 SET active=0 WHERE owner=? AND sender=? AND id<>?", owner, sender, r["id"])
            await db.q_run("UPDATE anon_masks2 SET active=1, last_ts=? WHERE id=?", now, r["id"])
            return await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", r["id"])
    r = await db.q_one("SELECT * FROM anon_masks2 WHERE owner=? AND sender=? AND active=1", owner, sender)
    if r and now - (r["last_ts"] or now) <= MASK_TTL:
        return r
    if r:   # тишина затянулась — маска сгорает
        await db.q_run("UPDATE anon_masks2 SET active=0 WHERE id=?", r["id"])
    import random
    used = {x["mask"] for x in await db.q_all("SELECT mask FROM anon_masks2 WHERE owner=? AND (active=1 OR last_ts>?)",
                                              owner, now - MASK_COOLDOWN)}
    free = [x for x in (_mask_text(a, b) for a in MASK_ADJ for b in MASK_ANIMAL) if x not in used]
    if free:
        mask = random.choice(free)
    else:   # у одного человека больше 320 анонимов — добавляем номер
        n = 2
        base = _mask_text(random.choice(MASK_ADJ), random.choice(MASK_ANIMAL))
        while f"{base} {n}" in used:
            n += 1
        mask = f"{base} {n}"
    mid = await db.q_run("INSERT INTO anon_masks2(owner, sender, mask, last_ts, active) VALUES(?,?,?,?,1)",
                         owner, sender, mask, now)
    return await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", mid)


async def touch_mask(mask_id: int):
    if mask_id:
        await db.q_run("UPDATE anon_masks2 SET last_ts=? WHERE id=?", int(time.time()), mask_id)


def mask_name(mk: dict) -> str:
    return (mk["mask"] + (f" · «{mk['label']}»" if mk.get("label") else "")
            + ("" if mk.get("active", 1) else " · 💤"))


async def name_of(uid: int) -> str:
    u = await db.get_user(uid) or {}
    return u.get("name") or "получатель"


# ================= ссылка =================
def code_of(uid: int) -> str:
    return hashlib.sha256(f"anon|{uid}|{config.BOT_TOKEN[:12]}".encode()).hexdigest()[:10]


async def ensure_link(uid: int) -> str:
    code = code_of(uid)
    await db.q_run("INSERT OR IGNORE INTO anon_links(uid, code, open) VALUES(?,?,1)", uid, code)
    return code


async def owner_of(code: str) -> dict | None:
    return await db.q_one("SELECT * FROM anon_links WHERE code=?", code)


async def home_view(bot: Bot, uid: int):
    """Волна 47: главная — коротко: ссылка, цифры, 5 кнопок. Настройки — отдельным экраном."""
    code = await ensure_link(uid)
    me = await bot.me()
    link = f"https://t.me/{me.username}?start=a_{code}"
    got = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=?", uid))["n"]
    wait = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=? AND seen=0 AND answered=0", uid))["n"]
    visits = int(await db.kv_get(f"an:visits:{uid}") or 0)
    row = await db.q_one("SELECT open FROM anon_links WHERE uid=?", uid) or {}
    share = ("https://t.me/share/url?url=" + quote(link) + "&text=" + quote("задай мне анонимный вопрос 👀"))
    text = (f"💌 <b>Анонимные вопросы</b>\n<code>{link}</code>\n"
            + ui.hint(f"👀 {visits} переходов · 📬 {got} получено" + (f" · 🔵 {wait} новых" if wait else "")
                      + ("" if row.get("open", 1) else " · 📴 приём выключен")))
    kb = kb_rows([("📤 Поделиться ссылкой", share, "success")],
                 [("🎨 В сторис", "an:cards"), (f"📥 Входящие · {wait}" if wait else "📥 Входящие", "an:inbox")],
                 [("🎲 Анонимный чат", "ch:menu"), ("⚙️ Настройки", "an:set")])
    return text, kb


async def home(m: Message, bot: Bot, uid: int):
    text, kb = await home_view(bot, uid)
    await m.answer(text, reply_markup=kb)


async def settings_view(uid: int):
    row = await db.q_one("SELECT open, nomat FROM anon_links WHERE uid=?", uid) or {}
    blocked = (await db.q_one("SELECT COUNT(*) n FROM anon_blocks WHERE owner=?", uid))["n"]
    text = ("⚙️ <b>Настройки анонимок</b>\n"
            + ui.hint("🔒 авторов не раскрываю никому — ни за звёзды, ни за деньги, даже тебе\n"
                      f"🎭 маска анонима сгорает после {MASK_TTL // 3600} ч тишины"))
    rows = [[(f"{ui.tog(row.get('open', 1))} Принимать сообщения", "an:toggle")],
            [(f"{ui.tog(row.get('nomat', 0))} 🤬 Не принимать мат", "an:mat")]]
    if blocked:
        rows.append([(f"🔓 Разблокировать всех · {blocked}", "an:unblock", "danger")])
    rows.append([("‹ Назад", "an:back")])
    return text, kb_rows(*rows)


@router.message(Command("link", "ссылка"))
async def cmd_link(m: Message, bot: Bot):
    await home(m, bot, m.from_user.id)


@router.callback_query(F.data == "an:home")
async def cb_home(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    await home(cb.message, bot, cb.from_user.id)


@router.callback_query(F.data == "an:back")
async def cb_back(cb: CallbackQuery, bot: Bot):
    await show(cb, *await home_view(bot, cb.from_user.id))


@router.callback_query(F.data == "an:set")
async def cb_settings(cb: CallbackQuery):
    await ensure_link(cb.from_user.id)
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data == "an:toggle")
async def cb_toggle(cb: CallbackQuery):
    await ensure_link(cb.from_user.id)
    await db.q_run("UPDATE anon_links SET open=1-open WHERE uid=?", cb.from_user.id)
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data == "an:mat")
async def cb_mat(cb: CallbackQuery):
    """Волна 45: фильтр грубостей — сообщения с матом не доходят, автора просят переписать."""
    await ensure_link(cb.from_user.id)
    await db.q_run("UPDATE anon_links SET nomat=1-nomat WHERE uid=?", cb.from_user.id)
    await show(cb, *await settings_view(cb.from_user.id))


# ================= написать анонимно =================
async def start_writing(m: Message, bot: Bot, code: str, uid: int | None = None, topic: str = "q",
                        parent: int = 0) -> bool:
    uid = uid or m.from_user.id
    topic = topic if topic in TOPICS else "q"
    from handlers import anonchat
    if uid in anonchat.PAIRS:
        await m.answer("ты сейчас в анонимном чате — сначала /stop, потом пиши по ссылке")
        return True
    o = await owner_of(code)
    if not o:
        await m.answer("🤔 ссылка не работает — попроси новую")
        return True
    if o["uid"] == uid:
        await m.answer("это твоя же ссылка 🙃 кинь её друзьям")
        return True
    if not o["open"]:
        await m.answer("📴 этот человек сейчас не принимает анонимные сообщения")
        return True
    if await db.q_one("SELECT 1 FROM anon_blocks WHERE owner=? AND sender=?", o["uid"], uid):
        await m.answer("🚫 получатель ограничил тебе сообщения")
        return True
    _writing[uid] = (o["uid"], time.time(), topic, parent)
    if parent:
        head = f"↩️ <b>ответ {escape(await name_of(o['uid']))}</b> — напиши, отправлю в вашу переписку"
    else:
        head = (f"{TOPIC_ICON[topic]} <b>{TOPICS[topic]}</b>" if topic != "q"
                else f"✍️ <b>напиши анонимное сообщение для {escape(await name_of(o['uid']))}</b>")
    tail = ("\nтекст, фото, голосовое, кружок или стикер — он не узнает, кто ты 🤫\n"
            "<i>🔒 я никогда не раскрываю авторов — ни за звёзды, ни за деньги</i>"
            if await first_time(uid, "write") else "\n<i>🔒 анонимно</i>")
    p = await m.answer(head + tail, reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    _prompts[uid] = p.message_id
    return True


def writing(m: Message) -> bool:
    w = _writing.get(m.from_user.id) if m.from_user else None
    return bool(w and time.time() - w[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def replying(m: Message) -> bool:
    r = _replying.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def _too_fast(uid: int) -> bool:
    now = time.time()
    q = [t for t in _sent.get(uid, []) if now - t < RATE[1]]
    _sent[uid] = q
    if len(q) >= RATE[0]:
        return True
    q.append(now)
    return False


@router.callback_query(F.data == "an:cancel")
async def cb_cancel(cb: CallbackQuery):
    _writing.pop(cb.from_user.id, None)
    _replying.pop(cb.from_user.id, None)
    _labeling.pop(cb.from_user.id, None)
    await cb.answer("отменила")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass


def _kb_for_owner(mid: int, seen: bool = False):
    return kb_rows([("↩️ Ответить", f"an:re:{mid}", "success"),
                    ("✓ прочитано" if seen else "👁 Прочитано", "noop" if seen else f"an:sn:{mid}")],
                   [("🚫 Блок", f"an:bl:{mid}"), ("⚠️ Жалоба", f"an:rep:{mid}", "danger")])


# ================= волна 47: интерфейс — одно событие = одно сообщение =================
CAPTIONED = ("photo", "video", "animation", "audio", "voice", "document")
_prompts: dict[int, int] = {}   # uid → id подсказки «напиши…», убираем её после отправки


async def deliver(bot: Bot, to: int, m: Message, head: str, kb=None, reply_to: int | None = None) -> int:
    """Шапка и содержимое — одним сообщением: текст в цитате, у медиа шапка в подписи.
    Стикер и кружок подпись не умеют — только для них шапка отдельной строкой. Возвращает id сообщения."""
    rp = {"reply_to_message_id": reply_to, "allow_sending_without_reply": True} if reply_to else {}
    if m.text:
        body = m.html_text if len(m.html_text) < 3500 else escape(m.text[:3500]) + "…"
        q = "blockquote expandable" if len(m.text) > 400 else "blockquote"
        sent = await bot.send_message(to, f"{head}\n<{q}>{body}</{q.split()[0]}>", reply_markup=kb, **rp)
        return sent.message_id
    if any(getattr(m, k, None) for k in CAPTIONED):
        cap = head + (f"\n<blockquote>{m.html_text}</blockquote>" if m.caption else "")
        cp = await bot.copy_message(to, m.chat.id, m.message_id, caption=cap[:1024], reply_markup=kb, **rp)
        return getattr(cp, "message_id", 0) or 0
    await bot.send_message(to, head, **rp)
    cp = await bot.copy_message(to, m.chat.id, m.message_id, reply_markup=kb)
    return getattr(cp, "message_id", 0) or 0


async def first_time(uid: int, key: str) -> bool:
    """Длинные подсказки — только в первый раз, дальше не мусорим."""
    k = f"seen:{key}:{uid}"
    if await db.kv_get(k):
        return False
    await db.kv_set(k, "1")
    return True


async def drop_prompt(bot: Bot, uid: int):
    mid = _prompts.pop(uid, None)
    if mid:
        try:
            await bot.delete_message(uid, mid)
        except Exception:
            pass


@router.message(writing)
async def on_write(m: Message, bot: Bot):
    to, ts, topic, parent = _writing.pop(m.from_user.id)
    if _too_fast(m.from_user.id):
        return await m.answer("⏳ слишком быстро — подожди минутку")
    if m.text and BAD.search(m.text):
        return await m.answer("🚫 такое не передам. угрозы и травля — не сюда")
    body = m.text or m.caption or ""
    if body:
        import profanity
        r = await db.q_one("SELECT nomat FROM anon_links WHERE uid=?", to)
        if r and r["nomat"] and profanity.has_mat(body):
            _writing[m.from_user.id] = (to, ts, topic, parent)   # даём переписать
            return await m.answer("🙊 этот человек не принимает сообщения с матом — перепиши помягче, я жду",
                                  reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    q = (m.text or m.caption or "")[:1000]
    par = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND to_uid=? AND from_uid=?", parent, to,
                         m.from_user.id) if parent else None
    mk = await mask_of(to, m.from_user.id, keep_id=(par or {}).get("mask_id") or 0)
    mid = await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, ts, answered, topic, qtext, src_mid, parent, mask_id) "
                         "VALUES(?,?,?,0,?,?,?,?,?)", to, m.from_user.id, int(time.time()), topic, q, m.message_id,
                         parent if par else 0, mk["id"])
    await touch_mask(mk["id"])
    # у получателя: продолжение ветки — ответом на его прошлый ответ
    reply_to = (par or {}).get("ans_mid") or None
    head = (f"💬 <b>{escape(mask_name(mk))}</b>" if par
            else f"💌 <b>{escape(mask_name(mk))}</b>"
            + (f" · {TOPIC_ICON[topic]} <i>{TOPICS[topic]}</i>" if topic != "q" else ""))
    try:
        dlv = await deliver(bot, to, m, head, _kb_for_owner(mid), reply_to)
        await db.q_run("UPDATE anon_msgs SET dlv_mid=? WHERE id=?", dlv, mid)
    except Exception as e:
        log.info("deliver: %s", e)
        return await m.answer("😕 не смогла доставить — возможно, человек заблокировал бота")
    await drop_prompt(bot, m.from_user.id)
    code = code_of(to)
    text = f"✅ доставлено · у {escape(await name_of(to))} ты <b>{escape(mk['mask'])}</b>"
    if await first_time(m.from_user.id, "mask"):
        text += "\n" + ui.hint(f"маска только у этого человека, сбросится после {MASK_TTL // 3600} ч тишины. "
                               "ответ придёт прямо на твоё сообщение")
    await m.reply(text, reply_markup=kb_rows([("✍️ Ещё", f"an:more:{code}"), ("🙋 Раскрыться", f"an:rv:{mid}"),
                                              ("💌 Моя ссылка", "an:home")]))


@router.callback_query(F.data.startswith("an:more:"))
async def cb_more(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    code, _, topic = cb.data[8:].partition("_")
    await start_writing(cb.message, bot, code, cb.from_user.id, topic or "q")


# ================= ответ, блок, жалоба =================
async def _msg(cb: CallbackQuery) -> dict | None:
    mid = int(cb.data.rsplit(":", 1)[1])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND to_uid=?", mid, cb.from_user.id)
    if not r:
        await cb.answer("сообщение не найдено", show_alert=True)
    return r


@router.callback_query(F.data.startswith("an:re:"))
async def cb_reply(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    _replying[cb.from_user.id] = (r["id"], time.time())
    await cb.answer()
    mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", r.get("mask_id") or 0)
    who = escape(mk["mask"]) if mk else "автору"
    p = await cb.message.reply(f"↩️ ответ для {who} — пиши", reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    _prompts[cb.from_user.id] = p.message_id


@router.message(replying)
async def on_reply(m: Message, bot: Bot):
    mid, _ = _replying.pop(m.from_user.id)
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=?", mid)
    if not r:
        return await m.answer("сообщение устарело")
    who = escape(await name_of(r["to_uid"]))
    try:   # волна 47: ответ — одно сообщение реплаем на вопрос автора
        await deliver(bot, r["from_uid"], m, f"💬 <b>{who}</b> ответил(а):",
                      kb_rows([("↩️ Ответить", f"an:fu:{mid}", "success"),
                               ("✍️ Новое", f"an:more:{code_of(r['to_uid'])}")]),
                      r.get("src_mid") or None)
    except Exception as e:
        log.info("reply: %s", e)
        return await m.answer("😕 автор недоступен — наверное, заблокировал бота")
    await db.q_run("UPDATE anon_msgs SET answered=1, seen=1, atext=?, ans_mid=? WHERE id=?",
                   (m.text or m.caption or "")[:1000], m.message_id, mid)
    await touch_mask(r.get("mask_id") or 0)   # ответ тоже продлевает жизнь маски
    await drop_prompt(bot, m.from_user.id)
    await m.reply("✅ отправлено", reply_markup=kb_rows([("🖼 В сторис", f"an:ac:{mid}")])
                  if m.text and r.get("qtext") else None)


@router.callback_query(F.data.startswith("an:fu:"))
async def cb_followup(cb: CallbackQuery, bot: Bot):
    """Волна 46: аноним отвечает на ответ — сообщение ляжет в ту же ветку у получателя."""
    mid = int(cb.data.split(":")[2])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND from_uid=?", mid, cb.from_user.id)
    if not r:
        return await cb.answer("переписка не найдена", show_alert=True)
    await cb.answer()
    await start_writing(cb.message, bot, code_of(r["to_uid"]), cb.from_user.id, r.get("topic") or "q", parent=mid)


@router.callback_query(F.data.startswith("an:bl:"))
async def cb_block(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("🚫 автор больше не сможет тебе писать", show_alert=True)


@router.callback_query(F.data == "an:blocks")
async def cb_blocks(cb: CallbackQuery):
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data == "an:unblock")
async def cb_unblock(cb: CallbackQuery):
    await db.q_run("DELETE FROM anon_blocks WHERE owner=?", cb.from_user.id)
    await show(cb, *await settings_view(cb.from_user.id))


@router.callback_query(F.data.startswith("an:rep:"))
async def cb_report(cb: CallbackQuery, bot: Bot):
    """Жалоба уходит владельцу бота — только он видит автора, чтобы забанить за травлю."""
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("⚠️ жалоба отправлена, автор заблокирован", show_alert=True)
    if config.OWNER_ID:
        try:
            await bot.send_message(config.OWNER_ID, f"⚠️ <b>жалоба на анонимку</b> #{r['id']}\n"
                                                    f"автор: <code>{r['from_uid']}</code> → получатель <code>{r['to_uid']}</code>\n"
                                                    f"забанить автора: <code>/ban {r['from_uid']}</code>")
            await bot.copy_message(config.OWNER_ID, cb.message.chat.id, cb.message.message_id)
        except Exception:
            pass


async def deep_link(m: Message, bot: Bot, arg: str) -> bool:
    if arg.startswith("a_"):
        code, _, topic = arg[2:].partition("_")
        o = await owner_of(code)
        if o and o["uid"] != m.from_user.id:   # волна 48: 👀 сколько раз открыли ссылку
            k = f"an:visits:{o['uid']}"
            await db.kv_set(k, str(int(await db.kv_get(k) or 0) + 1))
        return await start_writing(m, bot, code, topic=topic or "q")
    return False


# ================= 🎨 сторис — редактор (волна 48) =================
_story_in: dict[int, str] = {}        # uid → чего ждём: "photo" или "text"
_story_photo: dict[int, tuple[str, bytes]] = {}   # uid → (file_id, байты) — кэш фона
_render_lock: dict[int, "asyncio.Lock"] = {}


async def story_style(uid: int) -> dict:
    import json
    from handlers import anoncards
    try:
        st = json.loads(await db.kv_get(f"an:style:{uid}") or "{}")
    except ValueError:
        st = {}
    return {**anoncards.DEFAULT, "topic": "q", **st}


async def save_style(uid: int, st: dict):
    import json
    await db.kv_set(f"an:style:{uid}", json.dumps(st, ensure_ascii=False))


async def _photo_bytes(bot: Bot, uid: int) -> bytes | None:
    fid = await db.kv_get(f"an:sphoto:{uid}")
    if not fid:
        return None
    hit = _story_photo.get(uid)
    if hit and hit[0] == fid:
        return hit[1]
    import io
    buf = io.BytesIO()
    try:
        await bot.download(fid, destination=buf)
    except Exception as e:
        log.info("story photo: %s", e)
        return None
    _story_photo[uid] = (fid, buf.getvalue())
    if len(_story_photo) > 50:
        _story_photo.pop(next(iter(_story_photo)))
    return buf.getvalue()


def _editor_kb(st: dict):
    from handlers import anoncards
    bg = "📷 фото" if st.get("bg") == "photo" else anoncards.THEME_NAMES[int(st.get("bg") or 0) % len(anoncards.THEMES)]
    return kb_rows([(f"🎨 Фон: {bg}", "an:sc:bg"), ("📷 Своё фото", "an:sc:photo")],
                   [(f"🔤 {anoncards.FONTS[st.get('font', 'classic')][0]}", "an:sc:font"),
                    (f"▫️ Плашка: {anoncards.BOXES[st.get('box', 'light')]}", "an:sc:box")],
                   [("✏️ Свой текст", "an:sc:text"), (f"{TOPIC_ICON[st.get('topic', 'q')]} Тема", "an:sc:topic")],
                   [("✅ Готово", "an:sc:done", "success")])


async def _render(bot: Bot, uid: int, st: dict):
    import asyncio
    from handlers import anoncards
    code = await ensure_link(uid)
    me = await bot.me()
    topic = st.get("topic", "q")
    link = f"https://t.me/{me.username}?start=a_{code}" + (f"_{topic}" if topic != "q" else "")
    photo = await _photo_bytes(bot, uid) if st.get("bg") == "photo" else None
    lock = _render_lock.setdefault(uid, asyncio.Lock())
    async with lock:
        png = await asyncio.to_thread(anoncards.ask_card, TOPICS[topic], link, me.username or "", 0, st, photo)
    cap = (f"🎨 <b>сторис</b> · крути настройки кнопками\nссылка для стикера «ссылка»:\n<code>{link}</code>")
    return png, cap


async def send_editor(m: Message, bot: Bot, uid: int):
    from aiogram.types import BufferedInputFile
    st = await story_style(uid)
    png, cap = await _render(bot, uid, st)
    await m.answer_photo(BufferedInputFile(png, "story.png"), caption=cap, reply_markup=_editor_kb(st))


@router.callback_query(F.data == "an:cards")
async def cb_cards(cb: CallbackQuery, bot: Bot):
    await cb.answer("рисую…")
    await send_editor(cb.message, bot, cb.from_user.id)


@router.callback_query(F.data.startswith("an:card:"))
async def cb_card_old(cb: CallbackQuery, bot: Bot):
    """Старые кнопки «картинка по теме» (до волны 48) — открываем редактор с этой темой."""
    topic = cb.data[8:]
    st = await story_style(cb.from_user.id)
    if topic in TOPICS:
        st["topic"], st["text"] = topic, ""
        await save_style(cb.from_user.id, st)
    await cb.answer("рисую…")
    await send_editor(cb.message, bot, cb.from_user.id)


@router.callback_query(F.data.startswith("an:sc:"))
async def cb_story(cb: CallbackQuery, bot: Bot):
    from aiogram.types import BufferedInputFile, InputMediaPhoto
    from handlers import anoncards
    uid, act = cb.from_user.id, cb.data[6:]
    st = await story_style(uid)
    if act == "done":
        await cb.answer("✅ сохраняй картинку и выкладывай")
        try:
            await cb.message.edit_reply_markup(reply_markup=None)
        except TelegramBadRequest:
            pass
        return
    if act in ("photo", "text"):
        _story_in[uid] = act
        await cb.answer()
        p = await cb.message.reply("📷 пришли фото — сделаю его фоном" if act == "photo"
                                   else "✏️ напиши свой текст для сторис (до 120 символов). «-» — вернуть тему",
                                   reply_markup=kb_rows([("✖️ Отмена", "an:sc:cancel")]))
        _prompts[uid] = p.message_id
        return
    if act == "cancel":
        _story_in.pop(uid, None)
        await cb.answer("ок")
        try:
            await cb.message.delete()
        except TelegramBadRequest:
            pass
        return
    if act == "bg":
        cur = st.get("bg")
        st["bg"] = 0 if cur == "photo" else (int(cur or 0) + 1) % len(anoncards.THEMES)
        if cur != "photo" and st["bg"] == 0 and await db.kv_get(f"an:sphoto:{uid}"):
            st["bg"] = "photo"   # после последнего градиента — своё фото, если есть
    elif act == "font":
        keys = anoncards.FONT_KEYS
        st["font"] = keys[(keys.index(st.get("font", "classic")) + 1) % len(keys)]
    elif act == "box":
        keys = anoncards.BOX_KEYS
        st["box"] = keys[(keys.index(st.get("box", "light")) + 1) % len(keys)]
    elif act == "topic":
        keys = list(TOPICS)
        st["topic"] = keys[(keys.index(st.get("topic", "q")) + 1) % len(keys)]
        st["text"] = ""
    else:
        return await cb.answer()
    await save_style(uid, st)
    await cb.answer()
    png, cap = await _render(bot, uid, st)
    try:
        await cb.message.edit_media(InputMediaPhoto(media=BufferedInputFile(png, "story.png"), caption=cap),
                                    reply_markup=_editor_kb(st))
    except TelegramBadRequest as e:
        log.info("story edit: %s", e)


def story_input(m: Message) -> bool:
    k = _story_in.get(m.from_user.id) if m.from_user else None
    return bool(k and m.chat.type == "private" and ((k == "photo" and m.photo)
                                                    or (k == "text" and m.text and not m.text.startswith("/"))))


@router.message(story_input)
async def on_story_input(m: Message, bot: Bot):
    uid = m.from_user.id
    kind = _story_in.pop(uid)
    st = await story_style(uid)
    if kind == "photo":
        await db.kv_set(f"an:sphoto:{uid}", m.photo[-1].file_id)
        st["bg"] = "photo"
    else:
        st["text"] = "" if m.text.strip() == "-" else m.text.strip()[:120]
    await save_style(uid, st)
    await drop_prompt(bot, uid)
    await send_editor(m, bot, uid)


@router.callback_query(F.data.startswith("an:ac:"))
async def cb_answer_card(cb: CallbackQuery, bot: Bot):
    import asyncio
    from aiogram.types import BufferedInputFile
    from handlers import anoncards
    r = await _msg(cb)
    if not r:
        return
    await cb.answer("рисую…")
    me = await bot.me()
    st = await story_style(cb.from_user.id)
    photo = await _photo_bytes(bot, cb.from_user.id) if st.get("bg") == "photo" else None
    png = await asyncio.to_thread(anoncards.answer_card, r.get("qtext") or "", r.get("atext") or "",
                                  me.username or "", 1, st, photo)
    code = await ensure_link(cb.from_user.id)
    await cb.message.answer_photo(BufferedInputFile(png, "answer.png"),
                                  caption=f"🖼 в твоём стиле сторис · ссылка:\n"
                                          f"<code>https://t.me/{me.username}?start=a_{code}</code>",
                                  reply_markup=kb_rows([("🎨 Изменить стиль", "an:cards")]))


# ================= 📥 входящие — по маскам =================
async def inbox_view(uid: int):
    """Волна 47: входящие — список масок кнопками по две, без простыней."""
    rows = await db.q_all("SELECT mask_id, COUNT(*) n, SUM(seen=0 AND answered=0) waiting, MAX(id) last FROM anon_msgs "
                          "WHERE to_uid=? AND mask_id>0 GROUP BY mask_id ORDER BY last DESC LIMIT 12", uid)
    back = [("‹ Назад", "an:back")]
    if not rows:
        return ("📥 <b>Входящие</b>\n" + ui.hint("пусто — кинь ссылку в сторис, вопросы придут сюда"),
                kb_rows(back))
    btns, wait_n = [], 0
    for r in rows:
        mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", r["mask_id"])
        if not mk:
            continue
        wait_n += r["waiting"] or 0
        mark = (f" · {r['waiting']}" if r["waiting"] else "") + ("" if mk["active"] else " 💤")
        btns.append((mk["mask"] + mark, f"an:th:{mk['id']}", "success" if r["waiting"] else None))
    text = ("📥 <b>Входящие</b>\n" + ui.hint((f"🔵 новых: {wait_n} · " if wait_n else "все прочитаны · ")
                                             + "💤 — маска сгорела, вы давно не общались"))
    extra = [("✅ Прочитать всё", "an:sall", "primary")] if wait_n else []
    return text, kb_rows(*[btns[i:i + 2] for i in range(0, len(btns), 2)], extra, back)


async def _mask_by_id(cb: CallbackQuery) -> dict | None:
    mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=? AND owner=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not mk:
        await cb.answer("не нашла", show_alert=True)
    return mk


@router.callback_query(F.data.startswith("an:th:"))
async def cb_thread(cb: CallbackQuery):
    """Волна 47: переписка с маской — как чат, правкой того же сообщения."""
    mk = await _mask_by_id(cb)
    if not mk:
        return
    rows = await db.q_all("SELECT * FROM anon_msgs WHERE to_uid=? AND mask_id=? ORDER BY id DESC LIMIT 8",
                          cb.from_user.id, mk["id"])
    await db.q_run("UPDATE anon_msgs SET seen=1 WHERE to_uid=? AND mask_id=?", cb.from_user.id, mk["id"])
    icon = mk["mask"].split()[0]
    parts = [f"<b>{escape(mask_name(mk))}</b>"]
    for r in reversed(rows):
        parts.append(f"<blockquote>{icon} {escape((r.get('qtext') or '📎 медиа')[:200])}</blockquote>")
        if r["answered"]:
            parts.append(f"↩️ <i>{escape((r.get('atext') or '📎 медиа')[:200])}</i>")
    last_wait = next((r for r in rows if not r["answered"]), None)
    kb = []
    if last_wait:
        kb.append([("↩️ Ответить", f"an:re:{last_wait['id']}", "success")])
    kb.append([("✏️ Подпись", f"an:lb:{mk['id']}"), ("🚫 Блок", f"an:bm:{mk['id']}", "danger")])
    kb.append([("‹ Входящие", "an:inbox")])
    await show(cb, "\n".join(parts)[:4000], kb_rows(*kb))


# ================= волна 48: раскрыться можно только самому — по своему желанию =================
@router.callback_query(F.data.startswith("an:rv:"))
async def cb_reveal_ask(cb: CallbackQuery):
    mid = int(cb.data.split(":")[2])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND from_uid=?", mid, cb.from_user.id)
    if not r:
        return await cb.answer("не нашла", show_alert=True)
    await cb.answer()
    await cb.message.reply(f"🙋 точно раскрыться? {escape(await name_of(r['to_uid']))} увидит твоё имя и профиль. "
                           "отменить будет нельзя",
                           reply_markup=kb_rows([("🙋 Да, раскрыться", f"an:rvy:{mid}", "danger"), ("✖️ Нет", "an:cancel")]))


@router.callback_query(F.data.startswith("an:rvy:"))
async def cb_reveal(cb: CallbackQuery, bot: Bot):
    mid = int(cb.data.split(":")[2])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND from_uid=?", mid, cb.from_user.id)
    if not r:
        return await cb.answer("не нашла", show_alert=True)
    mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", r.get("mask_id") or 0)
    name = cb.from_user.first_name or "аноним"
    if mk:
        await db.q_run("UPDATE anon_masks2 SET label=? WHERE id=?", name[:30], mk["id"])
    who = escape(mk["mask"]) if mk else "аноним"
    try:
        await bot.send_message(r["to_uid"], f"🙋 {who} раскрылся(ась) сам(а): это "
                                            f'<a href="tg://user?id={cb.from_user.id}">{escape(name)}</a>',
                               reply_to_message_id=r.get("dlv_mid") or None, allow_sending_without_reply=True)
    except Exception as e:
        log.info("reveal: %s", e)
    await cb.answer("🙋 готово — теперь он(а) знает, что это ты", show_alert=True)
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("an:sn:"))
async def cb_seen(cb: CallbackQuery):
    """Волна 48: «👁 Прочитано» — без ответа, просто отметить."""
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("UPDATE anon_msgs SET seen=1 WHERE id=?", r["id"])
    await cb.answer("👁 прочитано")
    try:
        await cb.message.edit_reply_markup(reply_markup=_kb_for_owner(r["id"], seen=True))
    except TelegramBadRequest:
        pass


@router.callback_query(F.data == "an:sall")
async def cb_seen_all(cb: CallbackQuery):
    n = await db.q_run("UPDATE anon_msgs SET seen=1 WHERE to_uid=? AND seen=0", cb.from_user.id)
    await show(cb, *await inbox_view(cb.from_user.id))


@router.callback_query(F.data == "noop")
async def cb_noop(cb: CallbackQuery):
    await cb.answer()


@router.callback_query(F.data.startswith("an:lb:"))
async def cb_label(cb: CallbackQuery):
    mk = await _mask_by_id(cb)
    if not mk:
        return
    _labeling[cb.from_user.id] = mk["id"]
    await cb.answer()
    await cb.message.answer(f"✏️ как подписать {escape(mk['mask'])}? например: «тот, с работы». "
                            "подпись видишь только ты. «-» — убрать", reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))


def labeling(m: Message) -> bool:
    return bool(m.from_user and m.from_user.id in _labeling and m.chat.type == "private" and m.text
                and not m.text.startswith("/"))


@router.message(labeling)
async def on_label(m: Message):
    mid = _labeling.pop(m.from_user.id)
    label = "" if m.text.strip() == "-" else m.text.strip()[:30]
    await db.q_run("UPDATE anon_masks2 SET label=? WHERE id=? AND owner=?", label, mid, m.from_user.id)
    mk = await db.q_one("SELECT * FROM anon_masks2 WHERE id=?", mid)
    await m.answer(f"✅ теперь это {escape(mask_name(mk))}" if label else f"✅ подпись убрана: {escape(mk['mask'])}")


@router.callback_query(F.data.startswith("an:bm:"))
async def cb_block_mask(cb: CallbackQuery):
    mk = await _mask_by_id(cb)
    if not mk:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, mk["sender"], int(time.time()))
    await cb.answer(f"🚫 {mk['mask']} больше не сможет тебе писать", show_alert=True)


@router.message(Command("inbox", "входящие"))
async def cmd_inbox(m: Message):
    text, kb = await inbox_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "an:inbox")
async def cb_inbox(cb: CallbackQuery):
    await show(cb, *await inbox_view(cb.from_user.id))
