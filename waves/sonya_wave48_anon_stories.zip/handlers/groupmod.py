"""Группы: модерация (капча, антифлуд, антиссылки, варны/мут/бан), «что я пропустил», перевод."""
import asyncio
import logging
import re
import time
from collections import defaultdict, deque
from html import escape

from aiogram import Router, F, Bot, BaseMiddleware
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, ChatPermissions
from aiogram.exceptions import TelegramBadRequest

import config
import db
import llm
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("groupmod")
GROUPS = {"group", "supergroup"}
_admins: dict[int, tuple[float, set[int]]] = {}
_flood: dict[tuple[int, int], deque] = defaultdict(lambda: deque(maxlen=8))
_captcha: dict[tuple[int, int], int] = {}   # (chat, uid) → message_id
_sum_cd: dict[int, float] = {}
CAPTCHA_SEC = 120
FLOOD_N, FLOOD_SEC, FLOOD_MUTE = 6, 10, 300
WARN_LIMIT = 3
LINK_RE = re.compile(r"(https?://|t\.me/|www\.)", re.I)
NO_RIGHTS = ChatPermissions(can_send_messages=False)
ALL_RIGHTS = ChatPermissions(can_send_messages=True, can_send_audios=True, can_send_documents=True,
                             can_send_photos=True, can_send_videos=True, can_send_video_notes=True,
                             can_send_voice_notes=True, can_send_polls=True, can_send_other_messages=True,
                             can_add_web_page_previews=True, can_invite_users=True)


async def admins_of(bot: Bot, chat_id: int) -> set[int]:
    cached = _admins.get(chat_id)
    if cached and time.time() - cached[0] < 600:
        return cached[1]
    try:
        ids = {a.user.id for a in await bot.get_chat_administrators(chat_id)}
    except TelegramBadRequest:
        ids = set()
    _admins[chat_id] = (time.time(), ids)
    return ids


async def is_admin(bot: Bot, chat_id: int, uid: int) -> bool:
    return uid == config.OWNER_ID or uid in await admins_of(bot, chat_id)


async def _tmp_reply(m: Message, text: str, sec: int = 15):
    try:
        r = await m.answer(text)
    except TelegramBadRequest:
        return
    await asyncio.sleep(sec)
    try:
        await r.delete()
    except TelegramBadRequest:
        pass


# ================= страж группы (до всех хендлеров) =================
class GroupGuard(BaseMiddleware):
    async def __call__(self, handler, event, data):
        if not isinstance(event, Message) or event.chat.type not in GROUPS or not event.from_user \
                or event.from_user.is_bot:
            return await handler(event, data)
        bot: Bot = data["bot"]
        chat_id, uid = event.chat.id, event.from_user.id
        text = event.text or event.caption or ""
        # антифлуд
        if await db.chat_flag(chat_id, "antiflood") and not await is_admin(bot, chat_id, uid):
            q = _flood[(chat_id, uid)]
            q.append(time.time())
            if len(q) >= FLOOD_N and q[-1] - q[-FLOOD_N] < FLOOD_SEC:
                q.clear()
                try:
                    await bot.restrict_chat_member(chat_id, uid, NO_RIGHTS, until_date=int(time.time()) + FLOOD_MUTE)
                    asyncio.create_task(_tmp_reply(event, f"🤐 {escape(event.from_user.first_name)}, не флуди — "
                                                          f"помолчи {FLOOD_MUTE // 60} мин"))
                except TelegramBadRequest:
                    pass
                return
        # антиссылки
        has_link = bool(LINK_RE.search(text)) or any(e.type in ("url", "text_link") for e in
                                                      (event.entities or event.caption_entities or []))
        if has_link and await db.chat_flag(chat_id, "antilink") and not await is_admin(bot, chat_id, uid):
            try:
                await event.delete()
                asyncio.create_task(_tmp_reply(event, f"🔗 {escape(event.from_user.first_name)}, ссылки тут "
                                                      "только у админов", 10))
            except TelegramBadRequest:
                pass
            return
        # волна 45: антимат
        if text and await db.chat_flag(chat_id, "antimat") and not await is_admin(bot, chat_id, uid):
            import profanity
            if profanity.has_mat(text):
                try:
                    await event.delete()
                    asyncio.create_task(_tmp_reply(event, f"🤬 {escape(event.from_user.first_name)}, давай без мата 🙏",
                                                   10))
                except TelegramBadRequest:
                    pass
                return
        # лог для «что я пропустил»
        if text and not text.startswith("/") and await db.chat_flag(chat_id, "ai_on"):
            await db.log_group(chat_id, event.from_user.first_name or "аноним", text)
        return await handler(event, data)


# ================= капча =================
async def captcha_on(m: Message) -> bool:
    return m.chat.type in GROUPS and bool(m.new_chat_members) and await db.chat_flag(m.chat.id, "captcha")


@router.message(captcha_on)
async def on_join_captcha(m: Message, bot: Bot):
    me = await bot.me()
    for u in m.new_chat_members:
        if u.is_bot or u.id == me.id:
            continue
        try:
            await bot.restrict_chat_member(m.chat.id, u.id, NO_RIGHTS)
        except TelegramBadRequest as e:
            log.info("captcha restrict: %s", e)
            return await m.answer("🛡 капча включена, но мне нужны права админа «блокировать пользователей»")
        msg = await m.answer(f"👋 <a href=\"tg://user?id={u.id}\">{escape(u.first_name)}</a>, нажми кнопку, "
                             f"что ты не бот — у тебя {CAPTCHA_SEC // 60} мин",
                             reply_markup=kb_rows([("✅ Я человек", f"cap:{u.id}")]))
        _captcha[(m.chat.id, u.id)] = msg.message_id
        asyncio.create_task(_captcha_timeout(bot, m.chat.id, u.id, msg.message_id))


async def _captcha_timeout(bot: Bot, chat_id: int, uid: int, msg_id: int):
    await asyncio.sleep(CAPTCHA_SEC)
    if _captcha.pop((chat_id, uid), None) is None:
        return
    try:
        await bot.ban_chat_member(chat_id, uid, until_date=int(time.time()) + 60)  # кик: бан на минуту
        await bot.unban_chat_member(chat_id, uid, only_if_banned=True)
    except TelegramBadRequest:
        pass
    try:
        await bot.delete_message(chat_id, msg_id)
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("cap:"))
async def cb_captcha(cb: CallbackQuery, bot: Bot):
    uid = int(cb.data[4:])
    if cb.from_user.id != uid:
        return await cb.answer("это не твоя кнопка 🙃", show_alert=True)
    chat_id = cb.message.chat.id
    _captcha.pop((chat_id, uid), None)
    try:
        chat = await bot.get_chat(chat_id)
        await bot.restrict_chat_member(chat_id, uid, chat.permissions or ALL_RIGHTS)
    except TelegramBadRequest:
        pass
    await cb.answer("добро пожаловать 🖤")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass
    if await db.chat_flag(chat_id, "greet"):
        await cb.message.answer(f"👋 {escape(cb.from_user.first_name)} с нами, привет!")


# ================= команды модерации =================
def parse_dur(s: str | None, default: int) -> int:
    m = re.fullmatch(r"\s*(\d+)\s*([мmчhдd])?\w*\s*", s or "")
    if not m:
        return default
    n, u = int(m.group(1)), (m.group(2) or "м").lower()
    return n * (86400 if u in "дd" else 3600 if u in "чh" else 60)


def _human(sec: int) -> str:
    return f"{sec // 86400} д" if sec >= 86400 else f"{sec // 3600} ч" if sec >= 3600 else f"{sec // 60} мин"


async def _mod_target(m: Message, bot: Bot):
    if m.chat.type not in GROUPS:
        return None
    if not await is_admin(bot, m.chat.id, m.from_user.id):
        await m.reply("это только для админов")
        return None
    if not m.reply_to_message or not m.reply_to_message.from_user:
        await m.reply("ответь командой на сообщение нарушителя")
        return None
    u = m.reply_to_message.from_user
    if await is_admin(bot, m.chat.id, u.id) or u.is_bot:
        await m.reply("админов и ботов не трогаю 🙃")
        return None
    return u


@router.message(Command("mute"))
async def cmd_mute(m: Message, bot: Bot, command: CommandObject):
    u = await _mod_target(m, bot)
    if not u:
        return
    sec = parse_dur(command.args, 3600)
    try:
        await bot.restrict_chat_member(m.chat.id, u.id, NO_RIGHTS, until_date=int(time.time()) + sec)
        await m.reply(f"🤐 {escape(u.first_name)} молчит {_human(sec)}")
    except TelegramBadRequest as e:
        await m.reply(f"не вышло: дай мне права «блокировать пользователей» ({escape(str(e)[:60])})")


@router.message(Command("unmute"))
async def cmd_unmute(m: Message, bot: Bot):
    u = await _mod_target(m, bot)
    if not u:
        return
    try:
        chat = await bot.get_chat(m.chat.id)
        await bot.restrict_chat_member(m.chat.id, u.id, chat.permissions or ALL_RIGHTS)
        await m.reply(f"🗣 {escape(u.first_name)} снова может говорить")
    except TelegramBadRequest as e:
        await m.reply(f"не вышло: {escape(str(e)[:80])}")


@router.message(Command("warn"))
async def cmd_warn(m: Message, bot: Bot):
    u = await _mod_target(m, bot)
    if not u:
        return
    await db.q_run("INSERT INTO warns VALUES(?,?,1) ON CONFLICT(chat_id,uid) DO UPDATE SET n=n+1", m.chat.id, u.id)
    n = (await db.q_one("SELECT n FROM warns WHERE chat_id=? AND uid=?", m.chat.id, u.id))["n"]
    if n >= WARN_LIMIT:
        await db.q_run("DELETE FROM warns WHERE chat_id=? AND uid=?", m.chat.id, u.id)
        try:
            await bot.restrict_chat_member(m.chat.id, u.id, NO_RIGHTS, until_date=int(time.time()) + 86400)
            return await m.reply(f"⚠️ {escape(u.first_name)}: {WARN_LIMIT}/{WARN_LIMIT} — мут на сутки")
        except TelegramBadRequest:
            return await m.reply(f"⚠️ {WARN_LIMIT}/{WARN_LIMIT}, но замутить не могу — нет прав")
    await m.reply(f"⚠️ {escape(u.first_name)}: предупреждение {n}/{WARN_LIMIT}")


@router.message(Command("unwarn"))
async def cmd_unwarn(m: Message, bot: Bot):
    u = await _mod_target(m, bot)
    if u:
        await db.q_run("DELETE FROM warns WHERE chat_id=? AND uid=?", m.chat.id, u.id)
        await m.reply(f"✨ {escape(u.first_name)}: предупреждения сняты")


@router.message(Command("ban", "kick"), F.chat.type.in_(GROUPS))
async def cmd_ban(m: Message, bot: Bot):
    u = await _mod_target(m, bot)
    if not u:
        return
    kick = m.text.split()[0].lstrip("/").split("@")[0] == "kick"
    try:
        await bot.ban_chat_member(m.chat.id, u.id)
        if kick:
            await bot.unban_chat_member(m.chat.id, u.id, only_if_banned=True)
        await m.reply(f"{'👢 выгнала' if kick else '🚫 забанила'} {escape(u.first_name)}")
    except TelegramBadRequest as e:
        await m.reply(f"не вышло: {escape(str(e)[:80])}")


# ================= «что я пропустил» =================
SUMMARY_SYS = ("Ты Соня. Кратко перескажи, о чём говорили в чате: 4–7 пунктов, с именами, "
               "живо и с лёгкой иронией, по-русски. Без вступлений.")


async def summarize(rows: list[dict], system: str = SUMMARY_SYS) -> str:
    log_text = "\n".join(f"{r['name']}: {r['text']}" for r in rows)[-12000:]
    return await llm.ask([{"role": "system", "content": system}, {"role": "user", "content": log_text}],
                         max_tokens=900, temperature=0.6, feature="summary")


async def summary(m: Message):
    if m.chat.type not in GROUPS:
        return await m.reply("сводка работает в группах 🙂")
    left = 60 - (time.time() - _sum_cd.get(m.chat.id, 0))
    if left > 0:
        return await m.reply(f"сводку делала только что, подожди {int(left)} с")
    rows = await db.q_all("SELECT name, text FROM chat_log WHERE chat_id=? ORDER BY id DESC LIMIT 150", m.chat.id)
    if len(rows) < 5:
        return await m.reply("тут почти ничего не писали 🤷")
    _sum_cd[m.chat.id] = time.time()
    try:
        out = await summarize(list(reversed(rows)))
    except Exception as e:
        return await m.reply(f"😕 ии не ответил: {escape(str(e)[:80])}")
    await m.reply(f"🧾 <b>что вы пропустили</b>\n\n{escape(out)}")


@router.message(Command("summary", "сводка"))
async def cmd_summary(m: Message):
    await summary(m)


# ================= перевод =================
async def translate(m: Message, target_msg: Message | None):
    t = target_msg and (target_msg.text or target_msg.caption)
    if not t:
        return await m.reply("ответь <b>/tr</b> на сообщение — переведу")
    cyr = len(re.findall(r"[а-яё]", t, re.I)) / max(1, len(re.findall(r"\w", t)))
    lang = "английский" if cyr > 0.5 else "русский"
    try:
        out = await llm.ask([{"role": "system", "content": f"Переведи на {lang} язык естественно. Только перевод."},
                             {"role": "user", "content": t[:3500]}], max_tokens=1200, temperature=0.3)
    except Exception as e:
        return await m.reply(f"😕 не перевелось: {escape(str(e)[:80])}")
    await (target_msg or m).reply(f"🌍 {escape(out)}")


@router.message(Command("tr", "translate", "перевод"))
async def cmd_tr(m: Message):
    await translate(m, m.reply_to_message)
