"""Волна 44: 🧩 стикеры и эмодзи-паки из картинок (BOT_PROFILE=stk).
Кидаешь картинку — она становится стикером или эмодзи в твоём паке. Паки создаёт сам бот (Bot API),
имя пака кончается на _by_<бот>. Бесплатно: 1 пак, 30 штук, только картинки, в названии — подпись бота.
С Соней+: паков без лимита, до предела Telegram, видео-стикеры и эмодзи из GIF/видео, чистое название."""
import asyncio
import io
import logging
import os
import secrets
import shutil
import time
import unicodedata
import uuid
from collections import defaultdict
from html import escape
from urllib.parse import quote as quote_url

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile, InputSticker

import config
import db
import premium
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("stickers")
TG_MAX = {"emoji": 200, "sticker": 120}          # предел Telegram на пак
KIND_ICON = {"emoji": "🧩", "sticker": "🖼"}
KIND_NAME = {"emoji": "эмодзи", "sticker": "стикеров"}
DEFAULT_EMOJI = "✨"
VIDEO_LIMIT = {"emoji": 64 * 1024, "sticker": 256 * 1024}
_locks: dict[int, asyncio.Lock] = defaultdict(asyncio.Lock)
_pending: dict[int, Message] = {}                 # картинка, пришедшая до выбора типа пака
_del: dict[str, tuple[int, str, int]] = {}        # токен → (uid, file_id стикера, id пака)
_msgs: dict[str, Message] = {}                    # токен → сообщение (чужой стикер / текст для цитаты)


def _keep(m: Message) -> str:
    tok = secrets.token_hex(5)
    if len(_msgs) > 500:
        _msgs.pop(next(iter(_msgs)))
    _msgs[tok] = m
    return tok


# ================= база =================
async def packs_of(uid: int) -> list[dict]:
    return await db.q_all("SELECT * FROM sticker_packs WHERE uid=? ORDER BY id", uid)


async def current(uid: int) -> dict | None:
    pid = await db.kv_get(f"stk:cur:{uid}")
    if not pid:
        return None
    return await db.q_one("SELECT * FROM sticker_packs WHERE id=? AND uid=?", int(pid), uid)


def pack_url(p: dict) -> str:
    return f"https://t.me/{'addemoji' if p['kind'] == 'emoji' else 'addstickers'}/{p['name']}"


async def full_title(bot: Bot, uid: int, title: str) -> str:
    """Без Сони+ в названии пака — подпись бота: паки ходят по рукам и приводят людей."""
    if premium.plus(uid):
        return title[:64]
    me = await bot.me()
    tail = f" · @{me.username}"
    return title[:64 - len(tail)] + tail


def pick_emoji(text: str | None) -> str:
    for ch in text or "":
        if ord(ch) > 0x2000 and unicodedata.category(ch) in ("So", "Sk"):
            return ch
    return DEFAULT_EMOJI


# ================= картинки и видео =================
def cut_bg(im):
    """Волна 45: однотонный фон → прозрачный (заливка от углов) + белая обводка, как у вырезанной наклейки.
    Если вырезалось подозрительно мало или почти всё — оставляем как было. Возвращает (картинка, вырезали?)."""
    from PIL import Image, ImageDraw, ImageFilter
    im = im.convert("RGBA")
    im.thumbnail((480, 480), Image.LANCZOS)            # заливка на питоне — сначала уменьшаем
    pad = 16
    work = Image.new("RGBA", (im.width + 2 * pad, im.height + 2 * pad), (0, 0, 0, 0))
    inner = im.copy()
    w, h = inner.size
    for xy in ((0, 0), (w - 1, 0), (0, h - 1), (w - 1, h - 1)):
        if inner.getpixel(xy)[3] > 0:
            ImageDraw.floodfill(inner, xy, (0, 0, 0, 0), thresh=40)
    gone = inner.getchannel("A").histogram()[0] / (w * h)
    if gone < 0.03 or gone > 0.92:
        return im, False
    work.paste(inner, (pad, pad))
    alpha = work.getchannel("A").point(lambda a: 255 if a > 20 else 0)
    ring = alpha.filter(ImageFilter.MaxFilter(11))
    out = Image.new("RGBA", work.size, (255, 255, 255, 0))
    out.paste(Image.new("RGBA", work.size, (255, 255, 255, 255)), (0, 0), ring)
    out.alpha_composite(work)
    return out, True


def to_png(data: bytes, kind: str, cut: bool = False) -> bytes:
    """Статичный стикер: сторона 512 (эмодзи — ровно 100×100 с прозрачными полями), PNG до 512 КБ."""
    from PIL import Image, ImageOps
    im = ImageOps.exif_transpose(Image.open(io.BytesIO(data))).convert("RGBA")
    if cut:
        im, _ = cut_bg(im)
    if kind == "emoji":
        im.thumbnail((100, 100), Image.LANCZOS)
        canvas = Image.new("RGBA", (100, 100), (0, 0, 0, 0))
        canvas.paste(im, ((100 - im.width) // 2, (100 - im.height) // 2))
        im = canvas
    else:
        k = 512 / max(im.width, im.height)
        im = im.resize((max(1, round(im.width * k)), max(1, round(im.height * k))), Image.LANCZOS)
    out = io.BytesIO()
    im.save(out, "PNG", optimize=True)
    if out.tell() > 512 * 1024:
        out = io.BytesIO()
        im.save(out, "WEBP", quality=85)
    return out.getvalue()


async def to_webm(src: str, kind: str) -> bytes:
    """Видео-стикер: WEBM VP9, до 3 с, 30 к/с, без звука, сторона 512 (эмодзи 100×100), в лимит по размеру."""
    if not shutil.which("ffmpeg"):
        raise RuntimeError("на сервере нет ffmpeg")
    side = 100 if kind == "emoji" else 512
    vf = f"scale={side}:{side}:force_original_aspect_ratio=decrease,fps=30"
    if kind == "emoji":
        vf += f",pad={side}:{side}:(ow-iw)/2:(oh-ih)/2:color=black@0"
    out = src + ".webm"
    try:
        for br in (("200k", "100k", "50k") if kind == "emoji" else ("600k", "300k", "150k")):
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-loglevel", "error", "-i", src, "-t", "3", "-an", "-vf", vf,
                "-c:v", "libvpx-vp9", "-b:v", br, "-pix_fmt", "yuva420p", "-f", "webm", out,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
            try:
                await asyncio.wait_for(proc.wait(), 120)
            except asyncio.TimeoutError:
                proc.kill()
                raise RuntimeError("видео слишком долго перекодируется")
            if proc.returncode != 0:
                raise RuntimeError("не смогла перекодировать видео")
            if os.path.getsize(out) <= VIDEO_LIMIT[kind]:
                with open(out, "rb") as f:
                    return f.read()
        raise RuntimeError("видео не влезает в лимит Telegram — попробуй короче или проще")
    finally:
        for p in (src, out):
            try:
                os.unlink(p)
            except OSError:
                pass


def media_of(m: Message) -> tuple[str, object] | None:
    """('image'|'video'|'text', объект с file_id) или None."""
    if m.text and not m.text.startswith("/"):
        return "text", None
    if m.photo:
        return "image", m.photo[-1]
    if m.sticker:
        if m.sticker.is_animated:
            return None
        return ("video" if m.sticker.is_video else "image"), m.sticker
    if m.animation:
        return "video", m.animation
    if m.video:
        return "video", m.video
    if m.document and (m.document.mime_type or "").startswith("image/"):
        return "image", m.document
    if m.document and (m.document.mime_type or "").startswith("video/"):
        return "video", m.document
    return None


async def build(bot: Bot, m: Message, kind: str) -> InputSticker:
    what, obj = media_of(m)
    cut = bool(await db.kv_get(f"stk:cut:{m.from_user.id}"))
    if what == "text":   # волна 45: текст → стикер-цитата
        if kind == "emoji":
            raise RuntimeError("текст-стикеры делаю в паке стикеров, в эмодзи 100×100 текст не прочитать — /new")
        from handlers import tools
        quote = await asyncio.to_thread(tools.quote_image, m.text[:300], m.from_user.first_name or "я", None)
        data = await asyncio.to_thread(to_png, quote, kind)
        return InputSticker(sticker=BufferedInputFile(data, "s.png"), format="static", emoji_list=["💬"])
    if (getattr(obj, "file_size", 0) or 0) > config.TG_GET_MAX:
        raise RuntimeError(f"файл больше {config.mb(config.TG_GET_MAX)}")
    emoji = pick_emoji(m.caption) if not m.sticker else (m.sticker.emoji or DEFAULT_EMOJI)
    if what == "image":
        buf = io.BytesIO()
        await bot.download(obj.file_id, destination=buf)
        data = await asyncio.to_thread(to_png, buf.getvalue(), kind, cut and not m.sticker)
        return InputSticker(sticker=BufferedInputFile(data, "s.png"), format="static", emoji_list=[emoji])
    from autopost import media_dl
    media_dl._dir()
    src = str(media_dl.DL / uuid.uuid4().hex)
    await bot.download(obj.file_id, destination=src)
    data = await to_webm(src, kind)
    return InputSticker(sticker=BufferedInputFile(data, "s.webm"), format="video", emoji_list=[emoji])


# ================= добавление =================
async def _limit(m: Message, uid: int, feat: str):
    await premium.upsell(m, uid, feat)


async def add_media(m: Message, bot: Bot, kind_for_new: str | None = None):
    uid = m.from_user.id
    what = media_of(m)
    if not what:
        return await m.reply("анимированные стикеры (.tgs) не умею — пришли картинку, GIF или видео")
    if what[0] == "video" and not premium.plus(uid):
        return await _limit(m, uid, "stk_video")
    async with _locks[uid]:
        p = None if kind_for_new else await current(uid)
        if not p:
            kind = kind_for_new or await db.kv_get(f"stk:want:{uid}")
            if not kind:
                _pending[uid] = m
                return await m.reply("что делаем из этой картинки?",
                                     reply_markup=kb_rows([("🧩 Пак эмодзи", "stk:new:emoji"),
                                                           ("🖼 Пак стикеров", "stk:new:sticker")]))
            return await _create(m, bot, uid, kind)
        if p["n"] >= TG_MAX[p["kind"]]:
            return await m.reply(f"в паке уже {p['n']} — это предел Telegram. начни новый: /new")
        if p["n"] >= premium.COUNT["stk_items"] and not premium.plus(uid):
            return await _limit(m, uid, "stk_items")
        st = await m.reply("⏳ делаю…")
        try:
            sticker = await build(bot, m, p["kind"])
            await bot.add_sticker_to_set(user_id=uid, name=p["name"], sticker=sticker)
        except (TelegramBadRequest, RuntimeError) as e:
            return await st.edit_text(f"😕 не вышло: {escape(str(e)[:150])}")
        await db.q_run("UPDATE sticker_packs SET n=n+1 WHERE id=?", p["id"])
        await st.edit_text(f"✅ добавила в «{escape(p['title'])}» — теперь {p['n'] + 1}",
                           reply_markup=kb_rows([(f"{KIND_ICON[p['kind']]} Открыть пак", pack_url(p))]))


async def _create(m: Message, bot: Bot, uid: int, kind: str):
    if len(await packs_of(uid)) >= premium.COUNT["stk_packs"] and not premium.plus(uid):
        return await _limit(m, uid, "stk_packs")
    me = await bot.me()
    name = f"s{uid}_{secrets.token_hex(3)}_by_{me.username}"
    title = f"{m.from_user.first_name or 'мои'} — {'эмодзи' if kind == 'emoji' else 'стикеры'}"
    st = await m.reply("⏳ создаю пак…")
    try:
        sticker = await build(bot, m, kind)
        await bot.create_new_sticker_set(user_id=uid, name=name, title=await full_title(bot, uid, title),
                                         stickers=[sticker],
                                         sticker_type="custom_emoji" if kind == "emoji" else "regular")
    except (TelegramBadRequest, RuntimeError) as e:
        return await st.edit_text(f"😕 не вышло создать пак: {escape(str(e)[:150])}")
    pid = await db.q_run("INSERT INTO sticker_packs(uid, name, title, kind, n, ts) VALUES(?,?,?,?,1,?)",
                            uid, name, title, kind, int(time.time()))
    await db.kv_set(f"stk:cur:{uid}", str(pid))
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:want:{uid}")
    note = ("\n" + ui.hint("эмодзи из пака видят все, а ставить их в сообщения могут владельцы Telegram Premium")
            if kind == "emoji" else "")
    url = pack_url({'kind': kind, 'name': name})
    share = "https://t.me/share/url?url=" + quote_url(url) + "&text=" + quote_url("смотри, какой пак я сделал 😏")
    await st.edit_text(f"🎉 пак готов! присылай ещё картинки — добавлю туда же{note}",
                       reply_markup=kb_rows([(f"{KIND_ICON[kind]} Открыть пак", url), ("📤 Поделиться", share)],
                                            [("✏️ Название", f"stk:ren:{pid}"), ("📦 Мои паки", "stk:list")]))


# ================= свой стикер/эмодзи — удалить =================
async def _own(uid: int, set_name: str | None) -> dict | None:
    if not set_name:
        return None
    return await db.q_one("SELECT * FROM sticker_packs WHERE uid=? AND name=?", uid, set_name)


async def offer_delete(m: Message, uid: int, file_id: str, p: dict):
    tok = secrets.token_hex(5)
    _del[tok] = (uid, file_id, p["id"])
    await m.reply(f"это из твоего пака «{escape(p['title'])}». убрать его оттуда?",
                  reply_markup=kb_rows([("🗑 Удалить из пака", f"stk:rm:{tok}")]))


@router.message(F.chat.type == "private", F.sticker)
async def on_sticker(m: Message, bot: Bot):
    p = await _own(m.from_user.id, m.sticker.set_name)
    if p:
        return await offer_delete(m, m.from_user.id, m.sticker.file_id, p)
    tok = _keep(m)   # волна 45: чужой стикер — в свой пак или скачать картинкой
    rows = [("➕ В мой пак", f"stk:add:{tok}")]
    if not m.sticker.is_animated:
        rows.append(("📥 Скачать", f"stk:png:{tok}"))
    await m.reply("что делаем с этим стикером?", reply_markup=kb_rows(rows))


@router.callback_query(F.data.startswith("stk:add:"))
async def cb_add(cb: CallbackQuery, bot: Bot):
    m = _msgs.pop(cb.data.split(":")[2], None)
    if not m or m.from_user.id != cb.from_user.id:
        return await cb.answer("кнопка устарела — пришли ещё раз", show_alert=True)
    await cb.answer()
    await add_media(m, bot)


@router.callback_query(F.data.startswith("stk:png:"))
async def cb_png(cb: CallbackQuery, bot: Bot):
    m = _msgs.get(cb.data.split(":")[2])
    if not m or not m.sticker:
        return await cb.answer("кнопка устарела — пришли стикер ещё раз", show_alert=True)
    await cb.answer("качаю…")
    buf = io.BytesIO()
    await bot.download(m.sticker.file_id, destination=buf)
    if m.sticker.is_video:
        return await cb.message.answer_document(BufferedInputFile(buf.getvalue(), "sticker.webm"))

    def _conv(raw: bytes) -> bytes:
        from PIL import Image
        out = io.BytesIO()
        Image.open(io.BytesIO(raw)).save(out, "PNG")
        return out.getvalue()
    try:
        png = await asyncio.to_thread(_conv, buf.getvalue())
    except Exception:
        return await cb.message.answer("😕 не смогла открыть этот стикер")
    await cb.message.answer_document(BufferedInputFile(png, "sticker.png"), caption="📥 держи — с прозрачным фоном")


@router.message(F.chat.type == "private", F.photo | F.animation | F.video | F.document)
async def on_media(m: Message, bot: Bot):
    await add_media(m, bot)


# ================= команды и кнопки =================
async def start_screen(m: Message, uid: int):
    """Волна 47: коротко. Подробности — один раз, при первом заходе (кнопка «❔ Что умею» — всегда)."""
    from handlers import anon
    p = await current(uid)
    text = "🧩 <b>Стикеры и эмодзи</b>\n" + ui.hint("кидай картинку, GIF или текст — сделаю стикер")
    if p:
        text += f"\n📌 добавляю в <b>{escape(p['title'])}</b> · {p['n']}"
    if await anon.first_time(uid, "stk_intro"):
        text += "\n" + HELP_TEXT
    await m.answer(text, reply_markup=await start_kb(uid))


HELP_TEXT = ui.quote("1. выбери пак: эмодзи или стикеры\n2. кидай картинки — каждая станет стикером\n"
                     "3. открой пак по ссылке и добавь себе 🎉\n"
                     "😀 эмодзи в подписи — привяжу к нему стикер · ✂️ вырежу однотонный фон\n"
                     "💬 текст → стикер-цитата · 📥 чужой стикер → в твой пак или картинкой\n"
                     "🗑 убрать из пака — просто пришли стикер мне") + "\n" + ui.hint(
    f"🆓 {premium.COUNT['stk_packs']} пак до {premium.COUNT['stk_items']} штук · "
    "💎 Соня+: без лимитов, видео-стикеры из GIF, без подписи бота")


async def start_kb(uid: int):
    cut = bool(await db.kv_get(f"stk:cut:{uid}"))
    rows = [[("🖼 Пак стикеров", "stk:new:sticker", "success"), ("🧩 Пак эмодзи", "stk:new:emoji", "success")],
            [(f"{ui.tog(cut)} ✂️ Фон", "stk:cut"), ("📦 Мои паки", "stk:list"), ("❔", "stk:help")]]
    if config.MAIN_BOT:
        rows.append([("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}")])
    return kb_rows(*rows)


@router.message(Command("new"))
async def cmd_new(m: Message):
    await m.answer("какой пак начнём?", reply_markup=kb_rows([("🧩 Пак эмодзи", "stk:new:emoji"),
                                                               ("🖼 Пак стикеров", "stk:new:sticker")]))


@router.callback_query(F.data.startswith("stk:new:"))
async def cb_new(cb: CallbackQuery, bot: Bot):
    kind = cb.data.split(":")[2]
    uid = cb.from_user.id
    if kind not in TG_MAX:
        return await cb.answer()
    if len(await packs_of(uid)) >= premium.COUNT["stk_packs"] and not premium.plus(uid):
        await cb.answer()
        return await premium.upsell(cb.message, uid, "stk_packs")
    await cb.answer()
    pending = _pending.pop(uid, None)
    if pending:
        return await add_media(pending, bot, kind_for_new=kind)
    await db.kv_set(f"stk:want:{uid}", kind)
    await db.q_run("DELETE FROM kv WHERE k=?", f"stk:cur:{uid}")
    await cb.message.answer(f"{KIND_ICON[kind]} присылай первую картинку — из неё создам пак {KIND_NAME[kind]}")


@router.message(Command("packs"))
async def cmd_packs(m: Message):
    await show_packs(m, m.from_user.id)


@router.callback_query(F.data == "stk:list")
async def cb_list(cb: CallbackQuery):
    await cb.answer()
    await show_packs(cb.message, cb.from_user.id)


async def show_packs(m: Message, uid: int):
    ps = await packs_of(uid)
    if not ps:
        return await m.answer("паков пока нет — пришли картинку 🙂")
    cur = await current(uid)
    rows = []
    for p in ps:
        mark = "✅" if cur and cur["id"] == p["id"] else "▶️"
        rows.append([(f"{KIND_ICON[p['kind']]} {p['title'][:28]} · {p['n']}", pack_url(p)),
                     ("✏️", f"stk:ren:{p['id']}"), (mark, f"stk:use:{p['id']}")])
    await m.answer("📦 <b>твои паки</b>\n" + ui.hint("▶️ — добавлять картинки сюда · ✏️ — переименовать"),
                   reply_markup=kb_rows(*rows))


@router.callback_query(F.data.startswith("stk:use:"))
async def cb_use(cb: CallbackQuery):
    pid = int(cb.data.split(":")[2])
    p = await db.q_one("SELECT * FROM sticker_packs WHERE id=? AND uid=?", pid, cb.from_user.id)
    if not p:
        return await cb.answer("пак не найден", show_alert=True)
    await db.kv_set(f"stk:cur:{cb.from_user.id}", str(pid))
    await cb.answer(f"теперь добавляю в «{p['title'][:30]}»", show_alert=True)


@router.callback_query(F.data.startswith("stk:ren:"))
async def cb_ren(cb: CallbackQuery):
    pid = int(cb.data.split(":")[2])
    if not await db.q_one("SELECT id FROM sticker_packs WHERE id=? AND uid=?", pid, cb.from_user.id):
        return await cb.answer("пак не найден", show_alert=True)
    await db.kv_set(f"stk:ren:{cb.from_user.id}", str(pid))
    await cb.answer()
    await cb.message.answer("✏️ напиши новое название пака")


@router.callback_query(F.data.startswith("stk:rm:"))
async def cb_rm(cb: CallbackQuery, bot: Bot):
    rec = _del.pop(cb.data.split(":")[2], None)
    if not rec or rec[0] != cb.from_user.id:
        return await cb.answer("кнопка устарела — пришли стикер ещё раз", show_alert=True)
    try:
        await bot.delete_sticker_from_set(sticker=rec[1])
    except TelegramBadRequest as e:
        return await cb.answer(f"не вышло: {str(e)[:150]}", show_alert=True)
    await db.q_run("UPDATE sticker_packs SET n=MAX(0, n-1) WHERE id=? AND uid=?", rec[2], rec[0])
    await cb.answer("🗑 убрала")
    try:
        await cb.message.edit_text("🗑 убрала из пака (в Telegram обновится за пару минут)")
    except TelegramBadRequest:
        pass


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"))
async def on_text(m: Message, bot: Bot):
    uid = m.from_user.id
    pid = await db.kv_get(f"stk:ren:{uid}")
    if pid:
        await db.q_run("DELETE FROM kv WHERE k=?", f"stk:ren:{uid}")
        p = await db.q_one("SELECT * FROM sticker_packs WHERE id=? AND uid=?", int(pid), uid)
        if p:
            title = m.text.strip()[:60]
            try:
                await bot.set_sticker_set_title(name=p["name"], title=await full_title(bot, uid, title))
            except TelegramBadRequest as e:
                return await m.reply(f"😕 не вышло: {escape(str(e)[:150])}")
            await db.q_run("UPDATE sticker_packs SET title=? WHERE id=?", title, p["id"])
            return await m.reply(f"✏️ теперь пак называется «{escape(title)}»")
    for e in m.entities or []:   # своё эмодзи из пака — предложим убрать
        if e.type == "custom_emoji" and e.custom_emoji_id:
            try:
                st = (await bot.get_custom_emoji_stickers(custom_emoji_ids=[e.custom_emoji_id]))[0]
            except (TelegramBadRequest, IndexError):
                break
            p = await _own(uid, st.set_name)
            if p:
                return await offer_delete(m, uid, st.file_id, p)
            break
    tok = _keep(m)   # волна 45: любой текст можно превратить в стикер-цитату
    await m.reply("💬 сделать из этого текста стикер-цитату?",
                  reply_markup=kb_rows([("💬 Да, в стикер", f"stk:txt:{tok}"), ("❔ Как пользоваться", "stk:help")]))


@router.callback_query(F.data.startswith("stk:txt:"))
async def cb_txt(cb: CallbackQuery, bot: Bot):
    m = _msgs.pop(cb.data.split(":")[2], None)
    if not m or m.from_user.id != cb.from_user.id:
        return await cb.answer("кнопка устарела — напиши текст ещё раз", show_alert=True)
    await cb.answer()
    await add_media(m, bot)


@router.callback_query(F.data == "stk:help")
async def cb_help(cb: CallbackQuery):
    await cb.answer()
    await cb.message.answer("🧩 <b>как это работает</b>\n" + HELP_TEXT, reply_markup=await start_kb(cb.from_user.id))


@router.callback_query(F.data == "stk:cut")
async def cb_cut(cb: CallbackQuery):
    key = f"stk:cut:{cb.from_user.id}"
    on = not await db.kv_get(key)
    if on:
        await db.kv_set(key, "1")
    else:
        await db.q_run("DELETE FROM kv WHERE k=?", key)
    await cb.answer("✂️ буду вырезать однотонный фон и обводить белым" if on else "фон оставляю как есть",
                    show_alert=True)
    try:
        await cb.message.edit_reply_markup(reply_markup=await start_kb(cb.from_user.id))
    except TelegramBadRequest:
        pass
