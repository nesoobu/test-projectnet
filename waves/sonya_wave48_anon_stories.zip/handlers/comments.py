"""💬 Комментарии под постами канала: 🎵 трек из видео, 📝 текст песни под аудио.
Пост канала Telegram сам пересылает в привязанную группу обсуждения (is_automatic_forward) —
ответ на эту пересылку и есть комментарий."""
import asyncio
import hashlib
import logging
from html import escape

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, FSInputFile

import config
from autopost import store, media_dl
from downloader import core, catalog, audiofx
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("comments")
MAX_TG_FILE = config.TG_GET_MAX    # больше бот скачать из Telegram не может


# ================= настройки =================
@router.callback_query(F.data.startswith("ap:cm:"))
async def cb_cm(cb: CallbackQuery):
    _, _, what, cid = cb.data.split(":")
    cid = int(cid)
    c = await store.channel(cid, cb.from_user.id)
    if not c:
        return await cb.answer("канал не найден", show_alert=True)
    if what == "help":
        await cb.answer()
        return await cb.message.answer(
            "💬 <b>как Соня пишет в комментарии</b>\n"
            "1. у канала должно быть обсуждение: настройки канала → «Обсуждение» → привяжи группу\n"
            "2. добавь меня в эту группу и сделай админом (хватит права «удалять сообщения»)\n"
            "3. включи тут «🎵 Трек» и/или «📝 Текст»\n\n"
            "🎵 под видео, GIF и кружками — узнаю музыку и пришлю трек первым комментарием\n"
            "📝 под аудио — пришлю текст песни и пару похожих треков\n"
            "🎶 «трек в подписи» — после выхода видео-поста узнаю музыку и допишу «🎵 Артист — Трек» "
            "прямо в подпись (комментарии для этого не нужны)\n"
            "<i>если музыку не узнала — молчу, мусор в комментах не нужен</i>",
            reply_markup=kb_rows([("‹ К настройкам", f"ap:cs:{cid}")]))
    col = {"track": "cm_track", "lyrics": "cm_lyrics", "cap": "cap_track"}[what]
    await store.set_channel(cid, **{col: 0 if c.get(col) else 1})
    await cb.answer("включено" if not c.get(col) else "выключено")
    from handlers import ap_panel
    await show(cb, *await ap_panel.channel_view(cid))


# ================= пост пришёл в обсуждение =================
def channel_post(m: Message) -> bool:
    return bool(m.is_automatic_forward and m.sender_chat and m.chat.type in ("group", "supergroup"))


@router.message(channel_post)
async def on_channel_post(m: Message, bot: Bot):
    ch = await store.channel(m.sender_chat.id)
    if not ch:
        return
    if ch.get("cm_track") and (m.video or m.animation or m.video_note):
        asyncio.create_task(_safe(track_comment(m, bot)))
    elif ch.get("cm_lyrics") and m.audio:
        asyncio.create_task(_safe(lyrics_comment(m)))


async def _safe(coro):
    try:
        await coro
    except Exception as e:
        log.warning("comment: %r", e)


async def recognize_media(bot: Bot, obj) -> dict | None:
    from handlers import tools
    if (getattr(obj, "file_size", 0) or 0) > MAX_TG_FILE:
        return None
    path = audiofx.tmp(".mp4")
    try:
        await bot.download(obj.file_id, destination=path)
        return await tools.recognize(path)
    finally:
        core.remove(path)


async def catalog_track(artist: str, title: str, cover: str = "") -> dict:
    t = catalog.track("sz", hashlib.md5(f"{artist}|{title}".encode()).hexdigest()[:12], artist, title, cover=cover)
    try:
        for c in await catalog.search(f"{artist} {title}", 5):
            if c["title"].lower().startswith(title.lower()[:12]) and artist.lower()[:6] in c["artist"].lower():
                t = {**c, "cover": c["cover"] or cover}
                break
    except Exception as e:
        log.info("catalog: %s", e)
    await catalog.remember([t])
    return t


async def track_comment(m: Message, bot: Bot):
    obj = m.video or m.animation or m.video_note
    res = await recognize_media(bot, obj)
    if not res:
        return
    t = await catalog_track(res["artist"], res["title"], res.get("cover", ""))
    cap = f"🎵 <b>{escape(t['artist'])}</b> — {escape(t['title'])}"
    me = await bot.me()
    if me.username:
        cap += f'\n<i>нашла <a href="https://t.me/{me.username}">@{me.username}</a></i>'
    import db
    c = await db.dl_cache_get(f"audio:{t['key']}")
    if c:
        return await m.reply_audio(c["file_id"], caption=cap)
    f = None
    try:
        from handlers import music
        f = await core.download(await catalog.audio_url(t), "audio")
        sent = await m.reply_audio(FSInputFile(f["path"]), caption=cap, title=t["title"], performer=t["artist"],
                                   duration=f.get("duration") or t["dur"] or None,
                                   thumbnail=await music._thumb(t["cover"]))
        if sent.audio:
            await db.dl_cache_put(f"audio:{t['key']}", "audio", sent.audio.file_id, catalog.name(t))
    except media_dl.DLError as e:   # звук не скачался — хотя бы название
        log.info("comment audio: %s", e)
        await m.reply(cap)
    finally:
        core.remove(f and f.get("path"))


async def lyrics_comment(m: Message):
    from handlers import tools
    a = m.audio
    q = " ".join(x for x in (a.performer, a.title) if x) or (a.file_name or "").rsplit(".", 1)[0]
    if len(q) < 3:
        return
    parts = []
    try:
        got = await tools.lyrics(q)
    except Exception as e:
        log.info("lyrics: %s", e)
        got = None
    if got:
        body = escape(got["text"].strip())[:3200]
        parts.append(f"📝 <b>текст</b>\n<blockquote expandable>{body}</blockquote>")
    try:
        found = await catalog.search(q, 3)
        sim = (await catalog.similar(found[0]))[:5] if found else []
        if sim:
            parts.append("🎧 <b>похожее</b>\n" + "\n".join(f"• {escape(catalog.name(s))}" for s in sim))
    except Exception as e:
        log.info("similar: %s", e)
    if parts:
        await m.reply("\n\n".join(parts)[:4000])
