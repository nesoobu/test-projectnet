"""Инструменты волны 16: мемы, кружок и гифка из видео, обрезка аудио, QR, конвертер валют, крипта, файлы."""
import asyncio
import io
import json
import logging
import re
import shutil
import time
import zipfile
from html import escape

import aiohttp
from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, BufferedInputFile, FSInputFile

import config
import db
import limits
import llm
from downloader import core
from handlers import tools

router = Router()
log = logging.getLogger("studio")
MAX_DL = config.TG_GET_MAX   # больше телеграм боту не отдаёт (свой Bot API — больше)


async def _download(bot: Bot, obj, ext: str) -> str:
    if (getattr(obj, "file_size", 0) or 0) > MAX_DL:
        raise ValueError(f"файл больше {config.mb(config.TG_GET_MAX)} — телеграм не даёт мне его скачать")
    path = tools._tmp(ext)
    await bot.download(obj.file_id, destination=path)
    return path


async def ffmpeg(*args: str, timeout: int = 180) -> bool:
    if not shutil.which("ffmpeg"):
        raise RuntimeError("на сервере нет ffmpeg")
    proc = await asyncio.create_subprocess_exec("ffmpeg", "-y", "-loglevel", "error", *args,
                                                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    try:
        _, err = await asyncio.wait_for(proc.communicate(), timeout)
    except asyncio.TimeoutError:
        proc.kill()
        raise RuntimeError("слишком долго обрабатывается")
    if proc.returncode != 0:
        log.info("ffmpeg: %s", (err or b"").decode(errors="ignore")[-300:])
    return proc.returncode == 0


def _video_of(m: Message | None):
    if not m:
        return None
    return m.video or m.animation or m.video_note or (m.document if m.document and
                                                      (m.document.mime_type or "").startswith("video") else None)


# ================= 🖼 мем =================
def make_meme(img_bytes: bytes, top: str, bottom: str) -> bytes:
    from PIL import Image, ImageDraw
    im = Image.open(io.BytesIO(img_bytes)).convert("RGB")
    if max(im.size) > 1280:
        im.thumbnail((1280, 1280))
    d = ImageDraw.Draw(im)
    w, h = im.size
    for text, at_top in ((top, True), (bottom, False)):
        text = text.strip().upper()
        if not text:
            continue
        size = max(18, w // 9)
        while size > 14:
            font = tools._font(size, bold=True)
            lines = tools._wrap(d, text, font, int(w * 0.94))
            lh = int(size * 1.15)
            if len(lines) * lh < h * 0.3:
                break
            size -= 4
        y = int(h * 0.02) if at_top else h - len(lines) * lh - int(h * 0.03)
        for line in lines:
            tw = d.textlength(line, font=font)
            d.text(((w - tw) / 2, y), line, font=font, fill="white", stroke_width=max(2, size // 12),
                   stroke_fill="black")
            y += lh
    out = io.BytesIO()
    im.save(out, "JPEG", quality=90)
    return out.getvalue()


@router.message(Command("mem", "meme", "мем"))
async def cmd_mem(m: Message, bot: Bot, command: CommandObject):
    src = m if m.photo else m.reply_to_message
    photo = src.photo[-1] if src and src.photo else None
    if not photo:
        return await m.reply("🖼 ответь <code>/mem верх | низ</code> на фото (или пришли фото с такой подписью)")
    top, _, bottom = (command.args or "").partition("|")
    if not top.strip() and not bottom.strip():
        return await m.reply("а текст? <code>/mem когда пятница | а завтра на работу</code>")
    buf = io.BytesIO()
    await bot.download(photo.file_id, destination=buf)
    data = await asyncio.to_thread(make_meme, buf.getvalue(), top, bottom)
    await m.reply_photo(BufferedInputFile(data, "meme.jpg"))


# ================= ⭕ кружок и 🎞 гифка =================
async def _convert_video(m: Message, bot: Bot, kind: str):
    v = _video_of(m.reply_to_message) or _video_of(m)
    if not v:
        what = "кружок" if kind == "circle" else "гифку"
        return await m.reply(f"ответь командой на видео — сделаю {what}")
    src = out = None
    try:
        await bot.send_chat_action(m.chat.id, ChatAction.RECORD_VIDEO_NOTE if kind == "circle" else ChatAction.UPLOAD_VIDEO)
        src = await _download(bot, v, ".mp4")
        out = tools._tmp(".mp4")
        if kind == "circle":
            ok = await ffmpeg("-i", src, "-t", "59", "-vf", "crop='min(iw,ih)':'min(iw,ih)',scale=512:512",
                              "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-c:a", "aac", "-b:a", "64k",
                              "-movflags", "+faststart", out)
            if not ok:
                raise RuntimeError("не получилось перекодировать")
            await m.reply_video_note(FSInputFile(out), length=512)
        else:
            ok = await ffmpeg("-i", src, "-t", "30", "-an", "-vf", "scale='min(480,iw)':-2", "-c:v", "libx264",
                              "-preset", "veryfast", "-crf", "30", "-movflags", "+faststart", out)
            if not ok:
                raise RuntimeError("не получилось перекодировать")
            await m.reply_animation(FSInputFile(out))
    except Exception as e:
        await m.reply(f"😕 {escape(str(e)[:120])}")
    finally:
        core.remove(src)
        core.remove(out)


@router.message(Command("circle", "кружок"))
async def cmd_circle(m: Message, bot: Bot):
    await _convert_video(m, bot, "circle")


@router.message(Command("gif", "гиф"))
async def cmd_gif(m: Message, bot: Bot):
    await _convert_video(m, bot, "gif")


# ================= ✂️ обрезка аудио =================
def parse_ts(s: str) -> float | None:
    mt = re.fullmatch(r"(?:(\d+):)?(\d{1,2})(?:[.,](\d+))?", s.strip())
    if not mt:
        return None
    return int(mt.group(1) or 0) * 60 + int(mt.group(2)) + float("0." + (mt.group(3) or "0"))


@router.message(Command("cut", "обрезать", "рингтон"))
async def cmd_cut(m: Message, bot: Bot, command: CommandObject):
    r = m.reply_to_message
    obj = r and (r.audio or r.voice or r.video or r.video_note or r.document)
    args = (command.args or "").split()
    a = parse_ts(args[0]) if args else None
    b = parse_ts(args[1]) if len(args) > 1 else None
    if not obj or a is None or b is None or b <= a:
        return await m.reply("✂️ ответь на аудио, голосовое или видео: <code>/cut 0:30 1:00</code> — вырежу кусок в mp3 "
                             "(для рингтона — до 40 секунд)")
    if b - a > 600:
        return await m.reply("кусок до 10 минут, не больше")
    src = out = None
    try:
        await bot.send_chat_action(m.chat.id, ChatAction.UPLOAD_VOICE)
        src = await _download(bot, obj, ".bin")
        out = tools._tmp(".mp3")
        if not await ffmpeg("-ss", f"{a:.2f}", "-i", src, "-t", f"{b - a:.2f}", "-vn", "-c:a", "libmp3lame",
                            "-b:a", "192k", out):
            raise RuntimeError("не получилось вырезать")
        await m.reply_audio(FSInputFile(out), title=f"кусок {args[0]}–{args[1]}", performer="Соня ✂️")
    except Exception as e:
        await m.reply(f"😕 {escape(str(e)[:120])}")
    finally:
        core.remove(src)
        core.remove(out)


# ================= 🔳 QR =================
@router.message(Command("qr"))
async def cmd_qr(m: Message, command: CommandObject):
    text = (command.args or "").strip() or (m.reply_to_message and (m.reply_to_message.text or "")) or ""
    if not text:
        return await m.reply("🔳 <code>/qr https://t.me/Sonya_rubot</code> — сделаю QR-код (или ответом на текст)")
    try:
        import qrcode
    except ImportError:
        return await m.reply("на сервере нет библиотеки qrcode — владельцу: <code>pip install qrcode</code>")
    img = qrcode.make(text[:1000])
    buf = io.BytesIO()
    img.save(buf, "PNG")
    await m.reply_photo(BufferedInputFile(buf.getvalue(), "qr.png"), caption=f"🔳 {escape(text[:200])}")


# ================= 💱 конвертер и крипта =================
FIAT = {"USD": r"usd|\$|доллар\w*|бакс\w*", "EUR": r"eur|€|евро", "RUB": r"rub|₽|руб\w*|р",
        "CNY": r"cny|юан\w*", "KZT": r"kzt|тенге|тг", "TRY": r"try|лир\w*", "GBP": r"gbp|£|фунт\w*",
        "JPY": r"jpy|¥|иен\w*|йен\w*", "BYN": r"byn|бел\w*", "UAH": r"uah|грив\w*|грн", "AMD": r"amd|драм\w*",
        "GEL": r"gel|лари", "UZS": r"uzs|сум\w*"}
CRYPTO = {"BTC": (r"btc|биткоин\w*|битк\w*", "bitcoin"), "ETH": (r"eth|эфир\w*", "ethereum"),
          "TON": (r"ton|тон\w*", "the-open-network"), "USDT": (r"usdt|тезер\w*", "tether")}
CONV_RE = re.compile(r"^(?:сколько\s+(?:будет\s+)?)?(\d+(?:[.,]\d+)?)\s*([^\d\s]+)\s+(?:в|to|in)\s+([^\d\s?]+)\??$", re.I)
_crypto_cache: tuple[float, dict] = (0, {})


def currency(word: str) -> str | None:
    w = word.lower().strip(".")
    for code, rx in FIAT.items():
        if re.fullmatch(rx, w):
            return code
    for code, (rx, _id) in CRYPTO.items():
        if re.fullmatch(rx, w):
            return code
    return None


async def crypto_prices() -> dict:
    """{'BTC': {'usd': …, 'rub': …}, …} с кэшем на 5 минут."""
    global _crypto_cache
    if time.time() - _crypto_cache[0] < 300 and _crypto_cache[1]:
        return _crypto_cache[1]
    ids = ",".join(i for _rx, i in CRYPTO.values())
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=10)) as s:
        async with s.get(f"https://api.coingecko.com/api/v3/simple/price?ids={ids}&vs_currencies=usd,rub") as r:
            data = await r.json(content_type=None)
    out = {code: data[i] for code, (_rx, i) in CRYPTO.items() if i in data}
    _crypto_cache = (time.time(), out)
    return out


async def to_rub(code: str) -> float:
    if code == "RUB":
        return 1.0
    if code in CRYPTO:
        return float((await crypto_prices())[code]["rub"])
    v = (await tools.cbr())[code]
    return v["Value"] / v["Nominal"]


async def convert(amount: float, a: str, b: str) -> float:
    return amount * await to_rub(a) / await to_rub(b)


def fmt_num(x: float) -> str:
    if x >= 100:
        return f"{x:,.0f}".replace(",", " ")
    return f"{x:,.2f}".replace(",", " ") if x >= 1 else f"{x:.6f}".rstrip("0")


async def conv_reply(m: Message, amount: float, a: str, b: str):
    try:
        res = await convert(amount, a, b)
    except Exception as e:
        log.info("conv: %s", e)
        return await m.reply("😕 курс сейчас не отвечает, попробуй позже")
    await m.reply(f"💱 {fmt_num(amount)} {a} = <b>{fmt_num(res)} {b}</b>")


@router.message(Command("conv", "конверт"))
async def cmd_conv(m: Message, command: CommandObject):
    mt = CONV_RE.match((command.args or "").strip())
    a, b = (currency(mt.group(2)), currency(mt.group(3))) if mt else (None, None)
    if not mt or not a or not b:
        return await m.reply("💱 <code>/conv 100 usd в rub</code> или просто «100 долларов в рубли»\n"
                             "валюты ЦБ + BTC, ETH, TON, USDT")
    await conv_reply(m, float(mt.group(1).replace(",", ".")), a, b)


async def _conv_said(m: Message, bot: Bot) -> bool | dict:
    if not m.text or m.text.startswith("/"):
        return False
    from handlers import chat
    me = await bot.me()
    text = chat._addressed(m, me.id, me.username or "")
    mt = CONV_RE.match(text.strip()) if text else None
    if not mt:
        return False
    a, b = currency(mt.group(2)), currency(mt.group(3))
    return {"amount": float(mt.group(1).replace(",", ".")), "a": a, "b": b} if a and b and a != b else False


@router.message(_conv_said)
async def on_conv(m: Message, amount: float, a: str, b: str):
    await conv_reply(m, amount, a, b)


async def crypto_lines() -> list[str]:
    try:
        p = await crypto_prices()
    except Exception as e:
        log.info("crypto: %s", e)
        return []
    out = []
    for code, icon in (("BTC", "₿"), ("ETH", "◆"), ("TON", "💎")):
        if code in p:
            out.append(f"{icon} {code}: <b>${fmt_num(p[code]['usd'])}</b> · {fmt_num(p[code]['rub'])} ₽")
    return out


# ================= 📄 файлы =================
DOC_TTL = 2 * 3600
DOC_MAX = 12000
DOC_EXT = (".pdf", ".docx", ".txt", ".md", ".csv", ".json", ".py", ".html", ".log")


def extract_text(path: str, name: str) -> str:
    n = name.lower()
    if n.endswith(".pdf"):
        from pypdf import PdfReader
        r = PdfReader(path)
        return "\n".join((p.extract_text() or "") for p in r.pages[:40])
    if n.endswith(".docx"):
        with zipfile.ZipFile(path) as z:
            xml = z.read("word/document.xml").decode("utf-8", "ignore")
        xml = re.sub(r"</w:p>", "\n", xml)
        return re.sub(r"<[^>]+>", "", xml)
    raw = open(path, "rb").read()
    for enc in ("utf-8", "cp1251"):
        try:
            return raw.decode(enc)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "ignore")


async def doc_context(chat_id: int) -> str:
    """Текст недавно присланного документа — для вопросов по нему в обычном чате."""
    raw = await db.kv_get(f"doc:{chat_id}")
    if not raw:
        return ""
    d = json.loads(raw)
    if time.time() - d["ts"] > DOC_TTL:
        await db.q_run("DELETE FROM kv WHERE k=?", f"doc:{chat_id}")
        return ""
    return f"Собеседник прислал документ «{d['name']}». Его текст:\n{d['text']}"


async def read_doc(m: Message, bot: Bot, doc):
    name = doc.file_name or "file"
    if not name.lower().endswith(DOC_EXT):
        return await m.reply("📄 читаю PDF, DOCX и текстовые файлы (txt, md, csv…)")
    if not await limits.take(m.from_user.id):
        return await m.reply(limits.tired_text(m.from_user.id))
    st = await m.reply("📄 читаю…")
    path = None
    try:
        path = await _download(bot, doc, "." + name.rsplit(".", 1)[-1])
        text = re.sub(r"\n{3,}", "\n\n", (await asyncio.to_thread(extract_text, path, name))).strip()
        if len(text) < 20:
            await limits.give_back(m.from_user.id)
            return await st.edit_text("😕 текста не нашла — может, это скан? сканы читать пока не умею")
        await db.kv_set(f"doc:{m.chat.id}", json.dumps({"name": name, "text": text[:DOC_MAX], "ts": int(time.time())},
                                                       ensure_ascii=False))
        out = await llm.ask([{"role": "system", "content": "Ты Соня. Перескажи документ: суть в 2–3 предложениях, "
                                                           "потом 3–6 главных пунктов. По-русски, без воды."},
                             {"role": "user", "content": text[:DOC_MAX]}], max_tokens=1200, temperature=0.4,
                            feature="doc")
        await st.edit_text(f"📄 <b>{escape(name[:60])}</b>\n\n{escape(out[:3600])}\n\n"
                           "<i>спрашивай по документу — помню его пару часов</i>")
    except Exception as e:
        log.info("doc: %s", e)
        await limits.give_back(m.from_user.id)
        await st.edit_text(f"😕 не получилось прочитать: {escape(str(e)[:100])}")
    finally:
        core.remove(path)


@router.message(F.document, F.chat.type == "private")
async def on_document(m: Message, bot: Bot):
    if (m.document.mime_type or "").startswith(("video", "audio", "image")):
        return
    await read_doc(m, bot, m.document)


@router.message(Command("read", "прочитай"))
async def cmd_read(m: Message, bot: Bot):
    doc = (m.reply_to_message and m.reply_to_message.document) or m.document
    if not doc:
        return await m.reply("📄 ответь <code>/read</code> на PDF, DOCX или текстовый файл")
    await read_doc(m, bot, doc)
