"""«Сонь, скачай / сделай кружок / замедли / обрежь 0:10-0:20 / текст песни …» — без слешей.
Медиа берём из ответа (reply) на сообщение."""
import logging
from html import escape

from aiogram import Bot
from aiogram.types import Message, FSInputFile

import config
from autopost import media_dl
from downloader import core, audiofx, links as L

log = logging.getLogger("quick")
MAX_TG_FILE = config.TG_GET_MAX
FX_WORDS = [("замедл", "slow"), ("slowed", "slow"), ("ускор", "fast"), ("sped", "fast"), ("speed", "fast"),
            ("8d", "8d"), ("8д", "8d"), ("бас", "bass"), ("bass", "bass"), ("найткор", "night"), ("nightcore", "night")]


def _reply_media(m: Message, kinds: tuple):
    r = m.reply_to_message
    if not r:
        return None, None
    for k in kinds:
        obj = getattr(r, k, None)
        if obj:
            return obj, k
    if "video" in kinds and r.document and (r.document.mime_type or "").startswith("video"):
        return r.document, "video"
    if "audio" in kinds and r.document and (r.document.mime_type or "").startswith("audio"):
        return r.document, "audio"
    return None, None


async def _fetch(bot: Bot, obj, ext: str) -> str:
    if (getattr(obj, "file_size", 0) or 0) > MAX_TG_FILE:
        raise media_dl.DLError(f"файл больше {config.mb(config.TG_GET_MAX)} — телеграм не даёт мне его скачать")
    path = audiofx.tmp(ext)
    await bot.download(obj.file_id, destination=path)
    return path


HINT = {
    "note": "ответь «Сонь, кружок» на видео 🎬",
    "gif": "ответь «Сонь, гифку» на видео 🎬",
    "fx": "ответь «Сонь, замедли» (или ускорь, 8д, бас, найткор) на трек или голосовое 🎧",
    "asvoice": "ответь «Сонь, голосовым» на трек 🎧",
    "cut": "ответь на видео или трек: «Сонь, обрежь 0:10-0:25» ✂️",
    "transcribe": "ответь «Сонь, расшифруй» на голосовое, кружок или видео 🎙",
}


async def run(m: Message, bot: Bot, intent: str, arg: str):
    from handlers import music, melody, media, vtools, tools
    if intent == "dl":
        found = L.find_links(arg) or (L.find_links((m.reply_to_message.text or m.reply_to_message.caption or ""))
                                      if m.reply_to_message else [])
        if found:
            for link in found[:5]:
                await media.handle_link(m, bot, link)
            return
        if arg:   # «Сонь, скачай трек скриптонит космос» — это поиск музыки
            import re
            return await music.search(m, re.sub(r"^(?:трек|песню|музыку|песня)\s*", "", arg, flags=re.I))
        return await m.reply("кинь ссылку — или ответь «Сонь, скачай» на сообщение со ссылкой ⬇️")
    if intent == "lyrics":
        q = arg
        if not q and m.reply_to_message and m.reply_to_message.audio:
            a = m.reply_to_message.audio
            q = " ".join(x for x in (a.performer, a.title) if x)
        if not q:
            return await m.reply("чей текст ищем? «Сонь, текст песни скриптонит космос» или ответь так на трек 📝")
        return await tools.send_lyrics(m, q)
    if intent == "chart":
        return await music.chart_list(m)
    if intent == "mytracks":
        return await music.my_list(m, m.from_user.id)
    if intent == "melody":
        return await melody.start_game(m, bot, arg[:60], m.from_user.id)
    if intent == "taste":
        return await melody.taste(m, bot, m.from_user.id, m.from_user.first_name or "я")
    if intent == "history":
        text, kb = await vtools.history_view(m.from_user.id)
        return await m.answer(text, reply_markup=kb)
    if intent == "transcribe":
        r = m.reply_to_message
        if not r or not (r.voice or r.video_note or r.video or r.audio):
            return await m.reply(HINT["transcribe"])
        return await media.transcribe_message(m, bot, r)

    kinds = ("video", "animation", "video_note") if intent in ("note", "gif") else \
        ("audio", "voice", "video", "video_note") if intent in ("fx", "asvoice", "cut") else ()
    obj, kind = _reply_media(m, kinds)
    if not obj:
        return await m.reply(HINT[intent])
    paths = []
    try:
        st = await m.reply("⏳ колдую…")
        src = await _fetch(bot, obj, ".mp4" if kind in ("video", "animation", "video_note") else ".mp3")
        paths.append(src)
        if intent == "note":
            out = await audiofx.video_note(src)
            paths.append(out)
            await m.reply_video_note(FSInputFile(out), length=480)
        elif intent == "gif":
            out = await audiofx.gif(src)
            paths.append(out)
            await m.reply_animation(FSInputFile(out))
        elif intent == "asvoice":
            out = await audiofx.voice(src, 0, 600)
            paths.append(out)
            await m.reply_voice(FSInputFile(out))
        elif intent == "fx":
            import premium
            if not await premium.allow(m.from_user.id, "fx"):
                await st.delete()
                return await premium.upsell(m, m.from_user.id, "fx")
            low = (m.text or "").lower()
            fx = next((v for w, v in FX_WORDS if w in low), "slow")
            out = await audiofx.effect(src, fx)
            paths.append(out)
            a = getattr(obj, "title", None) or "трек"
            await m.reply_audio(FSInputFile(out), title=f"{a} ({audiofx.FX[fx][1]})",
                                performer=getattr(obj, "performer", None))
        elif intent == "cut":
            span = audiofx.parse_span(arg)
            if not span:
                await st.edit_text("какой кусок? «Сонь, обрежь 0:10-0:25» ✂️")
                return
            a, b = span
            if kind in ("video", "video_note"):
                out = await audiofx.cut_video(src, a, b)
                paths.append(out)
                await m.reply_video(FSInputFile(out), caption=f"✂️ {a // 60}:{a % 60:02d}–{b // 60}:{b % 60:02d}")
            else:
                out = await audiofx.cut_audio(src, a, b)
                paths.append(out)
                await m.reply_audio(FSInputFile(out), title=f"{getattr(obj, 'title', None) or 'отрывок'} (отрывок)")
        await st.delete()
    except media_dl.DLError as e:
        await m.reply(f"😕 {escape(str(e))}")
    except Exception as e:
        log.warning("quick %s: %r", intent, e)
        await m.reply("😕 не вышло — попробуй ещё раз")
    finally:
        for p in paths:
            core.remove(p)
