"""Волна 46: 🎲 случайный анонимный чат в боте анонимок (BOT_PROFILE=anon).
Очередь → пара 1 на 1 → сообщения пересылаются копией (без имени). /next — следующий, /stop — закончить.
Защита (по разбору чужих ботов и жалоб): 16+ и правила при входе; ссылки и @ники не передаю (спам и «пиши в
личку»); фото/видео/голосовые — только когда оба написали по 5 сообщений, фото и видео под спойлером;
жалоба → эту пару больше не сводим, 3 жалобы от разных людей за сутки → бан на неделю и сигнал владельцу;
👍/👎 после чата. Поиск по полу — с Соней+ (пол человек указывает сам, бот его не проверяет)."""
import asyncio
import logging
import re
import time
from dataclasses import dataclass, field

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery

import config
import db
import premium
import ui
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("anonchat")
TOPICS = {"any": "💬 О чём угодно", "games": "🎮 Игры", "music": "🎵 Музыка", "anime": "🎌 Аниме",
          "talk": "😔 Выговориться"}
GENDERS = {"m": "👦 парень", "f": "👧 девушка", "": "🤐 не скажу"}
WANT = {"": "всех", "m": "👦 парней", "f": "👧 девушек"}
MEDIA_AFTER = 5            # фото/видео/голос — после 5 сообщений от каждого
QUEUE_TTL = 300            # ищем не дольше 5 минут
BAN_REPORTS, BAN_DAYS = 3, 7
LINK = re.compile(r"(https?://|t\.me/|www\.|@[a-z0-9_]{4,}|\b[a-z0-9-]+\.(ru|com|me|org|net|io)\b)", re.I)
RULES = ("🎲 <b>анонимный чат</b> — случайный собеседник, 1 на 1, без имён\n" + ui.LINE + "\n"
         "• только 16+\n"
         "• нельзя: интим и просьбы о фото, угрозы, травля, реклама, продажа\n"
         "• ссылки и @ники не передаю — так меньше спама и мошенников\n"
         "• фото и видео — после 5 сообщений от каждого, под спойлером\n"
         "• не давай свой номер, адрес и соцсети незнакомцам\n"
         "• 🚨 жалоба — и вы больше не встретитесь; нарушителей баню")


@dataclass
class Seeker:
    uid: int
    topic: str
    gender: str
    want: str
    plus: bool
    ts: float = field(default_factory=time.time)


QUEUE: list[Seeker] = []
PAIRS: dict[int, int] = {}                 # uid → собеседник
COUNT: dict[int, int] = {}                 # uid → сколько он написал в текущем чате
LAST: dict[int, int] = {}                  # uid → прошлый собеседник (для оценки и жалобы)
_recent: dict[int, list[int]] = {}         # uid → последние собеседники, чтобы не сводить сразу снова


# ================= профиль =================
async def profile(uid: int) -> dict:
    await db.q_run("INSERT OR IGNORE INTO chat_profiles(uid) VALUES(?)", uid)
    return await db.q_one("SELECT * FROM chat_profiles WHERE uid=?", uid)


def menu_kb(p: dict, uid: int):
    want = p.get("want") or ""
    return kb_rows([("🔎 Найти собеседника", "ch:go", "success")],
                   [(f"🏷 {TOPICS.get(p.get('topic') or 'any')}", "ch:topic"),
                    (f"🔍 {WANT[want].capitalize()}" + ("" if want or premium.plus(uid) else " 💎"), "ch:want")],
                   [(f"👤 Я: {GENDERS.get(p.get('gender') or '')}", "ch:me"), ("‹ Назад", "an:back")])


async def menu_view(uid: int):
    """Волна 47: экран чата — для показа новым сообщением или правкой текущего."""
    p = await profile(uid)
    if not p["agreed"]:
        return RULES, kb_rows([("✅ Мне есть 16, согласен", "ch:agree", "success")])
    if p["banned_until"] > time.time():
        return (f"🚫 чат для тебя закрыт до {time.strftime('%d.%m %H:%M', time.localtime(p['banned_until']))} "
                "— на тебя пожаловались несколько человек"), None
    return ("🎲 <b>Анонимный чат</b>\n" + ui.hint(f"👍 {p['likes']} · 👎 {p['dislikes']} · /next — следующий · "
                                                 "/stop — закончить"), menu_kb(p, uid))


async def show_menu(target, uid: int):
    text, kb = await menu_view(uid)
    await show(target, text, kb)


@router.message(Command("chat", "чат"))
async def cmd_chat(m: Message):
    if m.chat.type != "private":
        return
    await show_menu(m, m.from_user.id)


@router.callback_query(F.data == "ch:menu")
async def cb_menu(cb: CallbackQuery):
    await show_menu(cb, cb.from_user.id)


@router.callback_query(F.data == "ch:agree")
async def cb_agree(cb: CallbackQuery):
    await profile(cb.from_user.id)
    await db.q_run("UPDATE chat_profiles SET agreed=1 WHERE uid=?", cb.from_user.id)
    await show(cb, "кто ты?\n" + ui.hint("можно не говорить — пол нужен только для поиска по полу"), GENDER_KB)


GENDER_KB = kb_rows([("👦 Парень", "ch:g:m"), ("👧 Девушка", "ch:g:f")], [("🤐 Не скажу", "ch:g:")])


@router.callback_query(F.data == "ch:me")
async def cb_me(cb: CallbackQuery):
    await show(cb, "кто ты?", GENDER_KB)


@router.callback_query(F.data.startswith("ch:g:"))
async def cb_gender(cb: CallbackQuery):
    g = cb.data[5:]
    if g not in GENDERS:
        return await cb.answer()
    await db.q_run("UPDATE chat_profiles SET gender=? WHERE uid=?", g, cb.from_user.id)
    await show_menu(cb, cb.from_user.id)


@router.callback_query(F.data == "ch:want")
async def cb_want(cb: CallbackQuery):
    if not premium.plus(cb.from_user.id):
        await cb.answer()
        return await premium.upsell(cb.message, cb.from_user.id, "chat_gender")
    await show(cb, "кого искать?\n" + ui.hint("пол собеседник указывает сам — я его не проверяю"),
               kb_rows([("👥 Всех", "ch:w:"), ("👦 Парней", "ch:w:m"), ("👧 Девушек", "ch:w:f")]))


@router.callback_query(F.data.startswith("ch:w:"))
async def cb_want_set(cb: CallbackQuery):
    w = cb.data[5:]
    if w not in WANT or (w and not premium.plus(cb.from_user.id)):
        return await cb.answer()
    await db.q_run("UPDATE chat_profiles SET want=? WHERE uid=?", w, cb.from_user.id)
    await show_menu(cb, cb.from_user.id)


@router.callback_query(F.data == "ch:topic")
async def cb_topic(cb: CallbackQuery):
    items = list(TOPICS.items())
    await show(cb, "о чём хочется поговорить?",
               kb_rows(*[[(v, f"ch:t:{k}") for k, v in items[i:i + 2]] for i in range(0, len(items), 2)]))


@router.callback_query(F.data.startswith("ch:t:"))
async def cb_topic_set(cb: CallbackQuery):
    t = cb.data[5:]
    if t not in TOPICS:
        return await cb.answer()
    await db.q_run("UPDATE chat_profiles SET topic=? WHERE uid=?", t, cb.from_user.id)
    await show_menu(cb, cb.from_user.id)


# ================= поиск и пара =================
async def _blocked(a: int, b: int) -> bool:
    return bool(await db.q_one("SELECT 1 FROM chat_reports WHERE (reporter=? AND target=?) OR (reporter=? AND target=?)",
                               a, b, b, a))


def _fits(a: Seeker, b: Seeker) -> bool:
    if a.uid == b.uid or b.uid in _recent.get(a.uid, [])[-2:] or a.uid in _recent.get(b.uid, [])[-2:]:
        return False
    if a.topic != b.topic and "any" not in (a.topic, b.topic):
        return False
    return (not a.want or a.want == b.gender) and (not b.want or b.want == a.gender)


async def search(bot: Bot, m: Message, uid: int):
    p = await profile(uid)
    if not p["agreed"] or p["banned_until"] > time.time():
        return await show_menu(m, uid)
    if uid in PAIRS:
        return await m.answer("ты уже в чате 🙂 /next — следующий, /stop — закончить")
    from handlers import anon
    anon._writing.pop(uid, None)
    me = Seeker(uid, p["topic"] or "any", p["gender"] or "", p["want"] if premium.plus(uid) else "", premium.plus(uid))
    QUEUE[:] = [s for s in QUEUE if s.uid != uid]
    cands = sorted((s for s in QUEUE if _fits(me, s)), key=lambda s: (not s.plus, s.ts))   # с Соней+ — первыми
    for s in cands:
        if await _blocked(uid, s.uid):
            continue
        QUEUE.remove(s)
        await _connect(bot, uid, s.uid, me.topic if me.topic != "any" else s.topic)
        return
    QUEUE.append(me)
    await m.answer(f"🔎 ищу собеседника · {TOPICS[me.topic]}" + (f" · {WANT[me.want]}" if me.want else "") + "…",
                   reply_markup=kb_rows([("✖️ Отменить поиск", "ch:cancel")]))


async def _connect(bot: Bot, a: int, b: int, topic: str):
    PAIRS[a], PAIRS[b] = b, a
    COUNT[a] = COUNT[b] = 0
    for u in (a, b):
        _recent.setdefault(u, []).append(PAIRS[u])
        _recent[u] = _recent[u][-5:]
        try:
            await bot.send_message(u, f"🎲 <b>собеседник найден!</b> · {TOPICS.get(topic, '')}\n"
                                      "пиши — он видит только текст, без имени\n"
                                      + ui.hint(f"фото и видео — после {MEDIA_AFTER} сообщений от каждого · "
                                                "ссылки и @ники не передаю"),
                                   reply_markup=kb_rows([("⏭ Дальше", "ch:next"), ("⛔ Стоп", "ch:stop"),
                                                         ("🚨", "ch:rep", "danger")]))
        except (TelegramForbiddenError, TelegramBadRequest):
            await end_chat(bot, u, quiet_self=True)
            return


async def end_chat(bot: Bot, uid: int, quiet_self: bool = False) -> int | None:
    """Разрываем пару. Обоим — оценка собеседника."""
    other = PAIRS.pop(uid, None)
    if other is None:
        return None
    PAIRS.pop(other, None)
    LAST[uid], LAST[other] = other, uid
    rate = kb_rows([("👍", "ch:like"), ("👎", "ch:dis"), ("🚨 Жалоба", "ch:rep", "danger")],
                   [("🔎 Найти нового", "ch:go", "success")])
    try:
        await bot.send_message(other, "👋 собеседник закончил чат. как он тебе?", reply_markup=rate)
    except Exception:
        pass
    if not quiet_self:
        try:
            await bot.send_message(uid, "⛔ чат закончен. как тебе собеседник?", reply_markup=rate)
        except Exception:
            pass
    return other


@router.message(Command("next", "дальше"))
async def cmd_next(m: Message, bot: Bot):
    await end_chat(bot, m.from_user.id)
    await search(bot, m, m.from_user.id)


@router.message(Command("stop", "стоп"), F.chat.type == "private")
async def cmd_stop(m: Message, bot: Bot):
    QUEUE[:] = [s for s in QUEUE if s.uid != m.from_user.id]
    if await end_chat(bot, m.from_user.id) is None:
        await m.answer("ты сейчас ни с кем не общаешься · /chat — найти собеседника")


@router.callback_query(F.data.in_({"ch:go", "ch:next", "ch:stop", "ch:cancel"}))
async def cb_flow(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    act = cb.data[3:]
    uid = cb.from_user.id
    if act == "cancel":
        QUEUE[:] = [s for s in QUEUE if s.uid != uid]
        return await cb.message.answer("✖️ поиск отменён")
    if act in ("next", "stop") and uid in PAIRS:
        await end_chat(bot, uid)
    if act in ("go", "next"):
        await search(bot, cb.message, uid)


# ================= оценка и жалобы =================
@router.callback_query(F.data.in_({"ch:like", "ch:dis"}))
async def cb_rate(cb: CallbackQuery):
    other = LAST.pop(cb.from_user.id, None)
    if not other:
        return await cb.answer("уже оценено")
    col = "likes" if cb.data == "ch:like" else "dislikes"
    await profile(other)
    await db.q_run(f"UPDATE chat_profiles SET {col}={col}+1 WHERE uid=?", other)
    await cb.answer("спасибо 💜")


@router.callback_query(F.data == "ch:rep")
async def cb_report(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    other = PAIRS.get(uid) or LAST.get(uid)
    if not other:
        return await cb.answer("не на кого жаловаться", show_alert=True)
    await db.q_run("INSERT OR IGNORE INTO chat_reports VALUES(?,?,?)", uid, other, int(time.time()))
    if PAIRS.get(uid) == other:
        await end_chat(bot, uid, quiet_self=True)
    LAST.pop(uid, None)
    await cb.answer("🚨 жалоба принята. вы больше не встретитесь", show_alert=True)
    n = (await db.q_one("SELECT COUNT(*) n FROM chat_reports WHERE target=? AND ts>?", other,
                        int(time.time()) - 86400))["n"]
    if n >= BAN_REPORTS:
        await profile(other)
        await db.q_run("UPDATE chat_profiles SET banned_until=? WHERE uid=?",
                       int(time.time()) + BAN_DAYS * 86400, other)
        QUEUE[:] = [s for s in QUEUE if s.uid != other]
        if other in PAIRS:
            await end_chat(bot, other)
        if config.OWNER_ID:
            try:
                await bot.send_message(config.OWNER_ID, f"🚨 анонимный чат: <code>{other}</code> забанен на {BAN_DAYS} дн. "
                                                        f"({n} жалоб за сутки)")
            except Exception:
                pass


# ================= пересылка сообщений =================
def in_pair(m: Message) -> bool:
    return bool(m.from_user and m.chat.type == "private" and m.from_user.id in PAIRS
                and not (m.text or "").startswith("/"))


@router.message(in_pair)
async def relay(m: Message, bot: Bot):
    uid = m.from_user.id
    other = PAIRS.get(uid)
    if not other:
        return
    text = m.text or m.caption or ""
    ents = (m.entities or []) + (m.caption_entities or [])
    if LINK.search(text) or any(e.type in ("url", "text_link", "mention") for e in ents):
        return await m.reply("🚫 ссылки и @ники в анонимном чате не передаю")
    heavy = m.photo or m.video or m.animation or m.voice or m.video_note or m.document or m.audio
    if heavy and (COUNT.get(uid, 0) < MEDIA_AFTER or COUNT.get(other, 0) < MEDIA_AFTER):
        return await m.reply(f"📵 фото, видео и голосовые — когда вы оба напишете хотя бы по {MEDIA_AFTER} сообщений")
    COUNT[uid] = COUNT.get(uid, 0) + 1
    try:
        if m.photo:
            await bot.send_photo(other, m.photo[-1].file_id, caption=m.caption, has_spoiler=True)
        elif m.video:
            await bot.send_video(other, m.video.file_id, caption=m.caption, has_spoiler=True)
        elif m.animation:
            await bot.send_animation(other, m.animation.file_id, caption=m.caption, has_spoiler=True)
        else:
            await bot.copy_message(other, m.chat.id, m.message_id)
    except (TelegramForbiddenError, TelegramBadRequest):
        await end_chat(bot, uid)


# ================= чистка очереди =================
async def loop(bot: Bot):
    while True:
        await asyncio.sleep(30)
        now = time.time()
        for s in [s for s in QUEUE if now - s.ts > QUEUE_TTL]:
            QUEUE.remove(s)
            try:
                await bot.send_message(s.uid, "😴 пока никого не нашлось — попробуй чуть позже",
                                       reply_markup=kb_rows([("🔎 Искать снова", "ch:go")]))
            except Exception:
                pass
