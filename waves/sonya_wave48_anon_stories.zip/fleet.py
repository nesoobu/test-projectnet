"""🛰 Все боты на одном сервере: здоровье, сердцебиение, тревоги, бэкап всех баз, рассылка через помощников.
Помощники описаны в /home/sonya/sonya/*.env (BOT_PROFILE + BOT_TOKEN + DB_FILE), службы — sonya-<профиль>."""
import asyncio
import gzip
import io
import logging
import os
import sqlite3
import time
import zipfile
from datetime import datetime
from pathlib import Path

import config

log = logging.getLogger("fleet")
HB_EVERY = 60
HB_STALE = 10 * 60          # нет сердцебиения 10 минут — бот считаем упавшим
NAMES = {"full": "🖤 Соня", "dl": "⬇️ скачивалка", "music": "🎵 музыка", "gw": "🎁 розыгрыши", "games": "🎮 игры",
         "anon": "💌 анонимки", "grp": "🛡 помощник групп", "stk": "🧩 стикеры"}


# ================= кто есть кто =================
def _parse_env(path: Path) -> dict:
    out = {}
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                out[k.strip()] = v.strip().strip('"').strip("'")
    except OSError:
        pass
    return out


def helpers() -> list[dict]:
    """Помощники: [{profile, name, token, db, service}] — по файлам *.env рядом с Соней."""
    out = []
    for p in sorted(config.BASE.glob("*.env")):
        env = _parse_env(p)
        prof = (env.get("BOT_PROFILE") or "").lower()
        if not prof or prof == "full" or not env.get("BOT_TOKEN"):
            continue
        out.append({"profile": prof, "name": NAMES.get(prof, prof), "token": env["BOT_TOKEN"],
                    "db": str(config.BASE / "data" / (env.get("DB_FILE") or f"{prof}.db")),
                    "service": f"sonya-{prof}", "env": p.name})
    return out


def all_bots() -> list[dict]:
    return [{"profile": "full", "name": NAMES["full"], "db": config.DB_PATH, "service": "sonya", "token": ""}] + helpers()


# ================= сердцебиение =================
async def hb_loop():
    import db
    while True:
        try:
            await db.kv_set("hb", str(int(time.time())))
        except Exception as e:
            log.info("hb: %s", e)
        await asyncio.sleep(HB_EVERY)


def read_hb(db_path: str) -> int:
    try:
        c = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=3)
        try:
            r = c.execute("SELECT v FROM kv WHERE k='hb'").fetchone()
            return int(r[0]) if r else 0
        finally:
            c.close()
    except (sqlite3.Error, ValueError):
        return 0


def users_of(db_path: str) -> list[int]:
    try:
        c = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True, timeout=3)
        try:
            return [r[0] for r in c.execute("SELECT id FROM users WHERE banned=0")]
        finally:
            c.close()
    except sqlite3.Error:
        return []


async def service(name: str) -> dict:
    """systemctl show — работает и без root. Нет systemd — пусто."""
    try:
        p = await asyncio.create_subprocess_exec(
            "systemctl", "show", name, "-p", "ActiveState", "-p", "MemoryCurrent", "-p", "ActiveEnterTimestamp",
            "-p", "NRestarts", stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL)
        out, _ = await asyncio.wait_for(p.communicate(), 5)
    except Exception:
        return {}
    d = dict(line.split("=", 1) for line in out.decode(errors="ignore").splitlines() if "=" in line)
    return d


def _ago(ts: int) -> str:
    s = int(time.time()) - ts
    return f"{s // 60} мин" if s < 3600 else f"{s // 3600} ч" if s < 86400 else f"{s // 86400} дн"


async def status_view() -> str:
    import ui
    lines = [ui.head("🩺", "Здоровье ботов", "все боты на этом сервере"), ""]
    for b in all_bots():
        sv = await service(b["service"])
        hb = read_hb(b["db"]) if b["profile"] != "full" else int(time.time())
        alive = (time.time() - hb) < HB_STALE if hb else False
        st = sv.get("ActiveState") or ""
        icon = "🟢" if alive and st in ("", "active") else "🟡" if alive else "🔴"
        mem = sv.get("MemoryCurrent", "")
        mem = f"{int(mem) // 1048576} МБ" if mem.isdigit() else "—"
        up = sv.get("ActiveEnterTimestamp", "")
        restarts = sv.get("NRestarts", "0")
        n = len(users_of(b["db"]))
        lines.append(f"{icon} <b>{b['name']}</b> · <code>{b['service']}</code>")
        lines.append(ui.hint(f"память {mem} · людей {n} · сердцебиение {_ago(hb) + ' назад' if hb else 'нет'}"
                             + (f" · перезапусков {restarts}" if restarts not in ("", "0") else "")
                             + (f" · с {up.split(' ', 1)[-1][:16]}" if up else "")))
    du = os.statvfs(str(config.BASE))
    free = du.f_bavail * du.f_frsize / 1024 ** 3
    lines += ["", ui.hint(f"💾 свободно на диске: {free:.1f} ГБ · 🔴 — бот молчит дольше 10 минут: "
                          "<code>systemctl restart имя_службы</code>")]
    return "\n".join(lines)


_alerted: dict[str, bool] = {}


async def watchdog(bot):
    """Только у Сони: помощник замолчал — пишу владельцу, ожил — тоже пишу."""
    await asyncio.sleep(120)
    while True:
        try:
            await check_once(bot)
        except Exception as e:
            log.warning("watchdog: %s", e)
        await asyncio.sleep(300)


async def check_once(bot):
    for h in helpers():
        hb = read_hb(h["db"])
        if not hb:
            continue
        dead = time.time() - hb > HB_STALE
        if dead and not _alerted.get(h["profile"]):
            _alerted[h["profile"]] = True
            await _say(bot, f"🔴 <b>{h['name']}</b> молчит {_ago(hb)}\n"
                            f"<code>systemctl restart {h['service']}</code>\n"
                            f"<code>journalctl -u {h['service']} -n 30 --no-pager</code>")
        elif not dead and _alerted.get(h["profile"]):
            _alerted[h["profile"]] = False
            await _say(bot, f"🟢 <b>{h['name']}</b> снова работает")


async def _say(bot, text: str):
    if config.OWNER_ID:
        try:
            await bot.send_message(config.OWNER_ID, text)
        except Exception as e:
            log.info("watchdog say: %s", e)


# ================= бэкап всех баз =================
def _dump_one(path: str) -> bytes | None:
    if not os.path.exists(path):
        return None
    tmp = path + ".fleetbak"
    src, dst = sqlite3.connect(path), sqlite3.connect(tmp)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    try:
        with open(tmp, "rb") as f:
            return f.read()
    finally:
        os.unlink(tmp)


def dump_all() -> bytes:
    """zip со всеми базами: sonya.db, dl.db, music.db, gw.db… (онлайн-копии, безопасно на ходу)."""
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        seen = set()
        for b in all_bots():
            if b["db"] in seen:
                continue
            seen.add(b["db"])
            data = _dump_one(b["db"])
            if data:
                z.writestr(Path(b["db"]).name, data)
    return buf.getvalue()


async def send_backup_all(bot, chat_id: int | None = None) -> str:
    from aiogram.types import BufferedInputFile
    chat_id = chat_id or config.OWNER_ID
    if not chat_id:
        return "нет OWNER_ID"
    data = await asyncio.to_thread(dump_all)
    if len(data) > config.TG_SEND_MAX:
        return f"архив больше {config.mb(config.TG_SEND_MAX)} — забери папку data/ с сервера"
    stamp = datetime.now().strftime("%Y-%m-%d_%H-%M")
    names = ", ".join(Path(b["db"]).name for b in all_bots() if os.path.exists(b["db"]))
    await bot.send_document(chat_id, BufferedInputFile(data, f"all_bots_{stamp}.zip"),
                            caption=f"💾 бэкап всех ботов · {len(data) // 1024} КБ\n<i>{names}</i>\n"
                                    "восстановить одну базу: распакуй и положи в /home/sonya/sonya/data/",
                            disable_notification=True)
    return "ok"


# ================= рассылка через помощников =================
async def content_of(bot, m) -> dict:
    """Что рассылаем: текст + (фото/видео байтами — file_id у каждого бота свой)."""
    c = {"text": m.html_text or "", "kind": "", "data": b""}
    obj = (m.photo[-1] if m.photo else None) or m.video or m.animation
    if obj:
        if (getattr(obj, "file_size", 0) or 0) > 20 * 1024 * 1024:
            raise ValueError("файл больше 20 МБ")
        buf = io.BytesIO()
        await bot.download(obj.file_id, destination=buf)
        c.update(kind="photo" if m.photo else "video" if m.video else "animation", data=buf.getvalue())
    return c


def make_bot(token: str):
    import tgapi   # помощники тоже на своём Bot API, если он есть
    return tgapi.make_bot(token)


async def broadcast_helper(h: dict, content: dict, progress=None) -> tuple[int, int]:
    from aiogram.exceptions import TelegramRetryAfter
    from aiogram.types import BufferedInputFile
    ids = users_of(h["db"])
    ok = fail = 0
    hb = make_bot(h["token"])
    file_id = None
    try:
        for uid in ids:
            for attempt in (1, 2):
                try:
                    if content["kind"]:
                        media = file_id or BufferedInputFile(content["data"], "file")
                        fn = {"photo": hb.send_photo, "video": hb.send_video, "animation": hb.send_animation}[content["kind"]]
                        sent = await fn(uid, media, caption=content["text"][:1024] or None)
                        if not file_id:
                            obj = (sent.photo[-1] if sent.photo else None) or sent.video or sent.animation
                            file_id = getattr(obj, "file_id", None)
                    else:
                        await hb.send_message(uid, content["text"][:4096])
                    ok += 1
                    break
                except TelegramRetryAfter as e:
                    await asyncio.sleep(e.retry_after)
                    if attempt == 2:
                        fail += 1
                except Exception:
                    fail += 1
                    break
            await asyncio.sleep(0.05)
    finally:
        await hb.session.close()
    return ok, fail
