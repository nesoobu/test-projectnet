"""Волна 49: реакции, «оцени меня» с рейтингом, вопрос дня, ночь без звука, срок маски, новая маска,
взаимное раскрытие в анонимном чате. BOT_PROFILE=anon python test_w49.py ../sonya"""
import asyncio
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "anon"
from aiogram.methods import SendMessage, SendPhoto, EditMessageReplyMarkup, EditMessageText


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    from handlers import anon, anonchat
    anon.night = lambda: False
    await dp.feed_update(bot, msg("/start", 10, 10, name="Тим"))
    code = anon.code_of(10)
    # ---- реакции ----
    await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20, name="Аня"))
    await dp.feed_update(bot, msg("привет!", 20, 20, name="Аня"))
    r = await db.q_one("SELECT * FROM anon_msgs WHERE from_uid=20")
    check("под анонимкой — реакции", "an:rx:" in str([m.reply_markup for m in H.sent(SendMessage, 10)][-1]))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:rx:{r['id']}:0", 10, 10, name="Тим"))
    to20 = [m for m in H.sent(SendMessage, 20)]
    check("реакция — автору, реплаем на его сообщение", to20 and "❤️" in to20[-1].text and "Тим" in to20[-1].text
          and to20[-1].reply_to_message_id == r["src_mid"])
    rr = await db.q_one("SELECT react, seen FROM anon_msgs WHERE id=?", r["id"])
    check("реакция записана и = прочитано", rr["react"] == "❤️" and rr["seen"] == 1
          and "❤️ ✓" in str(H.sent(EditMessageReplyMarkup)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:rx:{r['id']}:0", 10, 10, name="Тим"))
    check("та же реакция второй раз — без спама автору", not H.sent(SendMessage, 20))
    # ---- оцени меня ----
    for i, (u, n) in enumerate(((30, 9), (31, 7), (32, 10))):
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}_rate", u, u))
        if i == 0:
            check("«оцени меня» — кнопки 1–10", "an:rt:1" in kbs() and "an:rt:10" in kbs())
        await dp.feed_update(bot, cbq(f"an:rt:{n}", u, u))
    await dp.feed_update(bot, msg(f"/start a_{code}_rate", 33, 33))
    await dp.feed_update(bot, msg("ну где-то 6 из 10, не меньше", 33, 33))
    scores = sorted(x["score"] for x in await db.q_all("SELECT score FROM anon_msgs WHERE score>0"))
    check("оценки цифрой и словами записаны", scores == [6, 7, 9, 10])
    got = [m.text for m in H.sent(SendMessage, 10)]
    check("получатель видит оценку", any("⭐ 10/10" in t for t in H.texts()))
    SENT.clear()
    await dp.feed_update(bot, cbq("an:back", 10, 10))
    check("на главной — «⭐ Рейтинг · 4»", "Рейтинг · 4" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq("an:rating", 10, 10))
    ph = H.sent(SendPhoto)
    check("карточка рейтинга: средняя 8.0 и ссылка на «оцени»", ph and "8.0" in ph[-1].caption and "_rate" in ph[-1].caption)
    # ---- новая маска по желанию ----
    mk_old = await anon.mask_of(10, 20)
    await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20, name="Аня"))
    check("в приглашении — «🎭 Новая маска» (маска уже есть)", "an:nm" in kbs())
    await dp.feed_update(bot, cbq("an:nm", 20, 20))
    await dp.feed_update(bot, msg("я как будто новенькая", 20, 20, name="Аня"))
    mk_new = await db.q_one("SELECT * FROM anon_masks2 WHERE owner=10 AND sender=20 AND active=1")
    check("новая маска по просьбе анонима", mk_new["id"] != mk_old["id"])
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(10, 20, 0)")
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20, name="Аня"))
    check("блок по человеку, а не по маске — новая маска не спасает", "ограничил" in all_text())
    await db.q_run("DELETE FROM anon_blocks")
    # ---- срок маски — выбирает получатель ----
    SENT.clear()
    await dp.feed_update(bot, cbq("an:set", 10, 10))
    check("настройки: срок маски, ночь, вопрос дня", all(k in kbs() for k in ("an:mh", "an:qt", "an:dq")))
    await dp.feed_update(bot, cbq("an:mh", 10, 10))
    check("срок маски → сутки", await anon.ttl_of(10) == 24 * 3600)
    # ---- ночь без звука ----
    await dp.feed_update(bot, cbq("an:qt", 10, 10))
    anon.night = lambda: True
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start a_{code}", 21, 21))
    await dp.feed_update(bot, msg("ночное сообщение", 21, 21))
    m10 = [m for m in H.sent(SendMessage, 10)]
    check("ночью — без звука", m10 and m10[-1].disable_notification)
    await db.q_run("UPDATE anon_msgs SET ts=strftime('%s','now') WHERE from_uid=21")
    SENT.clear()
    await anon.send_morning(bot)
    check("утром — одна сводка", [m for m in H.sent(SendMessage, 10) if "пока ты спал" in m.text])
    anon.night = lambda: False
    # ---- вопрос дня ----
    await db.q_run("UPDATE users SET last_seen=strftime('%s','now')")
    SENT.clear()
    await anon.send_daily(bot, "2026-10-14")
    d = [m for m in H.sent(SendMessage, 10)]
    check("вопрос дня приходит с кнопкой «сторис»", d and anon.question_of_day("2026-10-14") in d[-1].text and "an:qd" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq("an:qd", 10, 10))
    check("вопрос дня → редактор сторис с этим текстом", H.sent(SendPhoto)
          and (await anon.story_style(10))["text"] == anon.question_of_day(__import__("datetime").datetime.now(
              __import__("persona").MSK).strftime("%Y-%m-%d")))
    await dp.feed_update(bot, cbq("an:dq0", 10, 10))
    SENT.clear()
    await anon.send_daily(bot, "2026-10-15")
    check("🔕 не присылать — больше не приходит", not H.sent(SendMessage, 10))
    # ---- взаимное раскрытие в анонимном чате ----
    for u in (40, 41):
        await dp.feed_update(bot, msg("/chat", u, u))
        await dp.feed_update(bot, cbq("ch:agree", u, u))
        await dp.feed_update(bot, cbq("ch:go", u, u))
    check("пара", anonchat.PAIRS.get(40) == 41)
    SENT.clear()
    await dp.feed_update(bot, cbq("ch:rv", 40, 40))
    check("один хочет — второму предложение, имён нет", "хочет обменяться" in all_text()
          and "tg://user" not in all_text())
    SENT.clear()
    await dp.feed_update(bot, cbq("ch:rv", 41, 41))
    links = [m for m in H.sent(SendMessage) if "tg://user" in m.text]
    check("оба согласны — оба видят друг друга", len(links) == 2 and {m.chat_id for m in links} == {40, 41})
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
