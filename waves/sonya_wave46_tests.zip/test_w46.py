"""Волна 46: анонимки — маски, ответы в ветке, входящие по маскам; 🎲 случайный анонимный чат.
BOT_PROFILE=anon python test_w46.py ../sonya"""
import asyncio
import sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "anon"
from aiogram.methods import SendMessage, CopyMessage, SendPhoto
from aiogram.types import PhotoSize


def all_text():
    return "\n".join(H.texts())


def kbs():
    return "\n".join(str(getattr(m, "reply_markup", "")) for m in SENT)


async def main():
    M, bot, dp = await setup()
    from handlers import anon, anonchat
    # владелец ссылки
    await dp.feed_update(bot, msg("/start", 10, 10, name="Тим"))
    code = anon.code_of(10)
    # ---------- маски ----------
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20, name="Аня"))
    check("пишущий видит, кому пишет", "для Тим" in all_text())
    SENT.clear()
    await dp.feed_update(bot, msg("привет, это я", 20, 20, name="Аня"))
    mk20 = await anon.mask_of(10, 20)
    to_owner = [m.text for m in H.sent(SendMessage, 10)]
    check("получатель видит маску", to_owner and mk20["mask"] in to_owner[-1])
    check("отправитель знает свою маску", any(mk20["mask"] in t and "у Тим ты" in t for t in H.texts()))
    await dp.feed_update(bot, cbq(f"an:more:{code}", 20, 20, name="Аня"))
    SENT.clear()
    await dp.feed_update(bot, msg("это снова я", 20, 20, name="Аня"))
    check("тот же аноним — та же маска", mk20["mask"] in [m.text for m in H.sent(SendMessage, 10)][-1])
    await dp.feed_update(bot, msg(f"/start a_{code}", 21, 21, name="Боря"))
    await dp.feed_update(bot, msg("а я другой", 21, 21, name="Боря"))
    mk21 = await anon.mask_of(10, 21)
    check("другой аноним — другая маска", mk21["mask"] != mk20["mask"])
    await dp.feed_update(bot, msg("/start", 11, 11, name="Маша"))
    other = await anon.mask_of(11, 20)
    check("у другого получателя — своя маска (отдельная запись)", other["id"] != mk20["id"])
    # переполнение: все комбинации заняты → номер
    adj, ani = anon.MASK_ADJ, anon.MASK_ANIMAL
    anon.MASK_ADJ, anon.MASK_ANIMAL = ["Хитрый"], ["🦊 Лис"]
    a = await anon.mask_of(12, 1001)
    b = await anon.mask_of(12, 1002)
    anon.MASK_ADJ, anon.MASK_ANIMAL = adj, ani
    check("маски кончились — добавляю номер", a["mask"] == "🦊 Хитрый Лис" and b["mask"] == "🦊 Хитрый Лис 2")
    # ---------- ответ владельца: реплаем и с именем ----------
    r = await db.q_one("SELECT * FROM anon_msgs WHERE from_uid=20 ORDER BY id LIMIT 1")
    await dp.feed_update(bot, cbq(f"an:re:{r['id']}", 10, 10, name="Тим"))
    SENT.clear()
    await dp.feed_update(bot, msg("и тебе привет", 10, 10, name="Тим"))
    head = [m for m in H.sent(SendMessage, 20)]
    check("ответ: с именем и реплаем на вопрос", head and "Тим" in head[-1].text
          and head[-1].reply_to_message_id == r["src_mid"])
    check("под ответом — «ответить Тим»", f"an:fu:{r['id']}" in kbs())
    # ---------- переписка веткой ----------
    await dp.feed_update(bot, cbq(f"an:fu:{r['id']}", 20, 20, name="Аня"))
    SENT.clear()
    await dp.feed_update(bot, msg("как дела?", 20, 20, name="Аня"))
    ans_mid = (await db.q_one("SELECT ans_mid FROM anon_msgs WHERE id=?", r["id"]))["ans_mid"]
    h = H.sent(SendMessage, 10)
    check("продолжение ложится в ветку у получателя", h and "продолжает переписку" in h[-1].text
          and h[-1].reply_to_message_id == ans_mid)
    last = await db.q_one("SELECT parent FROM anon_msgs ORDER BY id DESC LIMIT 1")
    check("родитель записан", last["parent"] == r["id"])
    # ---------- входящие по маскам ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/inbox", 10, 10, name="Тим"))
    t = all_text()
    check("входящие сгруппированы по маскам", mk20["mask"] in t and mk21["mask"] in t and f"an:th:{mk20['id']}" in kbs())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:th:{mk20['id']}", 10, 10, name="Тим"))
    check("ветка: вопросы и мои ответы", "и тебе привет" in all_text() and "как дела?" in all_text())
    await dp.feed_update(bot, cbq(f"an:lb:{mk20['id']}", 10, 10, name="Тим"))
    SENT.clear()
    await dp.feed_update(bot, msg("с работы", 10, 10, name="Тим"))
    check("подпись маски", (await anon.mask_of(10, 20))["label"] == "с работы" and "с работы" in all_text())
    SENT.clear()
    await dp.feed_update(bot, cbq(f"an:th:{mk20['id']}", 11, 11))
    from aiogram.methods import AnswerCallbackQuery
    check("чужую ветку открыть нельзя", "с работы" not in all_text()
          and any(isinstance(m, AnswerCallbackQuery) and m.show_alert for m in SENT))

    # ---------- 🎲 анонимный чат ----------
    for u in (30, 31, 32, 33, 34):
        await dp.feed_update(bot, msg("/chat", u, u))
        await dp.feed_update(bot, cbq("ch:agree", u, u))
    SENT.clear()
    await dp.feed_update(bot, cbq("ch:go", 30, 30))
    check("поиск: встал в очередь", any(s.uid == 30 for s in anonchat.QUEUE))
    await dp.feed_update(bot, cbq("ch:go", 31, 31))
    check("пара соединена", anonchat.PAIRS.get(30) == 31 and anonchat.PAIRS.get(31) == 30)
    SENT.clear()
    await dp.feed_update(bot, msg("привет! любишь музыку?", 30, 30))
    check("текст доходит копией", [m for m in H.sent(CopyMessage) if m.chat_id == 31])
    SENT.clear()
    await dp.feed_update(bot, msg("пиши мне @my_insta_acc", 30, 30))
    check("@ники не передаю", not H.sent(CopyMessage) and "не передаю" in all_text())
    ph = [PhotoSize(file_id="p", file_unique_id="p", width=1, height=1)]
    SENT.clear()
    await dp.feed_update(bot, msg(None, 30, 30, photo=ph))
    check("фото рано — не передаю", not H.sent(SendPhoto) and "5 сообщений" in all_text())
    for i in range(5):
        await dp.feed_update(bot, msg(f"раз {i}", 30, 30))
        await dp.feed_update(bot, msg(f"два {i}", 31, 31))
    SENT.clear()
    await dp.feed_update(bot, msg(None, 30, 30, photo=ph))
    sp = H.sent(SendPhoto)
    check("после 5 сообщений — фото под спойлером", sp and sp[-1].chat_id == 31 and sp[-1].has_spoiler)
    SENT.clear()
    await dp.feed_update(bot, msg("/stop", 30, 30))
    check("стоп: пара разорвана, обоим — оценка", 30 not in anonchat.PAIRS and "ch:like" in kbs()
          and len([m for m in H.sent(SendMessage) if "ch:like" in str(m.reply_markup)]) == 2)
    await dp.feed_update(bot, cbq("ch:like", 31, 31))
    check("лайк записан", (await db.q_one("SELECT likes FROM chat_profiles WHERE uid=30"))["likes"] == 1)
    # жалоба → больше не встретятся
    await dp.feed_update(bot, cbq("ch:rep", 30, 30))
    anonchat._recent.clear()
    await dp.feed_update(bot, cbq("ch:go", 30, 30))
    await dp.feed_update(bot, cbq("ch:go", 31, 31))
    check("после жалобы пару не сводим", anonchat.PAIRS.get(30) != 31)
    await dp.feed_update(bot, cbq("ch:cancel", 30, 30))
    await dp.feed_update(bot, cbq("ch:cancel", 31, 31))
    # 3 жалобы → бан
    await db.q_run("INSERT INTO chat_reports VALUES(32, 33, strftime('%s','now')), (34, 33, strftime('%s','now'))")
    anonchat.LAST[30] = 33
    await dp.feed_update(bot, cbq("ch:rep", 30, 30))
    check("3 жалобы за сутки — бан на неделю",
          (await db.q_one("SELECT banned_until FROM chat_profiles WHERE uid=33"))["banned_until"] > 0)
    SENT.clear()
    await dp.feed_update(bot, cbq("ch:go", 33, 33))
    check("забаненный не ищет", "закрыт" in all_text() and not any(s.uid == 33 for s in anonchat.QUEUE))
    # поиск по полу — только с Соней+
    SENT.clear()
    await dp.feed_update(bot, cbq("ch:want", 32, 32))
    check("поиск по полу без плюса — Соня+", "start=plus" in kbs())
    await dp.feed_update(bot, msg("/chat", 1, 1))
    await dp.feed_update(bot, cbq("ch:agree", 1, 1))
    await dp.feed_update(bot, cbq("ch:w:f", 1, 1))
    await dp.feed_update(bot, cbq("ch:g:m", 32, 32))
    await dp.feed_update(bot, cbq("ch:g:f", 34, 34))
    anonchat._recent.clear()
    await dp.feed_update(bot, cbq("ch:go", 32, 32))
    await dp.feed_update(bot, cbq("ch:go", 1, 1))
    check("ищу девушек — парня не дают", anonchat.PAIRS.get(1) is None)
    await dp.feed_update(bot, cbq("ch:go", 34, 34))
    check("ищу девушек — девушку дают", anonchat.PAIRS.get(1) == 34)
    # пока в чате — анонимку по ссылке не начать
    SENT.clear()
    await dp.feed_update(bot, msg(f"/start a_{code}", 34, 34))
    check("в чате — сначала /stop", "сначала /stop" in all_text())
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
