"""Волна 41: новые боты — 🎮 игры для чатов и 💌 анонимные вопросы. Профиль: аргумент 2 (games|anon)."""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "games"
from aiogram.methods import SendMessage, SetMyCommands, CopyMessage, EditMessageText


async def main():
    M, bot, dp = await setup()
    P = config.PROFILE
    SENT.clear()
    await M.setup_commands(bot)
    cmds = [c.command for m in SENT if isinstance(m, SetMyCommands) for c in m.commands]
    if P == "games":
        check("games: свои команды", {"mafia", "croc", "quiz", "melody"} <= set(cmds) and "draw" not in cmds)
        SENT.clear()
        await dp.feed_update(bot, msg("/start", 40, 40))
        kb = str(H.sent(SendMessage)[-1].reply_markup)
        check("games: старт — игры и «добавить в беседу»", "startgroup=games" in kb and "g:menu" in kb
              and "мафия" in H.sent(SendMessage)[-1].text)
        SENT.clear()
        await dp.feed_update(bot, cbq("g:menu", 40, 40))
        check("games: меню игр открывается", H.sent(EditMessageText) or H.sent(SendMessage))
        SENT.clear()
        await dp.feed_update(bot, cbq("m:home", 40, 40))
        t = [x.text for x in SENT if getattr(x, "text", None)]
        check("games: «‹ Меню» — на экран игр, не Сони", any("Игры для чата" in x for x in t))
        SENT.clear()
        await dp.feed_update(bot, msg("/quiz", -700, 41))
        check("games: викторина в группе", SENT)
        SENT.clear()
        await dp.feed_update(bot, msg("обнять", -700, 41, reply=H.reply_to(42, chat_id=-700)))
        check("games: РП «обнять»", any("🤗" in (getattr(x, "text", "") or "") and "id=42" in (getattr(x, "text", "") or "") for x in SENT))
        SENT.clear()
        await dp.feed_update(bot, msg("привет, как дела?", 40, 40))
        check("games: болтовни с ИИ нет — подсказка", any("Игры для чата" in (getattr(x, "text", "") or "") for x in SENT))
    else:
        from handlers import anon
        check("anon: свои команды", "link" in cmds and "mafia" not in cmds)
        SENT.clear()
        await dp.feed_update(bot, msg("/start", 10, 10))
        code = anon.code_of(10)
        check("anon: старт — личная ссылка", any(f"start=a_{code}" in (x.text or "") for x in H.sent(SendMessage)))
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20))
        check("anon: по ссылке — «напиши анонимно»", any("анонимное" in x.text for x in H.sent(SendMessage)))
        SENT.clear()
        await dp.feed_update(bot, msg("ты мне нравишься", 20, 20))
        cp = H.sent(CopyMessage)
        check("anon: доставлено получателю без автора", cp and cp[-1].chat_id == 10 and "an:re:" in str(cp[-1].reply_markup)
              and any(m.chat_id == 10 and "анонимное" in m.text for m in H.sent(SendMessage)))
        mid = (await db.q_one("SELECT id FROM anon_msgs ORDER BY id DESC LIMIT 1"))["id"]
        SENT.clear()
        await dp.feed_update(bot, cbq(f"an:re:{mid}", 10, 10))
        await dp.feed_update(bot, msg("спасибо! а кто ты?", 10, 10))
        cp = H.sent(CopyMessage)
        check("anon: ответ ушёл автору", cp and cp[-1].chat_id == 20
              and (await db.q_one("SELECT answered FROM anon_msgs WHERE id=?", mid))["answered"] == 1)
        # фильтр угроз
        await dp.feed_update(bot, msg(f"/start a_{code}", 21, 21))
        SENT.clear()
        await dp.feed_update(bot, msg("я найду тебя", 21, 21))
        check("anon: угрозы не передаю", not H.sent(CopyMessage) and any("не передам" in x.text for x in H.sent(SendMessage)))
        # блок
        await dp.feed_update(bot, cbq(f"an:bl:{mid}", 10, 10))
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}", 20, 20))
        check("anon: заблокированный не может писать", any("ограничил" in x.text for x in H.sent(SendMessage)))
        # своя ссылка, выключенный приём
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}", 10, 10))
        check("anon: своя ссылка — подсказка", any("твоя же" in x.text for x in H.sent(SendMessage)))
        await dp.feed_update(bot, cbq("an:toggle", 10, 10))
        SENT.clear()
        await dp.feed_update(bot, msg(f"/start a_{code}", 22, 22))
        check("anon: приём выключен — не пишут", any("не принимает" in x.text for x in H.sent(SendMessage)))
        await dp.feed_update(bot, cbq("an:toggle", 10, 10))
        # жалоба → владельцу бота
        await dp.feed_update(bot, msg(f"/start a_{code}", 23, 23))
        await dp.feed_update(bot, msg("гадость", 23, 23))
        mid2 = (await db.q_one("SELECT id FROM anon_msgs ORDER BY id DESC LIMIT 1"))["id"]
        SENT.clear()
        await dp.feed_update(bot, cbq(f"an:rep:{mid2}", 10, 10))
        check("anon: жалоба — владельцу бота с id автора", any(m.chat_id == 1 and "23" in m.text for m in H.sent(SendMessage)))
        # частота
        await dp.feed_update(bot, msg(f"/start a_{code}", 24, 24))
        for i in range(6):
            await dp.feed_update(bot, msg(f"/start a_{code}", 24, 24))
            await dp.feed_update(bot, msg(f"вопрос {i}", 24, 24))
        check("anon: не больше 5 в минуту", (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE from_uid=24"))["n"] == 5)
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
