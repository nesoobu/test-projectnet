"""Волна 67: сеть до Telegram моргнула — повтор запроса (только если не подключились), пост автопостинга
не бракуется, а переносится; одиночный сетевой сбой не шлёт владельцу алерт.
python test_w67.py ../sonya full"""
import asyncio, logging, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.exceptions import TelegramNetworkError
from aiogram.methods import SendMessage


def neterr(text):
    return TelegramNetworkError(method=SendMessage(chat_id=1, text="x"), message=text)


async def main():
    M, bot, dp = await setup()
    import middlewares, system
    from autopost import engine, store

    # ---------- повтор в сессии ----------
    middlewares.NetRetry.DELAYS = (0, 0, 0)
    nr = middlewares.NetRetry()
    calls = []

    async def flaky(bot_, method):
        calls.append(1)
        if len(calls) < 3:
            raise neterr("HTTP Client says - ClientConnectorError: Cannot connect to host api.telegram.org:443 "
                         "ssl:default [Connection reset by peer]")
        return "ok"
    r = await nr(flaky, bot, SendMessage(chat_id=1, text="x"))
    check("не подключились 2 раза — третья попытка прошла", r == "ok" and len(calls) == 3)
    calls.clear()

    async def timeout(bot_, method):
        calls.append(1)
        raise neterr("HTTP Client says - Request timeout error")
    try:
        await nr(timeout, bot, SendMessage(chat_id=1, text="x"))
        ok = False
    except TelegramNetworkError:
        ok = True
    check("таймаут после отправки — НЕ повторяю (иначе дубль)", ok and len(calls) == 1)
    calls.clear()

    async def down(bot_, method):
        calls.append(1)
        raise neterr("ClientConnectorError: Cannot connect to host")
    try:
        await nr(down, bot, SendMessage(chat_id=1, text="x"))
        ok = False
    except TelegramNetworkError:
        ok = True
    check("сеть лежит — 1 + 3 повтора, потом честная ошибка", ok and len(calls) == 4)

    # ---------- автопостинг ----------
    await db.q_run("INSERT INTO ap_channels(chat_id, owner_id, title, added) VALUES(-1007, 1, 'Канал', 0)")
    pid = await db.q_run("INSERT INTO ap_posts(owner_id, text, created) VALUES(1, 'пост', 0)")
    sid = await db.q_run("INSERT INTO ap_schedule(post_id, chat_id, at) VALUES(?, -1007, ?)", pid, int(time.time()) - 5)
    fails = [0]

    async def boom(bot_, s):
        fails[0] += 1
        raise neterr("ClientConnectorError: Cannot connect to host api.telegram.org:443 [Connection reset by peer]")
    engine.publish_row = boom
    await engine.publish_due(bot)
    s = await store.sched(sid)
    check("сбой сети — пост не «failed», а снова в очереди через 2 мин", s["status"] == "queued"
          and s["err"] == "net:1" and s["at"] > time.time() + 60)
    for _ in range(engine.NET_TRIES):
        await db.q_run("UPDATE ap_schedule SET at=? WHERE id=?", int(time.time()) - 5, sid)
        await engine.publish_due(bot)
    s = await store.sched(sid)
    check(f"после {engine.NET_TRIES} попыток — «failed» (не крутимся вечно)", s["status"] == "failed"
          and fails[0] == engine.NET_TRIES)
    sent = []

    async def okpub(bot_, s):
        sent.append(s["id"])
    engine.publish_row = okpub
    await db.q_run("UPDATE ap_schedule SET status='queued', err='net:2', at=? WHERE id=?", int(time.time()) - 5, sid)
    await engine.publish_due(bot)
    check("сеть вернулась — пост вышел", sent == [sid])

    # ---------- алерты владельцу ----------
    al = system.OwnerAlerts(bot)
    SENT.clear()
    log = logging.getLogger("autopost.engine")
    log.addHandler(al)
    try:
        raise neterr("ClientConnectorError: Cannot connect to host api.telegram.org:443 [Connection reset by peer]")
    except TelegramNetworkError:
        log.exception("publish 138")
    await asyncio.sleep(0.05)
    check("один сетевой сбой — владельца не дёргаю", not H.sent(SendMessage))
    for i in range(system.NET_ALERT):
        try:
            raise neterr("ClientConnectorError: Cannot connect to host")
        except TelegramNetworkError:
            log.exception("publish %s", 200 + i)
    await asyncio.sleep(0.05)
    msgs = [m.text for m in H.sent(SendMessage)]
    check("много сбоев за 10 минут — одно сообщение «связь барахлит»", len(msgs) == 1 and "барахлит" in msgs[0])
    try:
        raise ValueError("настоящая ошибка")
    except ValueError:
        log.exception("rules")
    await asyncio.sleep(0.05)
    check("обычные ошибки — как раньше приходят", any("настоящая ошибка" in (m.text or "") for m in H.sent(SendMessage)))
    log.removeHandler(al)

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
