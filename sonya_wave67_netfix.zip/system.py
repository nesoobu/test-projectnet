"""Надёжность: ежедневный бэкап базы владельцу и отчёты об ошибках в личку."""
import asyncio
import gzip
import hashlib
import logging
import os
import shutil
import sqlite3
import subprocess
import time
from datetime import datetime, timedelta

from aiogram import Bot
from aiogram.types import BufferedInputFile

import config
from persona import MSK

log = logging.getLogger("system")
BACKUP_HOUR = 4          # каждый день в 04:00 мск
MAX_FILE = config.TG_SEND_MAX


# ================= бэкап =================
# волна 61: в базах анонимки (кто кому писал), переписка ассистента — открытым файлом в телеграм их не шлём.
# Расшифровать на сервере (спросит пароль): openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000 -in ФАЙЛ.enc -out ФАЙЛ
DECRYPT = "openssl enc -d -aes-256-cbc -pbkdf2 -iter 200000"


def seal(data: bytes) -> tuple[bytes, bool]:
    """Шифрует паролем BACKUP_PASS (AES-256, PBKDF2 200 000 кругов). Нет пароля/openssl — (data, False)."""
    if not config.BACKUP_PASS or not shutil.which("openssl"):
        return data, False
    r = subprocess.run(["openssl", "enc", "-aes-256-cbc", "-pbkdf2", "-iter", "200000", "-salt",
                        "-pass", "env:SONYA_BACKUP_PASS"],   # пароль через окружение — в списке процессов не видно
                       input=data, capture_output=True, timeout=600,
                       env={**os.environ, "SONYA_BACKUP_PASS": config.BACKUP_PASS})
    if r.returncode != 0 or not r.stdout:
        raise RuntimeError("бэкап не зашифровался: " + r.stderr.decode(errors="ignore")[:200])
    return r.stdout, True


def backup_state() -> str:
    """Строка для «🗂 Сервер»."""
    if not config.BACKUP_PASS:
        return "🔓 без пароля — добавь BACKUP_PASS в .env"
    if not shutil.which("openssl"):
        return "🔓 нет openssl — шифровать нечем"
    return "🔐 шифрую паролем из BACKUP_PASS"


def _dump() -> bytes:
    src = sqlite3.connect(config.DB_PATH)
    tmp = config.DB_PATH + ".bak"
    dst = sqlite3.connect(tmp)
    try:
        src.backup(dst)          # онлайн-копия: безопасно, пока бот пишет в базу
    finally:
        dst.close()
        src.close()
    with open(tmp, "rb") as f:
        data = gzip.compress(f.read(), 6)
    try:
        import os
        os.unlink(tmp)
    except OSError:
        pass
    return data


async def send_backup(bot: Bot, chat_id: int | None = None) -> str:
    chat_id = chat_id or config.OWNER_ID
    if not chat_id:
        return "нет OWNER_ID"
    data = await asyncio.to_thread(_dump)
    data, sealed = await asyncio.to_thread(seal, data)
    if len(data) > MAX_FILE:
        await bot.send_message(chat_id, f"⚠️ бэкап {len(data) // 1024 // 1024} МБ — больше лимита телеграма, "
                                        "забери с сервера: data/sonya.db")
        return "слишком большой"
    stamp = datetime.now(MSK).strftime("%Y-%m-%d_%H-%M")
    await bot.send_document(chat_id, BufferedInputFile(data, f"sonya_{stamp}.db.gz" + (".enc" if sealed else "")),
                            caption=f"💾 бэкап базы · {len(data) // 1024} КБ\n"
                                    + ("🔐 зашифрован паролем BACKUP_PASS\n" if sealed else
                                       "🔓 открытым файлом — задай BACKUP_PASS в .env\n")
                                    + "<i>восстановление: /admin → 🗂 Сервер</i>",
                            disable_notification=True)
    return "ok"


async def backup_loop(bot: Bot):
    while True:
        now = datetime.now(MSK)
        nxt = now.replace(hour=BACKUP_HOUR, minute=0, second=0, microsecond=0)
        if nxt <= now:
            nxt += timedelta(days=1)
        await asyncio.sleep((nxt - now).total_seconds())
        try:
            import fleet   # все боты одним архивом; не вышло — хотя бы база Сони
            if not fleet.helpers() or await fleet.send_backup_all(bot) != "ok":
                await send_backup(bot)
        except Exception as e:
            log.warning("backup: %s", e)
            try:
                await send_backup(bot)
            except Exception as e2:   # волна 61: раньше молчали — а без бэкапа владелец должен знать
                log.error("бэкап не ушёл: %s", e2)


# ================= ошибки → владельцу =================
NET_ALERT = 5   # волна 67: столько сетевых сбоев за 10 мин — тогда одно сообщение владельцу


class OwnerAlerts(logging.Handler):
    """ERROR и выше уходят владельцу в личку. Одинаковые — не чаще раза в 30 мин, всего не больше 15 в час."""

    def __init__(self, bot: Bot):
        super().__init__(level=logging.ERROR)
        self.bot = bot
        self.seen: dict[str, float] = {}
        self.window: list[float] = []

    def emit(self, record: logging.LogRecord):
        if not config.OWNER_ID or record.name.startswith("system"):
            return
        if record.name.startswith("aiogram.dispatcher") and "Failed to fetch updates" in record.getMessage():
            return   # сетевой чих при опросе телеграма — aiogram сам переподключится
        try:
            msg = record.getMessage()
            low = msg.lower()
            # безобидные ошибки тайминга UI — не дёргаем владельца (устаревшие кнопки, пустые правки)
            if any(s in low for s in ("query is too old", "query id is invalid", "message is not modified",
                                      "message to edit not found", "message can't be deleted",
                                      "message to delete not found", "message to be replied not found")):
                return
            now = time.time()
            # волна 67: сетевой чих до Telegram (connection reset / не подключились) — не шлём каждый.
            # Пишем владельцу один раз, только если сбоев ≥ NET_ALERT за 10 минут — значит, связь правда лежит.
            tb_text = ""
            if record.exc_info and record.exc_info[1] is not None:
                tb_text = f"{type(record.exc_info[1]).__name__}: {record.exc_info[1]}"
            if any(s in (low + tb_text.lower()) for s in ("telegramnetworkerror", "cannot connect to host",
                                                          "connection reset by peer", "server disconnected")):
                self.net = [t for t in getattr(self, "net", []) if now - t < 600] + [now]
                if len(self.net) < NET_ALERT or now - getattr(self, "net_said", 0) < 3600:
                    return
                self.net_said = now
                loop = asyncio.get_running_loop()
                loop.create_task(self._send(f"📡 <b>связь с Telegram барахлит</b>: {len(self.net)} сбоев за 10 минут.\n"
                                            "проверь сеть сервера: <code>ping -c3 api.telegram.org</code>"))
                return
            key = hashlib.md5(f"{record.name}:{msg[:120]}".encode()).hexdigest()
            if now - self.seen.get(key, 0) < 1800:
                return
            self.window = [t for t in self.window if now - t < 3600]
            if len(self.window) >= 15:
                return
            self.seen[key] = now
            self.window.append(now)
            text = msg
            if record.exc_info:
                import traceback
                tb = "".join(traceback.format_exception(*record.exc_info))
                text += "\n" + tb[-1500:]
            from html import escape
            body = f"🚨 <b>ошибка</b> · <code>{escape(record.name)}</code>\n<pre>{escape(text[-3000:])}</pre>"
            loop = asyncio.get_running_loop()
            loop.create_task(self._send(body))
        except RuntimeError:
            pass  # нет цикла событий — не страшно
        except Exception:
            pass

    async def _send(self, body: str):
        try:
            await self.bot.send_message(config.OWNER_ID, body, disable_notification=True)
        except Exception:
            pass


def install_alerts(bot: Bot):
    logging.getLogger().addHandler(OwnerAlerts(bot))
