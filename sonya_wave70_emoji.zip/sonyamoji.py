"""Волна 68: анимированные премиум-эмодзи Сони (custom emoji). Рисуем сами — PIL + ffmpeg (VP9 с прозрачностью),
как требует Telegram: 100×100, ≤3 с, ≤30 к/с, ≤256 КБ, без звука. Пак создаёт бот (createNewStickerSet,
sticker_type=custom_emoji), владелец пака — тот, кто нажал «создать» в админке.
Единый стиль: фирменный градиент розовый→фиолетовый, белые блики, мягкая тень; рисуем в 4× и уменьшаем (гладкие края)."""
import io
import math
import os
import shutil
import subprocess
import tempfile

from PIL import Image, ImageDraw, ImageFilter, ImageFont

import banners

S = 400            # холст рисования (потом → 100×100)
OUT = 100
FPS, SECONDS = 30, 2
PINK, VIOLET, DEEP = (255, 92, 170), (150, 80, 255), (70, 30, 140)
GOLD, GOLD_D = (255, 205, 70), (210, 140, 20)
WHITE = (255, 255, 255)


def _lerp(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def _grad_fill(size, c1, c2) -> Image.Image:
    """Вертикальный градиент на весь холст — заливаем через маску фигуры."""
    g = Image.new("RGB", (1, size))
    for y in range(size):
        g.putpixel((0, y), _lerp(c1, c2, y / (size - 1)))
    return g.resize((size, size))


def _shape(draw_fn, c1=PINK, c2=VIOLET, outline=True) -> Image.Image:
    """Фигура с градиентом и тёмной обводкой (стикерный стиль)."""
    mask = Image.new("L", (S, S), 0)
    draw_fn(ImageDraw.Draw(mask), 255)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    if outline:
        # обводка ~12 px: размытие + порог в разы быстрее MaxFilter(25) при том же виде
        edge = mask.filter(ImageFilter.GaussianBlur(7)).point(lambda v: 255 if v > 8 else v * 30)
        im.paste(Image.new("RGBA", (S, S), DEEP + (255,)), (0, 0), edge)
    im.paste(_grad_fill(S, c1, c2).convert("RGBA"), (0, 0), mask)
    return im


def _shine(im: Image.Image, box, alpha=150):
    """Белый блик-овал."""
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(layer).ellipse(box, fill=(255, 255, 255, alpha))
    im.alpha_composite(layer.filter(ImageFilter.GaussianBlur(6)))


def _star_pts(cx, cy, r1, r2, n=5, rot=-math.pi / 2):
    return [(cx + math.cos(rot + i * math.pi / n) * (r1 if i % 2 == 0 else r2),
             cy + math.sin(rot + i * math.pi / n) * (r1 if i % 2 == 0 else r2)) for i in range(2 * n)]


def _heart_pts(cx, cy, r, steps=60):
    pts = []
    for i in range(steps):
        a = 2 * math.pi * i / steps
        x = 16 * math.sin(a) ** 3
        y = -(13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a))
        pts.append((cx + x * r / 17, cy + y * r / 17))
    return pts


def _transform(im: Image.Image, scale=1.0, angle=0.0, dx=0, dy=0, sx=None, sy=None) -> Image.Image:
    sx, sy = sx or scale, sy or scale
    w, h = max(1, int(S * sx)), max(1, int(S * sy))
    t = im.resize((w, h), Image.LANCZOS)
    if angle:
        t = t.rotate(angle, resample=Image.BICUBIC, expand=True)
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.alpha_composite(t, (int((S - t.width) / 2 + dx), int((S - t.height) / 2 + dy))) if t.width <= S and t.height <= S \
        else out.paste(t.crop(((t.width - S) // 2, (t.height - S) // 2, (t.width + S) // 2, (t.height + S) // 2)),
                       (int(dx), int(dy)))
    return out


def _beat(t):   # «тук-тук» сердца
    return max(math.exp(-((t - 0.1) / 0.06) ** 2), 0.7 * math.exp(-((t - 0.32) / 0.06) ** 2))


# ================= сами эмодзи: f(t) → RGBA S×S, t ∈ [0,1) =================
def heart(t):
    base = _shape(lambda d, f: d.polygon(_heart_pts(S / 2, S / 2 + 10, 150), fill=f))
    _shine(base, [110, 110, 170, 160])
    return _transform(base, 0.9 + 0.12 * _beat(t))


def sparkles(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for cx, cy, r, ph in ((175, 210, 120, 0.0), (300, 110, 62, 0.33), (305, 300, 50, 0.66)):
        k = 0.55 + 0.45 * (0.5 + 0.5 * math.sin(2 * math.pi * (t + ph)))
        rr = r * k
        st = _shape(lambda d, f: d.polygon(_star_pts(cx, cy, rr, rr * 0.28, 4), fill=f), GOLD, PINK)
        im.alpha_composite(st)
    return im


def dice(t):
    e = 0.5 - 0.5 * math.cos(2 * math.pi * t)
    base = _shape(lambda d, f: d.rounded_rectangle([90, 90, 310, 310], radius=50, fill=f), (255, 255, 255), (230, 220, 255))
    d = ImageDraw.Draw(base)
    for x, y in ((140, 140), (200, 200), (260, 260), (260, 140), (140, 260)):
        d.ellipse([x - 22, y - 22, x + 22, y + 22], fill=VIOLET)
    _shine(base, [110, 105, 180, 135], 120)
    return _transform(base, 0.92, angle=360 * e, dy=-40 * math.sin(math.pi * t))


def coin(t):
    c = math.cos(2 * math.pi * t)
    base = _shape(lambda d, f: d.ellipse([70, 70, 330, 330], fill=f), GOLD, GOLD_D)
    d = ImageDraw.Draw(base)
    d.ellipse([110, 110, 290, 290], outline=(255, 235, 150), width=12)
    if c > 0:
        d.text((200, 205), "S", font=banners._font(banners.HEAD_FONT, 150), fill=(255, 245, 200), anchor="mm")
    _shine(base, [100, 95, 170, 140], 140)
    return _transform(base, 0.95, sx=0.95 * max(0.08, abs(c)), sy=0.95)


def gift(t):
    hop = max(0.0, math.sin(math.pi * min(1, max(0, (t - 0.15) / 0.3))))
    shake = math.sin(2 * math.pi * t * 4) * 6 * (1 - hop) * (t < 0.15)
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    box = _shape(lambda d, f: d.rounded_rectangle([90, 175, 310, 340], radius=24, fill=f), PINK, VIOLET)
    d = ImageDraw.Draw(box)
    d.rectangle([182, 175, 218, 340], fill=GOLD)
    im.alpha_composite(box)
    lid = _shape(lambda d, f: d.rounded_rectangle([75, 120, 325, 185], radius=20, fill=f), (255, 140, 200), PINK)
    d = ImageDraw.Draw(lid)
    d.rectangle([182, 120, 218, 185], fill=GOLD)
    for side in (-1, 1):   # бант
        d.ellipse([200 + side * 70 - 45, 70, 200 + side * 70 + 45, 125], outline=GOLD, width=18)
    im.alpha_composite(_transform(lid, 1.0, angle=-12 * hop, dy=-60 * hop))
    return _transform(im, 0.95, angle=shake)


def trophy(t):
    def cup(d, f):
        d.pieslice([100, 30, 300, 260], 0, 180, fill=f)
        d.rectangle([100, 90, 300, 145], fill=f)
        d.rectangle([180, 240, 220, 300], fill=f)
        d.rounded_rectangle([120, 295, 280, 345], radius=14, fill=f)
        for side in (-1, 1):
            d.arc([200 + side * 125 - 55, 100, 200 + side * 125 + 55, 210], 0, 360, fill=f, width=22)
    base = _shape(cup, GOLD, GOLD_D)
    band = Image.new("L", (S, S), 0)
    x = -150 + 700 * t
    ImageDraw.Draw(band).polygon([(x, 0), (x + 60, 0), (x - 140, S), (x - 200, S)], fill=200)
    a = base.split()[3]
    shine = Image.new("RGBA", (S, S), (255, 255, 255, 0))
    shine.putalpha(Image.composite(band, Image.new("L", (S, S), 0), a).filter(ImageFilter.GaussianBlur(4)))
    base.alpha_composite(shine)
    return base


def megaphone(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    body = _shape(lambda d, f: (d.polygon([(70, 170), (220, 90), (220, 310), (70, 230)], fill=f),
                                d.rounded_rectangle([40, 165, 95, 235], radius=12, fill=f)))
    _shine(body, [150, 120, 205, 170], 110)
    im.alpha_composite(body)
    d = ImageDraw.Draw(im)
    for i in range(3):
        k = (t * 1.5 - i * 0.2) % 1
        if k < 0.7:
            a = int(255 * (1 - k / 0.7))
            r = 50 + i * 45
            d.arc([235 - r, 200 - r, 235 + r, 200 + r], -45, 45, fill=PINK + (a,), width=16)
    return im


def bolt(t):
    pts = [(230, 40), (110, 220), (195, 220), (165, 360), (295, 165), (210, 165), (250, 40)]
    base = _shape(lambda d, f: d.polygon(pts, fill=f), GOLD, (255, 140, 60))
    glow = base.split()[3].filter(ImageFilter.GaussianBlur(26))
    k = 0.55 + 0.45 * abs(math.sin(2 * math.pi * t * 2))
    g = Image.new("RGBA", (S, S), PINK + (0,))
    g.putalpha(glow.point(lambda v: int(v * k)))
    out = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    out.alpha_composite(g)
    out.alpha_composite(base)
    return out


def star(t):
    base = _shape(lambda d, f: d.polygon(_star_pts(200, 210, 160, 70), fill=f), GOLD, (255, 150, 60))
    _shine(base, [140, 120, 200, 170], 130)
    return _transform(base, 0.9 + 0.06 * math.sin(2 * math.pi * t), angle=14 * math.sin(2 * math.pi * t))


def gear(t):
    def g(d, f):
        for i in range(8):
            a = i * math.pi / 4
            d.polygon([(200 + math.cos(a - 0.22) * 120, 200 + math.sin(a - 0.22) * 120),
                       (200 + math.cos(a - 0.15) * 170, 200 + math.sin(a - 0.15) * 170),
                       (200 + math.cos(a + 0.15) * 170, 200 + math.sin(a + 0.15) * 170),
                       (200 + math.cos(a + 0.22) * 120, 200 + math.sin(a + 0.22) * 120)], fill=f)
        d.ellipse([60, 60, 340, 340], fill=f)
        d.ellipse([150, 150, 250, 250], fill=0)
    base = _shape(g, (190, 200, 230), VIOLET)
    return _transform(base, 0.92, angle=-360 * t / 4)


def question(t):
    b = abs(math.sin(math.pi * t * 2))
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    base = _shape(lambda d, f: d.text((200, 215), "?", font=banners._font(banners.HEAD_FONT, 330), fill=f, anchor="mm"))
    im.alpha_composite(base)
    squash = 1 - 0.12 * (b < 0.15)
    return _transform(im, 0.95, dy=-45 * b, sx=0.95 / squash, sy=0.95 * squash)


def bubble(t):
    base = _shape(lambda d, f: (d.rounded_rectangle([50, 80, 350, 290], radius=80, fill=f),
                                d.polygon([(110, 270), (90, 350), (180, 285)], fill=f)), (255, 255, 255), (225, 215, 255))
    d = ImageDraw.Draw(base)
    for i in range(3):
        y = 185 - 22 * max(0.0, math.sin(2 * math.pi * (t * 1.5 - i * 0.15)))
        d.ellipse([125 + i * 75 - 24, y - 24, 125 + i * 75 + 24, y + 24], fill=VIOLET)
    return base


def plane(t):
    a = 2 * math.pi * t
    base = _shape(lambda d, f: (d.polygon([(40, 210), (360, 70), (240, 330)], fill=f)), (255, 255, 255), (200, 190, 255))
    d = ImageDraw.Draw(base)
    d.polygon([(360, 70), (150, 230), (175, 320)], fill=(170, 150, 240))
    return _transform(base, 0.8, angle=8 * math.sin(a), dx=30 * math.sin(a), dy=-22 * math.sin(2 * a))


def bulb(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    k = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    d = ImageDraw.Draw(im)
    for i in range(8):
        a = -math.pi + i * math.pi / 7
        r1, r2 = 150, 150 + 40 * k
        d.line([(200 + math.cos(a) * r1, 175 + math.sin(a) * r1), (200 + math.cos(a) * r2, 175 + math.sin(a) * r2)],
               fill=GOLD + (int(120 + 135 * k),), width=16)
    glass = _shape(lambda d2, f: (d2.ellipse([90, 60, 310, 280], fill=f), d2.rectangle([150, 240, 250, 300], fill=f)),
                   _lerp((255, 240, 150), GOLD, 1 - k), GOLD)
    d2 = ImageDraw.Draw(glass)
    d2.rounded_rectangle([145, 295, 255, 350], radius=14, fill=(160, 160, 190))
    _shine(glass, [130, 95, 190, 160], 160)
    im.alpha_composite(glass)
    return im


# ================= волна 70: лицо Сони с эмоциями =================
EYE = (60, 40, 110)
INK = (40, 30, 70)
LIP = (150, 60, 90)
TEAR = (120, 190, 255)
HAIR = (45, 38, 90)


def _drop(d, x, y, r, fill=TEAR):
    """Капля (слеза/пот): круг + острый верх."""
    d.ellipse([x - r, y - r, x + r, y + r], fill=fill)
    d.polygon([(x - r * 0.9, y - r * 0.3), (x, y - r * 2.3), (x + r * 0.9, y - r * 0.3)], fill=fill)


def _zz(d, x, y, size, alpha):
    f = banners._font(banners.HEAD_FONT, int(size))
    d.text((x, y), "z", font=f, fill=(170, 150, 255, alpha), anchor="mm", stroke_width=max(2, int(size / 9)),
           stroke_fill=(70, 30, 140, alpha))


def _head(blush=1.0, tint=None):
    """Волосы, лицо, чёлка, наушники — общая основа всех эмоций."""
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    im.alpha_composite(_shape(lambda d, f: (d.ellipse([55, 45, 345, 335], fill=f), d.rectangle([55, 190, 345, 330], fill=f)),
                              (60, 50, 110), (30, 26, 60)))
    c1, c2 = (255, 232, 220), (255, 210, 200)
    if tint:   # злость — лицо краснеет
        c1, c2 = _lerp(c1, (255, 120, 110), tint), _lerp(c2, (240, 80, 80), tint)
    im.alpha_composite(_shape(lambda d, f: d.ellipse([95, 105, 305, 315], fill=f), c1, c2, outline=False))
    d = ImageDraw.Draw(im)
    d.polygon([(85, 150), (200, 85), (315, 150), (290, 120), (200, 70), (110, 120)], fill=HAIR)   # чёлка
    d.pieslice([90, 70, 310, 200], 180, 360, fill=HAIR)
    if blush:
        bl = Image.new("RGBA", (S, S), (0, 0, 0, 0))
        bd = ImageDraw.Draw(bl)
        for ex in (130, 270):
            w, h = 22 * (0.8 + 0.4 * blush), 12 * (0.8 + 0.4 * blush)
            bd.ellipse([ex - w, 256 - h, ex + w, 256 + h], fill=(255, 120, 160, int(min(255, 150 * blush))))
        im.alpha_composite(bl.filter(ImageFilter.GaussianBlur(4)))
    return im


def _phones(d):
    d.arc([40, 30, 360, 330], 200, 340, fill=VIOLET, width=26)   # дужка наушников
    for ex in (52, 348):
        d.rounded_rectangle([ex - 32, 170, ex + 32, 265], radius=22, fill=PINK, outline=DEEP, width=8)


def _eyes_open(d, dx=0, dy=0, big=1.0, pupil=1.0):
    for ex in (155, 245):
        rx, ry = 22 * big, 27 * big
        d.ellipse([ex - rx, 218 - ry, ex + rx, 218 + ry], fill=EYE)
        px, py = ex + dx, 218 + dy
        if pupil < 1:   # «шок» — маленькие зрачки на белом
            d.ellipse([ex - rx, 218 - ry, ex + rx, 218 + ry], fill=WHITE, outline=EYE, width=7)
            d.ellipse([px - 11, py - 11, px + 11, py + 11], fill=EYE)
        else:
            d.ellipse([px - 9 * big - 3, py - 18 * big, px + 3, py - 4 * big], fill=WHITE)


def _eyes_closed(d, up=True, y=222):
    for ex in (155, 245):
        if up:    # ^ ^ — довольная
            d.arc([ex - 26, y - 14, ex + 26, y + 26], 200, 340, fill=INK, width=9)
        else:     # ‿ ‿ — спит / плачет
            d.arc([ex - 26, y - 26, ex + 26, y + 14], 20, 160, fill=INK, width=9)


def _brows(d, inner, outer=0, y=180):
    """inner>0 — внутренние концы вверх (грусть), inner<0 — вниз (злость)."""
    for ex, s in ((155, 1), (245, -1)):
        x_in, x_out = ex + 26 * s, ex - 26 * s
        d.line([(x_out, y - outer), (x_in, y - inner)], fill=HAIR, width=10)


def _mouth(d, kind, k=0.0):
    if kind == "smile":
        d.arc([178, 248, 222, 282], 20, 160, fill=LIP, width=7)
    elif kind == "grin":
        d.chord([168, 245, 232, 300], 0, 180, fill=LIP)
        d.chord([182, 268, 218, 300], 0, 180, fill=(255, 130, 150))
    elif kind == "laugh":
        h = 40 + 12 * k
        d.chord([160, 240, 240, 240 + h * 1.6], 0, 180, fill=LIP)
        d.chord([175, 240 + h * 0.6, 225, 240 + h * 1.6], 0, 180, fill=(255, 130, 150))
    elif kind == "frown":
        d.arc([178, 268, 222, 300], 200, 340, fill=LIP, width=7)
    elif kind == "o":
        r = 12 + 5 * k
        d.ellipse([200 - r, 278 - r * 1.2, 200 + r, 278 + r * 1.2], fill=LIP)
    elif kind == "wavy":
        pts = [(176 + i * 4, 280 + 5 * math.sin(i * 0.9 + k * 6)) for i in range(13)]
        d.line(pts, fill=LIP, width=7, joint="curve")
    elif kind == "flat":
        d.line([(182, 278), (218, 274)], fill=LIP, width=7)
    elif kind == "smirk":
        d.arc([186, 244, 236, 280], 30, 140, fill=LIP, width=7)
        d.line([(170, 270), (190, 276)], fill=LIP, width=7)


def emo_face(emo: str):
    """Фабрика: emo → f(t). Каждая эмоция — своя мимика и своя анимация."""
    def draw(t):
        wave = math.sin(2 * math.pi * t)
        blink = 0.08 < (t % 1) < 0.15
        tint = 0.55 + 0.25 * wave if emo == "angry" else None
        blush = {"blush": 1.5 + 0.4 * wave, "love": 1.3, "angry": 0, "shock": 0.6, "cool": 0.6}.get(emo, 1.0)
        im = _head(blush, tint)
        d = ImageDraw.Draw(im)
        fx = Image.new("RGBA", (S, S), (0, 0, 0, 0))   # полупрозрачное (пар, слёзы, z) — отдельным слоем
        e = ImageDraw.Draw(fx)
        scale, angle, dx, dy = 0.95, 0.0, 0.0, -8 * wave
        if emo in ("base", "wink"):
            if blink or (emo == "wink" and 0.45 < t < 0.8):
                for i, ex in enumerate((155, 245)):
                    if blink or i == 1:
                        d.arc([ex - 26, 205, ex + 26, 240], 200, 340, fill=INK, width=9)
                    else:
                        d.ellipse([ex - 22, 192, ex + 22, 245], fill=EYE)
                        d.ellipse([ex - 9, 200, ex + 3, 214], fill=WHITE)
            else:
                _eyes_open(d)
            _mouth(d, "smile" if emo == "base" else "grin")
        elif emo == "happy":
            _eyes_closed(d, True)
            _mouth(d, "grin")
            dy = -14 * abs(math.sin(2 * math.pi * t))
        elif emo == "laugh":
            for ex, s in ((155, 1), (245, -1)):   # > <
                d.line([(ex - 20 * s, 205), (ex + 18 * s, 220), (ex - 20 * s, 236)], fill=INK, width=9, joint="curve")
            _mouth(d, "laugh", 0.5 + 0.5 * math.sin(2 * math.pi * t * 4))
            for x, s in ((108, -1), (292, 1)):   # слёзы радости брызгают
                k = (t * 2) % 1
                _drop(d, x + s * 30 * k, 230 - 30 * k + 60 * k * k, 13)
            angle = 6 * math.sin(2 * math.pi * t * 4)
        elif emo == "love":
            k = 0.85 + 0.25 * _beat(t)
            for ex in (155, 245):
                d.polygon(_heart_pts(ex, 222, 30 * k), fill=(255, 60, 120))
                d.ellipse([ex - 14, 205, ex - 4, 215], fill=(255, 220, 235))
            _mouth(d, "smile")
            hk = t % 1
            hh = _shape(lambda dd, f: dd.polygon(_heart_pts(320, 110 - 70 * hk, 34), fill=f), PINK, (255, 60, 120), outline=False)
            hh.putalpha(hh.split()[3].point(lambda v: int(v * (1 - hk))))
            im.alpha_composite(hh)
        elif emo == "sad":
            _eyes_open(d, dy=6, big=0.9)
            _brows(d, 16, -4)
            _mouth(d, "frown")
            k = t % 1   # одна слеза медленно катится
            _drop(d, 150, 245 + 60 * k, 10)
            dy = 6 + 3 * wave
        elif emo == "cry":
            _eyes_closed(d, False, 226)
            _brows(d, 18, -4)
            _mouth(d, "wavy", t)
            for ex in (150, 250):     # ручьи
                e.rectangle([ex - 9, 232, ex + 9, 320], fill=TEAR + (200,))
                for j in range(3):
                    k = (t * 2 + j / 3) % 1
                    _drop(d, ex + (-1 if ex < 200 else 1) * 40 * k, 300 + 60 * k, 9)
            angle = 3 * math.sin(2 * math.pi * t * 6)
        elif emo == "angry":
            _eyes_open(d, big=0.85)
            _brows(d, -18, 10, 185)
            _mouth(d, "frown")
            for x, ph in ((70, 0.0), (330, 0.5)):   # пар из ушей
                k = (t * 2 + ph) % 1
                r = 14 + 22 * k
                e.ellipse([x - r, 120 - 80 * k - r, x + r, 120 - 80 * k + r], fill=(235, 235, 245, int(230 * (1 - k))))
            dx = 5 * math.sin(2 * math.pi * t * 8)
        elif emo == "shock":
            jump = math.exp(-((t - 0.2) / 0.1) ** 2)
            _eyes_open(d, big=1.15, pupil=0.5)
            _brows(d, 0, 0, 160 - 12 * jump)
            _mouth(d, "o", jump)
            scale, dy = 0.95 + 0.05 * jump, -26 * jump
            _drop(d, 300, 150 + 20 * ((t * 1.5) % 1), 11)
        elif emo == "think":
            look = 0.5 + 0.5 * wave
            _eyes_open(d, dx=6 + 4 * look, dy=-8)
            _brows(d, 0, -10 * look)
            _mouth(d, "flat")
            for i in range(3):   # «…» появляются по очереди
                if (t * 3) % 3 >= i:
                    x, y, r = 285 + i * 26, 95 - i * 16, 11 + i * 3
                    d.ellipse([x - r, y - r, x + r, y + r], fill=WHITE, outline=DEEP, width=5)
            angle = 5 * look
        elif emo == "sleepy":
            _eyes_closed(d, False)
            _mouth(d, "o", 0.3 * (0.5 + 0.5 * wave))
            for j in range(2):
                k = (t + j / 2) % 1
                _zz(e, 280 + 30 * k, 130 - 70 * k, 40 + 26 * k, int(255 * (1 - k)))
            angle, dy = 6 * wave, 0
        elif emo == "cool":
            k = min(1.0, t / 0.3)
            k = 1 - (1 - k) ** 3
            gy = -80 + 300 * k
            _eyes_open(d)
            _mouth(d, "smirk")
            gl = Image.new("RGBA", (S, S), (0, 0, 0, 0))
            g = ImageDraw.Draw(gl)
            g.line([(100, 0), (300, 0)], fill=(20, 18, 30))
            for ex in (155, 245):
                g.rounded_rectangle([ex - 42, gy - 210 + 190, ex + 42, gy - 210 + 245], radius=18, fill=(25, 20, 45))
            g.rectangle([190, gy - 210 + 200, 210, gy - 210 + 212], fill=(25, 20, 45))
            g.line([(98, gy - 210 + 205), (302, gy - 210 + 205)], fill=(25, 20, 45), width=8)
            if t > 0.4:   # блик по стёклам
                sx = 100 + 300 * ((t - 0.4) / 0.6)
                g.polygon([(sx, gy - 20), (sx + 18, gy - 20), (sx - 4, gy + 35), (sx - 22, gy + 35)], fill=(255, 255, 255, 170))
            im.alpha_composite(gl)
        elif emo == "blush":
            for ex in (155, 245):   # глаза вниз
                d.arc([ex - 24, 210, ex + 24, 244], 20, 160, fill=INK, width=9)
            _mouth(d, "wavy", t * 0.5)
            dy = 4 * wave
            angle = -4
        elif emo == "smirk":
            for ex in (155, 245):
                d.ellipse([ex - 22, 200, ex + 22, 245], fill=EYE)
                d.rectangle([ex - 26, 190, ex + 26, 216], fill=(255, 225, 214))
                d.line([(ex - 26, 216), (ex + 26, 216)], fill=INK, width=8)
            _brows(d, 0, 0, 175 - 10 * (0.5 + 0.5 * wave))
            _mouth(d, "smirk")
        elif emo == "party":
            _eyes_closed(d, True)
            _mouth(d, "grin")
            hat = _shape(lambda dd, f: dd.polygon([(160, 112), (240, 112), (212, 22)], fill=f), (255, 205, 70), PINK)
            im.alpha_composite(_transform(hat, 1.0, angle=-14, dx=36, dy=-8))
            for i in range(10):    # конфетти
                k = (t + i / 10) % 1
                x = 40 + (i * 37) % 320
                col = (PINK, VIOLET, GOLD, (110, 230, 140))[i % 4]
                d.rectangle([x, 20 + 340 * k, x + 12, 32 + 340 * k], fill=col)
            dy = -12 * abs(math.sin(2 * math.pi * t * 2))
        im.alpha_composite(fx)
        _phones(d)
        return _transform(im, scale, angle=angle, dx=dx, dy=dy)
    return draw


face = emo_face("base")
wink = emo_face("wink")
# эмоция → (эмодзи для пака, подпись); их же Соня ставит в ответах
EMOTIONS = {
    "happy": ("😊", "радуется"), "laugh": ("😂", "хохочет"), "love": ("😍", "влюблена"), "sad": ("😢", "грустит"),
    "cry": ("😭", "плачет"), "angry": ("😡", "злится"), "shock": ("😮", "в шоке"), "think": ("🤔", "думает"),
    "sleepy": ("😴", "спит"), "cool": ("😎", "крутая"), "blush": ("😳", "смущается"), "smirk": ("😏", "ухмыляется"),
    "party": ("🥳", "празднует"),
}


def fire(t):
    def flame(d, f):
        pts = []
        for i in range(48):
            a = 2 * math.pi * i / 48
            r = 120 + 18 * math.sin(3 * a + 2 * math.pi * t * 2) + 10 * math.sin(5 * a - 2 * math.pi * t * 3)
            y = math.sin(a)
            stretch = 1.6 if y < 0 else 1.0
            pts.append((200 + math.cos(a) * r * (0.8 if y < 0 else 1), 250 + y * r * stretch))
        d.polygon(pts, fill=f)
    base = _shape(flame, (255, 220, 80), (255, 70, 60))
    inner = _shape(lambda d, f: d.ellipse([150, 230, 250, 350], fill=f), (255, 250, 200), (255, 200, 80), outline=False)
    base.alpha_composite(_transform(inner, 1.0, sy=1 + 0.08 * math.sin(2 * math.pi * t * 3)))
    return base


def check(t):
    p = min(1.0, t / 0.45)
    pop = 1 + 0.12 * math.exp(-((t - 0.5) / 0.08) ** 2)
    base = _shape(lambda d, f: d.rounded_rectangle([60, 60, 340, 340], radius=70, fill=f), (110, 230, 140), (40, 170, 90))
    d = ImageDraw.Draw(base)
    pts = [(120, 205), (180, 265), (290, 140)]
    if p > 0:
        seg = p * 2
        a = pts[0]
        b = pts[1] if seg >= 1 else (pts[0][0] + (pts[1][0] - pts[0][0]) * seg, pts[0][1] + (pts[1][1] - pts[0][1]) * seg)
        d.line([a, b], fill=WHITE, width=34, joint="curve")
        if seg > 1:
            k = seg - 1
            c = (pts[1][0] + (pts[2][0] - pts[1][0]) * k, pts[1][1] + (pts[2][1] - pts[1][1]) * k)
            d.line([pts[1], c], fill=WHITE, width=34, joint="curve")
    return _transform(base, 0.92 * pop)


def arrow(t):
    b = abs(math.sin(math.pi * t * 2))
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    tray = _shape(lambda d, f: (d.rounded_rectangle([60, 290, 340, 335], radius=20, fill=f),
                                d.rectangle([60, 240, 100, 320], fill=f), d.rectangle([300, 240, 340, 320], fill=f)),
                  (200, 190, 255), VIOLET)
    im.alpha_composite(tray)
    arr = _shape(lambda d, f: d.polygon([(165, 40), (235, 40), (235, 150), (290, 150), (200, 250), (110, 150),
                                         (165, 150)], fill=f))
    im.alpha_composite(_transform(arr, 1.0, dy=-10 + 30 * b))
    return im


def notes(t):
    im = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    for i, (x0, ph) in enumerate(((130, 0.0), (260, 0.5))):
        k = (t + ph) % 1
        y = 260 - 140 * k
        a = int(255 * min(1, (1 - k) * 2.5))
        n = _shape(lambda d, f: (d.ellipse([x0 - 55, y + 20, x0 + 25, y + 85], fill=f), d.rectangle([x0 + 5, y - 110, x0 + 27, y + 55], fill=f),
                                 d.polygon([(x0 + 5, y - 110), (x0 + 85, y - 75), (x0 + 85, y - 40), (x0 + 27, y - 70)], fill=f)),
                   PINK if i == 0 else VIOLET, VIOLET if i == 0 else PINK)
        n.putalpha(n.split()[3].point(lambda v: v * a // 255))
        im.alpha_composite(n)
    return im


def crown(t):
    def c(d, f):
        d.polygon([(60, 300), (60, 130), (130, 210), (200, 90), (270, 210), (340, 130), (340, 300)], fill=f)
        d.rounded_rectangle([55, 285, 345, 335], radius=16, fill=f)
    base = _shape(c, GOLD, GOLD_D)
    d = ImageDraw.Draw(base)
    k = 0.5 + 0.5 * math.sin(2 * math.pi * t)
    for x, col in ((120, PINK), (200, VIOLET), (280, PINK)):
        d.ellipse([x - 20, 290, x + 20, 330], fill=_lerp(col, WHITE, 0.4 * k))
    sp = _shape(lambda d2, f: d2.polygon(_star_pts(300, 80, 55 * k + 10, 14, 4), fill=f), WHITE, GOLD, outline=False)
    base.alpha_composite(sp)
    return _transform(base, 0.92, angle=4 * math.sin(2 * math.pi * t))


# имя → (функция, эмодзи для пака, подпись)
SET = {
    "sonya": (face, "💜", "Соня"), "wink": (wink, "😉", "подмигивает"), "heart": (heart, "💜", "сердечко"),
    "sparkles": (sparkles, "✨", "искры"), "dice": (dice, "🎲", "кубик"), "coin": (coin, "🪙", "монетка"),
    "gift": (gift, "🎁", "подарок"), "trophy": (trophy, "🏆", "кубок"), "megaphone": (megaphone, "📢", "рупор"),
    "bolt": (bolt, "⚡", "молния"), "star": (star, "⭐", "звезда"), "gear": (gear, "⚙", "шестерёнка"),
    "question": (question, "❓", "вопрос"), "bubble": (bubble, "💬", "печатает…"), "plane": (plane, "✈", "самолётик"),
    "bulb": (bulb, "💡", "идея"), "fire": (fire, "🔥", "огонь"), "check": (check, "✅", "готово"),
    "arrow": (arrow, "⬇", "скачать"), "notes": (notes, "🎵", "музыка"), "crown": (crown, "👑", "корона"),
}
SET.update({e: (emo_face(e), em, lab) for e, (em, lab) in EMOTIONS.items()})
# кнопки главного меню → какой эмодзи поставить (callback_data → имя)
MENU = {"g:menu": "dice", "m:tools": "bolt", "ap:home": "megaphone", "gw:list": "gift", "m:gifts": "heart",
        "m:profile": "sonya", "m:top:xp": "trophy", "g:bonus": "coin", "m:plus": "crown", "m:mode": "wink",
        "m:facts": "bulb", "biz:home": "bubble", "m:ref": "plane", "m:help": "question", "m:donate": "star",
        "adm:home": "gear"}


def frames(name: str) -> list[Image.Image]:
    fn = SET[name][0]
    n = FPS * SECONDS
    return [fn(i / n).resize((OUT, OUT), Image.LANCZOS) for i in range(n)]


def webm(name: str) -> bytes:
    """Кадры → WEBM VP9 с альфой (yuva420p). Подбираем качество, чтобы влезть в 256 КБ."""
    tmp = tempfile.mkdtemp(prefix="moji")
    try:
        for i, f in enumerate(frames(name)):
            f.save(os.path.join(tmp, f"{i:03d}.png"))
        out = os.path.join(tmp, "out.webm")
        for crf in (30, 38, 46):
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-framerate", str(FPS), "-i",
                            os.path.join(tmp, "%03d.png"), "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p",
                            "-b:v", "0", "-crf", str(crf), "-an", "-t", str(SECONDS), out],
                           check=True, timeout=120)
            if os.path.getsize(out) <= 250 * 1024:
                break
        with open(out, "rb") as fh:
            return fh.read()
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def preview_gif(names: list[str], cols: int = 7, cell: int = 120) -> bytes:
    """Превью всех эмодзи сеткой (анимированный GIF на тёмном фоне) — показать перед созданием пака."""
    all_frames = {n: frames(n) for n in names}
    rows = math.ceil(len(names) / cols)
    out = []
    font = banners._font(banners.TEXT_FONT, 15)
    for i in range(FPS * SECONDS):
        im = Image.new("RGB", (cols * cell, rows * (cell + 22)), (24, 22, 36))
        d = ImageDraw.Draw(im)
        for k, n in enumerate(names):
            x, y = (k % cols) * cell, (k // cols) * (cell + 22)
            im.paste(all_frames[n][i], (x + 10, y + 8), all_frames[n][i])
            d.text((x + cell // 2, y + cell + 6), SET[n][2], font=font, fill=(220, 215, 235), anchor="mm")
        out.append(im)
    buf = io.BytesIO()
    out[0].save(buf, "GIF", save_all=True, append_images=out[1::2], duration=1000 // FPS * 2, loop=0, optimize=True)
    return buf.getvalue()


# ================= волна 70: анимированные версии ВСЕХ эмодзи, что есть в текстах и кнопках =================
# Рисунок эмодзи — Noto Color Emoji (Apache 2.0), заранее отрисован в assets/moji/*.png (на сервере шрифт не нужен).
# Сверху — фирменная анимация Сони: прыжок/покачивание/пульс + розово-фиолетовые искорки и блик.
import re as _re
from pathlib import Path as _Path

GLYPHS = _Path(__file__).parent / "assets" / "moji"
B = 200   # холст «значков»
# обычные эмодзи → нарисованные вручную (лицо Сони вместо колобков, фирменные кубик/подарок/…)
ALIAS = {
    "🙂": "sonya", "🙃": "wink", "😉": "wink", "😊": "happy", "☺": "happy", "😌": "happy", "🤗": "happy", "😇": "happy",
    "😀": "laugh", "😃": "laugh", "😄": "laugh", "😁": "laugh", "😆": "laugh", "😅": "laugh", "😂": "laugh", "🤣": "laugh",
    "😍": "love", "🥰": "love", "😘": "love", "😻": "love", "😢": "sad", "😔": "sad", "😕": "sad", "😟": "sad",
    "🥲": "sad", "😞": "sad", "🙁": "sad", "☹": "sad", "😭": "cry", "😡": "angry", "😠": "angry", "🤬": "angry",
    "😤": "angry", "😮": "shock", "😯": "shock", "😲": "shock", "😱": "shock", "🤯": "shock", "😵": "shock",
    "🤔": "think", "🤨": "think", "🧐": "think", "😴": "sleepy", "💤": "sleepy", "🥱": "sleepy", "😎": "cool",
    "😳": "blush", "🥺": "blush", "😏": "smirk", "🥳": "party",
    "💜": "heart", "💖": "heart", "💗": "heart", "💕": "heart", "✨": "sparkles", "🎲": "dice", "🪙": "coin",
    "🎁": "gift", "🏆": "trophy", "📢": "megaphone", "📣": "megaphone", "⚡": "bolt", "⭐": "star", "🌟": "star",
    "⚙": "gear", "❓": "question", "❔": "question", "💬": "bubble", "✈": "plane", "💡": "bulb", "🔥": "fire",
    "✅": "check", "✔": "check", "⬇": "arrow", "📥": "arrow", "🎵": "notes", "🎶": "notes", "👑": "crown",
}
# не трогаю: масти карт, клетки досок и полоски, буквы флагов, служебные знаки
EXCLUDE = set("🏻🏼🏽🏾🏿➿♠♥♦♣▫◻◼▪⬜⬛🟦🟥🟩🟨🟪🟧🟫🔳🔲⚪⚫🔴🔵🟢🟡🟠🟣🟤▰▱✦✧★☆◆◇©®™ℹ↔↩↪⬅➡⬆↕#*0123456789")
_EMOJI_RX = _re.compile(r"(?:[\U0001F1E6-\U0001F1FF]{2}|[\U0001F000-\U0001FAFF☀-➿⬀-⯿←-⇿"
                        r"⌀-⏿㊗㊙‼⁉](?:️)?(?:\U0001F3FB-\U0001F3FF)?"
                        r"(?:‍[\U0001F000-\U0001FAFF☀-➿](?:️)?)*)")


def norm(e: str) -> str:
    """Ключ эмодзи: без вариационного селектора (❤️ и ❤ — одно и то же)."""
    return e.replace("️", "")


def gkey(e: str) -> str:
    return "-".join(f"{ord(c):x}" for c in norm(e))


def has_glyph(e: str) -> bool:
    return (GLYPHS / f"{gkey(e)}.png").exists()


def inventory(root: str | None = None) -> list[str]:
    """Все эмодзи из кода бота (тексты, кнопки) — у которых есть рисунок и нет ручной версии. Порядок — по частоте."""
    from collections import Counter
    base = _Path(root) if root else _Path(__file__).parent
    c = Counter()
    for p in list(base.glob("*.py")) + list(base.glob("handlers/*.py")) + list(base.glob("autopost/*.py")) \
            + list(base.glob("downloader/*.py")):
        try:
            c.update(norm(e) for e in _EMOJI_RX.findall(p.read_text(encoding="utf-8")))
        except OSError:
            continue
    return [e for e, _ in c.most_common() if e not in ALIAS and not (set(e) & EXCLUDE) and has_glyph(e)]


def _style(e: str) -> str:
    return ("bounce", "wobble", "pulse", "float", "flip")[sum(map(ord, e)) % 5] if e not in "🪙💰💎💿📀" else "flip"


def _twinkle(d, cx, cy, r, col):
    if r > 1:
        d.polygon(_star_pts(cx, cy, r, r * 0.3, 4), fill=col)


def badge(e: str):
    """Эмодзи → f(t): рисунок + анимация + фирменные искорки и блик."""
    src = Image.open(GLYPHS / f"{gkey(e)}.png").convert("RGBA")
    src = src.crop(src.getbbox() or (0, 0, src.width, src.height))
    k = 148 / max(src.size)
    g0 = src.resize((max(1, int(src.width * k)), max(1, int(src.height * k))), Image.LANCZOS)
    st = _style(e)
    ph = (sum(map(ord, e)) % 7) / 7

    def draw(t):
        w = math.sin(2 * math.pi * t)
        sx = sy = 1.0
        ang, dx, dy = 0.0, 0.0, 0.0
        if st == "bounce":
            h = abs(math.sin(math.pi * t * 2))
            dy = -20 * h
            if h < 0.2:
                sx, sy = 1.08 - 0.4 * h, 0.9 + 0.5 * h
        elif st == "wobble":
            ang = 11 * w
        elif st == "pulse":
            sx = sy = 0.9 + 0.12 * _beat(t)
        elif st == "float":
            dy, ang = 7 * w, 4 * math.sin(2 * math.pi * t + 1)
        else:   # flip — монетка/алмаз крутится
            sx = max(0.08, abs(math.cos(math.pi * t)))
        g = g0.resize((max(1, int(g0.width * sx)), max(1, int(g0.height * sy))), Image.LANCZOS)
        if ang:
            g = g.rotate(ang, resample=Image.BICUBIC, expand=True)
        # блик проходит по рисунку
        if 0.5 < t < 0.85:
            band = Image.new("L", g.size, 0)
            x = -40 + (g.width + 80) * (t - 0.5) / 0.35
            ImageDraw.Draw(band).polygon([(x, 0), (x + 26, 0), (x - 14, g.height), (x - 40, g.height)], fill=120)
            band = Image.composite(band, Image.new("L", g.size, 0), g.split()[3])
            g = g.copy()
            g.alpha_composite(Image.merge("RGBA", (*[Image.new("L", g.size, 255)] * 3, band)))
        im = Image.new("RGBA", (B, B), (0, 0, 0, 0))
        im.alpha_composite(g, (int((B - g.width) / 2 + dx), int((B - g.height) / 2 + dy + (6 if st == "bounce" else 0))))
        d = ImageDraw.Draw(im)
        for (cx, cy, r, col, p) in ((170, 30, 16, PINK, 0.0), (28, 168, 12, VIOLET, 0.45), (176, 150, 9, GOLD, 0.7)):
            kk = math.sin(math.pi * ((t + ph + p) % 1))
            _twinkle(d, cx, cy, r * kk, col)
        return im
    return draw


def make_fn(key: str):
    """Ключ пака → функция кадра: имя ручного эмодзи или сам символ (значок)."""
    if key in SET:
        return SET[key][0], S
    return badge(key), B


def frames(name: str) -> list[Image.Image]:   # noqa: F811 — волна 70: и ручные, и значки
    fn, size = make_fn(name)
    n = FPS * SECONDS
    return [fn(i / n).resize((OUT, OUT), Image.LANCZOS) for i in range(n)]


def label(key: str) -> str:
    return SET[key][2] if key in SET else key


def pack_emoji(key: str) -> str:
    """Какой эмодзи указать стикеру в паке (по нему Telegram ищет и подсказывает)."""
    return SET[key][1] if key in SET else key
