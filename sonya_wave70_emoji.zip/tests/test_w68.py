"""Волна 68: анимированные премиум-эмодзи Сони — рисуются (WEBM VP9 с альфой, 100×100, ≤3 с, ≤256 КБ),
пак создаётся из админки, иконки ставятся на кнопки главного меню, /emoji — ссылка для всех.
python test_w68.py ../sonya full"""
import asyncio, json, os, subprocess, sys, tempfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
from aiogram.methods import SendMessage, SendPhoto
from aiogram.types import StickerSet, Sticker


async def main():
    M, bot, dp = await setup()
    import sonyamoji, uikit, ui
    from handlers import admin

    # ---------- рисунки ----------
    ok = True
    for n in sonyamoji.SET:
        f = sonyamoji.SET[n][0](0.4).resize((100, 100))
        ok &= f.mode == "RGBA" and f.getpixel((0, 0))[3] == 0 and max(f.split()[3].getdata()) == 255
    check(f"все {len(sonyamoji.SET)} эмодзи рисуются, фон прозрачный", ok)
    data = sonyamoji.webm("heart")
    p = os.path.join(tempfile.mkdtemp(), "h.webm")
    open(p, "wb").write(data)
    pr = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,width,height:stream_tags=alpha_mode"
                         ":format=duration", "-of", "json", p], capture_output=True, text=True).stdout
    j = json.loads(pr)
    st = j["streams"][0]
    check("WEBM по правилам Telegram: VP9, 100×100, альфа, ≤3 с, ≤256 КБ",
          st["codec_name"] == "vp9" and st["width"] == 100 and st["height"] == 100
          and st.get("tags", {}).get("alpha_mode") == "1" and float(j["format"]["duration"]) <= 3 and len(data) <= 256 * 1024)
    cbs = {b.callback_data for row in ui.main_menu(True).inline_keyboard for b in row}
    check("каждой кнопке главного меню назначен свой эмодзи", cbs == set(sonyamoji.MENU) and
          set(sonyamoji.MENU.values()) <= set(sonyamoji.SET))

    # ---------- создание пака ----------
    sonyamoji.webm = lambda n: b"WEBM" + n.encode()
    sonyamoji.inventory = lambda *a: []   # волна 70: здесь — только пак с лицом Сони
    made = {}

    async def create(**kw):
        made.update(kw)
        return True

    async def getset(name):
        if not made:
            raise Exception("STICKERSET_INVALID")
        return StickerSet(name=name, title="t", sticker_type="custom_emoji", stickers=[
            Sticker(file_id=f"f{i}", file_unique_id=f"u{i}", type="custom_emoji", width=100, height=100,
                    is_animated=False, is_video=True, custom_emoji_id=f"ce{i}") for i, _ in enumerate(made["stickers"])])
    bot.create_new_sticker_set, bot.get_sticker_set = create, getset
    SENT.clear()
    await admin._make_pack(bot, 1, 1)
    ids = json.loads(await db.kv_get("moji:ids") or "{}")
    check("пак создан: custom_emoji, формат video, от владельца, имя _by_бот",
          made.get("sticker_type") == "custom_emoji" and made.get("user_id") == 1 and made["name"].endswith("_by_Sonya_rubot")
          and all(s.format == "video" for s in made["stickers"]) and len(ids) == len(sonyamoji.SET))
    check("владельцу — «пак готов» со ссылкой addemoji", any("паки готовы" in t and "addemoji" in t for t in H.texts()))

    # ---------- иконки на кнопки ----------
    n = await admin.apply_menu_icons(ids)
    bot.session.middleware(uikit.UiMiddleware())
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 70, 70))
    mk = (H.sent(SendMessage) or H.sent(SendPhoto))[-1].reply_markup
    btns = {b.callback_data: b for row in mk.inline_keyboard for b in row}
    g = btns.get("g:menu")
    check("кнопки меню с премиум-иконкой, эмодзи из текста убран (без двойного значка)",
          n >= 15 and g and g.icon_custom_emoji_id == ids["dice"] and g.text == "Игры"
          and btns["m:plus"].text == "Соня+ — без лимитов" and btns["m:plus"].style == "success")
    await admin.apply_menu_icons({})
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 71, 71))
    mk = (H.sent(SendMessage) or H.sent(SendPhoto))[-1].reply_markup
    g = {b.callback_data: b for row in mk.inline_keyboard for b in row}["g:menu"]
    check("«убрать с кнопок» — как было", not g.icon_custom_emoji_id and g.text.startswith("🎮"))

    # ---------- для всех ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/emoji", 72, 72))
    check("/emoji — ссылка на пак", "addemoji/sonya_emoji_by_Sonya_rubot" in str(H.sent(SendMessage)[-1].reply_markup))
    SENT.clear()
    await dp.feed_update(bot, msg("эмодзи", 72, 72))
    check("словами «эмодзи» — то же", "Эмодзи Сони" in "\n".join(H.texts()))
    SENT.clear()
    await dp.feed_update(bot, cbq("em:home", 72, 72))
    check("админ-экран эмодзи — только владельцу", not any("Эмодзи Сони" in t for t in H.texts()))

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
