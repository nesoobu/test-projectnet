"""Панель автопостинга: главная, каналы, очередь, история."""
import json
import time
from html import escape
from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery, MessageOriginChannel

import ui
from autopost import store, timeparse, publisher, engine
from handlers.ap_common import AP, show, kb_rows, cancel_kb, on, is_owner, MAX_CHANNELS

router = Router()
JITTERS = [0, 5, 10, 20, 30]
REACTS = ["", "🔥", "❤️", "👍", "🤩", "random"]


def _react_label(v: str) -> str:
    return {"": "выкл", "random": "случайная"}.get(v or "", v)


# ================= главная =================
async def home_view(uid: int):
    c = await store.counts(uid)
    chs = await store.channels(uid)
    errs = await store.errors_of(uid)
    text = (ui.head("📢", "Автопостинг", "каналы ведутся сами — ты только настраиваешь")
            + "\n" + ui.stats(("📢 каналов", c["channels"]), ("🤖 источников", c["rules"]),
                              ("📅 в очереди", c["queue"]), ("📤 за сутки", c["sent24"]),
                              ("⚠️ с ошибками", len(errs)) if errs else ("", ""))
            + "\n" + ui.hint("начни с «➕ Канал» — подключи свой канал" if not chs
                             else "выбери канал — там его источники, очередь и настройки"))
    rows = []
    for ch in chs:
        nr = len(await store.rules_of(uid, ch["chat_id"]))
        st = "⏸" if ch["paused"] else "🟢"
        rows.append([(f"{st} {ch['title'][:22]} · 🤖{nr}", f"ap:ch:{ch['chat_id']}")])
    inbox = f"📥 Модерация · {c['inbox']}" if c["inbox"] else "📥 Модерация"
    extra = [(inbox, "ap:inbox")]
    if errs:
        extra.append((f"⚠️ Ошибки · {len(errs)}", "ap:errs"))
    kb = kb_rows(*rows,
                 [("➕ Канал", "ap:chadd"), ("✍️ Пост", "ap:new")],
                 extra,
                 [("📅 Очередь", "ap:queue"), ("📜 История", "ap:hist"), ("🤖 Все источники", "ap:rules")],
                 [("🎁 Розыгрыши", "gw:list"), ("❔ Как это работает", "ap:help")],
                 [("‹ Меню", "m:home")])
    return text, kb


AP_HELP = (ui.head("❔", "Как работает автопостинг")
           + "\n" + ui.quote("1️⃣ <b>➕ Канал</b> — добавь меня админом в канал и перешли сюда любой пост оттуда\n"
                             "2️⃣ <b>➕ Источник</b> — откуда брать: Pinterest, TG-каналы, VK, Reddit, RSS, музыка, видео, ИИ\n"
                             "3️⃣ настрой расписание и вид поста — дальше я выкладываю сама")
           + "\n" + ui.quote("✍️ <b>Пост</b> — свой пост с кнопками, реакциями и отложкой\n"
                             "📥 <b>Модерация</b> — посты, которые ждут твоего «ок»\n"
                             "📅 <b>Очередь</b> / 📜 <b>История</b> — что выйдет и что вышло\n"
                             "🎁 <b>Розыгрыши</b> — с проверкой подписки")
           + "\n" + ui.hint("в каждом источнике есть своя кнопка ❔ Помощь"))


@router.callback_query(F.data == "ap:help")
async def cb_ap_help(cb: CallbackQuery):
    await show(cb, AP_HELP, kb_rows([("‹ Назад", "ap:home")]))


@router.message(Command("panel", "post"))
async def cmd_panel(m: Message, state: FSMContext):
    await state.clear()
    await show(m, *await home_view(m.from_user.id))


@router.callback_query(F.data == "ap:home")
async def cb_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, *await home_view(cb.from_user.id))


# ================= каналы =================
@router.callback_query(F.data == "ap:chs")
async def cb_channels(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    chs = await store.channels(cb.from_user.id)
    rows = [[(("⏸ " if c["paused"] else "🟢 ") + c["title"][:30], f"ap:ch:{c['chat_id']}")] for c in chs]
    text = f"<b>📢 мои каналы</b>\n{ui.LINE}\n"
    text += "выбери канал для настройки" if chs else "<i>пока пусто</i>"
    await show(cb, text, kb_rows(*rows, [("➕ Добавить канал", "ap:chadd")], [("‹ Назад", "ap:home")]))


ADD_HINT = (
    "<b>➕ подключаем канал</b>\n"
    f"{ui.LINE}\n"
    "1. добавь меня в админы канала с правом <b>публиковать сообщения</b>\n"
    "2. перешли сюда любой пост из канала\n"
    "   или пришли его @username\n\n"
    "<i>группы тоже можно</i>"
)


@router.callback_query(F.data == "ap:chadd")
async def cb_ch_add(cb: CallbackQuery, state: FSMContext):
    have = len(await store.channels(cb.from_user.id))
    if have >= MAX_CHANNELS and not is_owner(cb.from_user.id):
        return await cb.answer(f"максимум {MAX_CHANNELS} каналов", show_alert=True)
    import config
    from handlers import extra
    if config.FREE_CHANNELS and have >= config.FREE_CHANNELS and not extra.active(cb.from_user.id):
        return await cb.answer(f"без Соня+ — до {config.FREE_CHANNELS} канал(ов). больше — с /plus ✨",
                               show_alert=True)
    await state.set_state(AP.channel_add)
    await show(cb, ADD_HINT, cancel_kb("ap:home"))


@router.message(AP.channel_add)
async def st_ch_add(m: Message, state: FSMContext, bot: Bot):
    chat_ref = None
    if isinstance(m.forward_origin, MessageOriginChannel):
        chat_ref = m.forward_origin.chat.id
    elif m.text and m.text.strip().startswith(("@", "https://t.me/", "t.me/")):
        chat_ref = "@" + m.text.strip().split("/")[-1].lstrip("@")
    elif m.text and m.text.strip().lstrip("-").isdigit():
        chat_ref = int(m.text.strip())
    if chat_ref is None:
        return await m.answer("перешли пост из канала или пришли @username", reply_markup=cancel_kb("ap:home"))
    try:
        chat = await bot.get_chat(chat_ref)
        me = await bot.get_chat_member(chat.id, (await bot.me()).id)
        you = await bot.get_chat_member(chat.id, m.from_user.id)
    except Exception:
        return await m.answer("не вижу этот чат. я точно там админ?", reply_markup=cancel_kb("ap:home"))
    if you.status not in ("administrator", "creator"):
        return await m.answer("ты не админ этого канала 🤨", reply_markup=cancel_kb("ap:home"))
    if chat.type == "channel":
        if me.status != "administrator" or not getattr(me, "can_post_messages", False):
            return await m.answer("дай мне право «публиковать сообщения» и пришли ещё раз",
                                  reply_markup=cancel_kb("ap:home"))
    elif me.status not in ("administrator", "member"):
        return await m.answer("добавь меня в группу и пришли ещё раз", reply_markup=cancel_kb("ap:home"))
    exist = await store.channel(chat.id)
    if exist and exist["owner_id"] != m.from_user.id:
        return await m.answer("этот канал уже подключил другой админ")
    await store.add_channel(chat.id, m.from_user.id, chat.title or "без названия", chat.username)
    await state.clear()
    await m.answer(f"✅ <b>{escape(chat.title or '')}</b> подключён")
    await show(m, *await hub_view(chat.id, m.from_user.id))


async def channel_view(chat_id: int):
    c = await store.channel(chat_id)
    slots = json.loads(c["slots"] or "[]")
    text = (
        ui.head("⚙️", f"Настройки · {escape(c['title'])}", "как и когда выходят посты") + "\n"
        f"🕐 слоты: <b>{' · '.join(slots) or '—'}</b>\n"
        f"🎲 разброс: <b>{'±' + str(c['jitter']) + ' мин' if c['jitter'] else 'нет'}</b>\n"
        f"🌙 ночью (23–8) без звука: <b>{on(c['night_silent'])}</b>\n"
        f"✍️ подпись: <b>{escape(c['signature']) if c['signature'] else '—'}</b>\n"
        f"💜 реакция Сони под постом: <b>{_react_label(c.get('auto_react'))}</b>\n"
        f"💧 водяной знак: <b>{escape(c.get('watermark') or '') or '—'}</b>\n"
        f"🧬 похожие картинки: <b>{'не повторяю' if c.get('dedupe_img', 1) else 'можно'}</b>\n"
        f"🎵 трек в комментариях под видео: <b>{on(c.get('cm_track'))}</b>\n"
        f"📝 текст песни в комментариях под аудио: <b>{on(c.get('cm_lyrics'))}</b>\n"
        f"статус: <b>{'⏸ на паузе' if c['paused'] else '🟢 работает'}</b>"
    )
    cid = c["chat_id"]
    kb = kb_rows(
        [("🕐 Слоты", f"ap:chs_slots:{cid}"), ("🎲 Разброс", f"ap:chs_jit:{cid}")],
        [(f"🌙 Ночь: {on(c['night_silent'])}", f"ap:chs_night:{cid}"), ("✍️ Подпись", f"ap:chs_sign:{cid}")],
        [(f"💜 Реакция Сони: {_react_label(c.get('auto_react'))}", f"ap:chs_rx:{cid}")],
        [("💧 Водяной знак", f"ap:x_wm:{cid}"),
         (f"🧬 Похожие картинки: {'отсеиваю' if c.get('dedupe_img', 1) else 'пускаю'}", f"ap:x_dup:{cid}")],
        [(f"🎵 Трек в комменты: {on(c.get('cm_track'))}", f"ap:cm:track:{cid}"),
         (f"📝 Текст в комменты: {on(c.get('cm_lyrics'))}", f"ap:cm:lyrics:{cid}")],
        [("❔ Как работают комментарии", f"ap:cm:help:{cid}")],
        [("🗑 Отключить канал", f"ap:chs_del:{cid}")],
        [("‹ К каналу", f"ap:ch:{cid}")],
    )
    return text, kb


async def hub_view(chat_id: int, uid: int):
    c = await store.channel(chat_id)
    st = await store.channel_stats(chat_id)
    rs = await store.rules_of(uid, chat_id)
    nxt = [x for x in (st["next_post"], st["next_rule"]) if x]
    lines = [
        ui.head("📢", escape(c["title"]), (f"@{c['username']} · " if c["username"] else "")
                + ("⏸ на паузе" if c["paused"] else "🟢 работает")),
        ui.stats(("📤 за сутки", st["sent24"]), ("📊 всего", st["total"]), ("📅 в очереди", st["queue"]),
                 ("⏭ ближайшее", timeparse.fmt(min(nxt))) if nxt and not c["paused"] else ("", "")),
    ]
    if rs:
        lines.append(f"🤖 <b>источники · {len(rs)}</b>  " + ui.hint("🟢 работает · ⏸ выкл · ⚠️ ошибка"))
    else:
        lines.append(ui.hint("источников нет — «➕ Источник», и я начну сама"))
    rows = []
    from autopost import sources as _src, rules as _R
    for r in rs:
        icon = _src.TYPES.get(r["type"], ("•",))[0]
        state_ = "🟢" if r["active"] else "⏸"
        warn = "⚠️" if r["last_error"] else ""
        when = timeparse.fmt(r["next_run"]).split(" ")[-1] if r["active"] else "выкл"
        rows.append([(f"{state_}{warn} {icon} {r['title'][:20]} · {when}", f"ap:r:{r['id']}")])
    cid = chat_id
    kb = kb_rows(*rows,
                 [("➕ Источник", f"ap:radd:{cid}"), ("✍️ Пост сюда", f"ap:new:{cid}")],
                 [("📅 Очередь", f"ap:queue:{cid}"), ("📜 История", f"ap:hist:{cid}"), ("🎁 Розыгрыш", f"ap:gw:{cid}")],
                 [("⚙️ Настройки", f"ap:cs:{cid}"), ("▶️ Запустить" if c["paused"] else "⏸ Пауза", f"ap:chs_pause:{cid}")],
                 [("📊 Статистика", f"ap:x_stat:{cid}"), ("🗓 Контент-план", f"ap:x_plan:{cid}")],
                 [("♻️ Обнулить историю", f"ap:chrst:{cid}")],
                 [("‹ Все каналы", "ap:home")])
    return "\n".join(lines), kb


async def _own_channel(cb: CallbackQuery) -> int | None:
    cid = int(cb.data.rsplit(":", 1)[1])
    if not await store.channel(cid, cb.from_user.id):
        await cb.answer("канал не найден", show_alert=True)
        return None
    return cid


@router.callback_query(F.data.startswith("ap:ch:"))
async def cb_channel(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if cid := await _own_channel(cb):
        await show(cb, *await hub_view(cid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:cs:"))
async def cb_ch_settings(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if cid := await _own_channel(cb):
        await show(cb, *await channel_view(cid))


@router.callback_query(F.data.startswith("ap:chrst:"))
async def cb_ch_reset(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        await show(cb, "<b>♻️ обнулить историю канала?</b>\n\n"
                       "все источники канала забудут, что уже выкладывали, и смогут снова взять те же "
                       "картинки, видео и треки. копилки начнутся с начала.\n"
                       "<i>опубликованные посты в канале не трогаю</i>",
                   kb_rows([("♻️ Да, обнулить", f"ap:chrstok:{cid}"), ("‹ Нет", f"ap:ch:{cid}")]))


@router.callback_query(F.data.startswith("ap:chrstok:"))
async def cb_ch_resetok(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        await store.reset_channel_history(cid)
        await cb.answer("♻️ история канала обнулена", show_alert=True)
        await show(cb, *await hub_view(cid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:chs_jit:"))
async def cb_ch_jit(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        c = await store.channel(cid)
        cur = JITTERS.index(c["jitter"]) if c["jitter"] in JITTERS else 0
        await store.set_channel(cid, jitter=JITTERS[(cur + 1) % len(JITTERS)])
        await show(cb, *await channel_view(cid))


@router.callback_query(F.data.startswith("ap:chs_rx:"))
async def cb_ch_rx(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        c = await store.channel(cid)
        cur = c.get("auto_react") or ""
        nxt = REACTS[(REACTS.index(cur) + 1) % len(REACTS)] if cur in REACTS else ""
        await store.set_channel(cid, auto_react=nxt)
        await show(cb, *await channel_view(cid))


@router.callback_query(F.data.startswith("ap:chs_night:"))
async def cb_ch_night(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        c = await store.channel(cid)
        await store.set_channel(cid, night_silent=0 if c["night_silent"] else 1)
        await show(cb, *await channel_view(cid))


@router.callback_query(F.data.startswith("ap:chs_pause:"))
async def cb_ch_pause(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        c = await store.channel(cid)
        await store.set_channel(cid, paused=0 if c["paused"] else 1)
        await show(cb, *await hub_view(cid, cb.from_user.id))


@router.callback_query(F.data.startswith("ap:chs_del:"))
async def cb_ch_del(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        await show(cb, "<b>отключить канал?</b>\nочередь для него отменится, источники выключатся",
                   kb_rows([("🗑 Да, отключить", f"ap:chs_delok:{cid}"), ("‹ Нет", f"ap:cs:{cid}")]))


@router.callback_query(F.data.startswith("ap:chs_delok:"))
async def cb_ch_delok(cb: CallbackQuery, state: FSMContext):
    if cid := await _own_channel(cb):
        await store.del_channel(cid)
        await cb_home(cb, state)


@router.callback_query(F.data.startswith("ap:chs_slots:"))
async def cb_ch_slots(cb: CallbackQuery, state: FSMContext):
    if cid := await _own_channel(cb):
        await state.set_state(AP.ch_slots)
        await state.update_data(cid=cid)
        await show(cb, "<b>🕐 слоты публикаций</b>\n"
                       "пришли время через пробел, например:\n<code>9:00 13:30 18:00 21:00</code>\n\n"
                       "<i>«📥 В слот» в редакторе ставит пост в ближайшее свободное</i>",
                   cancel_kb(f"ap:cs:{cid}"))


@router.message(AP.ch_slots, F.text)
async def st_ch_slots(m: Message, state: FSMContext):
    cid = (await state.get_data())["cid"]
    slots = timeparse.parse_slots(m.text)
    if not slots or len(slots) > 24:
        return await m.answer("не поняла. пример: <code>10:00 14:00 19:00</code>")
    await store.set_channel(cid, slots=json.dumps(slots))
    await state.clear()
    await show(m, *await channel_view(cid))


@router.callback_query(F.data.startswith("ap:chs_sign:"))
async def cb_ch_sign(cb: CallbackQuery, state: FSMContext):
    if cid := await _own_channel(cb):
        await state.set_state(AP.ch_sign)
        await state.update_data(cid=cid)
        await show(cb, "<b>✍️ подпись</b>\nдобавлю её в конец каждого поста.\n"
                       "пример: <code>🖤 @mychannel</code>\n\n«-» — убрать подпись",
                   cancel_kb(f"ap:cs:{cid}"))


@router.message(AP.ch_sign, F.text)
async def st_ch_sign(m: Message, state: FSMContext):
    cid = (await state.get_data())["cid"]
    sig = "" if m.text.strip() == "-" else m.text.strip()[:200]
    await store.set_channel(cid, signature=sig)
    await state.clear()
    await show(m, *await channel_view(cid))


# ================= очередь =================
async def queue_view(uid: int, chat_id: int | None = None):
    rows = await (store.queue_of(uid, chat_id) if chat_id else store.queue(uid))
    title = ""
    if chat_id:
        title = " · " + escape((await store.channel(chat_id))["title"])
    text = f"<b>📅 очередь</b>{title}\n{ui.LINE}\n"
    if not rows:
        text += "<i>пусто. «✍️ Новый пост» — и поехали</i>"
    btns = []
    for r in rows:
        rep = "🔁" if r["repeat_h"] else ""
        label = f"{timeparse.fmt(r['at'])} {rep}· {r['ch_title'][:12]} · {publisher.snippet(r['ptext'], r['pmedia'], 18)}"
        btns.append([(label, f"ap:qi:{r['id']}")])
    back = f"ap:ch:{chat_id}" if chat_id else "ap:home"
    newp = f"ap:new:{chat_id}" if chat_id else "ap:new"
    return text, kb_rows(*btns, [("✍️ Новый пост", newp)], [("‹ Назад", back)])


@router.callback_query(F.data == "ap:queue")
async def cb_queue(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await show(cb, *await queue_view(cb.from_user.id))


@router.callback_query(F.data.startswith("ap:queue:"))
async def cb_queue_ch(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if cid := await _own_channel(cb):
        await show(cb, *await queue_view(cb.from_user.id, cid))


async def _own_sched(cb: CallbackQuery) -> dict | None:
    sid = int(cb.data.rsplit(":", 1)[1])
    s = await store.sched(sid)
    if not s or not await store.channel(s["chat_id"], cb.from_user.id):
        await cb.answer("уже нет в очереди", show_alert=True)
        return None
    return s


async def qitem_view(s: dict):
    p = await store.post(s["post_id"])
    ch = await store.channel(s["chat_id"])
    rep = {0: "нет", 24: "каждый день", 48: "раз в 2 дня", 168: "раз в неделю"}.get(s["repeat_h"], f"{s['repeat_h']}ч")
    text = (
        f"<b>📌 в очереди</b>\n{ui.LINE}\n"
        f"📢 {escape(ch['title'])}\n"
        f"⏰ <b>{timeparse.fmt(s['at'])}</b>\n"
        f"🔁 повтор: {rep}\n\n"
        f"<i>{escape(publisher.snippet(p['text'], p['media'], 120))}</i>"
    )
    sid = s["id"]
    kb = kb_rows(
        [("👁 Превью", f"ap:qprev:{sid}"), ("✏️ Править", f"ed:open:{p['id']}:{sid}")],
        [("🚀 Сейчас", f"ap:qnow:{sid}"), ("⏰ Перенести", f"ap:qtime:{sid}")],
        [("🗑 Убрать", f"ap:qdel:{sid}"), ("‹ Очередь", "ap:queue")],
    )
    return text, kb


@router.callback_query(F.data.startswith("ap:qi:"))
async def cb_qitem(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if s := await _own_sched(cb):
        await show(cb, *await qitem_view(s))


@router.callback_query(F.data.startswith("ap:qprev:"))
async def cb_qprev(cb: CallbackQuery, bot: Bot):
    if s := await _own_sched(cb):
        p = await store.post(s["post_id"])
        await publisher.send(bot, p, cb.from_user.id, await store.channel(s["chat_id"]), preview=True)
        await show(cb.message, *await qitem_view(s))
        await cb.answer()


@router.callback_query(F.data.startswith("ap:qnow:"))
async def cb_qnow(cb: CallbackQuery, bot: Bot):
    if s := await _own_sched(cb):
        if s["status"] != "queued":
            return await cb.answer("уже не в очереди", show_alert=True)
        await store.set_at(s["id"], time.time() - 1)
        await engine.publish_due(bot)
        s = await store.sched(s["id"])
        ok = s["status"] in ("sent", "deleted")
        await cb.answer("🚀 опубликовано" if ok else f"⚠️ {s['err'] or 'не вышло'}"[:190], show_alert=not ok)
        await show(cb, *await queue_view(cb.from_user.id))


@router.callback_query(F.data.startswith("ap:qdel:"))
async def cb_qdel(cb: CallbackQuery):
    if s := await _own_sched(cb):
        await store.mark(s["id"], "cancelled")
        await show(cb, *await queue_view(cb.from_user.id))


TIME_HINT = ("пришли время:\n"
             "<code>18:30</code> · <code>завтра 10:00</code> · <code>25.12 20:00</code>\n"
             "<code>+2ч</code> · <code>через 30м</code>\n<i>время московское</i>")


@router.callback_query(F.data.startswith("ap:qtime:"))
async def cb_qtime(cb: CallbackQuery, state: FSMContext):
    if s := await _own_sched(cb):
        await state.set_state(AP.q_time)
        await state.update_data(sid=s["id"])
        await show(cb, "<b>⏰ перенести</b>\n" + TIME_HINT, cancel_kb(f"ap:qi:{s['id']}"))


@router.message(AP.q_time, F.text)
async def st_qtime(m: Message, state: FSMContext):
    ts = timeparse.parse(m.text)
    if not ts:
        return await m.answer("не поняла время 🤔\n" + TIME_HINT)
    sid = (await state.get_data())["sid"]
    await store.set_at(sid, ts)
    await state.clear()
    await show(m, *await qitem_view(await store.sched(sid)))


# ================= история =================
STATUS_ICON = {"sent": "✅", "deleted": "🗑", "failed": "⚠️"}


@router.callback_query(F.data == "ap:hist")
async def cb_hist(cb: CallbackQuery):
    await _hist(cb, None)


@router.callback_query(F.data.startswith("ap:hist:"))
async def cb_hist_ch(cb: CallbackQuery):
    if cid := await _own_channel(cb):
        await _hist(cb, cid)


async def _hist(cb: CallbackQuery, chat_id):
    rows = await store.history_of(cb.from_user.id, chat_id, 15)
    lines = [f"<b>📜 последние публикации</b>", ui.LINE]
    if not rows:
        lines.append("<i>ещё ничего не публиковала</i>")
    for r in rows:
        when = timeparse.fmt(r["sent_at"] or r["at"])
        line = f"{STATUS_ICON.get(r['status'], '•')} {when} · {escape(r['ch_title'][:20])}"
        if r["status"] == "failed" and r["err"]:
            line += f"\n    <i>{escape(r['err'][:80])}</i>"
        lines.append(line)
    await show(cb, "\n".join(lines), kb_rows([("‹ Назад", f"ap:ch:{chat_id}" if chat_id else "ap:home")]))


@router.callback_query(F.data == "ap:errs")
async def cb_errs(cb: CallbackQuery):
    from autopost import sources as _src
    rs = await store.errors_of(cb.from_user.id)
    lines = ["<b>⚠️ источники с ошибками</b>", ui.LINE]
    if not rs:
        lines.append("<i>всё чисто ✨</i>")
    rows = []
    for r in rs:
        icon = _src.TYPES.get(r["type"], ("•",))[0]
        lines.append(f"{icon} <b>{escape(r['title'][:30])}</b> → {escape((r['ch_title'] or '?')[:20])}\n"
                     f"    <i>{escape(r['last_error'][:120])}</i>")
        rows.append([(f"{icon} {r['title'][:28]}", f"ap:r:{r['id']}")])
    await show(cb, "\n".join(lines), kb_rows(*rows, [("‹ Назад", "ap:home")]))
