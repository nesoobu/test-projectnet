"""Узкие боты на том же коде (BOT_PROFILE в окружении): ⬇️ dl — только скачивание, 🎵 music — только музыка.
Их задача — находиться в поиске Telegram по своим словам и приводить людей к основной Соне."""
import hashlib
import logging

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandStart
from aiogram.types import (Message, InlineQuery, InlineQueryResultsButton, InlineQueryResultCachedVideo,
                           InlineQueryResultCachedAudio, InlineQueryResultCachedPhoto)

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("solo")


def _main_btn():
    return ("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}") if config.MAIN_BOT else None


TEXTS = {
    "dl": (ui.head("⬇️", "Скачаю видео и музыку", "без водяных знаков и рекламы")
           + "\n" + ui.quote("просто кинь ссылку 👇\n"
                             "TikTok · YouTube и Shorts · Instagram Reels · Pinterest · VK · RuTube · X · Reddit · "
                             "Likee · Threads · Twitch · Дзен\n"
                             "🎧 SoundCloud, Spotify, Яндекс Музыка — пришлю mp3\n"
                             "🖼 фото-карусели TikTok и Pinterest — альбомом")
           + "\n" + ui.hint("ещё: голосовые и кружки → текст · работаю и в группах · "
                             "в любом чате: <code>@бот ссылка</code> — пришлю уже скачанное")),
    "music": (ui.head("🎵", "Найду любую песню", "и узнаю, что играет")
              + "\n" + ui.quote("✍️ напиши название или строчку из песни — пришлю mp3\n"
                                "🎙 пришли голосовое, кружок или видео — скажу, что за трек (как Shazam)\n"
                                "🔗 ссылка на Spotify, Яндекс Музыку, SoundCloud — скачаю\n"
                                "📝 под каждым треком — кнопка «Текст песни»")
              + "\n" + ui.hint("просто напиши, например: «скриптонит космос» · "
                               "в любом чате: <code>@бот название</code> — кину трек прямо туда")),
}


async def _start_text(m: Message, bot: Bot) -> tuple[str, object]:
    text = TEXTS.get(config.PROFILE, "")
    if config.MAIN_BOT:
        text += f"\n\n🖤 <i>а поболтать, поиграть и порисовать — у @{config.MAIN_BOT}</i>"
    btn = _main_btn()
    return text, (kb_rows([btn]) if btn else None)


@router.message(CommandStart())
@router.message(Command("help", "menu"))
async def solo_start(m: Message, bot: Bot):
    arg = ((m.text or "").split(maxsplit=1) + [""])[1].strip()
    if arg.startswith("q_") and await _from_inline(m, bot, arg[2:]):
        return
    text, kb = await _start_text(m, bot)
    await m.answer(text, reply_markup=kb)


# ---------- мягко зовём к Соне: один раз на 3-м скачивании и ещё раз на 30-м ----------
NUDGE_AT = (3, 30)


async def nudge(m: Message, uid: int):
    if not config.MAIN_BOT:
        return
    u = await db.get_user(uid)
    if not u or u.get("dls") not in NUDGE_AT:
        return
    try:
        await m.answer("🖤 нравится, как я качаю? у меня есть старшая сестра — "
                       f"@{config.MAIN_BOT}: болтает, рисует, играет в группах и тоже качает видео.",
                       reply_markup=kb_rows([_main_btn()]))
    except Exception as e:
        log.info("nudge: %s", e)


# ---------- инлайн: @бот ссылка / @бот название ----------
async def _park(kind: str, value: str) -> str:
    """Запрос не влезает в start-параметр (64 символа) — кладём в kv, отдаём короткий ключ."""
    tok = hashlib.md5(f"{kind}|{value}".encode()).hexdigest()[:12]
    await db.kv_set(f"iq:{tok}", f"{kind}|{value}")
    return "q_" + tok


async def _from_inline(m: Message, bot: Bot, tok: str) -> bool:
    raw = await db.kv_get(f"iq:{tok}")
    if "|" not in raw:
        return False
    kind, value = raw.split("|", 1)
    if kind == "dl":
        from downloader import links as L
        from handlers import media
        found = L.find_links(value)
        if not found:
            return False
        await m.answer("⬇️ качаю твою ссылку…")
        await media.handle_link(m, bot, found[0])
        return True
    if kind == "f":
        from handlers import tools
        await tools.find_music(m, value)
        return True
    return False


def _words(q: str) -> list[str]:
    return [w for w in q.casefold().split() if len(w) > 1]


async def _cached_audio(q: str, n: int = 20) -> list[dict]:
    ws = _words(q)
    if not ws:
        return []
    rows = await db.q_all("SELECT key, file_id, title FROM dl_cache WHERE type='audio' AND title!='' "
                          "ORDER BY ts DESC LIMIT 3000")
    return [r for r in rows if all(w in r["title"].casefold() for w in ws)][:n]


def _rid(*parts) -> str:
    return hashlib.md5("|".join(map(str, parts)).encode()).hexdigest()


@router.inline_query()
async def solo_inline(q: InlineQuery):
    text = (q.query or "").strip()
    results, button = [], None
    if config.PROFILE == "dl":
        from downloader import links as L
        found = L.find_links(text)
        if not found:
            button = InlineQueryResultsButton(text="⬇️ вставь ссылку на видео — или открой бота", start_parameter="go")
        else:
            url = found[0].url
            for kind in ("video", "audio", "photo"):
                c = await db.dl_cache_get(f"{kind}:{url}")
                if not c:
                    continue
                rid = _rid(kind, url)
                if c["type"] == "video":
                    results.append(InlineQueryResultCachedVideo(id=rid, video_file_id=c["file_id"],
                                                                title=f"🎬 {c['title'] or found[0].label}"[:60]))
                elif c["type"] == "audio":
                    results.append(InlineQueryResultCachedAudio(id=rid, audio_file_id=c["file_id"]))
                else:
                    results.append(InlineQueryResultCachedPhoto(id=rid, photo_file_id=c["file_id"]))
            button = InlineQueryResultsButton(
                text="⬇️ скачать в боте" if not results else "⬇️ открыть в боте",
                start_parameter=await _park("dl", url))
    elif config.PROFILE == "music":
        if len(text) < 2:
            button = InlineQueryResultsButton(text="🎵 напиши название песни", start_parameter="go")
        else:
            for r in await _cached_audio(text):
                results.append(InlineQueryResultCachedAudio(id=_rid("a", r["key"]), audio_file_id=r["file_id"]))
            button = InlineQueryResultsButton(text=f"🔎 найти «{text[:30]}» в боте",
                                              start_parameter=await _park("f", text[:100]))
    await q.answer(results, cache_time=5, is_personal=True, button=button)


# ---------- музыка: любой текст — поиск, любой звук — «что играет» ----------
def _music(_m: Message) -> bool:
    return config.PROFILE == "music"


def _no_links(m: Message) -> bool:
    from downloader import links as L
    return not L.find_links(m.text or "")   # со ссылкой — пусть идёт дальше, в скачивание


@router.message(F.chat.type == "private", F.voice | F.audio | F.video | F.video_note, _music)
async def music_shazam(m: Message, bot: Bot):
    from handlers import tools
    await tools.shazam(m, bot, m)


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"), _no_links)
async def private_text(m: Message, bot: Bot):
    if config.PROFILE == "music":
        from handlers import tools
        return await tools.find_music(m, m.text.strip()[:100])
    text, kb = await _start_text(m, bot)
    await m.answer("👀 кинь ссылку на видео — скачаю.\n\n" + text, reply_markup=kb)
