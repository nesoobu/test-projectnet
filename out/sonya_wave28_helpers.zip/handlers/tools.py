"""Инструменты: озвучка, поиск музыки, «что за трек», рисование, фото, цитаты, погода, курс."""
import asyncio
import base64
import io
import logging
import random
import re
import time
import uuid
from html import escape
from urllib.parse import quote

import aiohttp
from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, FSInputFile, BufferedInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import llm
import persona
import ui
from autopost import media_dl
from downloader import core
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("tools")
_last: dict[tuple[int, str], float] = {}


def too_soon(uid: int, what: str, sec: int) -> int:
    from handlers import extra
    if extra.active(uid):  # Соня+ — без ожидания
        return 0
    now = time.time()
    left = int(sec - (now - _last.get((uid, what), 0)))
    if left > 0:
        return left
    _last[(uid, what)] = now
    return 0


def _tmp(ext: str) -> str:
    media_dl._dir()
    return str(media_dl.DL / (uuid.uuid4().hex + ext))


# ================= 🗣 озвучка =================
VOICES = {
    "sonya": ("Соня", "ru-RU-SvetlanaNeural"),
    "dasha": ("Даша", "ru-RU-DariyaNeural"),
    "dima": ("Дима", "ru-RU-DmitryNeural"),
    "jenny": ("Jenny 🇺🇸", "en-US-JennyNeural"),
    "guy": ("Guy 🇺🇸", "en-US-GuyNeural"),
    "nanami": ("Nanami 🇯🇵", "ja-JP-NanamiNeural"),
    "polina": ("Поліна 🇺🇦", "uk-UA-PolinaNeural"),
    "aigul": ("Айгуль 🇰🇿", "kk-KZ-AigulNeural"),
}


async def tts(text: str, voice_key: str, rate: str = "+0%", pitch: str = "+0Hz") -> str:
    import edge_tts
    voice = VOICES.get(voice_key, VOICES["sonya"])[1]
    path = _tmp(".mp3")
    last = None
    for _ in range(3):  # edge-tts иногда отдаёт пустоту — пробуем ещё
        try:
            try:
                com = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
            except TypeError:   # старый edge-tts без pitch
                com = edge_tts.Communicate(text, voice, rate=rate)
            await com.save(path)
            return path
        except Exception as e:
            last = e
            await asyncio.sleep(1)
    raise RuntimeError(f"озвучка не ответила: {str(last)[:80]}")


async def say(m: Message, bot: Bot, text: str):
    text = re.sub(r"\s+", " ", text).strip()[:1000]
    if not text:
        return await m.reply("что озвучить? <code>/voice привет</code> или ответь /voice на сообщение")
    if (left := too_soon(m.from_user.id, "tts", 5)):
        return await m.reply(f"секунду, ещё {left} с")
    u = await db.get_user(m.from_user.id) or {}
    vk = u.get("voice") or "sonya"
    await bot.send_chat_action(m.chat.id, ChatAction.RECORD_VOICE)
    path = None
    try:
        path = await tts(text, vk)
        await m.reply_voice(FSInputFile(path), caption=f"🗣 {VOICES.get(vk, VOICES['sonya'])[0]}")
        db.emit("voice", m.from_user.id)
    except Exception as e:
        await m.reply(f"😕 {escape(str(e))}")
    finally:
        core.remove(path)


@router.message(Command("voice", "say", "озвучь"))
async def cmd_voice(m: Message, bot: Bot, command: CommandObject):
    text = command.args or ""
    if not text and m.reply_to_message:
        text = m.reply_to_message.text or m.reply_to_message.caption or ""
    await say(m, bot, text)


def voices_kb(cur: str):
    btns = [(("✓ " if k == cur else "") + n, f"vc:{k}") for k, (n, _) in VOICES.items()]
    return kb_rows(*[btns[i:i + 2] for i in range(0, len(btns), 2)])


@router.message(Command("voices", "голоса"))
async def cmd_voices(m: Message):
    u = await db.get_user(m.from_user.id) or {}
    await m.answer("<b>🗣 голос для озвучки</b>\nвыбери, каким голосом говорить",
                   reply_markup=voices_kb(u.get("voice") or "sonya"))


@router.callback_query(F.data.startswith("vc:"))
async def cb_voice(cb: CallbackQuery):
    k = cb.data[3:]
    if k not in VOICES:
        return await cb.answer()
    await db.set_voice(cb.from_user.id, k)
    try:
        await cb.message.edit_reply_markup(reply_markup=voices_kb(k))
    except TelegramBadRequest:
        pass
    await cb.answer(f"теперь говорю как {VOICES[k][0]}")


# ================= 🎵 поиск музыки =================
_found: dict[str, tuple[str, str, float]] = {}


def _search_sync(q: str, n: int) -> list[dict]:
    import yt_dlp
    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "extract_flat": True}) as y:
        info = y.extract_info(f"ytsearch{n}:{q}", download=False)
    out = []
    for e in info.get("entries") or []:
        if not e or not e.get("id"):
            continue
        dur = int(e.get("duration") or 0)
        if dur and dur > 15 * 60:
            continue
        out.append({"id": e["id"], "title": e.get("title") or "", "dur": dur,
                    "who": e.get("channel") or e.get("uploader") or ""})
    return out


async def find_music(m: Message, query: str):
    query = query.strip()[:100]
    if len(query) < 2:
        return await m.reply("что ищем? <code>/find Земфира хочешь</code>")
    if (left := too_soon(m.from_user.id, "find", 3)):
        return await m.reply(f"секунду, ещё {left} с")
    st = await m.reply("🔎 ищу…")
    try:
        res = await asyncio.to_thread(_search_sync, query, 6)
    except Exception as e:
        return await st.edit_text(f"😕 поиск не ответил: {escape(str(e)[:80])}")
    if not res:
        return await st.edit_text("ничего не нашла 🤷")
    rows = []
    for r in res[:6]:
        tok = uuid.uuid4().hex[:10]
        _found[tok] = (f"https://youtu.be/{r['id']}", r["title"], time.time())
        d = f" · {r['dur'] // 60}:{r['dur'] % 60:02d}" if r["dur"] else ""
        rows.append([(f"🎵 {r['title'][:45]}{d}", f"fm:{tok}")])
    await st.edit_text(f"🔎 <b>{escape(query)}</b> — выбирай:", reply_markup=kb_rows(*rows))


@router.message(Command("find", "найди", "music"))
async def cmd_find(m: Message, command: CommandObject):
    await find_music(m, command.args or "")


@router.callback_query(F.data.startswith("fm:"))
async def cb_found(cb: CallbackQuery, bot: Bot):
    rec = _found.get(cb.data[3:])
    if not rec:
        return await cb.answer("поиск устарел — поищи заново", show_alert=True)
    url, title, _ = rec
    await cb.answer("качаю…")
    cached = await db.dl_cache_get(f"audio:{url}")
    if cached:
        await db.count_dl(cb.from_user.id)
        await cb.message.answer_audio(cached["file_id"], reply_markup=kb_rows([lyrics_btn(title)]))
        return await _after_dl(cb.message, cb.from_user.id)
    await bot.send_chat_action(cb.message.chat.id, ChatAction.UPLOAD_VOICE)
    f = None
    try:
        f = await core.download(url, "audio")
        sent = await cb.message.answer_audio(FSInputFile(f["path"]), title=f.get("title") or title,
                                             performer=f.get("performer") or None,
                                             duration=f.get("duration") or None,
                                             reply_markup=kb_rows([lyrics_btn(title)]))
        if sent.audio:
            await db.dl_cache_put(f"audio:{url}", "audio", sent.audio.file_id, title)
        await db.count_dl(cb.from_user.id)
        await _after_dl(cb.message, cb.from_user.id)
    except media_dl.DLError as e:
        await cb.message.answer(f"😕 не скачалось: {escape(str(e))}")
    finally:
        core.remove(f and f.get("path"))


async def _after_dl(m: Message, uid: int):
    if config.PROFILE != "full" and m.chat.type == "private":
        from handlers import solo
        await solo.nudge(m, uid)


# ================= 📝 текст песни (lrclib.net — бесплатно, без ключа) =================
def clean_title(t: str) -> str:
    t = re.sub(r"[\(\[][^)\]]*[\)\]]", " ", t or "")          # (Official Video), [Lyrics]
    t = re.sub(r"(?i)\b(official|video|audio|lyrics?|клип|премьера|mv|hd|4k)\b", " ", t)
    return re.sub(r"\s+", " ", t.replace("|", " ").replace("«", "").replace("»", "")).strip(" -–—")


async def lyrics(query: str) -> dict | None:
    q = clean_title(query)
    if len(q) < 2:
        return None
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=12),
                                     headers={"User-Agent": "SonyaBot/1.0"}) as s:
        async with s.get("https://lrclib.net/api/search", params={"q": q}) as r:
            if r.status != 200:
                return None
            res = await r.json(content_type=None)
    for it in res or []:
        if it.get("plainLyrics") and not it.get("instrumental"):
            return {"artist": it.get("artistName") or "", "title": it.get("trackName") or "",
                    "text": it["plainLyrics"]}
    return None


def lyrics_btn(query: str):
    tok = uuid.uuid4().hex[:10]
    _found[tok] = ("", query, time.time())
    return ("📝 Текст песни", f"ly:{tok}")


@router.callback_query(F.data.startswith("ly:"))
async def cb_lyrics(cb: CallbackQuery):
    rec = _found.get(cb.data[3:])
    if not rec:
        return await cb.answer("кнопка устарела — найди трек заново", show_alert=True)
    if (left := too_soon(cb.from_user.id, "lyr", 3)):
        return await cb.answer(f"секунду, ещё {left} с")
    await cb.answer("ищу текст…")
    try:
        got = await lyrics(rec[1])
    except Exception as e:
        log.info("lyrics: %s", e)
        got = None
    if not got:
        return await cb.message.answer("🤷 текста не нашла — может, инструментал или трек редкий")
    body = escape(got["text"].strip())
    if len(body) > 3700:
        body = body[:3700] + "…"
    await cb.message.answer(f"📝 <b>{escape(got['artist'])} — {escape(got['title'])}</b>\n"
                            f"<blockquote expandable>{body}</blockquote>")


# ================= 🔎 что за трек =================
async def recognize(path: str) -> dict | None:
    from shazamio import Shazam
    out = await Shazam().recognize(path)
    t = (out or {}).get("track")
    if not t:
        return None
    return {"title": t.get("title") or "", "artist": t.get("subtitle") or "",
            "url": t.get("url") or "", "cover": ((t.get("images") or {}).get("coverart") or "")}


async def shazam(m: Message, bot: Bot, target: Message):
    obj = target.audio or target.voice or target.video or target.video_note or \
        (target.document if target.document and (target.document.mime_type or "").startswith(("audio", "video")) else None)
    if not obj:
        return await m.reply("ответь <b>/shazam</b> на аудио, видео, голосовое или кружок")
    if (obj.file_size or 0) > 20 * 1024 * 1024:
        return await m.reply("файл больше 20 МБ — телеграм не даёт мне его скачать")
    if (left := too_soon(m.from_user.id, "shazam", 5)):
        return await m.reply(f"секунду, ещё {left} с")
    st = await m.reply("🎧 слушаю…")
    path = _tmp(".bin")
    try:
        await bot.download(obj.file_id, destination=path)
        res = await recognize(path)
    except Exception as e:
        log.warning("shazam: %s", e)
        return await st.edit_text("😕 не получилось послушать")
    finally:
        core.remove(path)
    if not res:
        return await st.edit_text("🤷 не узнала трек. попробуй кусок подлиннее и почище")
    tok = uuid.uuid4().hex[:10]
    q = f"{res['artist']} {res['title']}"
    _found[tok] = (f"ytsearch1:{q} audio", q, time.time())
    text = f"🎵 <b>{escape(res['artist'])} — {escape(res['title'])}</b>"
    if res["url"]:
        text += f'\n<a href="{escape(res["url"], quote=True)}">shazam</a>'
    await st.edit_text(text, reply_markup=kb_rows([("⬇️ Скачать трек", f"fm:{tok}"), lyrics_btn(q)]))


@router.message(Command("shazam", "трек"))
async def cmd_shazam(m: Message, bot: Bot):
    target = m.reply_to_message or m
    await shazam(m, bot, target)


# ================= 🎨 рисование =================
async def draw(m: Message, bot: Bot, prompt: str, uid: int | None = None):
    uid = uid or m.from_user.id
    prompt = prompt.strip()[:400]
    if len(prompt) < 3:
        return await m.reply("что нарисовать? <code>/draw кот в космосе, аниме</code>")
    if (left := too_soon(uid, "draw", 20)):
        return await m.reply(f"кисточки сохнут, ещё {left} с 🎨")
    await bot.send_chat_action(m.chat.id, ChatAction.UPLOAD_PHOTO)
    st = await m.reply("🎨 рисую…")
    en = prompt
    try:
        en = await llm.ask([{"role": "system", "content": "Translate this image prompt to English, make it vivid "
                                                          "and detailed (max 60 words). Only the prompt."},
                            {"role": "user", "content": prompt}], max_tokens=300, temperature=0.4) or prompt
    except Exception:
        pass
    seed = random.randint(1, 10 ** 6)
    url = (f"https://image.pollinations.ai/prompt/{quote(en)}?width=1024&height=1024&nologo=true"
           f"&seed={seed}&model=flux")
    try:
        data = await fetch_image(url)
        await m.reply_photo(BufferedInputFile(data, "art.jpg"), caption=f"🎨 {escape(prompt[:200])}",
                            reply_markup=kb_rows([("🔁 Ещё вариант", "dr:again")]))
        _last_prompt[uid] = prompt
        db.emit("draw", uid)
        await st.delete()
    except Exception as e:
        await st.edit_text(f"😕 не нарисовалось: {escape(str(e)[:100])}")


_last_prompt: dict[int, str] = {}


def image_variants(url: str) -> list[str]:
    """С ключом — сначала gen.pollinations.ai (платный, без лимитов). Без ключа анонимный хост
    режет «nologo» и flux (402) — тогда пробуем попроще."""
    out = [url]
    if config.POLLINATIONS_TOKEN and url.startswith("https://image.pollinations.ai/prompt/"):
        gen = url.replace("https://image.pollinations.ai/prompt/", "https://gen.pollinations.ai/image/")
        gen = re.sub(r"[&?](?:nologo=true|model=flux)", "", gen).replace("?&", "?")
        out.insert(0, gen)
    if "nologo=true" in url and not config.POLLINATIONS_TOKEN:
        out.append(re.sub(r"[&?]nologo=true", "", url).replace("?&", "?"))
    if "model=flux" in out[-1]:
        out.append(re.sub(r"[&?]model=flux", "", out[-1]).replace("?&", "?"))
    return out


async def fetch_image(url: str) -> bytes:
    headers = {"Authorization": f"Bearer {config.POLLINATIONS_TOKEN}"} if config.POLLINATIONS_TOKEN else {}
    last = "?"
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120), headers=headers) as s:
        for u in image_variants(url):
            async with s.get(u) as r:
                if r.status == 200 and (r.headers.get("Content-Type") or "").startswith("image"):
                    return await r.read()
                last = r.status
            if last not in (402, 403, 429, 500, 502, 503):
                break
    raise RuntimeError(f"сервис ответил {last}")


@router.message(Command("draw", "нарисуй", "img"))
async def cmd_draw(m: Message, bot: Bot, command: CommandObject):
    await draw(m, bot, command.args or "")


@router.callback_query(F.data == "dr:again")
async def cb_draw_again(cb: CallbackQuery, bot: Bot):
    p = _last_prompt.get(cb.from_user.id)
    if not p:
        return await cb.answer("напиши /draw и что нарисовать", show_alert=True)
    await cb.answer()
    await draw(cb.message, bot, p, uid=cb.from_user.id)


# ================= 👀 фото =================
async def look(m: Message, bot: Bot, question: str):
    ph = m.photo[-1] if m.photo else None
    if not ph:
        return
    if (left := too_soon(m.from_user.id, "look", 5)):
        return await m.reply(f"секунду, ещё {left} с")
    import limits
    if not await limits.take(m.from_user.id):
        return await m.reply(limits.tired_text(m.from_user.id))
    await bot.send_chat_action(m.chat.id, ChatAction.TYPING)
    buf = io.BytesIO()
    await bot.download(ph.file_id, destination=buf)
    data_url = "data:image/jpeg;base64," + base64.b64encode(buf.getvalue()).decode()
    system = persona.BASE + "\n" + persona.mood() + "\nТебе прислали фото. Ответь на вопрос или прокомментируй, коротко."
    try:
        out = await llm.ask_vision(system, question or "что скажешь про это фото?", data_url, max_tokens=400)
    except Exception as e:
        log.info("vision: %s", e)
        await limits.give_back(m.from_user.id)
        out = random.choice(["глаза у меня сегодня не работают 🙈 скинь попозже",
                             "не могу разглядеть, кажется, зрение отвалилось"])
    await m.reply(out[:3500], parse_mode=None)


# ================= 💬 цитаты =================
def _font(size: int, bold: bool = False):
    from PIL import ImageFont
    names = (["DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"] if bold else
             ["DejaVuSans.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"])
    for n in names:
        try:
            return ImageFont.truetype(n, size)
        except OSError:
            continue
    return ImageFont.load_default()


def _wrap(draw, text: str, font, width: int) -> list[str]:
    lines = []
    for para in text.split("\n"):
        cur = ""
        for w in para.split():
            t = (cur + " " + w).strip()
            if draw.textlength(t, font=font) <= width:
                cur = t
            else:
                if cur:
                    lines.append(cur)
                cur = w
        lines.append(cur)
    return lines


PALETTES = [((88, 28, 135), (190, 24, 93)), ((15, 23, 42), (51, 65, 85)), ((30, 58, 138), (14, 116, 144)),
            ((124, 45, 18), (190, 18, 60)), ((20, 83, 45), (21, 94, 117))]


def quote_image(text: str, author: str, avatar: bytes | None) -> bytes:
    from PIL import Image, ImageDraw
    W = 512
    f_text, f_name = _font(26), _font(22, bold=True)
    tmp = Image.new("RGB", (W, 10))
    d = ImageDraw.Draw(tmp)
    lines = _wrap(d, text[:600], f_text, W - 130)[:14]
    H = max(150, 70 + len(lines) * 34 + 30)
    c1, c2 = random.choice(PALETTES)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bg = Image.new("RGB", (W, H))
    bd = ImageDraw.Draw(bg)
    for y in range(H):
        k = y / H
        bd.line([(0, y), (W, y)], fill=tuple(int(c1[i] + (c2[i] - c1[i]) * k) for i in range(3)))
    mask = Image.new("L", (W, H), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, H - 1], radius=28, fill=255)
    img.paste(bg, (0, 0), mask)
    d = ImageDraw.Draw(img)
    # аватар
    av = 64
    if avatar:
        try:
            a = Image.open(io.BytesIO(avatar)).convert("RGB").resize((av, av))
            am = Image.new("L", (av, av), 0)
            ImageDraw.Draw(am).ellipse([0, 0, av, av], fill=255)
            img.paste(a, (22, 22), am)
        except Exception:
            avatar = None
    if not avatar:
        d.ellipse([22, 22, 22 + av, 22 + av], fill=(255, 255, 255, 60))
        d.text((22 + av / 2, 22 + av / 2), (author[:1] or "?").upper(), font=_font(30, True), fill="white", anchor="mm")
    d.text((106, 26), author[:28], font=f_name, fill=(255, 220, 240))
    y = 60
    for ln in lines:
        d.text((106, y), ln, font=f_text, fill="white")
        y += 34
    out = io.BytesIO()
    img.save(out, "WEBP")
    return out.getvalue()


@router.message(Command("quote", "цитата", "q"))
async def cmd_quote(m: Message, bot: Bot):
    t = m.reply_to_message
    if not t or not (t.text or t.caption):
        return await m.reply("ответь <b>/quote</b> на сообщение с текстом — сделаю стикер-цитату")
    u = t.forward_from or t.from_user
    author = (u.full_name if u else None) or (t.forward_sender_name or "аноним")
    avatar = None
    try:
        if u:
            ph = await bot.get_user_profile_photos(u.id, limit=1)
            if ph.total_count:
                buf = io.BytesIO()
                await bot.download(ph.photos[0][0].file_id, destination=buf)
                avatar = buf.getvalue()
    except Exception:
        pass
    data = await asyncio.to_thread(quote_image, t.text or t.caption, author, avatar)
    await m.reply_sticker(BufferedInputFile(data, "quote.webp"))


# ================= ⛅ погода =================
WMO = {0: "☀️ ясно", 1: "🌤 почти ясно", 2: "⛅ переменная облачность", 3: "☁️ пасмурно", 45: "🌫 туман",
       48: "🌫 туман", 51: "🌦 морось", 53: "🌦 морось", 55: "🌦 морось", 61: "🌧 дождь", 63: "🌧 дождь",
       65: "🌧 ливень", 71: "🌨 снег", 73: "🌨 снег", 75: "❄️ снегопад", 77: "🌨 снег", 80: "🌦 ливень",
       81: "🌧 ливень", 82: "⛈ ливень", 85: "🌨 снег", 86: "❄️ снегопад", 95: "⛈ гроза", 96: "⛈ гроза", 99: "⛈ гроза"}


async def weather(city: str) -> str:
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
        async with s.get("https://geocoding-api.open-meteo.com/v1/search",
                         params={"name": city, "count": 1, "language": "ru"}) as r:
            g = await r.json(content_type=None)
        if not g.get("results"):
            return f"не знаю такой город: {escape(city)} 🤔"
        p = g["results"][0]
        async with s.get("https://api.open-meteo.com/v1/forecast", params={
            "latitude": p["latitude"], "longitude": p["longitude"], "timezone": "auto",
            "current": "temperature_2m,apparent_temperature,weather_code,wind_speed_10m,relative_humidity_2m",
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max", "forecast_days": 2,
        }) as r:
            w = await r.json(content_type=None)
    c, d = w["current"], w["daily"]
    t = round(c["temperature_2m"])
    desc = WMO.get(c["weather_code"], "🌡")
    vibe = ("кутайся, холодно 🧣" if t < 0 else "куртка обязательна" if t < 10 else
            "норм, но толстовку возьми" if t < 18 else "тепло, кайф ☀️" if t < 27 else "жара, пей воду 🥵")
    rain = d["precipitation_probability_max"][0]
    if rain and rain >= 50:
        vibe += " · зонт не забудь ☂️"
    return (f"<b>{escape(p['name'])}</b>{', ' + escape(p.get('country', '')) if p.get('country') else ''}\n"
            f"{desc}, <b>{t}°</b> (ощущается {round(c['apparent_temperature'])}°)\n"
            f"💨 {round(c['wind_speed_10m'])} км/ч · 💧 {c['relative_humidity_2m']}%\n"
            f"сегодня {round(d['temperature_2m_min'][0])}…{round(d['temperature_2m_max'][0])}°, "
            f"завтра {round(d['temperature_2m_min'][1])}…{round(d['temperature_2m_max'][1])}°\n\n<i>{vibe}</i>")


@router.message(Command("weather", "погода"))
async def cmd_weather(m: Message, command: CommandObject):
    city = (command.args or "Москва").strip()
    try:
        await m.reply(await weather(city))
    except Exception as e:
        await m.reply(f"😕 погода не ответила: {escape(str(e)[:80])}")


# ================= 💱 курс =================
async def cbr() -> dict:
    async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
        async with s.get("https://www.cbr-xml-daily.ru/daily_json.js") as r:
            data = await r.json(content_type=None)
    return data["Valute"]


async def rates() -> str:
    v = await cbr()
    lines = ["<b>💱 курс ЦБ</b>", ui.LINE]
    for code, flag in (("USD", "🇺🇸"), ("EUR", "🇪🇺"), ("CNY", "🇨🇳"), ("KZT", "🇰🇿"), ("TRY", "🇹🇷")):
        if code in v:
            x = v[code]
            val = x["Value"] / x["Nominal"]
            diff = val - x["Previous"] / x["Nominal"]
            arrow = "🔺" if diff > 0 else "🔻" if diff < 0 else "▫️"
            lines.append(f"{flag} {code}: <b>{val:.2f} ₽</b> {arrow}{abs(diff):.2f}")
    from handlers import studio
    crypto = await studio.crypto_lines()
    if crypto:
        lines += ["", *crypto]
    lines.append("\n<i>посчитать: «100 долларов в рубли» или /conv</i>")
    return "\n".join(lines)


@router.message(Command("rate", "курс"))
async def cmd_rate(m: Message):
    try:
        await m.reply(await rates())
    except Exception as e:
        await m.reply(f"😕 курс не ответил: {escape(str(e)[:80])}")


# ================= меню инструментов =================
TOOLS_TEXT = (
    ui.head("🛠", "Инструменты", "большинство работает и словами: «нарисуй…», «найди…»")
    + "\n" + ui.quote("⬇️ <b>скачать</b> — просто кинь ссылку\n"
                      "🎵 <b>трек</b> — /find название · 🔎 <b>что играет</b> — /shazam ответом\n"
                      "🗣 <b>озвучить</b> — /voice текст · 📝 <b>расшифровать</b> — /text ответом\n"
                      "🎨 <b>нарисовать</b> — /draw кот-самурай · 👀 <b>фото</b> — пришли с вопросом")
    + "\n" + ui.quote("🖼 /mem · ⭕ /circle · 🎞 /gif · ✂️ /cut · 🔳 /qr\n"
                      "📄 PDF и DOCX — перескажу · 🔎 /search — поищу в интернете\n"
                      "⛅ /weather · 💱 /rate · «100 $ в рубли» · ☀️ /morning")
)


@router.callback_query(F.data == "m:tools")
async def cb_tools(cb: CallbackQuery):
    try:
        await cb.message.edit_text(TOOLS_TEXT, reply_markup=kb_rows(
            [("🗣 Голос озвучки ›", "t:voices"), ("☀️ Утренняя рассылка ›", "mo:open")],
            [("❔ Подробнее", "m:help:tools"), ("‹ Меню", "m:home")]))
    except TelegramBadRequest:
        pass
    await cb.answer()


@router.callback_query(F.data == "t:voices")
async def cb_tvoices(cb: CallbackQuery):
    u = await db.get_user(cb.from_user.id) or {}
    await cb.message.answer("<b>🗣 голос для озвучки</b>", reply_markup=voices_kb(u.get("voice") or "sonya"))
    await cb.answer()
