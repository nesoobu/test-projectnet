from html import escape
from aiogram.utils.keyboard import InlineKeyboardBuilder

# уровни: (xp с которого, значок, название)
LEVELS = [
    (0, "🌱", "Новичок"),
    (50, "💬", "Свой"),
    (200, "🎧", "Завсегдатай"),
    (500, "🔥", "Огонь"),
    (1200, "⭐", "Звезда"),
    (3000, "👑", "Легенда"),
]


def esc(s) -> str:
    return escape(str(s or ""))


def level(xp: int) -> tuple[int, str, str, int, int]:
    """→ (номер, значок, название, xp начала уровня, xp следующего или 0)"""
    idx = 0
    for i, (need, *_rest) in enumerate(LEVELS):
        if xp >= need:
            idx = i
    start = LEVELS[idx][0]
    nxt = LEVELS[idx + 1][0] if idx + 1 < len(LEVELS) else 0
    return idx + 1, LEVELS[idx][1], LEVELS[idx][2], start, nxt


def bar(cur: int, total: int, width: int = 10) -> str:
    if total <= 0:
        return "▰" * width
    filled = max(0, min(width, round(cur / total * width)))
    return "▰" * filled + "▱" * (width - filled)


LINE = "──────────────"


# ================= дизайн-система: все экраны собираются из этих кусков =================
def head(icon: str, title: str, sub: str = "") -> str:
    """Шапка экрана: значок + заголовок, подзаголовок курсивом, тонкая линия."""
    return f"{icon} <b>{title}</b>" + (f"\n<i>{sub}</i>" if sub else "") + f"\n{LINE}"


def quote(text: str, expandable: bool = False) -> str:
    return f"<blockquote{' expandable' if expandable else ''}>{text}</blockquote>"


def stats(*pairs) -> str:
    """Карточка цифр в цитате: («🪙 монетки», 120) → «🪙 монетки · 120»."""
    return quote("\n".join(f"{k} · <b>{v}</b>" for k, v in pairs if k))


def item(icon: str, title: str, desc: str = "") -> str:
    return f"{icon} <b>{title}</b>" + (f" — {desc}" if desc else "")


def hint(text: str) -> str:
    return f"<i>{text}</i>"


def tog(v) -> str:
    """Переключатель: ✅ включено / ⬜ выключено."""
    return "✅" if v else "⬜"


def start_text(name: str) -> str:
    return (
        f"🖤 <b>хей, {esc(name)}</b>\n"
        "<i>я соня — болтаю, подкалываю и много чего умею</i>\n"
        f"{LINE}\n"
        + quote("⬇️ кинь ссылку — скачаю видео и музыку\n"
                "🎙 голосовые и кружки — расшифрую\n"
                "🎨 нарисую · 🗣 озвучу · 👀 посмотрю фото\n"
                "🎮 игры на монетки · 📢 автопостинг в каналы")
        + "\n" + hint("или просто напиши мне что-нибудь 👇")
    )


def main_menu(owner: bool = False):
    kb = InlineKeyboardBuilder()
    for text, data in (("🎮 Игры", "g:menu"), ("🎁 Бонус дня", "g:bonus"),
                       ("🛠 Инструменты", "m:tools"), ("📢 Автопостинг", "ap:home"),
                       ("👤 Профиль", "m:profile"), ("🏆 Топ", "m:top:xp"),
                       ("🎭 Характер", "m:mode"), ("🧠 Что я помню", "m:facts"),
                       ("✨ Соня+", "m:plus"), ("👥 Позвать друга", "m:ref"),
                       ("❔ Помощь", "m:help"), ("⭐ Поддержать", "m:donate")):
        kb.button(text=text, callback_data=data)
    if owner:
        kb.button(text="⚙️ Админка", callback_data="adm:home")
    kb.adjust(2, 2, 2, 2, 2, 2, 1)
    return kb.as_markup()


def back_kb(extra: list[tuple[str, str]] | None = None):
    kb = InlineKeyboardBuilder()
    for t, d in extra or []:
        kb.button(text=t, callback_data=d)
    kb.button(text="‹ Назад", callback_data="m:home")
    n = len(extra or [])
    sizes = [3] * (n // 3) + ([n % 3] if n % 3 else [])
    kb.adjust(*sizes, 1)
    return kb.as_markup()


def profile_text(u: dict, rank: int, donated: int, title: str = "") -> str:
    import time as _t
    n, icon, lvl_title, start, nxt = level(u["xp"])
    prog = (f"{bar(u['xp'] - start, nxt - start)}  {u['xp']}/{nxt}" if nxt else f"{bar(1, 1)}  максимум")
    sub = []
    if (u.get("plus_until") or 0) > _t.time():
        from autopost.timeparse import fmt
        sub.append(f"✨ Соня+ до {fmt(u['plus_until'])}")
    if title:
        sub.append(title)
    lines = [head(icon, esc(u["name"]), " · ".join(sub)),
             f"уровень <b>{n}</b> · {lvl_title}", f"<code>{prog}</code>", "",
             stats(("🪙 монетки", u.get("coins", 0)), ("🏅 победы", u.get("wins", 0)),
                   ("🔥 стрик", f"{u['streak']} дн.") if u.get("streak") else ("", ""),
                   ("💬 сообщений", u["msgs"]), ("❤️ репутация", u["rep"]), ("🏆 место в топе", f"#{rank}"),
                   ("⭐ поддержал", donated) if donated else ("", ""),
                   ("👥 привёл друзей", u["refs"]) if u.get("refs") else ("", ""))]
    return "\n".join(lines)


TOP_TITLES = {"xp": "🏆 Топ по уровню", "coins": "🪙 Топ богачей", "rep": "❤️ Топ по репутации",
              "msgs": "💬 Топ болтунов", "season_wins": "⚔️ Сезон: победы за месяц"}
MEDALS = ["🥇", "🥈", "🥉"]


def top_text(field: str, rows: list[dict]) -> str:
    icon, title = TOP_TITLES[field].split(" ", 1)
    out = [head(icon, title, "переключай рейтинги кнопками ниже")]
    if not rows:
        out.append(hint("пусто. будь первым"))
    lines = []
    for i, r in enumerate(rows):
        mark = MEDALS[i] if i < 3 else f"<code>{i + 1:>2}.</code>"
        lines.append(f"{mark} {esc(r['name'])} — <b>{r['v']}</b>")
    if lines:
        out.append(quote("\n".join(lines)))
    return "\n".join(out)


def top_kb(field: str):
    btns = [(("· " if f == field else "") + t.split(" ", 1)[0], f"m:top:{f}") for f, t in TOP_TITLES.items()]
    return back_kb(btns)


HELP = (
    head("❔", "что я умею", "всё по разделам — выбери нужный")
    + "\n" + quote("💬 в личке — просто пиши\n👥 в группе — «Соня, …» или ответ на моё сообщение\n"
                   "⬇️ ссылка — скачаю · 🎙 голосовое — расшифрую · 👀 фото — посмотрю")
    + "\n" + hint("выбери раздел 👇")
)

# раздел: (кнопка, текст). Каждый — отдельный экран, лимит 4096 на раздел
HELP_SECTIONS = {
    "chat": ("💬 Общение и память", (
        "<b>💬 Общение</b>\n"
        "в личке — просто пиши · в группе — «Соня, …» или ответ на моё сообщение\n"
        "/reset — забыть текущий диалог\n"
        "голосовые в личке — расшифрую и отвечу, иногда голосом 🎙\n"
        "🧠 в день до 100 ИИ-ответов (с Соней+ — больше) · пишу ответ прямо у тебя на глазах\n"
        "🎭 /mode — мой характер: обычная, милая, ботан; с Соней+ — злая, дворовая, психолог\n"
        "🤝 чем больше болтаем, тем мы ближе: незнакомец → приятель → друг → лучший друг\n"
        "🔎 «соня, загугли …» или /search — найду свежее в интернете\n"
        "📄 пришли PDF, DOCX или txt — перескажу и отвечу на вопросы по нему (/read — в группе)\n\n"
        "<b>🧠 Память</b>\n"
        "«соня, запомни: я люблю аниме» — запомню · важное из разговора запоминаю сама\n"
        "/memory — что я о тебе помню · /forget — забыть всё\n"
        "🎂 /bday 12.05 или «у меня др 12 мая» — поздравлю и подарю 🪙\n"
        "💌 пропадёшь на пару дней — напишу первой (/nudge — вкл/выкл)\n"
        "🔮 /horo — гороскоп по твоему ДР, он же в утренней рассылке\n\n"
        "<b>⏰ Напоминания</b>\n"
        "«соня, напомни через 2 часа выпить воды», «напомни завтра в 10:00 созвон», "
        "«напомни каждый день в 9:00 зарядка» · /reminders — список\n"
        "под напоминанием: 💤 10 мин · ⏰ час · 📅 завтра · ✅ готово")),
    "games": ("🎮 Игры и монетки", (
        "<b>🎮 Игры и монетки</b>\n"
        "/games — кости, дартс, баскет, футбол, боулинг, 🎰 казино, ✊ КНБ-дуэли, 🧠 квиз, 🔤 виселица\n"
        "🧞 /aki — акинатор: загадай персонажа, я угадаю\n"
        "🎵 /emoji — угадай песню по эмодзи · 🎭 /pd — правда или действие\n"
        "⚔️ /duel 50 — дуэль на кубиках на ставку (ответом — конкретному человеку)\n"
        "🐾 /pet — питомец: корми и играй, а то сбежит · /pet имя Барсик\n"
        "🎡 /wheel — колесо фортуны раз в 20 ч (монетки или день Соня+) · 🃏 /bj 50 — блэкджек\n"
        "в группе: 🕵️ /spy, 🔪 /mafia, 🐊 /croc — крокодил по картинке, 🎟 /lottery — лотерея дня, "
        "/stopgame — стоп\n\n"
        "<b>💰 Экономика</b>\n"
        "/bonus — ежедневные 🪙, стрик растёт · 📋 /quests — 3 задания дня\n"
        "/shop — титулы · /give 50 ответом — подарить монетки\n"
        "💍 /marry ответом — предложение · /divorce — развод\n\n"
        "<b>🏆 Уровни и топы</b>\n"
        "/me — профиль · /top — топ · 🏅 /ach — достижения с наградами\n"
        "🏆 сезон: топ по победам за месяц — первые три получают 🪙, первый — титул\n"
        "ответь «+» или «спасибо» на сообщение — +1 репутации автору")),
    "tools": ("🛠 Инструменты", (
        "<b>🛠 Инструменты</b>\n"
        "🎵 /find название — найду трек (или «найди …») · 🔎 /shazam ответом — что за трек · 📝 под треком — текст, ❤️ в мои, 🔁 похожие\n"
        "🔥 /chart — чарт · ❤️ /my — мои треки · 🔔 /subs — релизы · 📊 /taste — мой вкус\n"
        "🎛 под треком: slowed, sped up, 8D, bass, ✂️ рингтон, 🎙 голосовым · 🔎 «что за песня» под видео\n"
        "🎮 /melody [артист] — угадай мелодию (в группе — на скорость)\n"
        "🗣 /voice текст — озвучу (или «озвучь …»), /voices — выбрать голос\n"
        "🎨 /draw что-то — нарисую (или «нарисуй …»)\n"
        "👀 пришли фото с вопросом — посмотрю и отвечу\n"
        "💬 /quote ответом — стикер-цитата · ⛅ /weather город\n"
        "💱 /rate — курс ЦБ и крипта · «100 долларов в рубли» или /conv — посчитаю\n"
        "🖼 /mem верх | низ — мем из фото · ⭕ /circle — кружок из видео · 🎞 /gif — гифка\n"
        "✂️ /cut 0:30 1:00 ответом на аудио — вырежу кусок (рингтон) · 🔳 /qr текст — QR-код\n"
        "☀️ /morning — каждое утро погода, курс и факт дня (в личку или в группу)\n\n"
        "<b>⬇️ Скачивание</b>\n"
        "кинь ссылку — пришлю файл: YouTube и Shorts, TikTok, Instagram, Pinterest, VK, RuTube, X, Reddit, "
        "Likee, Threads, Twitch-клипы, Дзен и др.\n"
        "🎧 SoundCloud и YouTube Music — звуком, Spotify / Яндекс Музыка / Apple Music — найду трек и пришлю mp3\n"
        "длинное видео (10+ мин) — спрошу: видео или только звук; под видео есть «🎵 Звук отдельно»\n"
        "каналы и плейлисты целиком не качаю\n\n"
        "<b>📝 Расшифровка</b>\n"
        "голосовые и кружки расшифровываю сама, длинные — с кнопкой «✨ Кратко»\n"
        "/text — ответом на голосовое, кружок, аудио или видео")),
    "groups": ("👥 Группы", (
        "<b>👥 В группах</b>\n"
        "/settings — админы включают/выключают: болтовню, авто-скачивание, расшифровку, приветствия, живые реакции, "
        "капчу для новичков, антифлуд, запрет ссылок, поздравления с ДР, 🌙 итоги дня в 23:00, "
        "🤖 ИИ-антиспам (новички со ссылками и «заработком» — удаляю и мучу)\n"
        "📜 /rules текст — правила (кнопка в приветствии) · 📝 /note имя текст — заметка, вызов #имя, /notes\n"
        "🌙 /quiet 23-8 — ночная тишина: ночью пишут только админы\n"
        "👋 /welcome текст с {name} — своё приветствие · 🧹 уборка «вошёл/вышел» в /settings\n"
        "🚨 /report ответом — жалоба админам в личку\n"
        "🤗 РП ответом на сообщение: обнять, кусь, погладить, дай пять, на чай… · 💞 /pair — пара дня · ⭐ /hero\n"
        "🙈 /me, /bonus, /quests, /memory в группе видишь только ты — чат не засоряется\n"
        "🧾 /summary или «соня, что я пропустил» — сводка переписки · 🌍 /tr ответом — перевод\n"
        "📊 /stats — болтуны недели, активные часы, слово недели\n"
        "🎂 /bday — у кого скоро день рождения\n"
        "🛡 админам ответом: /warn (3 = мут на сутки), /unwarn, /mute 30m|2h|1d, /unmute, /kick, /ban")),
    "autopost": ("📢 Автопостинг", (
        "<b>📢 Автопостинг</b>\n"
        "/panel — панель автопостинга · /giveaway — розыгрыш в канале с проверкой подписки\n"
        "✍️ посты: кнопки, реакции, отложка, слоты, повтор, автоудаление, ИИ-редактура\n"
        "🤖 автоисточники: 🎵 Яндекс Музыка · 🎧 SoundCloud/YouTube-аудио · 🎬 видео файлами · "
        "📌 Pinterest · ✈️ TG-каналы · 👽 Reddit · 📰 RSS · 📦 копилка · 🧠 ИИ-рубрики\n"
        "у каждого: своё расписание (интервал/время/дни/часы), порядок, фильтры, живые подписи от ИИ (видит картинку), "
        "популярные хэштеги, шаблон, реакции, модерация\n"
        "♻️ обнуление истории — источник или весь канал снова сможет выкладывать уже взятое\n"
        "📋 источник можно скопировать или перенести в другой канал\n"
        "💜 Соня может сама ставить реакцию под каждым постом (настройка канала)\n"
        "🎞 видео достаю настоящие: видео-пины Pinterest, видео из TG-каналов и Reddit, гифки; можно «только видео»\n"
        "🟦 VK-паблики — новый источник\n"        "📌 Pinterest без поиска вручную: напиши слова (<code>парные аватарки</code>) или дай ссылку на один пин — "
        "возьму похожие по цепочке; пины-карусели — альбомом\n"
        "💧 водяной знак на картинках · 🧬 похожие картинки не повторяю (даже пережатые) — в настройках канала\n"
        "🗓 контент-план на неделю от ИИ — кнопка в канале\n"
        "📊 статистика канала: лучшие посты и лучшее время — по реакциям на кнопки Сони")),
    "plus": ("✨ Соня+ и друзья", (
        "<b>✨ Соня+ и друзья</b>\n"
        "/plus — Соня+ за ⭐: без ожидания, больше ИИ-ответов в день, бонус ×2, титул, режимы характера\n"
        "неделя 29 ⭐ · месяц 99 ⭐ · год 799 ⭐\n"
        "🎁 /gift @username или ответом — подарить Соню+ другу\n"
        "/ref — ссылка для друзей, обоим по 50 🪙\n"
        "🔎 в любом чате набери @ и мой ник с вопросом — отвечу, нарисую, погадаю\n"
        "/donate — просто поддержать звёздами")),
    "owner": ("⚙️ Владельцу", (
        "<b>⚙️ Владельцу</b>\n"
        "/admin — админка: статистика, рассылка, юзеры, баны, все каналы, ошибки, проверка ИИ, расход ИИ, сервер\n"
        "📊 графики активности и воронка новичков · 📣 рассылка по сегментам: всем, активным, Соня+, без, группам\n"
        "👤 /user id или @ник — карточка: выдать 🪙, Соня+, бан · /grant 123 coins 500\n"
        "📝 /admin → «Профиль бота» — описание для каталогов одной кнопкой\n"
        "в .env: REQUIRED_CHANNEL — обязательная подписка на канал · FREE_CHANNELS — лимит каналов без Соня+ · "
        "VK_TOKEN — источник VK\n"
        "🎨 /ui — конструктор: свой текст, эмодзи и премиум-эмодзи, медиа и ссылки на любом экране; "
        "у кнопок — текст, премиум-иконка, цвет, скрыть")),
}


def help_kb():
    kb = InlineKeyboardBuilder()
    for k, (btn, _t) in HELP_SECTIONS.items():
        kb.button(text=btn, callback_data=f"m:help:{k}")
    kb.button(text="‹ Меню", callback_data="m:home")
    kb.adjust(2, 2, 2, 1, 1)
    return kb.as_markup()


def help_section(key: str) -> str:
    return HELP_SECTIONS[key][1] + "\n\n<i>/help — все разделы</i>"


# ================= рост: «поделиться» и личные ответы в группах =================
async def share_url(bot, uid: int, text: str) -> str:
    """Ссылка «поделиться»: текст результата + реферальная ссылка на Соню (друзьям — бонус)."""
    from urllib.parse import quote as _q
    me = await bot.me()
    return (f"https://t.me/share/url?url={_q(f'https://t.me/{me.username}?start=ref_{uid}')}"
            f"&text={_q(text[:300])}")


async def personal(m, text: str, reply_markup=None):
    """В группе — эфемерно: видит только автор, чат не засоряется. Не вышло — обычный ответ."""
    if m.chat.type in ("group", "supergroup") and m.from_user:
        from aiogram.types import EphemeralMessageParameters
        try:
            return await m.answer(text, ephemeral_message_parameters=EphemeralMessageParameters(
                receiver_user_id=m.from_user.id))
        except Exception:
            pass
    return await m.reply(text, reply_markup=reply_markup)
