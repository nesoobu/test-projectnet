"""Узкие боты на том же коде (BOT_PROFILE в окружении): ⬇️ dl — только скачивание, 🎵 music — только музыка.
Их задача — находиться в поиске Telegram по своим словам и приводить людей к основной Соне."""
from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandStart
from aiogram.types import Message

import config
import ui
from handlers.ap_common import kb_rows

router = Router()


def _main_btn():
    return ("🖤 Познакомиться с Соней", f"https://t.me/{config.MAIN_BOT}") if config.MAIN_BOT else None


TEXTS = {
    "dl": (ui.head("⬇️", "Скачаю видео и музыку", "без водяных знаков и рекламы")
           + "\n" + ui.quote("просто кинь ссылку 👇\n"
                             "TikTok · YouTube и Shorts · Instagram Reels · Pinterest · VK · RuTube · X · Reddit · "
                             "Likee · Threads · Twitch · Дзен\n"
                             "🎧 SoundCloud, Spotify, Яндекс Музыка — пришлю mp3\n"
                             "🖼 фото-карусели TikTok и Pinterest — альбомом")
           + "\n" + ui.hint("ещё: голосовые и кружки → текст · работаю и в группах")),
    "music": (ui.head("🎵", "Найду любую песню", "и узнаю, что играет")
              + "\n" + ui.quote("✍️ напиши название или строчку из песни — пришлю mp3\n"
                                "🎙 пришли голосовое, кружок или видео — скажу, что за трек (как Shazam)\n"
                                "🔗 ссылка на Spotify, Яндекс Музыку, SoundCloud — скачаю")
              + "\n" + ui.hint("просто напиши, например: «скриптонит космос»")),
}


async def _start_text(m: Message, bot: Bot) -> tuple[str, object]:
    text = TEXTS.get(config.PROFILE, "")
    if config.MAIN_BOT:
        text += f"\n\n🖤 <i>а поболтать, поиграть и порисовать — у @{config.MAIN_BOT}</i>"
    btn = _main_btn()
    return text, (kb_rows([btn]) if btn else None)


@router.message(CommandStart())
@router.message(Command("help", "menu"))
async def solo_start(m: Message, bot: Bot):
    text, kb = await _start_text(m, bot)
    await m.answer(text, reply_markup=kb)


# ---------- музыка: любой текст — поиск, любой звук — «что играет» ----------
def _music(_m: Message) -> bool:
    return config.PROFILE == "music"


def _no_links(m: Message) -> bool:
    from downloader import links as L
    return not L.find_links(m.text or "")   # со ссылкой — пусть идёт дальше, в скачивание


@router.message(F.chat.type == "private", F.voice | F.audio | F.video | F.video_note, _music)
async def music_shazam(m: Message, bot: Bot):
    from handlers import tools
    await tools.shazam(m, bot, m)


@router.message(F.chat.type == "private", F.text, ~F.text.startswith("/"), _no_links)
async def private_text(m: Message, bot: Bot):
    if config.PROFILE == "music":
        from handlers import tools
        return await tools.find_music(m, m.text.strip()[:100])
    text, kb = await _start_text(m, bot)
    await m.answer("👀 кинь ссылку на видео — скачаю.\n\n" + text, reply_markup=kb)
