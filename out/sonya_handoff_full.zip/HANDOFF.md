# Соня — передача проекта в новый чат

Прочти это целиком. В архиве: `sonya/` — актуальный код (= волна 27), `tests/` — тесты, `sonya_promo_kit.md` — продвижение.

## Кто я и как работаем
- Тим, ИП, делаю Telegram-ботов. Работаю **только с телефона через Termius**, команды выполняю по шагам.
- Отвечать: по-русски, коротко, с юмором, без пересказов и чек-листов.
- Код для `nano` и команды терминала — **в разных блоках**. Команды установки — в чат, не в zip.
- Каждое обновление — **отдельный zip с новым именем** `sonya_waveNN_*.zip` (следующая — **wave28**). Старые не перезаписывать.
- В zip **не класть** `.env`, `data/`, `__pycache__`.
- Всё новое — в `/help` (`ui.HELP` / `HELP_SECTIONS`, лимит 4096 символов на раздел).
- Прежде чем описывать возможность бота — проверить в коде.
- Токены в чат не просить — Тим вставляет их в `.env` сам. Не советовать покупать «рефералов».

## Сервер
- Код: `/home/sonya/sonya`, юзер `sonya`, служба `sonya` (systemd).
- `ExecStart=/home/sonya/sonya/venv312/bin/python main.py`, `WorkingDirectory=/home/sonya/sonya`.
- venv от uv, pip поставлен через `python -m ensurepip`. `uv` в PATH нет.
- Zip-ы Тим кладёт в `/root/`. Шаблон установки:
```
systemctl stop sonya
unzip -o /root/sonya_waveNN_xxx.zip -d /home/sonya/sonya
chown -R sonya:sonya /home/sonya/sonya
systemctl start sonya
sleep 5; journalctl -u sonya -n 10 --no-pager
```
- Новые pip-зависимости: `/home/sonya/sonya/venv312/bin/python -m pip install ...`
- Серверу нужен reboot (давно висит).

## Стек
Python 3.12, aiogram 3.31, SQLite (aiosqlite).
- Новые таблицы — в `db.SCHEMA_V14`/`V15`, новые колонки — ALTER в `db.init()`.
- ИИ: Groq через OpenAI-совместимый API. Цепочка: основная → `LLM_MODEL_FALLBACK` → второй провайдер (`LLM_URL_2`/`LLM_KEY_2`/`LLM_MODEL_2`).
- Зрение: `qwen/qwen3.8-27b` с `reasoning_effort: "none"` (preview — может пропасть). Картинку Соня сама качает и шлёт data-URL.
- Рисование: pollinations, с `POLLINATIONS_TOKEN` → `gen.pollinations.ai/image/` (ключ берут на enter.pollinations.ai/keys).
- Стриминг: `send_message_draft` в личке, при ошибке — правки.
- Эфемерные ответы в группах: `ui.personal()` (`EphemeralMessageParameters`), фолбэк — обычный reply.
- edge-tts 6.1 без `pitch` — обёрнуто в try/except.

Переменные окружения: BOT_TOKEN OWNER_ID LLM_KEY LLM_URL LLM_MODEL LLM_MODEL_FALLBACK LLM_URL_2 LLM_KEY_2 LLM_MODEL_2 LLM_VISION_MODEL SEARCH_MODEL STREAM STT_URL STT_KEY STT_MODEL POLLINATIONS_TOKEN VK_TOKEN YTDLP_COOKIES AI_DAY_LIMIT AI_DAY_LIMIT_PLUS FREE_CHANNELS REQUIRED_CHANNEL BOT_PROFILE DB_FILE MAIN_BOT.
Config использует `setdefault` — переменные systemd перекрывают `.env`.

## Дизайн и UI
- `ui.py`: `head`, `quote` (blockquote), `stats`, `hint`, `tog` ✅/⬜, `LINE`, `share_url`, `personal`.
- Кнопки «›» открывают список выбора. В помощи — «‹ Разделы» и «‹ Меню», окна не путать.
- `uikit`: экран узнаётся по первой строке текста, кнопка — по callback + тексту.
- `ap_common.kb_rows`: data с http(s):// или tg:// → URL-кнопка.

## Карта модулей
- `main.py` — `routers_for(profile)`, `SOLO_CMDS`, `setup_commands` (чистит чужие команды во всех scope/языках).
- `limits.py`, `achievements.py`, `handlers/life.py` — ДР, /stats, /ach, nudge.
- `handlers/fun.py` — задания (asyncio.Lock на юзера), браки, питомец, дуэль, лотерея, сезоны.
- `handlers/aigames.py` — акинатор, крокодил, правда/действие, эмодзи-песня.
- `handlers/character.py` — /mode, /search. `handlers/chat.py` — болтовня, стриминг.
- `handlers/community.py` — правила, заметки, тишина, итоги дня, AntiSpam, /welcome, clean_service, /report.
- `handlers/studio.py` — мем, кружок, gif, cut, qr, конвертер, крипта, документы.
- `handlers/luck.py` — колесо, блэкджек, гороскоп. `handlers/rp.py` — РП, /pair, /hero (флаг `rp` в chats).
- `handlers/gate.py` — обязательная подписка. `handlers/admin.py` — /admin, «Сервер» (кнопка «⬆️ Обновить yt-dlp»), «📝 Профиль бота» (BOT_SHORT/BOT_DESC/BIO).
- `handlers/solo.py` — узкие боты. `handlers/media.py` — скачивание, альбомы, TikTok/Pinterest-карусели.
- `downloader/core.py` — yt-dlp, `tiktok_photos` (tikwm API → страница TikTok), `resolve_redirect`, `fetch_bytes`.
- Автопостинг: `autopost/*`, `handlers/ap_*.py`. Pinterest: внутренний API (как gallery-dl), `BaseSearch` без входа работает, `RelatedPinFeed` без входа отдаёт 0 → «похожие» сделаны поиском по ключевым словам пина. Карусели: `carousel_data.carousel_slots[].images`. Фильтр фото/видео под тип канала. dHash-дедуп и водяной знак — `autopost/imgtools.py`.

## Узкие боты (волна 27)
Один код, разные процессы: `BOT_PROFILE=dl|music`, `DB_FILE=dl.db|music.db`, свой BOT_TOKEN, `MAIN_BOT` (по умолчанию Sonya_rubot).
- dl — скачивание + голосовые→текст. music — текст → mp3, звук → «что играет».
- Установка: `/home/sonya/sonya/dl.env` (chmod 600), юнит `sonya-dl.service` = копия `sonya.service` + `EnvironmentFile=/home/sonya/sonya/dl.env` перед `ExecStart`. В логе должно быть «бот-помощник (dl) проснулся».
- После каждого обновления перезапускать все юниты (`sonya`, `sonya-dl`, `sonya-music`).

## Статус
- Волны 14–26 стоят на проде, всё работает (зрение ✅, новое меню ✅).
- **Волна 27 отправлена, Тим ещё не ставил.** Вживую не проверены: tikwm API, парсинг страницы TikTok, черновики-стриминг, эфемерные сообщения (везде есть фолбэк).
- Открыто: продажа звёзд (Тим не выбрал способ оплаты); модель зрения в preview; reboot сервера.

## Тесты
`tests/harness.py` — мок-сессия aiogram (SENT, ADMINS, LEFT, DICE), `setup()` собирает диспетчер как main.
Запуск (из папки tests, venv с requirements.txt):
```
python test_w27.py ../sonya full
BOT_PROFILE=dl python test_w27.py ../sonya dl
python smoke.py ../sonya
```
Первый аргумент — путь к коду. Регрессия — все `test_*.py` подряд.

## Грабли, на которые уже наступали
- Путь установки — `/home/sonya/sonya`, не `/home/sonya`.
- aiogram «проглатывает» апдейт, если хендлер сматчился и сделал return — условия выносить в фильтры.
- `m.answer(*tuple)` с клавиатурой — клавиатура улетает в parse_mode.
- Не выдумывать адреса сервисов — проверять.
