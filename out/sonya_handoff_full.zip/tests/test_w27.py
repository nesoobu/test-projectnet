"""Волна 27: TikTok-карусели, Pinterest-альбомы при скачивании, обновление yt-dlp. Профиль: аргумент 2 (full|dl|music)."""
import asyncio, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
from aiogram.methods import SendMediaGroup, SendAudio, SendPhoto, SetMyCommands

async def main():
    M, bot, dp = await setup()
    from downloader import core
    from autopost import media_dl
    P = config.PROFILE
    if P == "full":
        check("страница TikTok: карусель из JSON", core._tt_from_page(
            '<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">{"a":{"itemStruct":{"desc":"мои фото",'
            '"imagePost":{"images":[{"imageURL":{"urlList":["u1"]}},{"imageURL":{"urlList":["u2"]}}]},'
            '"music":{"playUrl":"m.mp3"}}}}</script>') == {"images": ["u1", "u2"], "music": "m.mp3", "title": "мои фото"})
    async def redirect(url): return "https://www.tiktok.com/@a/photo/7550000000000000000"
    async def photos(url): return {"images": [f"https://x/{i}.jpg" for i in range(12)], "music": "https://x/m.mp3", "title": "карусель"}
    async def fbytes(url, limit=0): return b"\xff\xd8x"
    core.resolve_redirect, core.tiktok_photos, core.fetch_bytes = redirect, photos, fbytes
    SENT.clear()
    await dp.feed_update(bot, msg("https://vt.tiktok.com/ZSq92JKST/", 70, 70))
    groups = H.sent(SendMediaGroup)
    check(f"[{P}] TikTok-карусель: 12 фото = альбом 10 + 2", len(groups) == 2 and len(groups[0].media) == 10 and len(groups[1].media) == 2)
    check(f"[{P}] TikTok-карусель: звук отдельно", H.sent(SendAudio))
    check(f"[{P}] подпись только на первом фото", groups[0].media[0].caption and not groups[0].media[1].caption)
    async def notfound(url): raise media_dl.DLError("такую ссылку не умею")
    async def plainredirect(url): return "https://www.tiktok.com/@a/video/1"
    core.resolve_redirect, core.probe = plainredirect, notfound
    SENT.clear()
    await dp.feed_update(bot, msg("https://vt.tiktok.com/ZSabc1234/", 70, 70))
    check(f"[{P}] yt-dlp не умеет — пробуем как карусель", H.sent(SendMediaGroup))
    # Pinterest-карусель по ссылке
    async def pin(url): return {"type": "photo", "url": "https://i.pinimg.com/736x/a.jpg"}
    async def pindata(url): return {"carousel_data": {"carousel_slots": [{"images": {"736x": {"url": "a"}}}, {"images": {"736x": {"url": "b"}}}]}}
    core.pinterest, media_dl.pinterest_pin = pin, pindata
    SENT.clear()
    await dp.feed_update(bot, msg("https://www.pinterest.com/pin/123/", 70, 70))
    check(f"[{P}] Pinterest-карусель по ссылке — альбомом", H.sent(SendMediaGroup) and len(H.sent(SendMediaGroup)[0].media) == 2)
    if P == "full":
        await dp.feed_update(bot, msg("привет", 70, 70))
        return await done()
    # узкие боты
    SENT.clear()
    await M.setup_commands(bot)
    cmds = [c.command for m in SENT if isinstance(m, SetMyCommands) for c in m.commands]
    check(f"[{P}] свои короткие команды", "start" in cmds and "games" not in cmds and ("find" in cmds) == (P == "music"))
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 71, 71))
    t = texts()[-1]
    check(f"[{P}] свой стартовый экран со ссылкой на Соню", ("Скачаю" if P == "dl" else "Найду любую песню") in t
          and "Sonya_rubot" in str(H.sent(H.SendMessage)[-1].reply_markup))
    from handlers import tools
    called = []
    async def fm(m, q): called.append(q)
    async def sz(m, b, t): called.append("shazam")
    tools.find_music, tools.shazam = fm, sz
    SENT.clear()
    await dp.feed_update(bot, msg("скриптонит космос", 71, 71))
    if P == "music":
        check("music: текст — сразу поиск трека", called == ["скриптонит космос"])
        from aiogram.types import Voice
        await dp.feed_update(bot, msg(None, 71, 71, voice=Voice(file_id="v", file_unique_id="v", duration=3)))
        check("music: голосовое — «что играет»", called[-1] == "shazam")
    else:
        check("dl: текст без ссылки — подсказка, без ИИ", not called and any("кинь ссылку" in t for t in texts()))
    await dp.feed_update(bot, msg("/games", 71, 71))
    check(f"[{P}] игр и болтовни нет", not any("Игры" in (t or "") for t in texts()[-1:]))
    await done()

async def done():
    await db.close()
    print("\nитого провалов:", len(FAILS))

asyncio.run(main())
