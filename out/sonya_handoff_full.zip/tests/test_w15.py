"""Волна 15: задания, браки, питомец, дуэль на ставку, лотерея, сезоны, ИИ-игры, /help по разделам."""
import asyncio
import json
import time
from datetime import datetime

from harness import *  # noqa: F401,F403
import harness as H


async def main():
    M, bot, dp = await setup()
    import llm
    from handlers import fun, aigames, games
    fun.BOT = bot

    async def say(model, messages, mt, t, url=None, key=None):
        return "ок", 1
    llm._call = say
    U = lambda i: db.touch_user(User(id=i, is_bot=False, first_name=f"U{i}"))
    for i in (10, 11, 12, 13):
        await U(i)

    # ---------- задания дня ----------
    qs = await fun.today_quests(10)
    check("задания: 3 штуки, одни и те же за день", len(qs) == 3 and qs == await fun.today_quests(10))
    await db.q_run("DELETE FROM quests WHERE uid=10")
    day = db._day()
    for c in ("bonus", "dl1", "chat5"):
        await db.q_run("INSERT INTO quests(uid, day, code, need) VALUES(10,?,?,?)", day, c, fun.QUESTS[c][1])
    await db.q_run("UPDATE users SET coins=0 WHERE id=10")
    SENT.clear()
    await dp.feed_update(bot, msg("/bonus", 10, 10))
    await asyncio.sleep(0.05)
    check("задание «бонус» засчитано по событию", (await db.q_one(
        "SELECT done FROM quests WHERE uid=10 AND code='bonus'"))["done"] == 1)
    await db.count_dl(10)
    for _ in range(5):
        db.emit("chat", 10)
    await asyncio.sleep(0.1)
    u = await db.get_user(10)
    check("все задания → бонус +50", u["coins"] >= 20 + 10 + 15 + 20 + 50)
    check("уведомление о задании пришло", any("задание выполнено" in t for t in texts()))
    check("уведомление «все задания»", any("все задания дня" in t for t in texts()))
    await dp.feed_update(bot, msg("/quests", 10, 10))
    check("/quests показывает прогресс", "задания на сегодня" in texts()[-1] and "✅" in texts()[-1])

    # ---------- браки ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/marry", -100, 10, "U10", reply=reply_to(11, "U11")))
    pid = (await db.q_one("SELECT id FROM game_state WHERE kind='marry'"))["id"].split(":")[1]
    await dp.feed_update(bot, cbq(f"mr:y:{pid}", -100, 12))
    check("чужой не может принять предложение", await fun.spouse(10) is None)
    await dp.feed_update(bot, cbq(f"mr:y:{pid}", -100, 11))
    s = await fun.spouse(10)
    check("брак заключён", s and s["id"] == 11 and (await fun.spouse(11))["id"] == 10)
    await dp.feed_update(bot, msg("/marry", -100, 12, "U12", reply=reply_to(11, "U11")))
    check("на занятом жениться нельзя", "занят" in texts()[-1])
    await dp.feed_update(bot, msg("/me", 10, 10))
    check("брак в профиле", "в браке с" in texts()[-1])
    await dp.feed_update(bot, msg("/divorce", 10, 10))
    check("развод", await fun.spouse(10) is None)

    # ---------- питомец ----------
    await db.q_run("UPDATE users SET coins=200 WHERE id=12")
    await dp.feed_update(bot, cbq("pet:new:cat", 12, 12))
    p = await fun.get_pet(12)
    check("питомец заведён за 100", p and p["alive"] and (await db.get_user(12))["coins"] == 100)
    await dp.feed_update(bot, cbq("pet:feed", 12, 12))
    check("сытого не кормим (монетки целы)", (await db.get_user(12))["coins"] == 100)
    await db.q_run("UPDATE pets SET fed=?, played=? WHERE uid=12", int(time.time()) - 30 * 3600, int(time.time()) - 3 * 3600)
    full, mood, lvl = fun.pet_state(await fun.get_pet(12))
    check("голод растёт со временем", 35 <= full <= 45)
    await dp.feed_update(bot, cbq("pet:feed", 12, 12))
    p = await fun.get_pet(12)
    check("покормили: −10 🪙, +10 опыта", (await db.get_user(12))["coins"] == 90 and p["xp"] == 10)
    await dp.feed_update(bot, cbq("pet:play", 12, 12))
    await dp.feed_update(bot, cbq("pet:play", 12, 12))
    check("поиграть — раз в 2 часа", (await fun.get_pet(12))["xp"] == 15)
    await dp.feed_update(bot, msg("/pet имя Барсик", 12, 12))
    check("переименовали", (await fun.get_pet(12))["name"] == "Барсик")
    await db.q_run("UPDATE pets SET fed=? WHERE uid=12", int(time.time()) - 80 * 3600)
    p = await fun.get_pet(12)
    check("не кормили 3 дня — сбежал", p and not p["alive"])
    await dp.feed_update(bot, cbq("pet:again", 12, 12))
    check("можно завести нового", await fun.get_pet(12) is None)

    # ---------- дуэль на ставку ----------
    await db.q_run("UPDATE users SET coins=100 WHERE id IN (10, 11)")
    await dp.feed_update(bot, msg("/duel 50", -100, 10, "U10"))
    did = (await db.q_one("SELECT id FROM game_state WHERE kind='sduel'"))["id"].split(":")[1]
    await db.q_run("UPDATE users SET coins=10 WHERE id=11")
    await dp.feed_update(bot, cbq(f"sd:y:{did}", -100, 11, name="U11"))
    check("без денег принять нельзя, дуэль жива", await db.q_one("SELECT 1 FROM game_state WHERE id=?", f"sduel:{did}"))
    await db.q_run("UPDATE users SET coins=100 WHERE id=11")
    H.DICE[:] = [6, 2, 2]
    t0 = time.time()
    await dp.feed_update(bot, cbq(f"sd:y:{did}", -100, 11, name="U11"))
    a, b = (await db.get_user(10))["coins"], (await db.get_user(11))["coins"]
    check("дуэль: победитель забрал банк", a == 150 and b == 50)
    before = (await db.get_user(12))["coins"]
    await dp.feed_update(bot, cbq(f"sd:y:{did}", -100, 12))
    check("дуэль второй раз не принять", (await db.get_user(12))["coins"] == before)
    await dp.feed_update(bot, msg("/duel 5", -100, 10))
    check("ставка меньше минимума — подсказка", "ставка от" in texts()[-1])

    # ---------- лотерея ----------
    await db.q_run("UPDATE users SET coins=100 WHERE id IN (10, 11)")
    fun.LOTTERY_HOUR = 25  # чтобы покупка была открыта в любое время теста
    await dp.feed_update(bot, cbq("lt:buy", -100, 10))
    await dp.feed_update(bot, cbq("lt:buy", -100, 10))
    await dp.feed_update(bot, cbq("lt:buy", -100, 11))
    rows = await db.q_all("SELECT uid, n FROM lottery")
    check("лотерея: билеты куплены", sorted((r["uid"], r["n"]) for r in rows) == [(10, 2), (11, 1)])
    SENT.clear()
    fun.LOTTERY_HOUR = 21
    await fun.draw_lottery(bot, datetime(2099, 1, 1, 22, tzinfo=fun.persona.MSK))
    c10, c11 = (await db.get_user(10))["coins"], (await db.get_user(11))["coins"]
    check("лотерея: банк 60 ушёл одному", sorted([c10 - 60, c11 - 80]) == [0, 60])
    check("лотерея: объявление", any("розыгрыш лотереи" in t for t in texts()))
    await db.q_run("INSERT INTO lottery VALUES(-100, '2000-01-01', 13, 'U13', 2)")
    await db.q_run("UPDATE users SET coins=0 WHERE id=13")
    await fun.draw_lottery(bot, datetime.now(fun.persona.MSK))
    check("лотерея: старая с одним участником — возврат", (await db.get_user(13))["coins"] == 40)

    # ---------- сезоны ----------
    await db.q_run("UPDATE users SET season_wins=0, coins=0")
    await db.add_coins(11, 0, win=True)
    await db.add_coins(11, 0, win=True)
    await db.add_coins(10, 0, win=True)
    await db.kv_set("season", "2000-01")
    SENT.clear()
    await fun.close_season(bot, "2000-02")
    u11, u10 = await db.get_user(11), await db.get_user(10)
    check("сезон: призы 500/300", u11["coins"] == 500 and u10["coins"] == 300)
    check("сезон: титул чемпиону", "champ" in u11["titles"])
    check("сезон: счётчик обнулён", u11["season_wins"] == 0)
    await dp.feed_update(bot, cbq("sh:wear:champ", 11, 11))
    check("титул чемпиона надевается", games.title_of(await db.get_user(11)) == "🏆 Чемпион сезона")
    await dp.feed_update(bot, cbq("m:top:season_wins", 11, 11))
    check("топ сезона открывается", any("Сезон" in t for t in texts()))

    # ---------- акинатор ----------
    steps = iter(['{"q": "Он реальный?"}', '{"q": "Он певец?"}', '{"guess": "Шрек"}', '{"guess": "Фиона"}'])

    async def aki_llm(model, messages, mt, t, url=None, key=None):
        return next(steps), 1
    llm._call = aki_llm
    SENT.clear()
    await dp.feed_update(bot, msg("/aki", 13, 13))
    gid = next(iter(aigames._aki))
    check("акинатор: первый вопрос", any("Он реальный?" in t for t in texts()))
    aigames._aki.clear()   # перезапуск
    await dp.feed_update(bot, cbq(f"ak:{gid}:n", 13, 13))
    await dp.feed_update(bot, cbq(f"ak:{gid}:y", 13, 12))
    check("акинатор: чужие кнопки не работают", len(aigames._aki[gid]["log"]) == 1)
    await dp.feed_update(bot, cbq(f"ak:{gid}:n", 13, 13))
    check("акинатор: догадка", any("Шрек" in t for t in texts()))
    await dp.feed_update(bot, cbq(f"ak:{gid}:lose", 13, 13))
    check("акинатор: после «нет» — новая догадка", any("Фиона" in t for t in texts()))
    await dp.feed_update(bot, cbq(f"ak:{gid}:win", 13, 13))
    check("акинатор: угадала — игра закрыта", await db.q_one("SELECT 1 FROM game_state WHERE id=?", f"aki:{gid}") is None)
    llm._call = say

    # ---------- крокодил ----------
    check("крокодил: «кот» ≠ «который»", not aigames.guessed("кот", "который час"))
    check("крокодил: «Кот!» засчитан", aigames.guessed("кот", "это Кот!"))
    check("крокодил: «подводная лодка» через дефис", aigames.guessed("подводная лодка", "подводная-лодка?"))
    check("крокодил: ё = е", aigames.guessed("ёлка", "елка"))
    from handlers import tools

    async def no_img(url):
        raise RuntimeError("offline")
    tools.fetch_image = no_img
    await dp.feed_update(bot, msg("/croc", -500, 10))
    word = aigames._croc[-500]["word"]
    aigames._croc.clear()
    await aigames.load()
    check("крокодил: поднят после перезапуска", aigames._croc.get(-500, {}).get("word") == word)
    await db.q_run("UPDATE users SET coins=0 WHERE id=11")
    await dp.feed_update(bot, msg("который", -500, 11))
    check("крокодил: неверное не засчитано", -500 in aigames._croc)
    await dp.feed_update(bot, msg(f"это {word}", -500, 11))
    check("крокодил: угадал +25", -500 not in aigames._croc and (await db.get_user(11))["coins"] == 25)

    # ---------- песня по эмодзи, правда/действие ----------
    llm._call = lambda *a, **k: (_ for _ in ()).throw(llm.LLMError("x"))

    async def fail(*a, **k):
        raise llm.LLMError("x")
    llm._call = fail
    SENT.clear()
    await dp.feed_update(bot, msg("/emoji", 13, 13))
    check("эмодзи-песня: вопрос из запаса без ИИ", any("угадай песню" in t for t in texts()))
    await dp.feed_update(bot, cbq("pd:t", -100, 13))
    check("правда или действие", any("правда для" in t for t in texts()))

    # ---------- /help по разделам ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/help", 13, 13))
    kb = H.sent(H.SendMessage)[-1].reply_markup
    check("/help: кнопки разделов", kb and len([b for r in kb.inline_keyboard for b in r]) == 8)
    await dp.feed_update(bot, cbq("m:help:games", 13, 13))
    check("/help: раздел игр", any("акинатор" in t for t in texts()))
    await dp.feed_update(bot, cbq("g:menu", 13, 13))
    check("меню игр открывается", any("лотерея" in t for t in texts()))

    await db.close()
    print("\nитого провалов:", len(FAILS))


asyncio.run(main())
