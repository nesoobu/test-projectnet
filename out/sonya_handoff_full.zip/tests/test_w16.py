"""Волна 16: характер, поток, поиск, группы (правила, заметки, тишина, итоги, антиспам), инструменты, файлы."""
import asyncio
import io
import os
import subprocess
import time
import zipfile

from harness import *  # noqa: F401,F403
import harness as H
from aiogram.methods import (DeleteMessage, RestrictChatMember, SetChatPermissions, SendVideoNote,  # noqa: E402
                             SendAnimation, SendAudio, SendPhoto)
from aiogram.types import Document, Video, PhotoSize, Animation  # noqa: E402


async def main():
    M, bot, dp = await setup()
    import llm
    import persona
    from handlers import chat, studio, community, character, extra, tools
    seen = []

    async def say(model, messages, mt, t, url=None, key=None):
        seen.append(messages)
        return "ответ", 1
    llm._call = say
    config.STREAM = False
    U = lambda i, n=None: db.touch_user(User(id=i, is_bot=False, first_name=n or f"U{i}"))
    for i in (20, 21, 22):
        await U(i)

    # ---------- характер ----------
    p = persona.system_prompt("Тим", [], False, "sweet", 200)
    check("режим «милая» в промпте", "милом режиме" in p)
    check("близость «друг» в промпте", "друзья" in p)
    check("близость: пороги", persona.closeness(0)[0] == "незнакомец" and persona.closeness(600)[0] == "лучший друг")
    await dp.feed_update(bot, cbq("md:evil", 20, 20))
    check("платный режим без Соня+ не включается", (await db.get_user(20))["mode"] == "base")
    await dp.feed_update(bot, cbq("md:nerd", 20, 20))
    check("бесплатный режим включается", (await db.get_user(20))["mode"] == "nerd")
    extra._plus[21] = time.time() + 100
    await dp.feed_update(bot, cbq("md:evil", 21, 21))
    check("с Соня+ — злая", (await db.get_user(21))["mode"] == "evil")
    extra._plus[21] = 0
    check("Соня+ кончилась — режим обычный", chat.user_mode(await db.get_user(21)) == "base")
    seen.clear()
    await dp.feed_update(bot, msg("привет", 20, 20))
    check("режим ботана уходит в ИИ", "режиме ботана" in seen[-1][0]["content"])
    check("близость растёт от болтовни", (await db.get_user(20))["close"] == 1)
    chat._night = lambda: False
    check("интонация: злая бойчее", chat.voice_style("evil")[0] == "+8%")

    # ---------- ответ по мере набора ----------
    config.STREAM = True
    chat.STREAM_EVERY = 0.01

    async def fake_stream(msgs, **k):
        for p_ in ["Привет, ", "это длинный ", "ответ по ", "кусочкам ", "для теста"]:
            await asyncio.sleep(0.02)
            yield p_
    llm.stream = fake_stream
    chat.VOICE_REPLY_CHANCE = chat.NIGHT_VOICE_CHANCE = 0
    from aiogram.methods import SendMessageDraft   # здесь проверяем запасной путь: черновики недоступны
    _orig_make = H.Mock._make
    async def _nodraft(self, b, method):
        if isinstance(method, SendMessageDraft):
            raise RuntimeError("no drafts")
        return await _orig_make(self, b, method)
    H.Mock._make = _nodraft
    SENT.clear()
    await dp.feed_update(bot, msg("расскажи", 22, 22))
    H.Mock._make = _orig_make
    sends = H.sent(H.SendMessage, 22)
    edits = [m_ for m_ in SENT if isinstance(m_, H.EditMessageText)]
    check("поток: одно сообщение + правки", len(sends) == 1 and len(edits) >= 2)
    check("поток: финал без курсора", edits[-1].text == "Привет, это длинный ответ по кусочкам для теста")
    hist = await db.get_history(22, 2)
    check("поток: ответ в истории", hist[-1]["text"].startswith("Привет, это"))

    async def dead_stream(msgs, **k):
        raise llm.LLMError("нет потока")
        yield ""
    llm.stream = dead_stream
    SENT.clear()
    await dp.feed_update(bot, msg("ещё", 22, 22))
    check("поток упал — обычный ответ", any(t == "ответ" for t in texts()))
    config.STREAM = False

    # ---------- поиск ----------
    async def fake_search(q):
        return f"нашла про {q}"
    llm.search = fake_search
    SENT.clear()
    await dp.feed_update(bot, msg("соня, найди в интернете курс биткоина", 20, 20))
    check("«найди в интернете» → поиск, а не трек", any("нашла про курс биткоина" in t for t in texts()))
    await dp.feed_update(bot, msg("загугли погоду в Сочи", 20, 20))
    check("«загугли» → поиск", any("погоду в Сочи" in t for t in texts()))

    # ---------- правила и заметки ----------
    H.ADMINS = {1, 20}
    from handlers import groupmod
    groupmod._admins.clear()
    await dp.feed_update(bot, msg("hi", -700, 21))
    await dp.feed_update(bot, msg("/rules не спамить", -700, 21))
    check("правила: не админ не может", await community.get_rules(-700) == "")
    await dp.feed_update(bot, msg("/rules не спамить, не ругаться", -700, 20))
    check("правила: админ сохранил", await community.get_rules(-700) == "не спамить, не ругаться")
    SENT.clear()
    from aiogram.types import Message as Msg, Chat as Ch
    join = H.Update(update_id=90001, message=Msg(message_id=5, date=__import__("datetime").datetime.now(),
                    chat=Ch(id=-700, type="supergroup", title="Чат"), from_user=User(id=22, is_bot=False, first_name="Нов"),
                    new_chat_members=[User(id=22, is_bot=False, first_name="Нов")]))
    await dp.feed_update(bot, join)
    greet = [m_ for m_ in H.sent(H.SendMessage, -700) if m_.reply_markup]
    check("приветствие с кнопкой правил", greet and "cm:rules" in str(greet[-1].reply_markup))
    await dp.feed_update(bot, msg("/note донат https://t.me/x — спасибо!", -700, 20))
    SENT.clear()
    await dp.feed_update(bot, msg("#донат", -700, 21))
    check("заметка по #тегу", any("спасибо" in t for t in texts()))
    await dp.feed_update(bot, msg("#нетакой", -700, 21))
    await dp.feed_update(bot, msg("/notes", -700, 21))
    check("список заметок", "#донат" in texts()[-1])
    await dp.feed_update(bot, msg("/delnote донат", -700, 20))
    check("заметка удалена", not await db.q_all("SELECT 1 FROM notes"))

    # ---------- ночная тишина ----------
    check("тишина: разбор", community.parse_quiet("23-8") == (23, 8) and community.parse_quiet("8-8") is None)
    check("тишина: через полночь", community.in_quiet(2, 23, 8) and not community.in_quiet(12, 23, 8))
    await dp.feed_update(bot, msg("/quiet 23-8", -700, 20))
    SENT.clear()
    await community.quiet_tick(bot, 1)
    perms = H.sent(SetChatPermissions)
    check("тишина: чат закрыт", perms and perms[-1].permissions.can_send_messages is False)
    await community.quiet_tick(bot, 2)
    check("тишина: не закрывает дважды", len(H.sent(SetChatPermissions)) == 1)
    await community.quiet_tick(bot, 9)
    perms = H.sent(SetChatPermissions)
    check("тишина: утром вернула прежние права", len(perms) == 2 and perms[-1].permissions.can_send_messages
          and perms[-1].permissions.can_send_photos is False)
    await community.quiet_tick(bot, 1)
    await dp.feed_update(bot, msg("/quiet off", -700, 20))
    check("тишина выключена ночью — чат открыт сразу", not await db.kv_get("quiet_perm:-700"))

    # ---------- итоги дня ----------
    await db.set_chat_flag(-700, "daily_sum", True)
    for i in range(25):
        await db.log_group(-700, "Аня", f"сообщение {i}")
    SENT.clear()
    await community.daily_summaries(bot)
    check("итоги дня отправлены", any("итоги дня" in t for t in texts()))

    # ---------- антиспам ----------
    await db.set_chat_flag(-700, "antispam", True)

    async def judge(model, messages, mt, t, url=None, key=None):
        return ("SPAM" if "заработок" in messages[-1]["content"] else "OK"), 1
    llm._call = judge
    SENT.clear()
    await dp.feed_update(bot, msg("лёгкий заработок без вложений, пиши в лс", -700, 30, "Спамер"))
    check("антиспам: удалено и мут", H.sent(DeleteMessage) and H.sent(RestrictChatMember))
    SENT.clear()
    await dp.feed_update(bot, msg("кто идёт в кино за 300 руб?", -700, 31, "Норм"))
    check("антиспам: нормальное с «руб» не тронуто", not H.sent(DeleteMessage))
    await db.q_run("UPDATE chat_daily SET n=50 WHERE uid=21")
    SENT.clear()
    await dp.feed_update(bot, msg("лёгкий заработок", -700, 21))
    check("антиспам: старожилов не трогает", not H.sent(DeleteMessage))
    llm._call = say

    # ---------- конвертер и крипта ----------
    async def cbr():
        return {"USD": {"Value": 90.0, "Nominal": 1, "Previous": 89.0}, "KZT": {"Value": 18.0, "Nominal": 100, "Previous": 18}}
    tools.cbr = cbr

    async def cp():
        return {"BTC": {"usd": 60000, "rub": 5400000}, "TON": {"usd": 5, "rub": 450}}
    studio.crypto_prices = cp
    check("валюты: распознаются", studio.currency("долларов") == "USD" and studio.currency("рубли") == "RUB"
          and studio.currency("биткоин") == "BTC" and studio.currency("часа") is None)
    check("конвертация 100 USD → 9000 RUB", round(await studio.convert(100, "USD", "RUB")) == 9000)
    check("конвертация 1 BTC → 60000 USD", round(await studio.convert(1, "BTC", "USD")) == 60000)
    SENT.clear()
    await dp.feed_update(bot, msg("100 долларов в рубли", 20, 20))
    check("«100 долларов в рубли» в личке", any("9 000 RUB" in t for t in texts()))
    await dp.feed_update(bot, msg("1000 тенге в рубли", 20, 20))
    check("тенге с номиналом 100", any("180" in t for t in texts()))
    await dp.feed_update(bot, msg("через 2 часа в 10", 20, 20))
    check("обычная фраза — не конвертер", not any("💱 2" in t for t in texts()))
    await dp.feed_update(bot, msg("/rate", 20, 20))
    check("/rate с криптой", any("BTC" in t and "USD" in t for t in texts()))

    # ---------- мем, QR ----------
    from PIL import Image
    b = io.BytesIO()
    Image.new("RGB", (600, 400), "gray").save(b, "JPEG")
    out = studio.make_meme(b.getvalue(), "когда пятница", "а завтра на работу и это очень длинный текст снизу")
    check("мем: картинка собрана", Image.open(io.BytesIO(out)).size == (600, 400))
    SENT.clear()
    await dp.feed_update(bot, msg("/qr https://t.me/Sonya_rubot", 20, 20))
    check("QR отправлен", H.sent(SendPhoto))

    # ---------- кружок / гифка / обрезка (настоящий ffmpeg) ----------
    vid = os.path.join(H.TMP, "v.mp4")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-f", "lavfi", "-i", "testsrc=size=640x360:rate=10",
                    "-f", "lavfi", "-i", "sine=frequency=440", "-t", "3", "-c:v", "libx264", "-c:a", "aac",
                    "-shortest", vid], check=True)

    async def fake_dl(bot_, obj, ext):
        import shutil as sh
        dst = tools._tmp(ext)
        sh.copy(vid, dst)
        return dst
    studio._download = fake_dl
    video_msg = reply_to(20, chat_id=20, text=None, video=Video(file_id="v", file_unique_id="v", width=640,
                                                                height=360, duration=3))
    SENT.clear()
    await dp.feed_update(bot, msg("/circle", 20, 20, reply=video_msg))
    check("кружок отправлен", H.sent(SendVideoNote))
    await dp.feed_update(bot, msg("/gif", 20, 20, reply=video_msg))
    check("гифка отправлена", H.sent(SendAnimation))
    await dp.feed_update(bot, msg("/cut 0:01 0:02", 20, 20, reply=video_msg))
    check("кусок аудио отправлен", H.sent(SendAudio))
    await dp.feed_update(bot, msg("/cut 0:05 0:02", 20, 20, reply=video_msg))
    check("/cut с кривым временем — подсказка", "ответь на аудио" in texts()[-1])
    check("время: 1:30 = 90 с", studio.parse_ts("1:30") == 90 and studio.parse_ts("45") == 45)

    # ---------- файлы ----------
    docx = os.path.join(H.TMP, "d.docx")
    with zipfile.ZipFile(docx, "w") as z:
        z.writestr("word/document.xml", "<w:document><w:body><w:p><w:r><w:t>Договор аренды</w:t></w:r></w:p>"
                                        "<w:p><w:r><w:t>Срок: 12 месяцев, оплата 30000 в месяц</w:t></w:r></w:p>"
                                        "</w:body></w:document>")
    check("docx читается", "Срок: 12 месяцев" in studio.extract_text(docx, "d.docx"))

    async def dl_docx(bot_, obj, ext):
        return docx
    studio._download = dl_docx
    seen.clear()
    doc_msg = H.Update(update_id=90002, message=Msg(
        message_id=7, date=__import__("datetime").datetime.now(), chat=Ch(id=20, type="private"),
        from_user=User(id=20, is_bot=False, first_name="Тим"),
        document=Document(file_id="d", file_unique_id="d", file_name="договор.docx",
                          mime_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")))
    await dp.feed_update(bot, doc_msg)
    check("документ пересказан", any("договор.docx" in t for t in texts()))
    seen.clear()
    await dp.feed_update(bot, msg("какой там срок?", 20, 20))
    check("вопрос по документу — текст в контексте", "12 месяцев" in seen[-1][0]["content"])
    await db.close()
    print("\nитого провалов:", len(FAILS))


asyncio.run(main())
