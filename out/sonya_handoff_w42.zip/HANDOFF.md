# Соня — передача проекта в новый чат

Прочти это целиком. В архиве: `sonya/` — актуальный код (= волна 42), `tests/` — тесты, `sonya_promo_kit.md` — продвижение.

## Кто я и как работаем
- Тим, ИП, делаю Telegram-ботов. Работаю **только с телефона через Termius**, команды выполняю по шагам.
- Отвечать: по-русски, коротко, с юмором, без пересказов и чек-листов.
- Код для `nano` и команды терминала — **в разных блоках**. Команды установки — в чат, не в zip.
- Каждое обновление — **отдельный zip с новым именем** `sonya_waveNN_*.zip` (следующая — **wave43**). Старые не перезаписывать.
- В zip **не класть** `.env`, `data/`, `__pycache__`.
- Всё новое — в `/help` (`ui.HELP` / `HELP_SECTIONS`, лимит 4096 символов на раздел).
- Прежде чем описывать возможность бота — проверить в коде.
- Токены в чат не просить — Тим вставляет их в `.env` сам. Не советовать покупать «рефералов».

## Сервер
- Код: `/home/sonya/sonya`, юзер `sonya`, служба `sonya` (systemd).
- `ExecStart=/home/sonya/sonya/venv312/bin/python main.py`, `WorkingDirectory=/home/sonya/sonya`.
- venv от uv, pip поставлен через `python -m ensurepip`. `uv` в PATH нет.
- Zip-ы Тим кладёт в `/root/`. Шаблон установки:
```
systemctl stop sonya
unzip -o /root/sonya_waveNN_xxx.zip -d /home/sonya/sonya
chown -R sonya:sonya /home/sonya/sonya
systemctl start sonya
sleep 5; journalctl -u sonya -n 10 --no-pager
```
- Новые pip-зависимости: `/home/sonya/sonya/venv312/bin/python -m pip install ...`
- Серверу нужен reboot (давно висит).

## Стек
Python 3.12, aiogram 3.31, SQLite (aiosqlite).
- Новые таблицы — в `db.SCHEMA_V14`/`V15`, новые колонки — ALTER в `db.init()`.
- ИИ: Groq через OpenAI-совместимый API. Цепочка: основная → `LLM_MODEL_FALLBACK` → второй провайдер (`LLM_URL_2`/`LLM_KEY_2`/`LLM_MODEL_2`).
- Зрение: `qwen/qwen3.8-27b` с `reasoning_effort: "none"` (preview — может пропасть). Картинку Соня сама качает и шлёт data-URL.
- Рисование: pollinations, с `POLLINATIONS_TOKEN` → `gen.pollinations.ai/image/` (ключ берут на enter.pollinations.ai/keys).
- Стриминг: `send_message_draft` в личке, при ошибке — правки.
- Эфемерные ответы в группах: `ui.personal()` (`EphemeralMessageParameters`), фолбэк — обычный reply.
- edge-tts 6.1 без `pitch` — обёрнуто в try/except.

Переменные окружения: BOT_TOKEN OWNER_ID LLM_KEY LLM_URL LLM_MODEL LLM_MODEL_FALLBACK LLM_URL_2 LLM_KEY_2 LLM_MODEL_2 LLM_VISION_MODEL SEARCH_MODEL STREAM STT_URL STT_KEY STT_MODEL POLLINATIONS_TOKEN VK_TOKEN YTDLP_COOKIES AI_DAY_LIMIT AI_DAY_LIMIT_PLUS FREE_CHANNELS REQUIRED_CHANNEL BOT_PROFILE DB_FILE MAIN_BOT.
Config использует `setdefault` — переменные systemd перекрывают `.env`.

## Дизайн и UI
- `ui.py`: `head`, `quote` (blockquote), `stats`, `hint`, `tog` ✅/⬜, `LINE`, `share_url`, `personal`.
- Кнопки «›» открывают список выбора. В помощи — «‹ Разделы» и «‹ Меню», окна не путать.
- `uikit`: экран узнаётся по первой строке текста, кнопка — по callback + тексту.
- `ap_common.kb_rows`: data с http(s):// или tg:// → URL-кнопка.

## Карта модулей
- `main.py` — `routers_for(profile)`, `SOLO_CMDS`, `setup_commands` (чистит чужие команды во всех scope/языках).
- `limits.py`, `achievements.py`, `handlers/life.py` — ДР, /stats, /ach, nudge.
- `handlers/fun.py` — задания (asyncio.Lock на юзера), браки, питомец, дуэль, лотерея, сезоны.
- `handlers/aigames.py` — акинатор, крокодил, правда/действие, эмодзи-песня.
- `handlers/character.py` — /mode, /search. `handlers/chat.py` — болтовня, стриминг.
- `handlers/community.py` — правила, заметки, тишина, итоги дня, AntiSpam, /welcome, clean_service, /report.
- `handlers/studio.py` — мем, кружок, gif, cut, qr, конвертер, крипта, документы.
- `handlers/luck.py` — колесо, блэкджек, гороскоп. `handlers/rp.py` — РП, /pair, /hero (флаг `rp` в chats).
- `handlers/gate.py` — обязательная подписка. `handlers/admin.py` — /admin, «Сервер» (кнопка «⬆️ Обновить yt-dlp»), «📝 Профиль бота» (BOT_SHORT/BOT_DESC/BIO).
- `handlers/solo.py` — узкие боты. `handlers/media.py` — скачивание, альбомы, TikTok/Pinterest-карусели.
- `downloader/core.py` — yt-dlp, `tiktok_photos` (tikwm API → страница TikTok), `resolve_redirect`, `fetch_bytes`.
- Автопостинг: `autopost/*`, `handlers/ap_*.py`. Pinterest: внутренний API (как gallery-dl), `BaseSearch` без входа работает, `RelatedPinFeed` без входа отдаёт 0 → «похожие» сделаны поиском по ключевым словам пина. Карусели: `carousel_data.carousel_slots[].images`. Фильтр фото/видео под тип канала. dHash-дедуп и водяной знак — `autopost/imgtools.py`.

## Боты (один код, разные профили BOT_PROFILE)
| профиль | служба | env | что это |
|---|---|---|---|
| full | sonya | .env | Соня — всё |
| dl | sonya-dl | dl.env | скачивалка видео |
| music | sonya-music | music.env | музыка (@SonyaMusicruBot) |
| gw | sonya-gw | gw.env | розыгрыши |
| games | sonya-games | games.env | игры для чатов |
| anon | sonya-anon | anon.env | анонимные вопросы |
Каждый env: BOT_TOKEN, BOT_PROFILE, DB_FILE (свою базу в data/). Юнит = копия sonya.service + `EnvironmentFile=/home/sonya/sonya/<x>.env` перед ExecStart.
`main.routers_for(profile)` — какие роутеры у профиля; `SOLO_CMDS` — меню команд; `admin.BIO` — описания; `solo.py` — стартовые экраны узких ботов.
**После любого обновления:** `systemctl restart sonya sonya-dl sonya-music sonya-gw sonya-games sonya-anon`
Память: 1.9 ГБ + swap 1 ГБ, после 6 ботов available ~650 МБ.

## Что сделано в волнах 28–42
- 28: тексты песен (lrclib), инлайн у помощников, экран «🤝 Помощники».
- 29–30: музыка: каталог (Яндекс→Deezer→YouTube; Яндекс с сервера 451 — отключается на 6ч), список с номерами, обложки, ❤️ мои, похожие, чарт, эффекты slowed/8D/bass (ffmpeg), рингтон, «угадай мелодию», /taste карточка, релизы артистов, «что за песня в видео».
- 31–32: видео: качество, без сжатия, кружок, GIF, обрезка, инфо, обложка, текст из видео, /history, прогресс %, очередь, tikwm-запасной для TikTok, журнал скачиваний, автообновление yt-dlp. 32b: YouTube 403 → перебор player_client.
- 33: трек/текст в комментариях канала, живые команды «Сонь, …» (quick.py, intents.py).
- 34: «📤 В канал» под скачанным, трек в подписи видео-поста.
- 35: монетизация: premium.py — лимиты (эффекты/текст из видео 3/день, HD и подписки), пробная Соня+ 3 дня, подписка 99⭐/мес (create_invoice_link subscription_period), приоритет очереди, «💰 Доходы». FREE_CHANNELS/FREE_SOURCES в .env (0 = без лимита).
- 36: фонд звёзд на подарки (gifts.py, /fund), розыгрыш подарков Telegram (sendGift), победитель выбирает.
- 37–39: розыгрыши (giveaway.py): спонсоры, билеты за друзей, Premium, итоги по числу, картинка/видео, перевыбор, отмена с возвратом, капча, отсев ботов, бусты, подтверждение победы 24ч, CSV, хэш итогов заранее (commit-reveal) + /check, призы по местам, отложенный старт, повтор, прирост подписчиков, «через @бот», итоги проигравшим.
- 40: fleet.py — здоровье всех ботов, сердцебиение и тревога, бэкап всех баз zip в 4:00, рассылка через всех помощников.
- 41: боты games и anon. 42: анонимки — темы ссылок, картинки для сторис (anoncards.py, QR), карточка «вопрос-ответ», /inbox.
- ВПН — решили НЕ делать (закон о рекламе VPN, риск для Сони). Казино на звёздах — не делать.

## Открыто / идеи
- Волна 42 — Тим ставит прямо сейчас.
- Fragment-юзернейм без «bot» — на будущее; пока канал-витрина.
- Свой Bot API (BOT_API_URL) для файлов до 2 ГБ — по желанию.

## Тесты
`tests/harness.py` — мок-сессия aiogram (SENT, ADMINS, LEFT, DICE), `setup()` собирает диспетчер как main.
Запуск (из папки tests, venv с requirements.txt):
```
python test_w27.py ../sonya full
BOT_PROFILE=dl python test_w27.py ../sonya dl
BOT_PROFILE=gw python test_w39.py ../sonya gw
BOT_PROFILE=anon python test_w42.py ../sonya anon
python smoke.py ../sonya          # и с BOT_PROFILE=dl/music/gw/games/anon
```
Первый аргумент — путь к коду. Регрессия — все `test_*.py` подряд.

## Грабли, на которые уже наступали
- Путь установки — `/home/sonya/sonya`, не `/home/sonya`.
- aiogram «проглатывает» апдейт, если хендлер сматчился и сделал return — условия выносить в фильтры.
- `m.answer(*tuple)` с клавиатурой — клавиатура улетает в parse_mode.
- Не выдумывать адреса сервисов — проверять.
- Тесты с python stdout в пайп: запускать `python -u … > log`, иначе при таймауте вывод теряется.
- ffmpeg-тесты (эффекты, кружок) используют настоящий ffmpeg.
- В .env токены не просить в чат.
