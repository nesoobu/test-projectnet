import asyncio
import logging
import re
import aiohttp
import config

log = logging.getLogger("llm")
_THINK = re.compile(r"<think>.*?</think>", re.S)
_session: aiohttp.ClientSession | None = None


class LLMError(Exception):
    pass


async def _sess() -> aiohttp.ClientSession:
    global _session
    if _session is None or _session.closed:
        _session = aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=60))
    return _session


async def close():
    if _session and not _session.closed:
        await _session.close()


def chain() -> list[tuple[str, str, str]]:
    """(url, key, model) по порядку: основная → запасная → второй провайдер (если задан)."""
    out = [(config.LLM_URL, config.LLM_KEY, config.LLM_MODEL)]
    if config.LLM_MODEL_FALLBACK:
        out.append((config.LLM_URL, config.LLM_KEY, config.LLM_MODEL_FALLBACK))
    if config.LLM_URL_2 and config.LLM_KEY_2 and config.LLM_MODEL_2:
        out.append((config.LLM_URL_2, config.LLM_KEY_2, config.LLM_MODEL_2))
    return [x for x in out if x[1]]


async def _call(model: str, messages: list, max_tokens: int, temperature: float,
                url: str | None = None, key: str | None = None, extra: dict | None = None) -> tuple[str, int]:
    s = await _sess()
    payload = {"model": model, "messages": messages,
               "max_tokens": max_tokens, "temperature": temperature, **(extra or {})}
    headers = {"Authorization": f"Bearer {key or config.LLM_KEY}"}
    try:
        async with s.post(url or config.LLM_URL, json=payload, headers=headers) as r:
            data = await r.json(content_type=None)
    except (aiohttp.ClientError, asyncio.TimeoutError, ValueError) as e:
        raise LLMError(f"сеть: {type(e).__name__} {e}") from e
    if not isinstance(data, dict) or "choices" not in data:
        err = (data.get("error") or {}) if isinstance(data, dict) else {}
        if isinstance(err, str):
            err = {"message": err}
        raise LLMError(f"{r.status} {err.get('code') or ''} {err.get('message') or data}")
    text = data["choices"][0]["message"].get("content") or ""
    tokens = int((data.get("usage") or {}).get("total_tokens") or 0)
    return _THINK.sub("", text).strip(), tokens


async def _stat(feature: str, tokens: int, ok: bool):
    try:
        import db
        await db.q_run("INSERT INTO ai_stats(day, feature, calls, tokens, fails) VALUES(?,?,?,?,?) "
                       "ON CONFLICT(day, feature) DO UPDATE SET calls=calls+excluded.calls, "
                       "tokens=tokens+excluded.tokens, fails=fails+excluded.fails",
                       db._day(), feature, int(ok), tokens, int(not ok))
    except Exception as e:
        log.debug("ai_stats: %s", e)


async def ask(messages: list, max_tokens: int = 700, temperature: float = 0.9, feature: str = "other") -> str:
    """Идёт по цепочке chain(): любая ошибка (лимит, ключ, сеть, модель) → следующий вариант."""
    variants = chain()
    if not variants:
        raise LLMError("нет LLM_KEY в .env")
    last: Exception | None = None
    for i, (url, key, model) in enumerate(variants):
        try:
            text, tokens = await _call(model, messages, max_tokens, temperature, url, key)
            await _stat(feature, tokens, True)
            return text
        except LLMError as e:
            last = e
            if i + 1 < len(variants):
                log.warning("%s упала (%s), пробую %s", model, str(e)[:120], variants[i + 1][2])
    await _stat(feature, 0, False)
    raise last


def _shrink(data: bytes, side: int = 1024) -> bytes:
    import io
    from PIL import Image
    im = Image.open(io.BytesIO(data))
    im.thumbnail((side, side))
    out = io.BytesIO()
    im.convert("RGB").save(out, "JPEG", quality=85)
    return out.getvalue()


async def inline_image(image_url: str) -> str:
    """Ссылку на картинку → data:URL. Многие сайты (pinimg, википедия) не пускают сервер Groq — качаем сами."""
    if not image_url.startswith("http"):
        return image_url
    import base64
    try:
        s = await _sess()
        hdr = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36"}
        async with s.get(image_url, headers=hdr, timeout=aiohttp.ClientTimeout(total=20)) as r:
            if r.status != 200:
                return image_url
            data = await r.read()
        small = await asyncio.to_thread(_shrink, data)
        return "data:image/jpeg;base64," + base64.b64encode(small).decode()
    except Exception as e:
        log.info("inline image: %s", e)
        return image_url


async def ask_vision(system: str, text: str, image_url: str, max_tokens: int = 120) -> str:
    """Запрос с картинкой. Бросает LLMError, если модель не умеет/недоступна."""
    if not config.LLM_KEY or not config.LLM_VISION_MODEL:
        raise LLMError("vision выключен")
    image_url = await inline_image(image_url)
    msgs = [{"role": "system", "content": system},
            {"role": "user", "content": [{"type": "text", "text": text},
                                         {"type": "image_url", "image_url": {"url": image_url}}]}]
    model = config.LLM_VISION_MODEL
    # думающие модели (qwen) тратят токены на размышления — короткая подпись выходит пустой
    extra = {"reasoning_effort": "none"} if "qwen" in model.lower() else None
    try:
        try:
            out, tokens = await _call(model, msgs, max_tokens, 0.95, extra=extra)
        except LLMError as e:
            if not extra or "reasoning" not in str(e).lower():
                raise
            out, tokens = await _call(model, msgs, max_tokens + 600, 0.95)   # параметр не принят — дадим подумать
        if not out and extra:
            out, tokens = await _call(model, msgs, max_tokens + 600, 0.95)
    except LLMError:
        await _stat("vision", 0, False)
        raise
    await _stat("vision", tokens, True)
    return out


# ================= ответ по мере набора =================
def sse_delta(line: bytes | str) -> str | None:
    """Строка SSE «data: {...}» → кусочек текста; None — служебная строка или конец."""
    if isinstance(line, bytes):
        line = line.decode("utf-8", "ignore")
    line = line.strip()
    if not line.startswith("data:"):
        return None
    body = line[5:].strip()
    if body == "[DONE]":
        return None
    try:
        import json
        d = json.loads(body)
        return (d["choices"][0].get("delta") or {}).get("content") or ""
    except (ValueError, KeyError, IndexError, TypeError):
        return None


class ThinkFilter:
    """Вырезает <think>…</think> из потока (qwen думает вслух)."""

    def __init__(self):
        self.buf, self.inside, self.started = "", False, False

    def feed(self, chunk: str) -> str:
        self.buf += chunk
        out = ""
        while self.buf:
            if self.inside:
                end = self.buf.find("</think>")
                if end < 0:
                    self.buf = self.buf[-8:]
                    return out
                self.buf, self.inside = self.buf[end + 8:], False
                continue
            start = self.buf.find("<think>")
            if start < 0:
                keep = next((k for k in range(min(7, len(self.buf)), 0, -1) if "<think>".startswith(self.buf[-k:])), 0)
                out += self.buf[:len(self.buf) - keep]
                self.buf = self.buf[len(self.buf) - keep:]
                return out
            out += self.buf[:start]
            self.buf, self.inside = self.buf[start + 7:], True
        return out

    def flush(self) -> str:
        out, self.buf = ("" if self.inside else self.buf), ""
        return out


async def stream(messages: list, max_tokens: int = 700, temperature: float = 0.9, feature: str = "chat"):
    """Кусочки ответа основной модели. Если упало до первого кусочка — LLMError (зови ask())."""
    if not config.LLM_KEY:
        raise LLMError("нет LLM_KEY в .env")
    s = await _sess()
    payload = {"model": config.LLM_MODEL, "messages": messages, "max_tokens": max_tokens,
               "temperature": temperature, "stream": True}
    headers = {"Authorization": f"Bearer {config.LLM_KEY}"}
    flt, total = ThinkFilter(), ""
    try:
        async with s.post(config.LLM_URL, json=payload, headers=headers) as r:
            if r.status != 200:
                raise LLMError(f"{r.status} {(await r.text())[:200]}")
            async for line in r.content:
                piece = sse_delta(line)
                if piece:
                    piece = flt.feed(piece)
                    if piece:
                        total += piece
                        yield piece
            tail = flt.flush()
            if tail:
                total += tail
                yield tail
    except (aiohttp.ClientError, asyncio.TimeoutError) as e:
        if not total:
            raise LLMError(f"сеть: {type(e).__name__}") from e
    await _stat(feature, len(total) // 3, bool(total))


# ================= поиск в интернете =================
async def search(question: str) -> str:
    """Ответ с поиском в интернете (Groq compound — сам гуглит). LLMError, если недоступно."""
    if not config.SEARCH_MODEL:
        raise LLMError("поиск выключен")
    msgs = [{"role": "system", "content": "Найди в интернете свежую информацию и ответь по-русски коротко и по делу "
                                          "(3–6 предложений). В конце — 1–2 источника ссылками."},
            {"role": "user", "content": question[:800]}]
    try:
        out, tokens = await _call(config.SEARCH_MODEL, msgs, 1200, 0.3)
    except LLMError:
        await _stat("search", 0, False)
        raise
    await _stat("search", tokens, True)
    return out
