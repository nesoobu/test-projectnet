import asyncio
import logging
import time

from aiogram import BaseMiddleware
from aiogram.types import Message, CallbackQuery
import db

log = logging.getLogger("mw")


def _night() -> bool:
    return 3 <= time.gmtime(time.time() + 3 * 3600).tm_hour < 5   # 3–5 утра по МСК


class UserMiddleware(BaseMiddleware):
    """Регистрирует юзера, начисляет xp, отсекает забаненных, проверяет достижения."""

    async def __call__(self, handler, event, data):
        u = getattr(event, "from_user", None)
        if u is None or u.is_bot:
            return await handler(event, data)
        if isinstance(event, (Message, CallbackQuery)):
            user = await db.touch_user(u, count=isinstance(event, Message))
            import uikit
            uikit.note_name(u.id, (u.full_name or "")[:64])
            if user and user["banned"]:
                return
            data["user"] = user
            import config
            if user and config.PROFILE == "full":
                chat = event.chat if isinstance(event, Message) else (event.message and event.message.chat)
                where = chat.id if chat and chat.type != "channel" else None   # из канала — в личку
                asyncio.create_task(_achievements(data["bot"], user, where,
                                                  isinstance(event, Message) and _night()))
        if isinstance(event, Message) and event.chat.type in ("group", "supergroup"):
            await db.add_chat(event.chat.id, event.chat.title or "")
            await db.track_group(event.chat.id, u.id)
        return await handler(event, data)


async def _achievements(bot, user: dict, chat_id: int | None, night: bool):
    import achievements
    try:
        await achievements.check(bot, user, chat_id, night)
    except Exception as e:
        log.info("achievements: %s", e)
