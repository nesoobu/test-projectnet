from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, LabeledPrice, PreCheckoutQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

from html import escape

import db
import ui

router = Router()
AMOUNTS = [15, 50, 100, 500]

TEXT = (
    ui.head("⭐", "Поддержать Соню", "звёзды идут на сервер и мозги")
    + "\n" + ui.quote("нейросеть сама себя не оплатит 🫠\nв профиле появится отметка ⭐")
    + "\n" + ui.hint("своя сумма: /donate 250")
)


def _kb():
    kb = InlineKeyboardBuilder()
    for a in AMOUNTS:
        kb.button(text=f"⭐ {a}", callback_data=f"d:{a}")
    kb.button(text="‹ Назад", callback_data="m:home")
    kb.adjust(4, 1)
    return kb.as_markup()


async def _invoice(bot: Bot, chat_id: int, amount: int):
    await bot.send_invoice(
        chat_id,
        title=f"Поддержать Соню · {amount}⭐",
        description="спасибо, ты лучший 🖤",
        payload=f"donate:{amount}",
        currency="XTR",
        prices=[LabeledPrice(label="Поддержка", amount=amount)],
    )


@router.message(Command("donate"))
async def cmd_donate(m: Message, command: CommandObject, bot: Bot):
    arg = (command.args or "").strip()
    if arg.isdigit() and 1 <= int(arg) <= 10000:
        return await _invoice(bot, m.chat.id, int(arg))
    await m.answer(TEXT, reply_markup=_kb())


@router.callback_query(F.data == "m:donate")
async def cb_donate(cb: CallbackQuery):
    await cb.message.edit_text(TEXT, reply_markup=_kb())
    await cb.answer()


@router.callback_query(F.data.startswith("d:"))
async def cb_amount(cb: CallbackQuery, bot: Bot):
    amount = int(cb.data[2:])
    if amount not in AMOUNTS:
        return await cb.answer()
    await _invoice(bot, cb.message.chat.id, amount)
    await cb.answer()


@router.pre_checkout_query()
async def pre_checkout(q: PreCheckoutQuery):
    await q.answer(ok=q.invoice_payload.startswith(("donate:", "plus:", "gift:", "plussub", "fund:")))


@router.message(F.successful_payment)
async def paid(m: Message):
    p = m.successful_payment
    kind = p.invoice_payload.split(":")[0]
    await db.add_donation(m.from_user.id, p.total_amount, p.telegram_payment_charge_id, kind)
    if p.invoice_payload.startswith("fund:"):
        from handlers import gifts
        return await gifts.paid(m, p.total_amount)
    if p.invoice_payload == "plussub":   # подписка: первый платёж и каждое продление
        from handlers import extra
        from autopost import timeparse
        until = await extra.grant_plus(m.from_user.id, 30)
        exp = getattr(p, "subscription_expiration_date", None)
        if exp and exp > until:
            await db.q_run("UPDATE users SET plus_until=? WHERE id=?", exp, m.from_user.id)
            extra._plus[m.from_user.id] = until = exp
        first = not getattr(p, "is_recurring", False) or getattr(p, "is_first_recurring", True)
        return await m.answer(("🔁 <b>подписка на Соню+ оформлена!</b>" if first else "🔁 Соня+ продлена 🖤")
                              + f"\nактивна до {timeparse.fmt(until)}")
    if p.invoice_payload.startswith("plus:"):
        from handlers import extra
        from autopost import timeparse
        days = int(p.invoice_payload.split(":")[1] or 30)
        until = await extra.grant_plus(m.from_user.id, days)
        return await m.answer(f"✨ <b>Соня+ активна</b> до {timeparse.fmt(until)}!\n"
                              "кулдаунов больше нет, бонус ×2, титул «✨ Соня+» — в /shop 🖤")
    if p.invoice_payload.startswith("gift:"):
        from handlers import extra
        from autopost import timeparse
        _, uid, days = p.invoice_payload.split(":")
        until = await extra.grant_plus(int(uid), int(days))
        try:
            await m.bot.send_message(int(uid), f"🎁 <b>{escape(m.from_user.first_name or 'кто-то')}</b> подарил(а) "
                                               f"тебе Соню+ до {timeparse.fmt(until)}! ✨ /plus")
        except Exception:
            pass
        return await m.answer("🎁 подарок доставлен! ты лучший друг на свете 🖤")
    await m.answer(f"<b>+{p.total_amount}⭐</b> получила! ты лучший 🖤")
