"""☀️ Утренняя рассылка: погода, курс, факт дня и пожелание — в личку или в группу."""
import asyncio
import logging
import random
import re
from datetime import datetime
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

import config
import db
import llm
import ui
from handlers.ap_common import kb_rows
from persona import MSK

router = Router()
log = logging.getLogger("morning")

WINDOW_MIN = 180          # если бот лежал — догоняем не позже чем через 3 часа
DAYS = ["понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье"]
MONTHS = ["января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября",
          "октября", "ноября", "декабря"]
WISHES = [
    "пусть сегодня всё получается с первого раза ✨", "не забудь позавтракать, это важно 🍳",
    "сегодня ты справишься со всем, я верю 🖤", "улыбнись — это бесплатно и работает 😊",
    "маленький шаг сегодня = большой результат потом 🚀", "кофе, плейлист и вперёд ☕🎧",
    "будь котом: делай что хочешь и не переживай 🐈‍⬛", "сегодня отличный день, чтобы быть собой 🌿",
    "береги себя и пей воду 💧", "пусть сегодня будет хоть одна приятная мелочь 🍀",
]
FALLBACK_FACTS = [
    "осьминоги имеют три сердца и голубую кровь.",
    "мёд не портится: съедобный мёд находили в египетских гробницах.",
    "бананы — ягоды, а клубника с ботанической точки зрения — нет.",
    "на Венере день длиннее года.",
    "у улитки может быть больше 10 000 зубов.",
]
_fact: tuple[str, str] = ("", "")


class MorningSt(StatesGroup):
    city = State()
    time = State()


async def _row(chat_id: int) -> dict:
    r = await db.q_one("SELECT * FROM morning WHERE chat_id=?", chat_id)
    if not r:
        await db.q_run("INSERT OR IGNORE INTO morning(chat_id) VALUES(?)", chat_id)
        r = await db.q_one("SELECT * FROM morning WHERE chat_id=?", chat_id)
    return r


def _today() -> str:
    return datetime.now(MSK).strftime("%Y-%m-%d")


def _passed(hh: int, mm: int) -> bool:
    now = datetime.now(MSK)
    return hh * 60 + mm <= now.hour * 60 + now.minute


async def _fix_last(chat_id: int, hh: int, mm: int):
    """После включения или смены времени: если время сегодня уже прошло — первая рассылка завтра."""
    await db.q_run("UPDATE morning SET last=? WHERE chat_id=?", _today() if _passed(hh, mm) else "", chat_id)


def _view(r: dict) -> tuple[str, object]:
    on = r["on_"]
    text = (f"<b>☀️ утренняя рассылка</b>\n{ui.LINE}\n"
            f"статус: {'✅ включена' if on else '⏸ выключена'}\n"
            f"🏙 город: <b>{escape(r['city'])}</b>\n"
            f"⏰ время: <b>{r['hh']:02d}:{r['mm']:02d}</b> мск\n\n"
            "<i>что внутри: погода на день · курс $ и € · факт дня · пожелание от меня</i>")
    kb = kb_rows([("⏸ Выключить" if on else "✅ Включить", "mo:t")],
                 [("🏙 Город", "mo:c"), ("⏰ Время", "mo:h")],
                 [("👀 Прислать сейчас", "mo:p")],
                 [("‹ Меню", "m:home")])
    return text, kb


async def _can_edit(bot: Bot, chat, uid: int) -> bool:
    if chat.type == "private" or uid == config.OWNER_ID:
        return True
    try:
        m = await bot.get_chat_member(chat.id, uid)
        return m.status in ("creator", "administrator")
    except Exception:
        return False


@router.message(Command("morning", "утро"))
async def cmd_morning(m: Message, bot: Bot, state: FSMContext):
    await state.clear()
    if not await _can_edit(bot, m.chat, m.from_user.id):
        return await m.answer("настраивать утреннюю рассылку в группе могут только админы")
    text, kb = _view(await _row(m.chat.id))
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("mo:"))
async def cb_morning(cb: CallbackQuery, bot: Bot, state: FSMContext):
    chat = cb.message.chat
    if not await _can_edit(bot, chat, cb.from_user.id):
        return await cb.answer("только для админов", show_alert=True)
    act = cb.data[3:]
    r = await _row(chat.id)
    if act == "p":
        await cb.answer("собираю…")
        return await cb.message.answer(await compose(r["city"], cb.message.chat.id))
    if act == "c":
        await state.set_state(MorningSt.city)
        await cb.answer()
        return await cb.message.answer("🏙 напиши город, например: <code>Казань</code>",
                                       reply_markup=kb_rows([("✖️ Отмена", "mo:x")]))
    if act == "h":
        await state.set_state(MorningSt.time)
        await cb.answer()
        return await cb.message.answer("⏰ во сколько присылать? по Москве, например: <code>7:30</code>",
                                       reply_markup=kb_rows([("✖️ Отмена", "mo:x")]))
    if act == "x":
        await state.clear()
        await cb.answer("ок")
        try:
            await cb.message.delete()
        except TelegramBadRequest:
            pass
        return
    if act == "t":
        on = 0 if r["on_"] else 1
        await db.q_run("UPDATE morning SET on_=? WHERE chat_id=?", on, chat.id)
        if on:
            await _fix_last(chat.id, r["hh"], r["mm"])
        await cb.answer("включила ☀️" if on else "выключила")
    else:
        await cb.answer()
    text, kb = _view(await _row(chat.id))
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        await cb.message.answer(text, reply_markup=kb)


@router.message(MorningSt.city, F.text)
async def st_city(m: Message, state: FSMContext):
    city = m.text.strip()[:40]
    if city.startswith("/"):
        await state.clear()
        return await m.answer("ок, не меняю")
    from handlers import tools
    try:
        w = await tools.weather(city)
        if w.startswith("не знаю"):
            return await m.answer(f"не нашла город «{escape(city)}» 🤔 попробуй ещё раз")
    except Exception:
        pass
    await state.clear()
    await _row(m.chat.id)
    await db.q_run("UPDATE morning SET city=? WHERE chat_id=?", city, m.chat.id)
    text, kb = _view(await _row(m.chat.id))
    await m.answer("готово ✅\n\n" + text, reply_markup=kb)


@router.message(MorningSt.time, F.text)
async def st_time(m: Message, state: FSMContext):
    mt = re.fullmatch(r"\s*(\d{1,2})(?:[:.\s](\d{2}))?\s*", m.text)
    if not mt or int(mt[1]) > 23 or int(mt[2] or 0) > 59:
        if m.text.startswith("/"):
            await state.clear()
            return await m.answer("ок, не меняю")
        return await m.answer("не поняла 🙈 напиши время так: <code>8:00</code>")
    hh, mm = int(mt[1]), int(mt[2] or 0)
    await state.clear()
    await _row(m.chat.id)
    await db.q_run("UPDATE morning SET hh=?, mm=? WHERE chat_id=?", hh, mm, m.chat.id)
    await _fix_last(m.chat.id, hh, mm)
    text, kb = _view(await _row(m.chat.id))
    await m.answer("готово ✅\n\n" + text, reply_markup=kb)


# ================= сборка выпуска =================
async def fact_of_day() -> str:
    global _fact
    today = _today()
    if _fact[0] == today:
        return _fact[1]
    try:
        f = await llm.ask([
            {"role": "system", "content": "Ты — Соня. Напиши ОДИН удивительный, но достоверный и общеизвестный "
                                          "факт (наука, природа, история, космос) в 1–2 коротких предложениях. "
                                          "Только факт, по-русски, без вступлений, кавычек и эмодзи."},
            {"role": "user", "content": f"факт дня на {today}"}], max_tokens=200)
        f = (f or "").strip().strip('"«»')
        if not f or len(f) > 400:
            raise ValueError("bad fact")
    except Exception as e:
        log.info("fact: %s", e)
        f = random.choice(FALLBACK_FACTS)
    _fact = (today, f)
    return f


async def _rates_line() -> str:
    from handlers import tools
    v = await tools.cbr()
    out = []
    for code, sign in (("USD", "$"), ("EUR", "€")):
        x = v[code]
        val = x["Value"] / x["Nominal"]
        diff = val - x["Previous"] / x["Nominal"]
        arrow = "🔺" if diff > 0 else "🔻" if diff < 0 else "▫️"
        out.append(f"{sign} <b>{val:.2f}</b> {arrow}{abs(diff):.2f}")
    return "💱 " + " · ".join(out)


async def compose(city: str, chat_id: int | None = None) -> str:
    from handlers import tools
    now = datetime.now(MSK)
    parts = [f"☀️ <b>доброе утро!</b>\n<i>{DAYS[now.weekday()]}, {now.day} {MONTHS[now.month - 1]}</i>"]
    try:
        parts.append("⛅ " + await tools.weather(city))
    except Exception as e:
        log.info("morning weather: %s", e)
    try:
        parts.append(await _rates_line())
    except Exception as e:
        log.info("morning rates: %s", e)
    parts.append(f"💡 <b>факт дня:</b> {escape(await fact_of_day())}")
    if chat_id and chat_id > 0:   # в личке — гороскоп по дню рождения
        try:
            from handlers import luck
            h = await luck.horo_line(chat_id)
            if h:
                parts.append(h)
        except Exception as e:
            log.info("morning horo: %s", e)
    parts.append(f"🖤 {random.choice(WISHES)}")
    return "\n\n".join(parts)


async def tick(bot: Bot):
    now = datetime.now(MSK)
    today, cur = _today(), now.hour * 60 + now.minute
    for r in await db.q_all("SELECT * FROM morning WHERE on_=1 AND last!=?", today):
        t = r["hh"] * 60 + r["mm"]
        if not (t <= cur < t + WINDOW_MIN):
            continue
        await db.q_run("UPDATE morning SET last=? WHERE chat_id=?", today, r["chat_id"])
        try:
            await bot.send_message(r["chat_id"], await compose(r["city"], r["chat_id"]))
        except TelegramForbiddenError:
            await db.q_run("UPDATE morning SET on_=0 WHERE chat_id=?", r["chat_id"])
        except TelegramBadRequest as e:
            log.info("morning %s: %s", r["chat_id"], e)
        await asyncio.sleep(0.1)


async def loop(bot: Bot):
    while True:
        try:
            await tick(bot)
        except Exception:
            log.exception("morning tick")
        await asyncio.sleep(30)
