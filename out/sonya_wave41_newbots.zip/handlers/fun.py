"""Экономика и игры волны 15: задания дня, браки, питомец, дуэли на ставку, лотерея, сезоны."""
import asyncio
import json
import logging
import random
import time
import uuid
from datetime import datetime
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery

import db
import persona
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("fun")
GROUPS = {"group", "supergroup"}
BOT: Bot | None = None   # ставит main — для уведомлений о заданиях


def link(uid: int, name: str) -> str:
    return f'<a href="tg://user?id={uid}">{escape(name or "игрок")}</a>'


async def _edit(cb: CallbackQuery, text: str, kb=None):
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass


# ================= 📋 задания дня =================
# code: (событие, сколько, текст, награда)
QUESTS = {
    "chat5": ("chat", 5, "поболтай со мной 5 раз", 20),
    "win3": ("win", 3, "выиграй 3 раза в играх", 30),
    "game5": ("game", 5, "сыграй 5 раз в любые игры", 20),
    "dl1": ("dl", 1, "скачай видео или трек", 15),
    "bonus": ("bonus", 1, "забери /bonus", 10),
    "quiz1": ("quiz", 1, "ответь верно на квиз", 20),
    "draw1": ("draw", 1, "попроси меня нарисовать", 15),
    "pet1": ("pet", 1, "покорми питомца", 15),
    "voice1": ("voice", 1, "попроси меня озвучить текст", 15),
}
QUEST_N = 3
ALL_DONE_PRIZE = 50


async def today_quests(uid: int) -> list[dict]:
    day = db._day()
    rows = await db.q_all("SELECT * FROM quests WHERE uid=? AND day=?", uid, day)
    if not rows:
        rnd = random.Random(f"{uid}:{day}")
        for code in rnd.sample(sorted(QUESTS), QUEST_N):
            await db.q_run("INSERT OR IGNORE INTO quests(uid, day, code, need) VALUES(?,?,?,?)",
                           uid, day, code, QUESTS[code][1])
        rows = await db.q_all("SELECT * FROM quests WHERE uid=? AND day=?", uid, day)
    return rows


_locks: dict[int, asyncio.Lock] = {}


async def on_event(uid: int, event: str, n: int = 1):
    lock = _locks.setdefault(uid, asyncio.Lock())   # события одного юзера — по очереди, иначе счётчики затрут друг друга
    async with lock:
        await _on_event(uid, event, n)


async def _on_event(uid: int, event: str, n: int = 1):
    try:
        rows = await today_quests(uid)
        done_now = []
        for r in rows:
            if r["done"] or QUESTS.get(r["code"], ("",))[0] != event:
                continue
            got = min(r["need"], r["got"] + n)
            done = int(got >= r["need"])
            await db.q_run("UPDATE quests SET got=?, done=? WHERE uid=? AND day=? AND code=?",
                           got, done, uid, r["day"], r["code"])
            if done:
                await db.add_coins(uid, QUESTS[r["code"]][3])
                done_now.append(r["code"])
        if not done_now:
            return
        lines = [f"📋 задание выполнено: <b>{QUESTS[c][2]}</b> · +{QUESTS[c][3]} 🪙" for c in done_now]
        left = await db.q_one("SELECT COUNT(*) AS n FROM quests WHERE uid=? AND day=? AND done=0", uid, db._day())
        if left["n"] == 0:
            await db.add_coins(uid, ALL_DONE_PRIZE)
            lines.append(f"🎉 все задания дня! бонус <b>+{ALL_DONE_PRIZE} 🪙</b>")
        if BOT:
            try:
                await BOT.send_message(uid, "\n".join(lines), disable_notification=True)
            except Exception:
                pass
    except Exception as e:
        log.info("quest %s: %s", event, e)


for _ev in {q[0] for q in QUESTS.values()}:
    db.on(_ev, on_event)


async def quests_text(uid: int) -> str:
    rows = await today_quests(uid)
    lines = ["<b>📋 задания на сегодня</b>", ui.LINE]
    for r in rows:
        _ev, need, text, prize = QUESTS.get(r["code"], ("", 1, "?", 0))
        mark = "✅" if r["done"] else "▫️"
        lines.append(f"{mark} {text} — <b>{r['got']}/{need}</b> · {prize} 🪙")
    lines.append(f"\nвсе три — ещё <b>+{ALL_DONE_PRIZE} 🪙</b>. новые — в полночь по мск")
    return "\n".join(lines)


@router.message(Command("quests", "задания"))
async def cmd_quests(m: Message):
    await ui.personal(m, await quests_text(m.from_user.id))


@router.callback_query(F.data == "g:quests")
async def cb_quests(cb: CallbackQuery):
    await cb.message.answer(await quests_text(cb.from_user.id))
    await cb.answer()


# ================= 💍 браки =================
async def spouse(uid: int) -> dict | None:
    r = await db.q_one("SELECT a, b, ts FROM marriages WHERE a=? OR b=?", uid, uid)
    if not r:
        return None
    other = r["b"] if r["a"] == uid else r["a"]
    u = await db.get_user(other) or {"name": "?"}
    return {"id": other, "name": u["name"], "ts": r["ts"]}


async def marriage_line(uid: int) -> str:
    s = await spouse(uid)
    if not s:
        return ""
    days = int((time.time() - s["ts"]) // 86400)
    return f"💍 в браке с <b>{escape(s['name'])}</b> · {days} дн."


@router.message(Command("marry", "брак"))
async def cmd_marry(m: Message):
    t = m.reply_to_message.from_user if m.reply_to_message else None
    if not t or t.is_bot:
        return await m.reply("💍 ответь <code>/marry</code> на сообщение того, кому делаешь предложение")
    if t.id == m.from_user.id:
        return await m.reply("себя любить важно, но жениться на себе — перебор 🙃")
    if await spouse(m.from_user.id):
        return await m.reply("ты уже в браке. сначала /divorce 👀")
    if await spouse(t.id):
        return await m.reply(f"{escape(t.first_name)} уже занят(а) 💔")
    pid = uuid.uuid4().hex[:8]
    await db.q_run("INSERT OR REPLACE INTO game_state VALUES(?,?,?,?)", f"marry:{pid}", "marry",
                   json.dumps({"a": m.from_user.id, "an": m.from_user.first_name, "b": t.id, "bn": t.first_name}),
                   int(time.time()))
    await m.answer(f"💍 {link(m.from_user.id, m.from_user.first_name)} делает предложение "
                   f"{link(t.id, t.first_name)}!\nсогласна(ен)?",
                   reply_markup=kb_rows([("💍 Да!", f"mr:y:{pid}"), ("💔 Нет", f"mr:n:{pid}")]))


@router.callback_query(F.data.startswith("mr:"))
async def cb_marry(cb: CallbackQuery):
    _, ans, pid = cb.data.split(":")
    r = await db.q_one("SELECT data FROM game_state WHERE id=?", f"marry:{pid}")
    if not r:
        return await cb.answer("предложение устарело")
    d = json.loads(r["data"])
    if cb.from_user.id != d["b"]:
        return await cb.answer("это не тебе предлагают 🙃", show_alert=True)
    await db.q_run("DELETE FROM game_state WHERE id=?", f"marry:{pid}")
    if ans == "n":
        return await _edit(cb, f"💔 {escape(d['bn'])} отказал(а) {escape(d['an'])}. бывает…")
    if await spouse(d["a"]) or await spouse(d["b"]):
        return await _edit(cb, "кто-то из вас уже успел жениться на другом 👀")
    a, b = sorted((d["a"], d["b"]))
    await db.q_run("INSERT INTO marriages VALUES(?,?,?)", a, b, int(time.time()))
    await _edit(cb, f"💒 горько! {link(d['a'], d['an'])} и {link(d['b'], d['bn'])} теперь в браке 🥂")
    await cb.answer("💍")


@router.message(Command("divorce", "развод"))
async def cmd_divorce(m: Message):
    s = await spouse(m.from_user.id)
    if not s:
        return await m.reply("ты и так свободен как ветер 🍃")
    await db.q_run("DELETE FROM marriages WHERE a=? OR b=?", m.from_user.id, m.from_user.id)
    await m.reply(f"💔 развод оформлен. {escape(s['name'])}, держись")


# ================= 🐾 питомец =================
PETS = {"cat": ("🐱", "котик"), "dog": ("🐶", "пёс"), "fox": ("🦊", "лиса"), "dragon": ("🐉", "дракон"),
        "frog": ("🐸", "жаба"), "bat": ("🦇", "летучая мышь")}
PET_PRICE, FEED_PRICE = 100, 10
HUNGER_H = 2.0      # сытость −2% в час (пустой за 50 ч)
RUNAWAY_H = 74      # не кормили 74 ч — сбежал
PLAY_EVERY = 2 * 3600


def pet_state(p: dict, now: float | None = None) -> tuple[int, int, int]:
    """→ (сытость %, настроение %, уровень)."""
    now = now or time.time()
    full = max(0, round(100 - (now - p["fed"]) / 3600 * HUNGER_H))
    mood = max(0, round(100 - (now - p["played"]) / 3600 * 3))
    return full, mood, p["xp"] // 100 + 1


async def get_pet(uid: int) -> dict | None:
    p = await db.q_one("SELECT * FROM pets WHERE uid=? AND alive=1", uid)
    if p and time.time() - p["fed"] > RUNAWAY_H * 3600:
        await db.q_run("UPDATE pets SET alive=0 WHERE uid=?", uid)
        p["alive"] = 0
    return p


def pet_view(p: dict | None) -> tuple[str, object]:
    if not p:
        rows = [[(f"{e} {n}", f"pet:new:{k}")] for k, (e, n) in PETS.items()]
        return (f"<b>🐾 питомец</b>\n{ui.LINE}\nу тебя пока никого. заведи за <b>{PET_PRICE} 🪙</b>:\n"
                "корми, играй — он растёт. забудешь покормить 3 дня — сбежит 💨"), kb_rows(*rows)
    if not p["alive"]:
        return (f"💨 {escape(p['name'])} сбежал(а) — его не кормили больше трёх дней.\n"
                "можно завести нового 🐾"), kb_rows([("🐾 Завести нового", "pet:again")])
    e, kind = PETS.get(p["kind"], ("🐾", "зверь"))
    full, mood, lvl = pet_state(p)
    face = "😋" if full > 70 else "😐" if full > 30 else "😫"
    text = (f"<b>{e} {escape(p['name'])}</b> · {kind}, уровень <b>{lvl}</b> {face}\n{ui.LINE}\n"
            f"🍖 сытость <code>{ui.bar(full, 100)}</code> {full}%\n"
            f"🎾 настроение <code>{ui.bar(mood, 100)}</code> {mood}%\n"
            f"✨ опыт: {p['xp'] % 100}/100 · возраст: {int((time.time() - p['born']) // 86400)} дн.\n\n"
            "<i>переименовать: /pet имя Барсик</i>")
    return text, kb_rows([(f"🍖 Покормить · {FEED_PRICE} 🪙", "pet:feed"), ("🎾 Поиграть", "pet:play")],
                         [("🔄", "pet:show"), ("🎮 Игры", "g:menu")])


@router.message(Command("pet", "питомец"))
async def cmd_pet(m: Message, command: CommandObject):
    args = (command.args or "").split(maxsplit=1)
    p = await get_pet(m.from_user.id)
    if len(args) == 2 and args[0].lower() in ("имя", "name") and p and p["alive"]:
        name = args[1].strip()[:20]
        await db.q_run("UPDATE pets SET name=? WHERE uid=?", name, m.from_user.id)
        p["name"] = name
    text, kb = pet_view(p)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("pet:"))
async def cb_pet(cb: CallbackQuery):
    act = cb.data.split(":")
    uid = cb.from_user.id
    p = await get_pet(uid)
    now = int(time.time())
    if act[1] == "again" and p is not None and not p["alive"]:
        await db.q_run("DELETE FROM pets WHERE uid=?", uid)
        p = None
    elif act[1] == "new" and (not p or not p["alive"]) and act[2] in PETS:
        if not await db.take_coins(uid, PET_PRICE):
            return await cb.answer(f"нужно {PET_PRICE} 🪙 — забери /bonus", show_alert=True)
        await db.q_run("INSERT OR REPLACE INTO pets(uid, kind, name, born, fed, played, xp, alive) "
                       "VALUES(?,?,?,?,?,?,0,1)", uid, act[2], PETS[act[2]][1].capitalize(), now, now, now)
        await cb.answer("🎉 у тебя новый друг!")
        p = await get_pet(uid)
    elif act[1] == "feed" and p and p["alive"]:
        full, _, _ = pet_state(p)
        if full > 90:
            return await cb.answer("он не голоден 🙅")
        if not await db.take_coins(uid, FEED_PRICE):
            return await cb.answer(f"нужно {FEED_PRICE} 🪙", show_alert=True)
        await db.q_run("UPDATE pets SET fed=?, xp=xp+10 WHERE uid=?", now, uid)
        db.emit("pet", uid)
        await cb.answer("ням 😋 +10 опыта")
        p = await get_pet(uid)
    elif act[1] == "play" and p and p["alive"]:
        if now - p["played"] < PLAY_EVERY:
            return await cb.answer(f"устал, приходи через {(PLAY_EVERY - now + p['played']) // 60} мин")
        await db.q_run("UPDATE pets SET played=?, xp=xp+5 WHERE uid=?", now, uid)
        await cb.answer(random.choice(["🎾 апорт!", "🧶 поиграли", "🤸 весело!"]) + " +5 опыта")
        p = await get_pet(uid)
    else:
        await cb.answer()
    text, kb = pet_view(p)
    await _edit(cb, text, kb)


@router.callback_query(F.data == "g:pet")
async def cb_pet_menu(cb: CallbackQuery):
    text, kb = pet_view(await get_pet(cb.from_user.id))
    await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


# ================= ⚔️ дуэль на ставку =================
DUEL_MIN, DUEL_MAX = 10, 10000


@router.message(Command("duel", "дуэль"))
async def cmd_duel(m: Message, command: CommandObject):
    arg = (command.args or "").strip()
    if not arg.isdigit() or not DUEL_MIN <= int(arg) <= DUEL_MAX:
        return await m.reply(f"⚔️ дуэль на кубиках: <code>/duel 50</code> — ставка от {DUEL_MIN} 🪙. "
                             "ответом на сообщение — вызов конкретному человеку, иначе любому")
    bet = int(arg)
    u = await db.get_user(m.from_user.id)
    if (u.get("coins") or 0) < bet:
        return await m.reply("у тебя столько нет 🥲 /bonus")
    t = m.reply_to_message.from_user if m.reply_to_message and not m.reply_to_message.from_user.is_bot else None
    did = uuid.uuid4().hex[:8]
    await db.q_run("INSERT OR REPLACE INTO game_state VALUES(?,?,?,?)", f"sduel:{did}", "sduel",
                   json.dumps({"a": m.from_user.id, "an": m.from_user.first_name, "bet": bet,
                               "to": t.id if t else 0}), int(time.time()))
    who = f" {link(t.id, t.first_name)}" if t else ""
    await m.answer(f"⚔️ {link(m.from_user.id, m.from_user.first_name)} вызывает{who} на дуэль!\n"
                   f"ставка <b>{bet} 🪙</b> — победитель забирает всё 🎲",
                   reply_markup=kb_rows([("⚔️ Принять", f"sd:y:{did}"), ("✖️ Отмена", f"sd:x:{did}")]))


@router.callback_query(F.data.startswith("sd:"))
async def cb_sduel(cb: CallbackQuery, bot: Bot):
    _, act, did = cb.data.split(":")
    r = await db.q_one("SELECT data FROM game_state WHERE id=?", f"sduel:{did}")
    if not r:
        return await cb.answer("дуэль уже закончилась")
    d = json.loads(r["data"])
    uid = cb.from_user.id
    if act == "x":
        if uid != d["a"]:
            return await cb.answer("отменить может только тот, кто вызвал", show_alert=True)
        await db.q_run("DELETE FROM game_state WHERE id=?", f"sduel:{did}")
        return await _edit(cb, "✖️ дуэль отменена")
    if uid == d["a"]:
        return await cb.answer("сам с собой? 🙃", show_alert=True)
    if d["to"] and uid != d["to"]:
        return await cb.answer("вызов не тебе", show_alert=True)
    bet = d["bet"]
    if ((await db.get_user(uid)) or {}).get("coins", 0) < bet:
        return await cb.answer(f"нужно {bet} 🪙 — забери /bonus", show_alert=True)
    c = await db.db()
    cur = await c.execute("DELETE FROM game_state WHERE id=?", (f"sduel:{did}",))
    await c.commit()
    if not cur.rowcount:
        return await cb.answer("кто-то успел раньше")
    if not await db.take_coins(uid, bet):
        return await _edit(cb, "⚔️ дуэль сорвалась — у соперника не хватило 🪙")
    if not await db.take_coins(d["a"], bet):
        await db.add_coins(uid, bet)
        return await _edit(cb, f"⚔️ дуэль сорвалась — у {escape(d['an'])} кончились 🪙")
    await cb.answer("🎲")
    await _edit(cb, f"⚔️ {escape(d['an'])} vs {escape(cb.from_user.first_name)} · ставка {bet} 🪙")
    chat = cb.message.chat.id
    a = (await bot.send_dice(chat, emoji="🎲")).dice.value
    b = (await bot.send_dice(chat, emoji="🎲")).dice.value
    await asyncio.sleep(3.5)
    db.emit("game", d["a"])
    db.emit("game", uid)
    if a == b:
        await db.add_coins(d["a"], bet)
        await db.add_coins(uid, bet)
        return await bot.send_message(chat, f"🎲 {a} : {b} — ничья, ставки вернула 🤝")
    win_id, win_name = (d["a"], d["an"]) if a > b else (uid, cb.from_user.first_name)
    await db.add_coins(win_id, bet * 2, win=True)
    await bot.send_message(chat, f"🎲 {escape(d['an'])} <b>{a}</b> : <b>{b}</b> {escape(cb.from_user.first_name)}\n"
                                 f"🏆 {link(win_id, win_name)} забирает <b>{bet * 2} 🪙</b>")


# ================= 🎟 лотерея в группе =================
TICKET = 20
LOTTERY_HOUR = 21


async def lottery_view(chat_id: int, uid: int) -> tuple[str, object]:
    day = db._day()
    rows = await db.q_all("SELECT uid, name, n FROM lottery WHERE chat_id=? AND day=? ORDER BY n DESC", chat_id, day)
    total = sum(r["n"] for r in rows)
    mine = next((r["n"] for r in rows if r["uid"] == uid), 0)
    lines = ["<b>🎟 лотерея дня</b>", ui.LINE, f"банк: <b>{total * TICKET} 🪙</b> · билетов: {total}",
             f"розыгрыш сегодня в {LOTTERY_HOUR}:00 мск — шанс по числу билетов", ""]
    lines += [f"• {escape(r['name'])} — {r['n']} 🎟" for r in rows[:10]]
    if mine:
        lines.append(f"\nу тебя: <b>{mine}</b> 🎟")
    return "\n".join(lines), kb_rows([(f"🎟 Билет · {TICKET} 🪙", "lt:buy"), ("🔄", "lt:show")])


@router.message(Command("lottery", "лотерея"))
async def cmd_lottery(m: Message):
    if m.chat.type not in GROUPS:
        return await m.reply("🎟 лотерея живёт в группах — там весь чат скидывается в банк")
    text, kb = await lottery_view(m.chat.id, m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("lt:"))
async def cb_lottery(cb: CallbackQuery):
    chat_id = cb.message.chat.id
    if cb.data == "lt:buy":
        if datetime.now(persona.MSK).hour >= LOTTERY_HOUR:
            return await cb.answer("сегодняшний розыгрыш прошёл, билеты — с полуночи", show_alert=True)
        if not await db.take_coins(cb.from_user.id, TICKET):
            return await cb.answer(f"билет стоит {TICKET} 🪙", show_alert=True)
        await db.q_run("INSERT INTO lottery VALUES(?,?,?,?,1) ON CONFLICT(chat_id, day, uid) DO UPDATE SET n=n+1",
                       chat_id, db._day(), cb.from_user.id, cb.from_user.first_name or "игрок")
        await cb.answer("🎟 билет куплен!")
    else:
        await cb.answer()
    text, kb = await lottery_view(chat_id, cb.from_user.id)
    await _edit(cb, text, kb)


async def draw_lottery(bot: Bot, now: datetime):
    """Разыграть всё, что пора: сегодняшнее после 21:00 и прошлые дни (если бот лежал)."""
    today = now.strftime("%Y-%m-%d")
    upto = today if now.hour >= LOTTERY_HOUR else ""
    chats = await db.q_all("SELECT DISTINCT chat_id, day FROM lottery WHERE day<? OR day=?", today, upto)
    for c in chats:
        day = c["day"]
        rows = await db.q_all("SELECT uid, name, n FROM lottery WHERE chat_id=? AND day=?", c["chat_id"], day)
        await db.q_run("DELETE FROM lottery WHERE chat_id=? AND day=?", c["chat_id"], day)
        total = sum(r["n"] for r in rows)
        if len(rows) < 2:
            for r in rows:
                await db.add_coins(r["uid"], r["n"] * TICKET)
            text = "🎟 в лотерею сыграл всего один человек — вернула билеты. завтра зовите друзей!"
        else:
            w = random.choices(rows, weights=[r["n"] for r in rows])[0]
            await db.add_coins(w["uid"], total * TICKET, win=True)
            text = (f"🎟 <b>розыгрыш лотереи!</b>\n{len(rows)} участников, {total} билетов\n"
                    f"🏆 банк <b>{total * TICKET} 🪙</b> забирает {link(w['uid'], w['name'])} 🎉")
        try:
            await bot.send_message(c["chat_id"], text)
        except Exception as e:
            log.info("lottery %s: %s", c["chat_id"], e)


# ================= 🏆 сезоны =================
SEASON_PRIZES = [500, 300, 150]
CHAMP_TITLE = ("champ", "🏆 Чемпион сезона")


async def close_season(bot: Bot, key: str):
    """Раз в месяц: топ-3 по победам за сезон — монетки и титул, счётчик в ноль."""
    top = await db.q_all("SELECT id, name, season_wins FROM users WHERE banned=0 AND season_wins>0 "
                         "ORDER BY season_wins DESC LIMIT 3")
    await db.q_run("UPDATE users SET season_wins=0")
    await db.kv_set("season", key)
    for i, u in enumerate(top):
        await db.add_coins(u["id"], SEASON_PRIZES[i])
        if i == 0:
            r = await db.get_user(u["id"])
            titles = {t for t in (r.get("titles") or "").split(",") if t} | {CHAMP_TITLE[0]}
            await db.q_run("UPDATE users SET titles=? WHERE id=?", ",".join(sorted(titles)), u["id"])
        try:
            await bot.send_message(u["id"], f"🏆 сезон закрыт! ты на <b>{i + 1} месте</b> ({u['season_wins']} побед)\n"
                                            f"награда: <b>+{SEASON_PRIZES[i]} 🪙</b>"
                                            + (f" и титул «{CHAMP_TITLE[1]}» — надень в /shop" if i == 0 else ""))
        except Exception:
            pass


# ================= фоновый цикл =================
async def loop(bot: Bot):
    while True:
        try:
            now = datetime.now(persona.MSK)
            await draw_lottery(bot, now)
            key = now.strftime("%Y-%m")
            last = await db.kv_get("season")
            if not last:
                await db.kv_set("season", key)
            elif last != key:
                await close_season(bot, key)
        except Exception:
            log.exception("fun loop")
        await asyncio.sleep(60)
