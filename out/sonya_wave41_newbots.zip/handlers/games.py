"""Игры: кубики Telegram, КНБ-дуэли, квиз от ИИ, виселица. Награды — монетки."""
import asyncio
import json
import random
import re
import time
import uuid
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import db
import llm
import ui
from handlers.ap_common import kb_rows

router = Router()
_cool: dict[int, float] = {}


def _cooldown(uid: int, sec: float = 4) -> bool:
    now = time.time()
    if now - _cool.get(uid, 0) < sec:
        return True
    _cool[uid] = now
    return False


def name_of(u) -> str:
    return escape(u.first_name or "аноним")


# ================= состояние игр в базе (переживает перезапуск) =================
async def _put(kind: str, gid: str, d: dict):
    data = json.dumps(d, ensure_ascii=False, default=lambda o: sorted(o) if isinstance(o, set) else str(o))
    await db.q_run("INSERT OR REPLACE INTO game_state VALUES(?,?,?,?)", f"{kind}:{gid}", kind, data, int(time.time()))


async def _drop(kind: str, gid: str):
    await db.q_run("DELETE FROM game_state WHERE id=?", f"{kind}:{gid}")


async def _get(kind: str, gid: str, cache: dict, sets: tuple = ()) -> dict | None:
    """Из памяти, а если бот перезапускался — из базы."""
    if gid in cache:
        return cache[gid]
    r = await db.q_one("SELECT data FROM game_state WHERE id=?", f"{kind}:{gid}")
    if not r:
        return None
    d = json.loads(r["data"])
    for k in sets:
        d[k] = set(d.get(k) or [])
    cache[gid] = d
    return d


# ================= меню =================
GAMES_TEXT = (
    ui.head("🎮", "Игры", "выигрывай 🪙 — они в профиле и в топе")
    + "\n" + ui.quote("🎲 <b>кости</b> против меня · 🎯 🏀 ⚽ 🎳\n"
                      "🎰 <b>казино</b> — ставка 5 🪙, 777 = джекпот\n"
                      "✊ <b>КНБ</b> · 🧠 <b>квиз</b> · 🔤 <b>виселица</b>\n"
                      "🧞 <b>акинатор</b> · 🎵 <b>песня по эмодзи</b> · 🎭 <b>правда или действие</b>\n"
                      "🎡 <b>колесо фортуны</b> раз в день · 🃏 <b>блэкджек</b> на монетки")
    + "\n" + ui.quote("👥 <b>в группе:</b> 🕵️ шпион · 🔪 мафия · 🐊 крокодил · 🎟 лотерея · ⚔️ /duel 50")
    + "\n" + ui.hint("📋 задания дня · 🐾 питомец · 🛍 титулы · 🏆 сезон — кнопки ниже")
)


def games_kb():
    return kb_rows(
        [("🎲", "g:d:🎲"), ("🎯", "g:d:🎯"), ("🏀", "g:d:🏀"), ("⚽", "g:d:⚽"), ("🎳", "g:d:🎳"), ("🎰", "g:d:🎰")],

        [("✊ КНБ", "g:rps"), ("🧠 Квиз", "g:quiz"), ("🔤 Виселица", "g:hang")],
        [("🧞 Акинатор", "g:aki"), ("🎵 Эмодзи-песня", "g:emoji"), ("🎭 П/Д", "g:pd")],
        [("🕵️ Шпион", "g:spy"), ("🔪 Мафия", "g:mafia"), ("🐊 Крокодил", "g:croc")],
        [("🎡 Колесо фортуны", "g:wheel"), ("🃏 Блэкджек", "g:bj")],
        [("📋 Задания", "g:quests"), ("🐾 Питомец", "g:pet")],
        [("🎁 Бонус", "g:bonus"), ("🛍 Магазин", "g:shop"), ("🏆 Сезон", "m:top:season_wins")],
        [("‹ Меню", "m:home")],
    )


@router.message(Command("games", "игры"))
async def cmd_games(m: Message):
    await m.answer(GAMES_TEXT, reply_markup=games_kb())


@router.callback_query(F.data == "g:menu")
async def cb_games(cb: CallbackQuery):
    try:
        await cb.message.edit_text(GAMES_TEXT, reply_markup=games_kb())
    except TelegramBadRequest:
        await cb.message.answer(GAMES_TEXT, reply_markup=games_kb())
    await cb.answer()


# ================= бонус =================
async def bonus_text(uid: int) -> str:
    got, streak, wait = await db.claim_bonus(uid)
    if not got:
        h, mnt = wait // 3600, wait % 3600 // 60
        return f"🎁 уже забрал сегодня. следующий через <b>{h} ч {mnt} мин</b>\n🔥 стрик: {streak} дн."
    from handlers import extra
    plus = ""
    if extra.active(uid):
        await db.add_coins(uid, got)
        got *= 2
        plus = " (×2 Соня+ ✨)"
    u = await db.get_user(uid)
    fire = "🔥" * min(streak, 7)
    return (f"🎁 <b>+{got} 🪙</b>{plus}\n{fire} стрик: <b>{streak}</b> дн. (завтра будет больше)\n"
            f"на счету: <b>{u['coins']} 🪙</b>")


@router.message(Command("bonus", "бонус"))
async def cmd_bonus(m: Message):
    await ui.personal(m, await bonus_text(m.from_user.id))


@router.callback_query(F.data == "g:bonus")
async def cb_bonus(cb: CallbackQuery):
    await cb.message.answer(await bonus_text(cb.from_user.id))
    await cb.answer()


# ================= кубики =================
DICE_RULES = {
    "🎲": "duel",
    "🎯": lambda v: (20, "в яблочко! 🎯") if v == 6 else (5, "почти") if v >= 4 else (0, "мимо"),
    "🏀": lambda v: (15, "в кольцо! 🏀") if v >= 4 else (0, "не попал"),
    "⚽": lambda v: (10, "гооол! ⚽") if v >= 3 else (0, "мимо ворот"),
    "🎳": lambda v: (20, "страйк! 🎳") if v == 6 else (5, "неплохо") if v >= 4 else (0, "в желоб"),
}
SLOT_COST = 5
DICE_WAIT = 3.5  # пока крутится анимация кубика


def slot_result(v: int) -> tuple[int, str]:
    # значения 1..64: 64 = 777, 1 = бары, 22 = виноград, 43 = лимоны
    if v == 64:
        return 100, "💥 ДЖЕКПОТ 777!"
    if v in (1, 22, 43):
        return 30, "три в ряд! 🍀"
    return 0, "не повезло"


async def play_dice(bot: Bot, chat_id: int, user, emoji: str, reply_to: int | None = None) -> str:
    uid = user.id
    if emoji == "🎰":
        if not await db.take_coins(uid, SLOT_COST):
            return f"🎰 ставка {SLOT_COST} 🪙, а у тебя меньше. забери /bonus"
    db.emit("game", uid)
    d = await bot.send_dice(chat_id, emoji=emoji, reply_to_message_id=reply_to)
    v = d.dice.value
    if emoji == "🎲":
        await asyncio.sleep(DICE_WAIT / 9)
        mine = await bot.send_dice(chat_id, emoji="🎲")
        await asyncio.sleep(DICE_WAIT)
        sv = mine.dice.value
        if v > sv:
            bal = await db.add_coins(uid, 10, win=True)
            return f"🎲 {name_of(user)}: <b>{v}</b> vs Соня: <b>{sv}</b> — ты выиграл +10 🪙 (всего {bal})"
        if v < sv:
            return f"🎲 {name_of(user)}: <b>{v}</b> vs Соня: <b>{sv}</b> — я победила 😏"
        return f"🎲 {v} : {sv} — ничья"
    await asyncio.sleep(DICE_WAIT)
    if emoji == "🎰":
        prize, msg = slot_result(v)
    else:
        prize, msg = DICE_RULES[emoji](v)
    if prize:
        bal = await db.add_coins(uid, prize, win=True)
        return f"{msg} {name_of(user)} +{prize} 🪙 (всего {bal})"
    return f"{msg}, {name_of(user)}"


@router.callback_query(F.data.startswith("g:d:"))
async def cb_dice(cb: CallbackQuery, bot: Bot):
    emoji = cb.data[4:]
    if emoji not in DICE_RULES and emoji != "🎰":
        return await cb.answer()
    if _cooldown(cb.from_user.id):
        return await cb.answer("не так быстро 🙂")
    await cb.answer()
    text = await play_dice(bot, cb.message.chat.id, cb.from_user, emoji)
    await cb.message.answer(text, reply_markup=kb_rows([("🔁 Ещё", cb.data), ("🎮 Игры", "g:menu")]))


@router.message(Command("dice", "кости", "casino", "казино", "darts", "дартс"))
async def cmd_dice(m: Message, bot: Bot):
    cmd = m.text.split()[0].lstrip("/").split("@")[0].lower()
    emoji = {"dice": "🎲", "кости": "🎲", "casino": "🎰", "казино": "🎰", "darts": "🎯", "дартс": "🎯"}[cmd]
    if _cooldown(m.from_user.id):
        return
    await m.answer(await play_dice(bot, m.chat.id, m.from_user, emoji, m.message_id))


# ================= КНБ =================
RPS = {"r": "✊", "p": "✋", "s": "✌️"}
BEATS = {"r": "s", "p": "r", "s": "p"}
_duels: dict[str, dict] = {}


def rps_kb(prefix: str):
    return kb_rows([(f"{RPS[k]}", f"{prefix}:{k}") for k in "rps"])


@router.callback_query(F.data == "g:rps")
async def cb_rps_menu(cb: CallbackQuery):
    await cb.answer()
    if cb.message.chat.type == "private":
        await cb.message.answer("✊✋✌️ выбирай!", reply_markup=rps_kb("rps:solo"))
    else:
        await _duel_invite(cb.message, cb.from_user)


@router.message(Command("rps", "кнб"))
async def cmd_rps(m: Message):
    if m.chat.type == "private":
        return await m.answer("✊✋✌️ выбирай!", reply_markup=rps_kb("rps:solo"))
    await _duel_invite(m, m.from_user)


@router.callback_query(F.data.startswith("rps:solo:"))
async def cb_rps_solo(cb: CallbackQuery):
    me = cb.data[-1]
    bot_pick = random.choice("rps")
    db.emit("game", cb.from_user.id)
    if BEATS[me] == bot_pick:
        bal = await db.add_coins(cb.from_user.id, 5, win=True)
        res = f"ты выиграл +5 🪙 (всего {bal})"
    elif BEATS[bot_pick] == me:
        res = random.choice(["я победила 😏", "ха, предсказуемо", "ещё разок?"])
    else:
        res = "ничья 🤝"
    try:
        await cb.message.edit_text(f"ты {RPS[me]} — я {RPS[bot_pick]}\n{res}", reply_markup=rps_kb("rps:solo"))
    except TelegramBadRequest:
        pass
    await cb.answer()


async def _duel_invite(m: Message, user):
    did = uuid.uuid4().hex[:8]
    _duels[did] = {"a": user.id, "an": user.first_name, "b": None, "bn": "", "pa": None, "pb": None,
                   "ts": time.time()}
    await _put("duel", did, _duels[did])
    await m.answer(f"⚔️ <b>{name_of(user)}</b> вызывает на КНБ! ставка 10 🪙 с победы",
                   reply_markup=kb_rows([("⚔️ Принять вызов", f"rps:j:{did}")]))


@router.callback_query(F.data.startswith("rps:j:"))
async def cb_duel_join(cb: CallbackQuery):
    d = await _get("duel", cb.data[6:], _duels)
    if not d:
        return await cb.answer("вызов устарел", show_alert=True)
    if cb.from_user.id == d["a"]:
        return await cb.answer("сам с собой? 🙃 жди соперника", show_alert=True)
    if d["b"]:
        return await cb.answer("уже занято", show_alert=True)
    d["b"], d["bn"] = cb.from_user.id, cb.from_user.first_name
    did = cb.data[6:]
    await _put("duel", did, d)
    try:
        await cb.message.edit_text(f"⚔️ {escape(d['an'])} vs {escape(d['bn'])}\nвыбирайте тайно 👇",
                                   reply_markup=rps_kb(f"rps:p:{did}"))
    except TelegramBadRequest:
        pass
    await cb.answer()


@router.callback_query(F.data.startswith("rps:p:"))
async def cb_duel_pick(cb: CallbackQuery):
    _, _, did, pick = cb.data.split(":")
    d = await _get("duel", did, _duels)
    if not d:
        return await cb.answer("дуэль устарела", show_alert=True)
    uid = cb.from_user.id
    if uid == d["a"] and not d["pa"]:
        d["pa"] = pick
    elif uid == d["b"] and not d["pb"]:
        d["pb"] = pick
    elif uid not in (d["a"], d["b"]):
        return await cb.answer("это не твоя дуэль", show_alert=True)
    else:
        return await cb.answer("ты уже выбрал")
    await cb.answer(f"ты выбрал {RPS[pick]}")
    if not (d["pa"] and d["pb"]):
        await _put("duel", did, d)
    else:
        _duels.pop(did, None)
        await _drop("duel", did)
        db.emit("game", d["a"])
        db.emit("game", d["b"])
        a, b = d["pa"], d["pb"]
        line = f"{escape(d['an'])} {RPS[a]} — {RPS[b]} {escape(d['bn'])}\n"
        if a == b:
            line += "ничья 🤝"
        else:
            win_id, win_name = (d["a"], d["an"]) if BEATS[a] == b else (d["b"], d["bn"])
            await db.add_coins(win_id, 10, win=True)
            line += f"🏆 победил <b>{escape(win_name)}</b> +10 🪙"
        try:
            await cb.message.edit_text(line)
        except TelegramBadRequest:
            pass


# ================= квиз =================
LOCAL_QUIZ = [
    ("Сколько планет в Солнечной системе?", ["7", "8", "9", "10"], 1),
    ("Какая самая длинная река в мире?", ["Амазонка", "Нил", "Янцзы", "Волга"], 0),
    ("Кто написал «Мастера и Маргариту»?", ["Булгаков", "Толстой", "Чехов", "Пелевин"], 0),
    ("Сколько костей у взрослого человека?", ["186", "206", "226", "256"], 1),
    ("Какой газ преобладает в атмосфере Земли?", ["Кислород", "Азот", "CO₂", "Аргон"], 1),
    ("В каком году вышел первый iPhone?", ["2005", "2007", "2009", "2010"], 1),
    ("Какая страна самая большая по площади?", ["Канада", "Китай", "Россия", "США"], 2),
    ("Сколько игроков в футбольной команде на поле?", ["9", "10", "11", "12"], 2),
]
TOPICS = ["кино", "музыка", "игры", "наука", "история", "география", "аниме", "интернет-культура",
          "спорт", "животные", "космос", "еда", "технологии", "литература"]
_quiz: dict[str, dict] = {}


async def make_quiz() -> tuple[str, list[str], int, str]:
    topic = random.choice(TOPICS)
    try:
        out = await llm.ask([{"role": "system", "content":
                              "Сгенерируй один интересный вопрос викторины средней сложности на русском. "
                              "Ответ строго JSON: {\"q\": \"вопрос\", \"options\": [\"a\",\"b\",\"c\",\"d\"], "
                              "\"answer\": индекс 0-3, \"fact\": \"короткий интересный факт по теме\"}. "
                              "Варианты короткие. Только JSON."},
                             {"role": "user", "content": f"Тема: {topic}. Случайное число: {random.randint(1, 99999)}"}],
                            max_tokens=700, temperature=1.0, feature="quiz")
        m = re.search(r"\{.*\}", out, re.S)
        d = json.loads(m.group(0))
        opts = [str(o)[:40] for o in d["options"]][:4]
        ans = int(d["answer"])
        if len(opts) == 4 and 0 <= ans < 4 and d.get("q"):
            return f"[{topic}] {d['q']}", opts, ans, str(d.get("fact") or "")[:200]
    except Exception:
        pass
    q, opts, ans = random.choice(LOCAL_QUIZ)
    return q, opts, ans, ""


async def send_quiz(m: Message, maker=None):
    q, opts, ans, fact = await (maker or make_quiz)()
    qid = uuid.uuid4().hex[:8]
    _quiz[qid] = {"ans": ans, "opts": opts, "fact": fact, "done": False, "tried": set(), "q": q}
    await _put("quiz", qid, _quiz[qid])
    await m.answer(f"🧠 <b>{escape(q)}</b>",
                   reply_markup=kb_rows(*[[(o, f"qz:{qid}:{i}")] for i, o in enumerate(opts)]))


@router.callback_query(F.data == "g:quiz")
async def cb_quiz_new(cb: CallbackQuery):
    if _cooldown(cb.from_user.id, 3):
        return await cb.answer("секунду…")
    await cb.answer("придумываю вопрос…")
    await send_quiz(cb.message)


@router.message(Command("quiz", "квиз"))
async def cmd_quiz(m: Message):
    await send_quiz(m)


@router.callback_query(F.data.startswith("qz:"))
async def cb_quiz(cb: CallbackQuery):
    _, qid, i = cb.data.split(":")
    q = await _get("quiz", qid, _quiz, ("tried",))
    if not q or q["done"]:
        return await cb.answer("вопрос уже закрыт")
    uid = cb.from_user.id
    if uid in q["tried"]:
        return await cb.answer("у тебя была попытка 🙃")
    q["tried"].add(uid)
    db.emit("game", uid)
    if int(i) != q["ans"]:
        await _put("quiz", qid, q)
        return await cb.answer("неа ❌", show_alert=False)
    q["done"] = True
    _quiz.pop(qid, None)
    await _drop("quiz", qid)
    db.emit("quiz", uid)
    bal = await db.add_coins(uid, 15, win=True)
    text = (f"🧠 {escape(q['q'])}\n\n✅ <b>{escape(q['opts'][q['ans']])}</b>\n"
            f"🏆 {name_of(cb.from_user)} +15 🪙 (всего {bal})")
    if q["fact"]:
        text += f"\n\n💡 <i>{escape(q['fact'])}</i>"
    try:
        await cb.message.edit_text(text, reply_markup=kb_rows([("🧠 Ещё вопрос", "g:quiz")]))
    except TelegramBadRequest:
        pass
    await cb.answer("верно! +15 🪙")


# ================= виселица =================
WORDS = ("альтушка вайб наушники плейлист телеграм мемасик скейтборд кофейня подъезд гитара троллейбус "
         "чебурашка кринж зефир сериал аниме фонарик метро самокат пельмени капибара шаурма бабушка "
         "дискотека эскимо котлета паутина горизонт вертолёт кукуруза библиотека карусель снеговик "
         "фейерверк черепаха радуга ананас кенгуру паровоз ромашка").split()
STAGES = ["😶", "😐", "😕", "😟", "😣", "😫", "💀"]
ALPHA = "абвгдежзийклмнопрстуфхцчшщъыьэюя"
_hang: dict[str, dict] = {}


def _hang_view(g: dict) -> tuple[str, object]:
    word = g["word"]
    shown = " ".join(c.upper() if c in g["got"] else "_" for c in word)
    miss = len(g["miss"])
    text = (f"🔤 <b>виселица</b>  {STAGES[miss]}  ошибок: {miss}/{len(STAGES) - 1}\n\n<code>{shown}</code>")
    if g["miss"]:
        text += f"\n\nмимо: {' '.join(sorted(g['miss'])).upper()}"
    rows, row = [], []
    for ch in ALPHA:
        if ch in g["got"] or ch in g["miss"]:
            continue
        row.append((ch.upper(), f"hg:{g['id']}:{ch}"))
        if len(row) == 8:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    return text, kb_rows(*rows)


async def new_hang(m: Message):
    gid = uuid.uuid4().hex[:8]
    g = {"id": gid, "word": random.choice(WORDS).replace("ё", "е"), "got": set(), "miss": set()}
    _hang[gid] = g
    await _put("hang", gid, g)
    text, kb = _hang_view(g)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "g:hang")
async def cb_hang_new(cb: CallbackQuery):
    await cb.answer()
    await new_hang(cb.message)


@router.message(Command("hangman", "виселица"))
async def cmd_hang(m: Message):
    await new_hang(m)


@router.callback_query(F.data.startswith("hg:"))
async def cb_hang(cb: CallbackQuery):
    _, gid, ch = cb.data.split(":")
    g = await _get("hang", gid, _hang, ("got", "miss"))
    if not g:
        return await cb.answer("игра закончилась")
    if ch in g["got"] or ch in g["miss"]:
        return await cb.answer()
    (g["got"] if ch in g["word"] else g["miss"]).add(ch)
    won = all(c in g["got"] for c in g["word"])
    lost = len(g["miss"]) >= len(STAGES) - 1
    if won or lost:
        _hang.pop(gid, None)
        await _drop("hang", gid)
        db.emit("game", cb.from_user.id)
        if won:
            bal = await db.add_coins(cb.from_user.id, 20, win=True)
            text = f"🎉 <b>{g['word'].upper()}</b>! последнюю букву угадал {name_of(cb.from_user)} +20 🪙 (всего {bal})"
        else:
            text = f"💀 не угадали. слово: <b>{g['word'].upper()}</b>"
        try:
            await cb.message.edit_text(text, reply_markup=kb_rows([("🔤 Ещё слово", "g:hang")]))
        except TelegramBadRequest:
            pass
        return await cb.answer()
    await _put("hang", gid, g)
    text, kb = _hang_view(g)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer("есть!" if ch in g["word"] else "мимо")


# ================= магазин титулов и переводы =================
TITLES = {
    "cat": ("🐈‍⬛ Чёрный кот", 50), "night": ("🦇 Ночной житель", 100), "vibe": ("🎧 Вайбовый", 150),
    "meme": ("🤡 Мемолог", 200), "chill": ("🧊 Хладнокровный", 300), "gamer": ("🎮 Задрот", 400),
    "rich": ("💸 Мажор", 700), "legend": ("👑 Легенда чата", 1000), "sonya": ("🖤 Любимчик Сони", 2000),
}
PLUS_TITLE = ("plus", "✨ Соня+")
SPECIAL = {"champ": "🏆 Чемпион сезона"}   # не продаются — только за заслуги


def _owned(u: dict) -> set[str]:
    from handlers import extra
    owned = {t for t in (u.get("titles") or "").split(",") if t}
    if extra.active(u["id"]):
        owned.add(PLUS_TITLE[0])
    return owned


async def shop_view(uid: int):
    u = await db.get_user(uid)
    owned = _owned(u)
    lines = ["<b>🛍 магазин титулов</b>", ui.LINE, f"на счету: <b>{u['coins']} 🪙</b>",
             "титул виден в профиле и топе\n"]
    rows = []
    if PLUS_TITLE[0] in owned:
        mark = "✓ надет" if u.get("title") == PLUS_TITLE[0] else "надеть"
        rows.append([(f"{PLUS_TITLE[1]} · {mark}", f"sh:wear:{PLUS_TITLE[0]}")])
    for k, name in SPECIAL.items():
        if k in owned:
            mark = "✓ надет" if u.get("title") == k else "надеть"
            rows.append([(f"{name} · {mark}", f"sh:wear:{k}")])
    for k, (name, price) in TITLES.items():
        if k in owned:
            mark = "✓ надет" if u.get("title") == k else "надеть"
            rows.append([(f"{name} · {mark}", f"sh:wear:{k}")])
        else:
            rows.append([(f"{name} · {price} 🪙", f"sh:buy:{k}")])
    if u.get("title"):
        rows.append([("🚫 Снять титул", "sh:wear:-")])
    rows.append([("🎮 Игры", "g:menu"), ("‹ Меню", "m:home")])
    return "\n".join(lines), kb_rows(*rows)


@router.message(Command("shop", "магазин"))
async def cmd_shop(m: Message):
    text, kb = await shop_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "g:shop")
async def cb_shop(cb: CallbackQuery):
    text, kb = await shop_view(cb.from_user.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data.startswith("sh:"))
async def cb_shop_act(cb: CallbackQuery):
    _, act, k = cb.data.split(":")
    uid = cb.from_user.id
    u = await db.get_user(uid)
    owned = _owned(u)
    if act == "buy":
        if k not in TITLES or k in owned:
            return await cb.answer()
        price = TITLES[k][1]
        if not await db.take_coins(uid, price):
            return await cb.answer(f"не хватает 🪙 — нужно {price}", show_alert=True)
        bought = (owned - {PLUS_TITLE[0]}) | {k}   # особые (champ) остаются в owned
        await db.q_run("UPDATE users SET titles=?, title=? WHERE id=?", ",".join(sorted(bought)), k, uid)
        await cb.answer(f"куплено и надето: {TITLES[k][0]}", show_alert=True)
    else:
        if k != "-" and k not in owned:
            return await cb.answer()
        await db.q_run("UPDATE users SET title=? WHERE id=?", "" if k == "-" else k, uid)
        await cb.answer("готово")
    text, kb = await shop_view(uid)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass


def title_of(u: dict) -> str:
    if u.get("title") == PLUS_TITLE[0]:
        from handlers import extra
        return PLUS_TITLE[1] if extra.active(u["id"]) else ""
    if u.get("title") in SPECIAL:
        return SPECIAL[u["title"]]
    return TITLES.get(u.get("title") or "", ("",))[0]


@router.message(Command("give", "дать"))
async def cmd_give(m: Message):
    args = (m.text or "").split()[1:]
    target_id, target_name, amount = None, "", None
    if m.reply_to_message and m.reply_to_message.from_user and not m.reply_to_message.from_user.is_bot:
        target_id, target_name = m.reply_to_message.from_user.id, m.reply_to_message.from_user.first_name
    for a in args:
        if a.isdigit():
            amount = int(a)
        elif a.startswith("@") and not target_id:
            r = await db.q_one("SELECT id, name FROM users WHERE lower(username)=?", a[1:].lower())
            if r:
                target_id, target_name = r["id"], r["name"]
    if not target_id or not amount:
        return await m.reply("как перевести: ответь <code>/give 50</code> на сообщение друга "
                             "или <code>/give @username 50</code>")
    if target_id == m.from_user.id:
        return await m.reply("себе нельзя 🙃")
    if amount < 1 or amount > 100000:
        return await m.reply("сумма от 1 🪙")
    if not await db.take_coins(m.from_user.id, amount):
        return await m.reply("не хватает монеток 🥲 /bonus")
    await db.add_coins(target_id, amount)
    await m.reply(f"💸 {name_of(m.from_user)} → {escape(target_name)}: <b>{amount} 🪙</b>")
