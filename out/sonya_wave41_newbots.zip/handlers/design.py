"""🎨 Конструктор интерфейса (только владелец): тексты, эмодзи и премиум-эмодзи, цвет кнопок, медиа, ссылки."""
import html
import re

from aiogram import Router, F, Bot, BaseMiddleware
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

import config
import ui
import uikit as K
from handlers.ap_common import kb_rows

router = Router()
STYLE_NAMES = {"": "обычный", "primary": "🔵 синий", "success": "🟢 зелёный", "danger": "🔴 красный"}
CTX: dict[str, list[str]] = {}       # экран → id его кнопок (для списка в редакторе)
BACK: dict[str, str] = {}            # id кнопки → экран, откуда пришли
LABELS: dict[str, str] = {}          # id кнопки → её подпись при открытии


class NoUi(BaseMiddleware):
    """Внутри конструктора ничего не подменяем — чтобы его нельзя было «сломать» своими правками."""
    async def __call__(self, handler, event, data):
        tok = K.NO_UI.set(True)
        try:
            return await handler(event, data)
        finally:
            K.NO_UI.reset(tok)


router.message.middleware(NoUi())
router.callback_query.middleware(NoUi())
owner = F.from_user.id == config.OWNER_ID


class UiSt(StatesGroup):
    text = State()
    media = State()
    link = State()
    btext = State()
    bicon = State()


# ================= главная =================
def home_view():
    on = K.EDIT["on"]
    text = (f"<b>🎨 конструктор интерфейса</b>\n{ui.LINE}\n"
            f"режим правки: <b>{'✅ включён' if on else 'выключен'}</b>\n"
            f"изменено: экранов <b>{len(K.SCREENS)}</b> · кнопок <b>{len(K.BTNS)}</b>\n\n"
            "1. включи режим правки\n"
            "2. под каждым моим сообщением тебе в личке появится «✏️ Изменить экран»\n"
            "   в группе — ответь <code>/ui</code> на моё сообщение, редактор придёт в личку\n"
            "3. меняй текст (с эмодзи и премиум-эмодзи), добавляй фото/видео/гиф и кнопки-ссылки, "
            "а у кнопок — текст, премиум-иконку, цвет или скрывай их\n\n"
            "<i>правки видят все пользователи сразу. премиум-эмодзи работают, если у владельца бота "
            "есть Telegram Premium</i>")
    kb = kb_rows([("⏸ Выключить правку" if on else "✏️ Включить режим правки", "ui:mode")],
                 [(f"📋 Экраны · {len(K.SCREENS)}", "ui:ls"), (f"🔘 Кнопки · {len(K.BTNS)}", "ui:lb")],
                 [("♻️ Сбросить всё", "ui:rst")],
                 [("‹ Админка", "adm:home")])
    return text, kb


async def _show(cb: CallbackQuery, text: str, kb):
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest as e:
        if "not modified" not in str(e).lower():
            await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


@router.message(Command("ui", "design"), owner)
async def cmd_ui(m: Message, bot: Bot, state: FSMContext):
    await state.clear()
    r = m.reply_to_message
    if r and r.from_user and r.from_user.id == (await bot.me()).id:
        k = K.LASTKEY.get((r.chat.id, r.message_id))
        if not k:
            src = r.html_text if (r.text or r.caption) else ""
            k = K.key_of(src, True)
            K.SAMPLES.setdefault(k, (src, True))
        text, kb = screen_view(k, r.reply_markup)
        try:
            await bot.send_message(config.OWNER_ID, text, reply_markup=kb)
            if m.chat.id != config.OWNER_ID:
                await m.reply("✏️ редактор этого экрана — у тебя в личке")
        except TelegramBadRequest:
            await m.reply("напиши мне в личку /start, потом повтори")
        return
    text, kb = home_view()
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "ui:home", owner)
async def cb_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await _show(cb, *home_view())


@router.callback_query(F.data == "ui:mode", owner)
async def cb_mode(cb: CallbackQuery):
    K.EDIT["on"] = not K.EDIT["on"]
    await _show(cb, *home_view())
    if K.EDIT["on"]:
        await cb.message.answer("✏️ режим правки включён. открой /menu и ходи по экранам — "
                                "под каждым будет «✏️ Изменить экран»")


@router.callback_query(F.data == "ui:rst", owner)
async def cb_rst(cb: CallbackQuery):
    await _show(cb, "♻️ <b>сбросить все правки?</b>\nвсе тексты, кнопки и медиа вернутся как было",
                kb_rows([("🗑 Да, сбросить", "ui:rst!"), ("✖️ Нет", "ui:home")]))


@router.callback_query(F.data == "ui:rst!", owner)
async def cb_rst_go(cb: CallbackQuery):
    await K.reset_all()
    await _show(cb, *home_view())


def _short(s: str, n: int = 40) -> str:
    s = re.sub(r"\s+", " ", K.plain(s)).strip()
    return s[:n] + ("…" if len(s) > n else "")


@router.callback_query(F.data == "ui:ls", owner)
async def cb_list_screens(cb: CallbackQuery):
    rows = []
    for k, o in list(K.SCREENS.items())[:40]:
        smp = K.screen_sample(k)
        marks = ("✏️" if o.get("tpl") else "") + ("🖼" if o.get("media") else "") + ("🔗" if o.get("links") else "")
        rows.append([(f"{marks} {_short(smp[0] if smp else k, 32)}", f"ui:s:{k}")])
    text = "<b>📋 изменённые экраны</b>" + ("" if rows else "\n\n<i>пока ничего не менял</i>")
    await _show(cb, text, kb_rows(*rows, [("‹ Назад", "ui:home")]))


@router.callback_query(F.data == "ui:lb", owner)
async def cb_list_btns(cb: CallbackQuery):
    rows = []
    for key, o in list(K.BTNS.items())[:40]:
        lab = o.get("text") or o.get("label") or key
        marks = ("🙈 " if o.get("hide") else "") + ("💎" if o.get("icon") else "") + \
                {"primary": "🔵", "success": "🟢", "danger": "🔴"}.get(o.get("style") or "", "")
        rows.append([(f"{marks} {lab}"[:60], f"ui:b:{K.bid(key)}")])
    text = "<b>🔘 изменённые кнопки</b>" + ("" if rows else "\n\n<i>пока ничего не менял</i>")
    await _show(cb, text, kb_rows(*rows, [("‹ Назад", "ui:home")]))


# ================= редактор экрана =================
def screen_view(k: str, markup: InlineKeyboardMarkup | None = None):
    o = K.SCREENS.get(k, {})
    smp = K.screen_sample(k)
    if markup is not None:
        ids = []
        for row in markup.inline_keyboard:
            for b in row:
                key = K.find_bkey(b)
                if key and not (b.callback_data or "").startswith("ui:") and not any(
                        b.url and [b.text, b.url] == lk for lk in o.get("links") or []):
                    i = K.bid(key)
                    if i not in ids:
                        ids.append(i)
                        LABELS[i] = b.text
                        BACK[i] = k
        CTX[k] = ids
    media = o.get("media")
    long_warn = ""
    if media and smp and len(K.plain(K.render(o.get("tpl") or "{orig}", smp[0], smp[1], "Тим"))) > K.CAPTION_MAX:
        long_warn = "\n⚠️ текст длиннее 1024 символов — с медиа Telegram так не умеет, медиа не покажется"
    text = (f"<b>✏️ экран</b>\n{ui.LINE}\n"
            f"«{html.escape(_short(smp[0], 120)) if smp else 'экран'}»\n\n"
            f"текст: <b>{'свой' if o.get('tpl') else 'исходный'}</b>\n"
            f"медиа: <b>{ {'photo': '🖼 фото', 'video': '🎬 видео', 'animation': '🎞 гиф'}.get((media or {}).get('type'), 'нет')}</b>\n"
            f"кнопки-ссылки: <b>{len(o.get('links') or [])}</b>{long_warn}\n\n"
            "<i>ниже — кнопки этого экрана, нажми чтобы изменить</i>")
    rows = [[("✏️ Заменить текст", f"ui:t:{k}:r")],
            [("⬆️ Текст сверху", f"ui:t:{k}:t"), ("⬇️ Текст снизу", f"ui:t:{k}:b")],
            [("🖼 Медиа", f"ui:m:{k}")] + ([("🗑 Убрать медиа", f"ui:md:{k}")] if media else []),
            [("🔗 Добавить ссылку", f"ui:l:{k}")] + ([("🗑 Убрать ссылки", f"ui:ld:{k}")] if o.get("links") else []),
            [("👀 Как сейчас", f"ui:v:{k}")] + ([("↩️ Исходный текст", f"ui:o:{k}")] if o.get("tpl") else [])]
    for i in CTX.get(k, [])[:30]:
        key = K.BIDS.get(i, "")
        bo = K.BTNS.get(key, {})
        lab = bo.get("text") or LABELS.get(i) or bo.get("label") or "кнопка"
        mark = "🙈 " if bo.get("hide") else "🔘 "
        rows.append([(f"{mark}{lab}"[:60], f"ui:b:{i}")])
    rows.append([("🎨 Конструктор", "ui:home"), ("✖️ Закрыть", "ui:x")])
    return text, kb_rows(*rows)


@router.callback_query(F.data.startswith("ui:e:"), owner)
async def cb_edit_screen(cb: CallbackQuery):
    k = cb.data[5:]
    text, kb = screen_view(k, cb.message.reply_markup)
    await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data.startswith("ui:s:"), owner)
async def cb_screen(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await _show(cb, *screen_view(cb.data[5:]))


@router.callback_query(F.data == "ui:x", owner)
async def cb_close(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass
    await cb.answer()


def _remember_sample(k: str):
    smp = K.screen_sample(k)
    if smp:
        o = K.SCREENS.setdefault(k, {})
        o["sample"], o["html"] = smp


ASK = {
    "r": "✏️ пришли новый текст экрана — с эмодзи, премиум-эмодзи, жирным, курсивом, ссылками, как хочешь.\n\n"
         "<code>{orig}</code> — вставить мой исходный текст (нужно, если на экране живые цифры)\n"
         "<code>{name}</code> — имя того, кто смотрит",
    "t": "⬆️ пришли текст, который добавить <b>над</b> экраном",
    "b": "⬇️ пришли текст, который добавить <b>под</b> экраном",
}


@router.callback_query(F.data.startswith("ui:t:"), owner)
async def cb_text(cb: CallbackQuery, state: FSMContext):
    _, _, k, mode = cb.data.split(":")
    await state.set_state(UiSt.text)
    await state.update_data(k=k, mode=mode)
    await cb.message.answer(ASK[mode], reply_markup=kb_rows([("✖️ Отмена", f"ui:s:{k}")]))
    await cb.answer()


async def _preview(bot: Bot, k: str) -> str | None:
    """Показывает экран как его увидят. Ошибка разметки → текст ошибки."""
    smp = K.screen_sample(k)
    if not smp:
        return None
    tok = K.NO_UI.set(True)
    try:
        o = K.SCREENS.get(k, {})
        name = await K._name(config.OWNER_ID)
        text = K.render(o["tpl"], smp[0], smp[1], name) if o.get("tpl") else smp[0]
        pm = "HTML" if (o.get("tpl") or smp[1]) else None
        media = o.get("media")
        mk = K._with_rows(None, K._link_rows(o))
        if media and len(K.plain(text, pm is not None)) <= K.CAPTION_MAX:
            cls, field = K.SEND[media["type"]]
            await bot(cls(chat_id=config.OWNER_ID, caption=text, parse_mode=pm, reply_markup=mk,
                          **{field: media["id"]}))
        else:
            await bot.send_message(config.OWNER_ID, text, parse_mode=pm, reply_markup=mk)
    except TelegramBadRequest as e:
        return str(e)
    finally:
        K.NO_UI.reset(tok)
    return None


@router.message(UiSt.text, owner)
async def st_text(m: Message, state: FSMContext, bot: Bot):
    if not (m.text or m.caption):
        return await m.answer("нужен текст 🙂")
    d = await state.get_data()
    k, mode = d["k"], d["mode"]
    new = m.html_text
    o = K.SCREENS.setdefault(k, {})
    old = o.get("tpl")
    cur = old or "{orig}"
    o["tpl"] = new if mode == "r" else (new + "\n\n" + cur if mode == "t" else cur + "\n\n" + new)
    _remember_sample(k)
    err = await _preview(bot, k)
    if err:
        if old:
            o["tpl"] = old
        else:
            o.pop("tpl", None)
        return await m.answer(f"😕 Telegram не принял текст: <code>{html.escape(err[:200])}</code>\n"
                              "проверь разметку или премиум-эмодзи и пришли ещё раз")
    await K.save_screen(k)
    await state.clear()
    await m.answer("✅ сохранила — выше видно, как будет", reply_markup=kb_rows([("‹ К экрану", f"ui:s:{k}")]))


@router.callback_query(F.data.startswith("ui:o:"), owner)
async def cb_orig(cb: CallbackQuery):
    k = cb.data[5:]
    if k in K.SCREENS:
        K.SCREENS[k].pop("tpl", None)
        await K.save_screen(k)
    await _show(cb, *screen_view(k))


@router.callback_query(F.data.startswith("ui:v:"), owner)
async def cb_view(cb: CallbackQuery, bot: Bot):
    k = cb.data[5:]
    err = await _preview(bot, k)
    await cb.answer("не помню исходник этого экрана — открой его ещё раз" if err is None and not K.screen_sample(k)
                    else (f"ошибка: {err[:150]}" if err else ""), show_alert=bool(err) or not K.screen_sample(k))


@router.callback_query(F.data.startswith("ui:m:"), owner)
async def cb_media(cb: CallbackQuery, state: FSMContext):
    k = cb.data[5:]
    await state.set_state(UiSt.media)
    await state.update_data(k=k)
    await cb.message.answer("🖼 пришли фото, видео или гифку — буду показывать её на этом экране",
                            reply_markup=kb_rows([("✖️ Отмена", f"ui:s:{k}")]))
    await cb.answer()


@router.message(UiSt.media, owner)
async def st_media(m: Message, state: FSMContext, bot: Bot):
    if m.animation:
        media = {"type": "animation", "id": m.animation.file_id}
    elif m.photo:
        media = {"type": "photo", "id": m.photo[-1].file_id}
    elif m.video:
        media = {"type": "video", "id": m.video.file_id}
    else:
        return await m.answer("нужно фото, видео или гиф 🙂")
    k = (await state.get_data())["k"]
    o = K.SCREENS.setdefault(k, {})
    o["media"] = media
    _remember_sample(k)
    await K.save_screen(k)
    await state.clear()
    await _preview(bot, k)
    await m.answer("✅ медиа добавлено", reply_markup=kb_rows([("‹ К экрану", f"ui:s:{k}")]))


@router.callback_query(F.data.startswith("ui:md:"), owner)
async def cb_media_del(cb: CallbackQuery):
    k = cb.data[6:]
    if k in K.SCREENS:
        K.SCREENS[k].pop("media", None)
        await K.save_screen(k)
    await _show(cb, *screen_view(k))


@router.callback_query(F.data.startswith("ui:l:"), owner)
async def cb_link(cb: CallbackQuery, state: FSMContext):
    k = cb.data[5:]
    await state.set_state(UiSt.link)
    await state.update_data(k=k)
    await cb.message.answer("🔗 пришли кнопку так: <code>Мой канал - https://t.me/mychannel</code>\n"
                            "можно несколько, каждую с новой строки",
                            reply_markup=kb_rows([("✖️ Отмена", f"ui:s:{k}")]))
    await cb.answer()


@router.message(UiSt.link, owner, F.text)
async def st_link(m: Message, state: FSMContext):
    links = []
    for line in m.text.splitlines():
        mt = re.match(r"\s*(.+?)\s*[-—|]\s*((?:https?|tg)://\S+)\s*$", line)
        if mt:
            links.append([mt[1][:60], mt[2]])
    if not links:
        return await m.answer("не поняла 🙈 формат: <code>Текст - https://ссылка</code>")
    k = (await state.get_data())["k"]
    o = K.SCREENS.setdefault(k, {})
    o["links"] = ((o.get("links") or []) + links)[:8]
    _remember_sample(k)
    await K.save_screen(k)
    await state.clear()
    await m.answer(f"✅ добавила кнопок: {len(links)}", reply_markup=kb_rows([("‹ К экрану", f"ui:s:{k}")]))


@router.callback_query(F.data.startswith("ui:ld:"), owner)
async def cb_link_del(cb: CallbackQuery):
    k = cb.data[6:]
    if k in K.SCREENS:
        K.SCREENS[k].pop("links", None)
        await K.save_screen(k)
    await _show(cb, *screen_view(k))


# ================= редактор кнопки =================
def btn_view(i: str):
    key = K.BIDS.get(i)
    if not key:
        return "кнопка устарела — открой экран заново", kb_rows([("🎨 Конструктор", "ui:home")])
    o = K.BTNS.get(key, {})
    data, label = key.split("|", 1)
    orig = o.get("label") or LABELS.get(i) or label
    text = (f"<b>🔘 кнопка</b>\n{ui.LINE}\n"
            f"было: «{html.escape(orig)}»\n"
            f"сейчас: «{html.escape(o.get('text') or orig)}»\n"
            f"премиум-иконка: <b>{'есть 💎' if o.get('icon') else 'нет'}</b>\n"
            f"цвет: <b>{STYLE_NAMES.get(o.get('style') or '', 'обычный')}</b>\n"
            f"{'🙈 <b>скрыта</b>' if o.get('hide') else 'видна'}\n\n"
            "<i>меняется везде, где есть такая кнопка. цвет видно в свежих версиях Telegram</i>")
    style = o.get("style") or ""
    rows = [[("✏️ Текст и эмодзи", f"ui:bt:{i}"), ("💎 Премиум-иконка", f"ui:bi:{i}")],
            [(("· " if style == v else "") + n.split()[0], f"ui:bc:{i}:{c}")
             for c, v, n in (("p", "primary", "🔵"), ("s", "success", "🟢"), ("d", "danger", "🔴"), ("n", "", "⚪"))],
            [("👁 Показать" if o.get("hide") else "🙈 Скрыть", f"ui:bh:{i}")]
            + ([("🗑 Убрать иконку", f"ui:bin:{i}")] if o.get("icon") else []),
            [("↩️ Сбросить", f"ui:br:{i}")],
            [("‹ К экрану", f"ui:s:{BACK[i]}") if i in BACK else ("‹ Кнопки", "ui:lb")]]
    return text, kb_rows(*rows)


def _bo(i: str) -> tuple[str, dict] | tuple[None, None]:
    key = K.BIDS.get(i)
    if not key:
        return None, None
    o = K.BTNS.setdefault(key, {})
    data, label = key.split("|", 1)
    o.setdefault("data", data)
    o.setdefault("label", LABELS.get(i) or label)
    return key, o


@router.callback_query(F.data.startswith("ui:b:"), owner)
async def cb_btn(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await _show(cb, *btn_view(cb.data[5:]))


@router.callback_query(F.data.regexp(r"^ui:b(c|h|in|r):"), owner)
async def cb_btn_act(cb: CallbackQuery):
    parts = cb.data.split(":")
    act, i = parts[1], parts[2]
    key, o = _bo(i)
    if not key:
        return await cb.answer("кнопка устарела")
    if act == "bc":
        o["style"] = K.STYLES.get(parts[3], "")
    elif act == "bh":
        o["hide"] = not o.get("hide")
    elif act == "bin":
        o.pop("icon", None)
    elif act == "br":
        for f in ("text", "icon", "style", "hide"):
            o.pop(f, None)
    await K.save_btn(key)
    await _show(cb, *btn_view(i))


@router.callback_query(F.data.regexp(r"^ui:b(t|i):"), owner)
async def cb_btn_ask(cb: CallbackQuery, state: FSMContext):
    _, act, i = cb.data.split(":")
    await state.set_state(UiSt.btext if act == "bt" else UiSt.bicon)
    await state.update_data(i=i)
    ask = ("✏️ пришли новый текст кнопки. обычные эмодзи — прямо в текст. "
           "премиум-эмодзи в начале станет иконкой кнопки 💎" if act == "bt" else
           "💎 пришли один премиум-эмодзи (или эмодзи-стикер) — он встанет перед текстом кнопки")
    await cb.message.answer(ask, reply_markup=kb_rows([("✖️ Отмена", f"ui:b:{i}")]))
    await cb.answer()


def _custom_emoji(m: Message) -> tuple[str | None, str]:
    """→ (id первого премиум-эмодзи, текст без него)."""
    text = m.text or ""
    for e in m.entities or []:
        if e.type == "custom_emoji":
            raw = text.encode("utf-16-le")
            rest = (raw[:e.offset * 2] + raw[(e.offset + e.length) * 2:]).decode("utf-16-le")
            return e.custom_emoji_id, rest.strip()
    if m.sticker and m.sticker.custom_emoji_id:
        return m.sticker.custom_emoji_id, ""
    return None, text.strip()


async def _test_btn(bot: Bot, o: dict) -> str | None:
    b = InlineKeyboardButton(text=o.get("text") or o.get("label") or "кнопка", callback_data="ui:home",
                             icon_custom_emoji_id=o.get("icon"), style=o.get("style") or None)
    tok = K.NO_UI.set(True)
    try:
        await bot.send_message(config.OWNER_ID, "👀 так будет выглядеть кнопка:",
                               reply_markup=InlineKeyboardMarkup(inline_keyboard=[[b]]))
    except TelegramBadRequest as e:
        return str(e)
    finally:
        K.NO_UI.reset(tok)
    return None


@router.message(UiSt.btext, owner)
async def st_btext(m: Message, state: FSMContext, bot: Bot):
    i = (await state.get_data())["i"]
    key, o = _bo(i)
    if not key:
        await state.clear()
        return await m.answer("кнопка устарела — открой экран заново")
    icon, label = _custom_emoji(m)
    if not label and not icon:
        return await m.answer("нужен текст 🙂")
    old = dict(o)
    if label:
        o["text"] = label[:64]
    if icon:
        o["icon"] = icon
    err = await _test_btn(bot, o)
    if err:
        o.clear()
        o.update(old)
        return await m.answer(f"😕 Telegram не принял: <code>{html.escape(err[:200])}</code>\n"
                              "премиум-иконки работают, только если у владельца бота есть Telegram Premium")
    await K.save_btn(key)
    await state.clear()
    text, kb = btn_view(i)
    await m.answer("✅ готово\n\n" + text, reply_markup=kb)


@router.message(UiSt.bicon, owner)
async def st_bicon(m: Message, state: FSMContext, bot: Bot):
    i = (await state.get_data())["i"]
    key, o = _bo(i)
    if not key:
        await state.clear()
        return await m.answer("кнопка устарела — открой экран заново")
    icon, _ = _custom_emoji(m)
    if not icon:
        return await m.answer("это обычный эмодзи 🙂 его можно просто вписать в текст кнопки (✏️ Текст). "
                              "сюда нужен именно премиум-эмодзи")
    old = o.get("icon")
    o["icon"] = icon
    err = await _test_btn(bot, o)
    if err:
        if old:
            o["icon"] = old
        else:
            o.pop("icon", None)
        return await m.answer(f"😕 Telegram не принял иконку: <code>{html.escape(err[:200])}</code>\n"
                              "нужен Telegram Premium у владельца бота")
    await K.save_btn(key)
    await state.clear()
    text, kb = btn_view(i)
    await m.answer("✅ готово\n\n" + text, reply_markup=kb)
