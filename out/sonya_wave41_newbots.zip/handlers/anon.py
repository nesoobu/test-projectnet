"""💌 Анонимные вопросы: у каждого своя ссылка → друзья пишут анонимно → отвечаешь, не зная, кто это.
Защита: блок отправителя, жалоба, фильтр угроз, лимит частоты, «не принимать сообщения»."""
import hashlib
import logging
import re
import time
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("anon")
RATE = (5, 60)            # не больше 5 сообщений в минуту от одного человека
_writing: dict[int, tuple[int, float]] = {}    # отправитель → (кому пишет, когда начал)
_replying: dict[int, tuple[int, float]] = {}   # получатель → (id анонимки, когда нажал «ответить»)
_sent: dict[int, list[float]] = {}
BAD = re.compile(r"(убью|убить тебя|зарежу|сдохни|выпились|самоубий|твой адрес|найду тебя|слив|интим фото)", re.I)


# ================= ссылка =================
def code_of(uid: int) -> str:
    return hashlib.sha256(f"anon|{uid}|{config.BOT_TOKEN[:12]}".encode()).hexdigest()[:10]


async def ensure_link(uid: int) -> str:
    code = code_of(uid)
    await db.q_run("INSERT OR IGNORE INTO anon_links(uid, code, open) VALUES(?,?,1)", uid, code)
    return code


async def owner_of(code: str) -> dict | None:
    return await db.q_one("SELECT * FROM anon_links WHERE code=?", code)


async def home(m: Message, bot: Bot, uid: int):
    code = await ensure_link(uid)
    me = await bot.me()
    link = f"https://t.me/{me.username}?start=a_{code}"
    row = await db.q_one("SELECT open FROM anon_links WHERE uid=?", uid)
    got = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=?", uid))["n"]
    ans = (await db.q_one("SELECT COUNT(*) n FROM anon_msgs WHERE to_uid=? AND answered=1", uid))["n"]
    share = ("https://t.me/share/url?url=" + quote(link) + "&text=" + quote("задай мне анонимный вопрос 👀"))
    text = (ui.head("💌", "Анонимные вопросы", "тебе пишут — ты не знаешь кто")
            + "\n" + ui.quote(f"твоя ссылка:\n<code>{link}</code>")
            + "\n" + ui.hint("кинь её в сторис, био или чат — и жди вопросов 👀")
            + "\n" + ui.stats(("📬 получено", got), ("💬 отвечено", ans),
                              ("📭 приём", "включён" if (row or {}).get("open", 1) else "выключен")))
    kb = kb_rows([("📤 Поделиться ссылкой", share)],
                 [("📴 Не принимать" if (row or {}).get("open", 1) else "📬 Принимать снова", "an:toggle")],
                 [("🚫 Мои блокировки", "an:blocks")])
    await m.answer(text, reply_markup=kb)


@router.message(Command("link", "ссылка"))
async def cmd_link(m: Message, bot: Bot):
    await home(m, bot, m.from_user.id)


@router.callback_query(F.data == "an:home")
async def cb_home(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    await home(cb.message, bot, cb.from_user.id)


@router.callback_query(F.data == "an:toggle")
async def cb_toggle(cb: CallbackQuery, bot: Bot):
    await ensure_link(cb.from_user.id)
    await db.q_run("UPDATE anon_links SET open=1-open WHERE uid=?", cb.from_user.id)
    r = await db.q_one("SELECT open FROM anon_links WHERE uid=?", cb.from_user.id)
    await cb.answer("принимаю сообщения 📬" if r["open"] else "больше не принимаю 📴", show_alert=True)


# ================= написать анонимно =================
async def start_writing(m: Message, bot: Bot, code: str, uid: int | None = None) -> bool:
    uid = uid or m.from_user.id
    o = await owner_of(code)
    if not o:
        await m.answer("🤔 ссылка не работает — попроси новую")
        return True
    if o["uid"] == uid:
        await m.answer("это твоя же ссылка 🙃 кинь её друзьям")
        return True
    if not o["open"]:
        await m.answer("📴 этот человек сейчас не принимает анонимные сообщения")
        return True
    if await db.q_one("SELECT 1 FROM anon_blocks WHERE owner=? AND sender=?", o["uid"], uid):
        await m.answer("🚫 получатель ограничил тебе сообщения")
        return True
    _writing[uid] = (o["uid"], time.time())
    await m.answer("✍️ <b>напиши анонимное сообщение</b>\nтекст, фото, голосовое, кружок или стикер — "
                   "он не узнает, кто ты 🤫",
                   reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))
    return True


def writing(m: Message) -> bool:
    w = _writing.get(m.from_user.id) if m.from_user else None
    return bool(w and time.time() - w[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def replying(m: Message) -> bool:
    r = _replying.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[1] < 1800 and m.chat.type == "private"
                and not (m.text or "").startswith("/"))


def _too_fast(uid: int) -> bool:
    now = time.time()
    q = [t for t in _sent.get(uid, []) if now - t < RATE[1]]
    _sent[uid] = q
    if len(q) >= RATE[0]:
        return True
    q.append(now)
    return False


@router.callback_query(F.data == "an:cancel")
async def cb_cancel(cb: CallbackQuery):
    _writing.pop(cb.from_user.id, None)
    _replying.pop(cb.from_user.id, None)
    await cb.answer("отменила")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass


def _kb_for_owner(mid: int):
    return kb_rows([("↩️ Ответить", f"an:re:{mid}"), ("🚫 Заблокировать", f"an:bl:{mid}")],
                   [("⚠️ Пожаловаться", f"an:rep:{mid}")])


@router.message(writing)
async def on_write(m: Message, bot: Bot):
    to, _ = _writing.pop(m.from_user.id)
    if _too_fast(m.from_user.id):
        return await m.answer("⏳ слишком быстро — подожди минутку")
    if m.text and BAD.search(m.text):
        return await m.answer("🚫 такое не передам. угрозы и травля — не сюда")
    mid = await db.q_run("INSERT INTO anon_msgs(to_uid, from_uid, ts, answered) VALUES(?,?,?,0)",
                         to, m.from_user.id, int(time.time()))
    try:
        await bot.send_message(to, "💌 <b>новое анонимное сообщение</b>")
        await bot.copy_message(to, m.chat.id, m.message_id, reply_markup=_kb_for_owner(mid))
    except Exception as e:
        log.info("deliver: %s", e)
        return await m.answer("😕 не смогла доставить — возможно, человек заблокировал бота")
    code = code_of(to)
    await m.answer("✅ отправлено анонимно! если ответят — пришлю сюда 🤫",
                   reply_markup=kb_rows([("✍️ Написать ещё", f"an:more:{code}")], [("💌 Хочу свою ссылку", "an:home")]))


@router.callback_query(F.data.startswith("an:more:"))
async def cb_more(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    await start_writing(cb.message, bot, cb.data[8:], cb.from_user.id)


# ================= ответ, блок, жалоба =================
async def _msg(cb: CallbackQuery) -> dict | None:
    mid = int(cb.data.rsplit(":", 1)[1])
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=? AND to_uid=?", mid, cb.from_user.id)
    if not r:
        await cb.answer("сообщение не найдено", show_alert=True)
    return r


@router.callback_query(F.data.startswith("an:re:"))
async def cb_reply(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    _replying[cb.from_user.id] = (r["id"], time.time())
    await cb.answer()
    await cb.message.reply("↩️ напиши ответ — отправлю анонимному автору (он тоже не узнает, кто ты, "
                           "если не скажешь сам)", reply_markup=kb_rows([("✖️ Отмена", "an:cancel")]))


@router.message(replying)
async def on_reply(m: Message, bot: Bot):
    mid, _ = _replying.pop(m.from_user.id)
    r = await db.q_one("SELECT * FROM anon_msgs WHERE id=?", mid)
    if not r:
        return await m.answer("сообщение устарело")
    try:
        await bot.send_message(r["from_uid"], "💬 <b>тебе ответили на анонимное сообщение:</b>")
        await bot.copy_message(r["from_uid"], m.chat.id, m.message_id,
                               reply_markup=kb_rows([("✍️ Написать ещё", f"an:more:{code_of(r['to_uid'])}")]))
    except Exception as e:
        log.info("reply: %s", e)
        return await m.answer("😕 автор недоступен — наверное, заблокировал бота")
    await db.q_run("UPDATE anon_msgs SET answered=1 WHERE id=?", mid)
    await m.answer("✅ ответ отправлен")


@router.callback_query(F.data.startswith("an:bl:"))
async def cb_block(cb: CallbackQuery):
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("🚫 автор больше не сможет тебе писать", show_alert=True)


@router.callback_query(F.data == "an:blocks")
async def cb_blocks(cb: CallbackQuery):
    n = (await db.q_one("SELECT COUNT(*) n FROM anon_blocks WHERE owner=?", cb.from_user.id))["n"]
    await cb.answer()
    await cb.message.answer(f"🚫 заблокировано авторов: <b>{n}</b>",
                            reply_markup=kb_rows([("🔓 Разблокировать всех", "an:unblock")]) if n else None)


@router.callback_query(F.data == "an:unblock")
async def cb_unblock(cb: CallbackQuery):
    await db.q_run("DELETE FROM anon_blocks WHERE owner=?", cb.from_user.id)
    await cb.answer("разблокировала всех", show_alert=True)


@router.callback_query(F.data.startswith("an:rep:"))
async def cb_report(cb: CallbackQuery, bot: Bot):
    """Жалоба уходит владельцу бота — только он видит автора, чтобы забанить за травлю."""
    r = await _msg(cb)
    if not r:
        return
    await db.q_run("INSERT OR IGNORE INTO anon_blocks VALUES(?,?,?)", cb.from_user.id, r["from_uid"], int(time.time()))
    await cb.answer("⚠️ жалоба отправлена, автор заблокирован", show_alert=True)
    if config.OWNER_ID:
        try:
            await bot.send_message(config.OWNER_ID, f"⚠️ <b>жалоба на анонимку</b> #{r['id']}\n"
                                                    f"автор: <code>{r['from_uid']}</code> → получатель <code>{r['to_uid']}</code>\n"
                                                    f"забанить автора: <code>/ban {r['from_uid']}</code>")
            await bot.copy_message(config.OWNER_ID, cb.message.chat.id, cb.message.message_id)
        except Exception:
            pass


async def deep_link(m: Message, bot: Bot, arg: str) -> bool:
    if arg.startswith("a_"):
        return await start_writing(m, bot, arg[2:])
    return False
