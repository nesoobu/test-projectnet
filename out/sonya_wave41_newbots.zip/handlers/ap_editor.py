"""Редактор поста: создание, кнопки, реакции, опции, ИИ, публикация."""
import asyncio
import re
import time
from html import escape
from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.types import Message, CallbackQuery

import llm
import ui
from autopost import store, publisher, timeparse, engine
from handlers.ap_common import AP, show, kb_rows, cancel_kb

router = Router()
_albums: dict[str, int] = {}
_alock = asyncio.Lock()

DEL_STEPS = [0, 1, 6, 24, 48, 168]
REPEATS = [0, 24, 48, 168]
REPEAT_NAMES = {0: "нет", 24: "каждый день", 48: "раз в 2 дня", 168: "раз в неделю"}
MEDIA_NAMES = {"photo": "фото", "video": "видео", "animation": "гиф", "document": "файл", "audio": "аудио"}


def extract_media(m: Message) -> dict | None:
    if m.photo:
        return {"type": "photo", "src": m.photo[-1].file_id}
    if m.animation:
        return {"type": "animation", "src": m.animation.file_id}
    if m.video:
        return {"type": "video", "src": m.video.file_id}
    if m.audio:
        return {"type": "audio", "src": m.audio.file_id}
    if m.document:
        return {"type": "document", "src": m.document.file_id}
    return None


def _hours(h: int) -> str:
    if not h:
        return "нет"
    return f"{h // 24} д" if h % 24 == 0 and h >= 24 else f"{h} ч"


# ================= карточка =================
async def card(pid: int, uid: int):
    p = await store.post(pid, uid)
    o = p["opts"]
    chs = {c["chat_id"]: c for c in await store.channels(uid)}
    targets = [chs[c]["title"] for c in p["channels"] if c in chs]
    media = p["media"]
    plain = re.sub(r"<[^>]+>", "", p["text"] or "")
    kind = (MEDIA_NAMES[media[0]["type"]] + (f" ×{len(media)}" if len(media) > 1 else "")) if media else "текст"
    flags = []
    if o.get("silent"):
        flags.append("🔕 без звука")
    if o.get("pin"):
        flags.append("📌 закреп")
    if o.get("protect"):
        flags.append("🔒 защита")
    if o.get("del_after"):
        flags.append(f"🗑 удалить через {_hours(o['del_after'])}")
    if o.get("repeat"):
        flags.append(f"🔁 {REPEAT_NAMES[o['repeat']]}")
    nbtn = sum(len(r) for r in p["buttons"])
    lines = [
        f"<b>✍️ пост #{pid}</b> · {kind} · {len(plain)} симв.",
        ui.LINE,
        f"📢 куда: <b>{escape(', '.join(targets)) if targets else '— выбери канал'}</b>",
        f"🔗 кнопки: <b>{nbtn or '—'}</b>   ❤️ реакции: <b>{' '.join(p['reactions']) or '—'}</b>",
    ]
    if flags:
        lines.append(" · ".join(flags))
    warn = []
    if len(media) > 1 and (p["buttons"] or p["reactions"]):
        warn.append("к альбому кнопки придут отдельным сообщением")
    if media and len(plain) > 1024:
        warn.append("текст длиннее 1024 — уйдёт отдельно от медиа")
    if warn:
        lines.append("<i>⚠️ " + "; ".join(warn) + "</i>")
    edit_mode = p["status"] == "queued"
    if edit_mode:
        lines.append("\n<i>пост в очереди — изменения применятся к публикации</i>")

    def t(flag, label):
        return ("✓ " if o.get(flag) else "") + label

    rows = [
        [("📢 Каналы", f"ed:chs:{pid}")],
        [("✏️ Текст", f"ed:text:{pid}"), ("🖼 Медиа", f"ed:media:{pid}")],
        [("🔗 Кнопки", f"ed:btn:{pid}"), ("❤️ Реакции", f"ed:react:{pid}")],
        [(t("silent", "🔕 Тихо"), f"ed:o:silent:{pid}"), (t("pin", "📌 Закреп"), f"ed:o:pin:{pid}"),
         (t("protect", "🔒 Защита"), f"ed:o:protect:{pid}")],
        [(f"🗑 Удалить: {_hours(o.get('del_after', 0))}", f"ed:del:{pid}"),
         (f"🔁 Повтор: {REPEAT_NAMES[o.get('repeat', 0)]}", f"ed:rep:{pid}")],
        [("✨ ИИ", f"ed:ai:{pid}"), ("👁 Превью", f"ed:prev:{pid}")],
    ]
    if edit_mode:
        rows.append([("💾 Готово", "ap:queue")])
    else:
        rows.append([("🚀 Сейчас", f"ed:now:{pid}"), ("📥 В слот", f"ed:slot:{pid}"),
                     ("⏰ Время", f"ed:time:{pid}")])
        rows.append([("🗑 Удалить черновик", f"ed:drop:{pid}")])
    return "\n".join(lines), kb_rows(*rows)


async def _pid(cb: CallbackQuery) -> int | None:
    parts = cb.data.split(":")
    pid = int(parts[-1]) if parts[-1].isdigit() else int(parts[2])
    if not await store.post(pid, cb.from_user.id):
        await cb.answer("пост не найден", show_alert=True)
        return None
    return pid


# ================= создание =================
@router.callback_query(F.data == "ap:new")
@router.callback_query(F.data.startswith("ap:new:"))
async def cb_new(cb: CallbackQuery, state: FSMContext):
    if not await store.channels(cb.from_user.id):
        return await cb.answer("сначала подключи канал: ➕ Канал", show_alert=True)
    target = None
    if cb.data.startswith("ap:new:"):
        cid = int(cb.data.split(":")[2])
        if await store.channel(cid, cb.from_user.id):
            target = cid
    await state.set_state(AP.post_wait)
    await state.update_data(target=target)
    await show(cb, "<b>✍️ новый пост</b>\n"
                   f"{ui.LINE}\n"
                   "пришли мне пост как есть: текст, фото, видео, гиф, файл или альбом.\n"
                   "можно переслать из другого канала — форматирование сохраню",
               cancel_kb())


@router.message(AP.post_wait)
async def st_new_post(m: Message, state: FSMContext):
    uid = m.from_user.id
    media = extract_media(m)
    text = m.html_text if (m.text or m.caption) else ""
    if not media and not text:
        return await m.answer("это я опубликовать не смогу. текст или медиа, пожалуйста")
    chs = await store.channels(uid)
    target = (await state.get_data()).get("target")
    default_ch = [target] if target else ([chs[0]["chat_id"]] if len(chs) == 1 else [])

    if m.media_group_id:
        gid = m.media_group_id
        async with _alock:
            if gid in _albums:
                pid = _albums[gid]
                p = await store.post(pid)
                p["media"].append(media)
                await store.set_post(pid, media=p["media"][:10],
                                     **({"text": text} if text and not p["text"] else {}))
                return
            pid = await store.new_post(uid, text, [media], default_ch)
            _albums[gid] = pid
        await asyncio.sleep(1.5)  # ждём остальные части альбома
        _albums.pop(gid, None)
        p = await store.post(pid)
        if not publisher.album_ok(p["media"]):
            await m.answer("⚠️ телеграм не даёт смешивать такие файлы в одном альбоме — оставила первый")
            await store.set_post(pid, media=p["media"][:1])
    else:
        pid = await store.new_post(uid, text, [media] if media else [], default_ch)

    await state.clear()
    await show(m, *await card(pid, uid))


@router.callback_query(F.data.startswith("ed:open:"))
async def cb_open(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    pid = int(cb.data.split(":")[2])
    if not await store.post(pid, cb.from_user.id):
        return await cb.answer("пост не найден", show_alert=True)
    await show(cb, *await card(pid, cb.from_user.id))


@router.callback_query(F.data.startswith("ed:card:"))
async def cb_card(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    if pid := await _pid(cb):
        await show(cb, *await card(pid, cb.from_user.id))


# ================= каналы =================
@router.callback_query(F.data.startswith("ed:chs:") | F.data.startswith("ed:cht:"))
async def cb_chs(cb: CallbackQuery):
    pid = await _pid(cb)
    if not pid:
        return
    p = await store.post(pid)
    if cb.data.startswith("ed:cht:"):
        cid = int(cb.data.split(":")[2])
        sel = p["channels"]
        sel = [c for c in sel if c != cid] if cid in sel else sel + [cid]
        await store.set_post(pid, channels=sel)
        p["channels"] = sel
    rows = [[(("✅ " if c["chat_id"] in p["channels"] else "◻️ ") + c["title"][:30],
              f"ed:cht:{c['chat_id']}:{pid}")] for c in await store.channels(cb.from_user.id)]
    await show(cb, "<b>📢 куда публикуем?</b>\nможно несколько", kb_rows(*rows, [("✓ Готово", f"ed:card:{pid}")]))


# ================= текст / медиа / кнопки =================
@router.callback_query(F.data.startswith("ed:text:"))
async def cb_text(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        await state.set_state(AP.ed_text)
        await state.update_data(pid=pid)
        await show(cb, "<b>✏️ новый текст</b>\nпришли текст целиком, форматирование сохраню.\n«-» — убрать текст",
                   cancel_kb(f"ed:card:{pid}"))


@router.message(AP.ed_text, F.text)
async def st_text(m: Message, state: FSMContext):
    pid = (await state.get_data())["pid"]
    p = await store.post(pid, m.from_user.id)
    new = "" if m.text.strip() == "-" else m.html_text
    if not new and not p["media"]:
        return await m.answer("без текста и без медиа пост будет пустой 🙃")
    await store.set_post(pid, text=new)
    await state.clear()
    await show(m, *await card(pid, m.from_user.id))


def _media_kb(pid):
    return kb_rows([("🗑 Убрать всё медиа", f"ed:mclr:{pid}")], [("✓ Готово", f"ed:card:{pid}")])


@router.callback_query(F.data.startswith("ed:media:"))
async def cb_media(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        p = await store.post(pid)
        await state.set_state(AP.ed_media)
        await state.update_data(pid=pid)
        await show(cb, f"<b>🖼 медиа</b> · сейчас: {len(p['media'])}/10\n"
                       "присылай фото/видео/файлы — добавлю к посту", _media_kb(pid))


@router.message(AP.ed_media)
async def st_media(m: Message, state: FSMContext):
    pid = (await state.get_data())["pid"]
    med = extract_media(m)
    if not med:
        return await m.answer("жду фото, видео, гиф или файл", reply_markup=_media_kb(pid))
    async with _alock:
        p = await store.post(pid, m.from_user.id)
        new = p["media"] + [med]
        if len(new) > 10:
            return await m.answer("максимум 10 в альбоме", reply_markup=_media_kb(pid))
        if not publisher.album_ok(new):
            return await m.answer("такое в один альбом не смешать (фото+видео ок, аудио и файлы — отдельно)",
                                  reply_markup=_media_kb(pid))
        await store.set_post(pid, media=new)
    if not m.media_group_id or m.media_group_id not in _albums:
        if m.media_group_id:
            _albums[m.media_group_id] = pid
            await asyncio.sleep(1.5)
            _albums.pop(m.media_group_id, None)
            p = await store.post(pid)
            await m.answer(f"добавлено, всего {len(p['media'])}/10", reply_markup=_media_kb(pid))
        else:
            await m.answer(f"добавлено, всего {len(new)}/10", reply_markup=_media_kb(pid))


@router.callback_query(F.data.startswith("ed:mclr:"))
async def cb_mclr(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        p = await store.post(pid)
        if not p["text"]:
            return await cb.answer("сначала добавь текст, иначе пост пустой", show_alert=True)
        await store.set_post(pid, media=[])
        await state.clear()
        await show(cb, *await card(pid, cb.from_user.id))


BTN_HINT = ("<b>🔗 кнопки-ссылки</b>\n"
            "каждая строка — ряд кнопок, в ряду через <code>|</code>:\n\n"
            "<code>Наш чат - https://t.me/chat\n"
            "Сайт - https://site.ru | Магазин - https://shop.ru</code>")


@router.callback_query(F.data.startswith("ed:btn:"))
async def cb_btn(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        await state.set_state(AP.ed_buttons)
        await state.update_data(pid=pid)
        await show(cb, BTN_HINT, kb_rows([("🗑 Убрать кнопки", f"ed:bclr:{pid}")],
                                         [("✖️ Отмена", f"ed:card:{pid}")]))


@router.message(AP.ed_buttons, F.text)
async def st_btn(m: Message, state: FSMContext):
    pid = (await state.get_data())["pid"]
    rows = publisher.parse_buttons(m.text)
    if not rows:
        return await m.answer("не поняла формат 🤔\n\n" + BTN_HINT)
    await store.set_post(pid, buttons=rows)
    await state.clear()
    await show(m, *await card(pid, m.from_user.id))


@router.callback_query(F.data.startswith("ed:bclr:"))
async def cb_bclr(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        await store.set_post(pid, buttons=[])
        await state.clear()
        await show(cb, *await card(pid, cb.from_user.id))


# ================= реакции / опции =================
@router.callback_query(F.data.startswith("ed:react:"))
async def cb_react(cb: CallbackQuery):
    if pid := await _pid(cb):
        p = await store.post(pid)
        sets = publisher.REACTION_SETS
        cur = sets.index(p["reactions"]) if p["reactions"] in sets else 0
        await store.set_post(pid, reactions=sets[(cur + 1) % len(sets)])
        await show(cb, *await card(pid, cb.from_user.id))


@router.callback_query(F.data.startswith("ed:o:"))
async def cb_opt(cb: CallbackQuery):
    if pid := await _pid(cb):
        flag = cb.data.split(":")[2]
        if flag not in ("silent", "pin", "protect"):
            return await cb.answer()
        p = await store.post(pid)
        p["opts"][flag] = not p["opts"].get(flag)
        await store.set_post(pid, opts=p["opts"])
        await show(cb, *await card(pid, cb.from_user.id))


async def _cycle(cb: CallbackQuery, key: str, steps: list[int]):
    if pid := await _pid(cb):
        p = await store.post(pid)
        cur = p["opts"].get(key, 0)
        p["opts"][key] = steps[(steps.index(cur) + 1) % len(steps)] if cur in steps else steps[0]
        await store.set_post(pid, opts=p["opts"])
        await show(cb, *await card(pid, cb.from_user.id))


@router.callback_query(F.data.startswith("ed:del:"))
async def cb_del(cb: CallbackQuery):
    await _cycle(cb, "del_after", DEL_STEPS)


@router.callback_query(F.data.startswith("ed:rep:"))
async def cb_rep(cb: CallbackQuery):
    await _cycle(cb, "repeat", REPEATS)


# ================= ИИ =================
AI_ACTIONS = {
    "fix": ("✨ Улучшить", "Исправь ошибки и сделай текст поста читабельнее, сохрани смысл, тон и длину. "
                         "Эмодзи оставь как есть. Только текст."),
    "short": ("✂️ Короче", "Сократи текст поста вдвое, сохрани главное. Только текст."),
    "sonya": ("😏 Как Соня", "Перепиши пост живо, дерзко и с иронией, как пишет девушка-альтушка Соня. "
                            "Сохрани смысл и факты. Только текст."),
    "tags": ("#️⃣ Хэштеги", None),
    "en": ("🌍 На английский", "Translate this Telegram post into natural English. Only the translation."),
    "ru": ("🇷🇺 На русский", "Переведи пост на естественный русский. Только перевод."),
}


@router.callback_query(F.data.startswith("ed:ai:"))
async def cb_ai(cb: CallbackQuery):
    if pid := await _pid(cb):
        p = await store.post(pid)
        btns = [(v[0], f"ed:aix:{k}:{pid}") for k, v in AI_ACTIONS.items()]
        rows = [btns[i:i + 2] for i in range(0, len(btns), 2)]
        if p["opts"].get("prev_text") is not None:
            rows.append([("↩️ Вернуть как было", f"ed:aiundo:{pid}")])
        await show(cb, "<b>✨ ИИ-помощник</b>\nчто сделать с текстом?\n"
                       "<i>форматирование (жирный, ссылки) после ИИ сбросится</i>",
                   kb_rows(*rows, [("‹ Назад", f"ed:card:{pid}")]))


@router.callback_query(F.data.startswith("ed:aix:"))
async def cb_aix(cb: CallbackQuery):
    pid = await _pid(cb)
    if not pid:
        return
    act = cb.data.split(":")[2]
    if act not in AI_ACTIONS:
        return await cb.answer()
    p = await store.post(pid)
    plain = re.sub(r"<[^>]+>", "", p["text"] or "")
    import html as _h
    plain = _h.unescape(plain).strip()
    if not plain:
        return await cb.answer("в посте нет текста", show_alert=True)
    await cb.answer("думаю…")
    try:
        if act == "tags":
            out = await llm.ask([{"role": "system", "content":
                                  "Придумай 3–5 коротких релевантных хэштегов на русском для поста. "
                                  "Только хэштеги через пробел."},
                                 {"role": "user", "content": plain[:2000]}], max_tokens=80, temperature=0.5)
            tags = " ".join(w for w in out.split() if w.startswith("#"))[:200]
            new = (p["text"] + "\n\n" + escape(tags)) if tags else p["text"]
        else:
            out = await llm.ask([{"role": "system", "content": AI_ACTIONS[act][1]},
                                 {"role": "user", "content": plain[:3500]}], max_tokens=1200, temperature=0.7)
            new = escape(out.strip()) if out.strip() else p["text"]
    except Exception as e:
        return await cb.message.answer(f"ии сейчас не отвечает: <code>{escape(str(e)[:150])}</code>")
    p["opts"]["prev_text"] = p["text"]
    await store.set_post(pid, text=new, opts=p["opts"])
    await cb_preview_send(cb, pid)


@router.callback_query(F.data.startswith("ed:aiundo:"))
async def cb_aiundo(cb: CallbackQuery):
    if pid := await _pid(cb):
        p = await store.post(pid)
        prev = p["opts"].pop("prev_text", None)
        if prev is not None:
            await store.set_post(pid, text=prev, opts=p["opts"])
        await cb_preview_send(cb, pid)


# ================= превью =================
async def cb_preview_send(cb: CallbackQuery, pid: int):
    bot = cb.bot
    p = await store.post(pid)
    ch = await store.channel(p["channels"][0]) if p["channels"] else None
    try:
        await publisher.send(bot, p, cb.from_user.id, ch, preview=True)
    except Exception as e:
        await cb.message.answer(f"⚠️ превью не собралось: <code>{escape(str(e)[:200])}</code>")
    await show(cb.message, *await card(pid, cb.from_user.id))
    try:
        await cb.answer()
    except Exception:
        pass


@router.callback_query(F.data.startswith("ed:prev:"))
async def cb_prev(cb: CallbackQuery):
    if pid := await _pid(cb):
        await cb_preview_send(cb, pid)


# ================= публикация =================
async def _ready(cb: CallbackQuery, pid: int) -> dict | None:
    p = await store.post(pid)
    own = {c["chat_id"] for c in await store.channels(cb.from_user.id)}
    p["channels"] = [c for c in p["channels"] if c in own]
    if not p["channels"]:
        await cb.answer("выбери хотя бы один канал 📢", show_alert=True)
        return None
    return p


async def _done(target, pid: int, lines: list[str]):
    await store.set_post(pid, status="queued")
    # если пост пришёл из модерации — закрываем заявку
    from autopost.store import _run
    await _run("UPDATE ap_inbox SET status='approved' WHERE post_id=? AND status='pending'", pid)
    await show(target, "<b>✅ готово</b>\n" + ui.LINE + "\n" + "\n".join(lines),
               kb_rows([("📅 Очередь", "ap:queue"), ("✍️ Ещё пост", "ap:new")], [("‹ Панель", "ap:home")]))


@router.callback_query(F.data.startswith("ed:now:"))
async def cb_now(cb: CallbackQuery, bot: Bot):
    pid = await _pid(cb)
    p = pid and await _ready(cb, pid)
    if not p:
        return
    rep = p["opts"].get("repeat", 0)
    sids = [await store.schedule(pid, c, time.time() - 1, rep) for c in p["channels"]]
    await engine.publish_due(bot)
    lines = []
    for sid in sids:
        s = await store.sched(sid)
        ch = await store.channel(s["chat_id"])
        if s["status"] in ("sent", "deleted"):
            lines.append(f"🚀 {escape(ch['title'])} — опубликовано")
        elif s["status"] == "queued":
            lines.append(f"⏸ {escape(ch['title'])} — канал на паузе, жду")
        else:
            lines.append(f"⚠️ {escape(ch['title'])} — <code>{escape((s['err'] or '')[:120])}</code>")
    await _done(cb, pid, lines)


@router.callback_query(F.data.startswith("ed:slot:"))
async def cb_slot(cb: CallbackQuery):
    import json
    pid = await _pid(cb)
    p = pid and await _ready(cb, pid)
    if not p:
        return
    lines = []
    for cid in p["channels"]:
        ch = await store.channel(cid)
        busy = await store.busy_times(cid, int(time.time()))
        ts = timeparse.next_slot(json.loads(ch["slots"] or "[]"), busy, ch["jitter"])
        await store.schedule(pid, cid, ts, p["opts"].get("repeat", 0))
        lines.append(f"📥 {escape(ch['title'])} — {timeparse.fmt(ts)}")
    await _done(cb, pid, lines)


@router.callback_query(F.data.startswith("ed:time:"))
async def cb_time(cb: CallbackQuery, state: FSMContext):
    pid = await _pid(cb)
    if not pid or not await _ready(cb, pid):
        return
    from handlers.ap_panel import TIME_HINT
    await state.set_state(AP.ed_time)
    await state.update_data(pid=pid)
    await show(cb, "<b>⏰ когда публикуем?</b>\n" + TIME_HINT, cancel_kb(f"ed:card:{pid}"))


@router.message(AP.ed_time, F.text)
async def st_time(m: Message, state: FSMContext):
    from handlers.ap_panel import TIME_HINT
    ts = timeparse.parse(m.text)
    if not ts:
        return await m.answer("не поняла время 🤔\n" + TIME_HINT)
    pid = (await state.get_data())["pid"]
    p = await store.post(pid, m.from_user.id)
    own = {c["chat_id"]: c for c in await store.channels(m.from_user.id)}
    lines = []
    for cid in p["channels"]:
        if cid in own:
            await store.schedule(pid, cid, ts, p["opts"].get("repeat", 0))
            lines.append(f"⏰ {escape(own[cid]['title'])} — {timeparse.fmt(ts)}")
    await state.clear()
    await _done(m, pid, lines)


@router.callback_query(F.data.startswith("ed:drop:"))
async def cb_drop(cb: CallbackQuery, state: FSMContext):
    if pid := await _pid(cb):
        await store.set_post(pid, status="dropped")
        from autopost.store import _run
        await _run("UPDATE ap_inbox SET status='skipped' WHERE post_id=? AND status='pending'", pid)
        await state.clear()
        from handlers.ap_panel import home_view
        await cb.answer("черновик удалён")
        await show(cb, *await home_view(cb.from_user.id))
