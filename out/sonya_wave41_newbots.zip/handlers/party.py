"""Групповые игры: 🕵️ Шпион и 🔪 Мафия. Набор кнопкой в чате, роли — в личку."""
import asyncio
import logging
import random
import time
from collections import Counter
from html import escape

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery
from aiogram.utils.keyboard import InlineKeyboardBuilder

import config
import db
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("party")

GAMES: dict[int, "Game"] = {}
LOBBY_TTL = 300
SPY_ROUND, SPY_VOTE = 360, 60
MF_NIGHT, MF_DAY, MF_VOTE = 45, 90, 45
MAX_DAYS = 15
MIN = {"spy": 3, "mafia": 4}
MAX_PLAYERS = 12
SPY_CITY_PRIZE, SPY_SPY_PRIZE, MAFIA_PRIZE = 30, 60, 50
TITLE = {"spy": "🕵️ Шпион", "mafia": "🔪 Мафия"}

LOCATIONS = [
    "🏖 Пляж", "✈️ Самолёт", "🏥 Больница", "🏫 Школа", "🎬 Кинотеатр", "🍕 Пиццерия", "🚂 Поезд",
    "🏦 Банк", "🚀 Космическая станция", "🏴‍☠️ Пиратский корабль", "🎪 Цирк", "🏟 Стадион", "🛒 Супермаркет",
    "🏰 Средневековый замок", "🚓 Полицейский участок", "🎰 Казино", "🧖 Баня", "🛳 Круизный лайнер",
    "🏔 Горнолыжный курорт", "🎓 Университет", "💈 Барбершоп", "🚇 Метро", "🏕 Лагерь в лесу",
    "🎭 Театр", "🪖 Военная база", "🛸 НЛО", "🏛 Музей", "🌋 Вулкан-экспедиция", "🎤 Караоке",
    "🏋️ Спортзал", "⛪ Свадьба", "🏝 Необитаемый остров", "🚒 Пожарная часть", "🧪 Лаборатория",
]
ROLE_INFO = {
    "mafia": ("🔪 мафия", "ночью вместе выбираете жертву. днём — притворяйся мирным 😇"),
    "doctor": ("💉 доктор", "ночью лечишь одного — если мафия придёт к нему, он выживет. "
                          "одного и того же два раза подряд нельзя"),
    "sheriff": ("🔎 комиссар", "ночью проверяешь одного — узнаешь, мафия он или нет"),
    "civil": ("🙂 мирный", "ночью спишь. днём ищи мафию и голосуй с умом"),
}


class Game:
    def __init__(self, kind: str, chat_id: int, owner: int, chat_title: str):
        self.kind, self.chat_id, self.owner, self.chat_title = kind, chat_id, owner, chat_title
        self.players: dict[int, str] = {}
        self.started = self.finished = False
        self.msg_id: int | None = None
        self.task: asyncio.Task | None = None
        self.event = asyncio.Event()
        self.phase = "lobby"
        # голосование
        self.ready: set[int] = set()
        self.ready_msg: int | None = None
        self.voters: set[int] = set()
        self.cands: list[int] = []
        self.votes: dict[int, int] = {}
        self.vote_skip = False
        self.vote_msg: int | None = None
        # шпион
        self.location, self.spy, self.guessed = "", 0, False
        # мафия
        self.roles: dict[int, str] = {}
        self.alive: list[int] = []
        self.night: dict[str, dict[int, int]] = {}
        self.last_heal = 0
        self.day = 0

    def link(self, uid: int) -> str:
        return f'<a href="tg://user?id={uid}">{escape(self.players.get(uid, "игрок"))}</a>'

    def voters_now(self) -> list[int]:
        return list(self.players) if self.kind == "spy" else list(self.alive)

    def name(self, uid: int) -> str:
        return escape(self.players.get(uid, "игрок"))


# ================= перезапуск бота =================
async def _live(g: Game):
    await db.q_run("INSERT OR REPLACE INTO party_live VALUES(?,?,?)", g.chat_id, g.kind, int(time.time()))


async def _forget(g: Game):
    """Игра закончилась — убрать из памяти и из базы."""
    if GAMES.get(g.chat_id) is g:
        GAMES.pop(g.chat_id, None)
        await db.q_run("DELETE FROM party_live WHERE chat_id=?", g.chat_id)


async def recover(bot: Bot):
    """После перезапуска: честно сказать, что игра слетела. Призов не было — возвращать нечего."""
    rows = await db.q_all("SELECT chat_id, kind FROM party_live")
    await db.q_run("DELETE FROM party_live")
    for r in rows:
        if r["kind"] not in TITLE:
            continue
        try:
            await bot.send_message(r["chat_id"], f"😵 я перезагружалась — игра «{TITLE[r['kind']]}» слетела. "
                                                 f"простите! начать заново: /{r['kind']}",
                                   reply_markup=kb_rows([("🔁 Начать заново", f"g:{r['kind']}")]))
        except Exception as e:
            log.info("party recover %s: %s", r["chat_id"], e)


async def _is_admin(bot: Bot, chat_id: int, uid: int) -> bool:
    if uid == config.OWNER_ID:
        return True
    try:
        m = await bot.get_chat_member(chat_id, uid)
        return m.status in ("creator", "administrator")
    except Exception:
        return False


async def _dm(bot: Bot, uid: int, text: str, kb=None) -> bool:
    try:
        await bot.send_message(uid, text, reply_markup=kb)
        return True
    except (TelegramForbiddenError, TelegramBadRequest):
        return False


async def _say(bot: Bot, g: Game, text: str, kb=None):
    try:
        return await bot.send_message(g.chat_id, text, reply_markup=kb)
    except Exception as e:
        log.warning("party say %s: %s", g.chat_id, e)


async def _wait(g: Game, sec: float):
    """Ждёт sec секунд или пока фазу не завершат досрочно (g.event)."""
    try:
        await asyncio.wait_for(g.event.wait(), sec)
    except asyncio.TimeoutError:
        pass
    g.event.clear()


# ================= лобби =================
def _lobby_text(g: Game) -> str:
    lst = "\n".join(f"{i}. {g.name(u)}" for i, u in enumerate(g.players, 1)) or "<i>пока никого</i>"
    rules = ("все, кроме одного, знают локацию. шпион — нет. задавайте вопросы и вычислите его"
             if g.kind == "spy" else
             "мафия убивает ночью, город казнит днём. доктор лечит, комиссар проверяет")
    return (f"<b>{TITLE[g.kind]}</b> — набор игроков\n{ui.LINE}\n<i>{rules}</i>\n\n{lst}\n\n"
            f"нужно от {MIN[g.kind]} до {MAX_PLAYERS} · роли придут в личку\n"
            f"<i>не писал мне раньше? нажми «🤖 Открыть личку» → Start</i>")


async def _lobby_kb(bot: Bot):
    me = await bot.me()
    kb = InlineKeyboardBuilder()
    kb.button(text="✋ Играю", callback_data="pt:j")
    kb.button(text="🚪 Выйти", callback_data="pt:l")
    kb.button(text="▶️ Начать", callback_data="pt:go")
    kb.button(text="✖️ Отмена", callback_data="pt:x")
    kb.button(text="🤖 Открыть личку", url=f"https://t.me/{me.username}?start=game")
    kb.adjust(2, 2, 1)
    return kb.as_markup()


async def _refresh_lobby(bot: Bot, g: Game):
    try:
        await bot.edit_message_text(_lobby_text(g), chat_id=g.chat_id, message_id=g.msg_id,
                                    reply_markup=await _lobby_kb(bot))
    except TelegramBadRequest:
        pass


async def _lobby_timeout(bot: Bot, g: Game):
    await asyncio.sleep(LOBBY_TTL)
    if not g.started and GAMES.get(g.chat_id) is g:
        await _forget(g)
        try:
            await bot.edit_message_text(f"<b>{TITLE[g.kind]}</b>\n⌛ набор закрыт — не собрались",
                                        chat_id=g.chat_id, message_id=g.msg_id)
        except TelegramBadRequest:
            pass


async def open_lobby(m: Message, bot: Bot, kind: str, user):
    if m.chat.type == "private":
        return await m.answer(f"{TITLE[kind]} — игра для компании. добавь меня в группу и напиши там "
                              f"/{'spy' if kind == 'spy' else 'mafia'} 🎲")
    if m.chat.id in GAMES:
        return await m.answer("тут уже идёт игра. остановить: /stopgame")
    g = Game(kind, m.chat.id, user.id, m.chat.title or "")
    GAMES[m.chat.id] = g
    await _live(g)
    g.players[user.id] = user.first_name or "игрок"
    sent = await m.answer(_lobby_text(g), reply_markup=await _lobby_kb(bot))
    g.msg_id = sent.message_id
    g.task = asyncio.create_task(_lobby_timeout(bot, g))
    if not await _dm(bot, user.id, f"✅ ты в игре «{TITLE[kind]}» в чате <b>{escape(g.chat_title)}</b>. "
                                   "роль пришлю сюда"):
        g.players.pop(user.id, None)
        await _refresh_lobby(bot, g)


@router.message(Command("spy", "шпион"))
async def cmd_spy(m: Message, bot: Bot):
    await open_lobby(m, bot, "spy", m.from_user)


@router.message(Command("mafia", "мафия"))
async def cmd_mafia(m: Message, bot: Bot):
    await open_lobby(m, bot, "mafia", m.from_user)


@router.callback_query(F.data.in_({"g:spy", "g:mafia"}))
async def cb_open(cb: CallbackQuery, bot: Bot):
    kind = cb.data[2:]
    if cb.message.chat.type == "private":
        return await cb.answer(f"{TITLE[kind]} — игра для группы: добавь меня в чат и напиши там "
                               f"/{kind}", show_alert=True)
    await cb.answer()
    await open_lobby(cb.message, bot, kind, cb.from_user)


@router.callback_query(F.data.in_({"pt:j", "pt:l", "pt:go", "pt:x"}))
async def cb_lobby(cb: CallbackQuery, bot: Bot):
    g = GAMES.get(cb.message.chat.id)
    if not g or g.msg_id != cb.message.message_id:
        return await cb.answer("эта игра уже закончилась")
    if g.started:
        return await cb.answer("игра уже идёт 🎲")
    uid, act = cb.from_user.id, cb.data[3:]
    if act == "j":
        if uid in g.players:
            return await cb.answer("ты уже в игре")
        if len(g.players) >= MAX_PLAYERS:
            return await cb.answer("мест нет 😔", show_alert=True)
        ok = await _dm(bot, uid, f"✅ ты в игре «{TITLE[g.kind]}» в чате <b>{escape(g.chat_title)}</b>. "
                                 "роль пришлю сюда")
        if not ok:
            return await cb.answer("не могу написать тебе в личку 🙈 нажми «🤖 Открыть личку» → Start, "
                                   "потом снова «Играю»", show_alert=True)
        g.players[uid] = cb.from_user.first_name or "игрок"
        await cb.answer("ты в игре!")
        return await _refresh_lobby(bot, g)
    if act == "l":
        if uid not in g.players:
            return await cb.answer("тебя и так нет в списке")
        g.players.pop(uid)
        await cb.answer("вышел")
        return await _refresh_lobby(bot, g)
    if uid != g.owner and not await _is_admin(bot, g.chat_id, uid):
        return await cb.answer("начать/отменить может тот, кто открыл набор, или админ", show_alert=True)
    if act == "x":
        await _forget(g)
        if g.task:
            g.task.cancel()
        await cb.answer()
        try:
            await cb.message.edit_text(f"<b>{TITLE[g.kind]}</b>\n✖️ набор отменён")
        except TelegramBadRequest:
            pass
        return
    if len(g.players) < MIN[g.kind]:
        return await cb.answer(f"нужно минимум {MIN[g.kind]} игрока, сейчас {len(g.players)}", show_alert=True)
    g.started = True
    if g.task:
        g.task.cancel()
    await cb.answer("поехали!")
    try:
        await cb.message.edit_reply_markup(reply_markup=None)
    except TelegramBadRequest:
        pass
    g.task = asyncio.create_task(_run(bot, g))


async def _run(bot: Bot, g: Game):
    try:
        await (run_spy(bot, g) if g.kind == "spy" else run_mafia(bot, g))
    except asyncio.CancelledError:
        raise
    except Exception:
        log.exception("party game crashed")
        await finish(bot, g, "😵 игра сломалась, извините. попробуйте ещё раз", [], 0)


async def finish(bot: Bot, g: Game, text: str, winners: list[int], prize: int):
    if g.finished:
        return
    g.finished = True
    g.phase = "end"
    g.event.set()
    await _forget(g)
    if winners and prize:
        for w in winners:
            await db.add_coins(w, prize, win=True)
        text += f"\n\n🏆 +{prize} 🪙 победителям: " + ", ".join(g.link(w) for w in winners)
    await _say(bot, g, text, kb_rows([("🔁 Ещё раз", f"g:{g.kind}")]))


@router.message(Command("stopgame", "стоп"))
async def cmd_stop(m: Message, bot: Bot):
    g = GAMES.get(m.chat.id)
    if not g:
        return await m.answer("сейчас никакой игры нет")
    if m.from_user.id != g.owner and not await _is_admin(bot, m.chat.id, m.from_user.id):
        return await m.answer("остановить может тот, кто начал игру, или админ")
    g.finished = True
    await _forget(g)
    if g.task and g.task is not asyncio.current_task():
        g.task.cancel()
    extra = ""
    if g.kind == "spy" and g.spy:
        extra = f"\nшпионом был {g.link(g.spy)}, локация — {g.location}"
    await m.answer(f"⏹ игра остановлена{extra}")


# ================= голосование (общее) =================
def _ready_kb(g: Game):
    return kb_rows([(f"🗳 Голосовать сейчас ({len(g.ready)}/{len(g.voters_now())})", "pt:rd")])


@router.callback_query(F.data == "pt:rd")
async def cb_ready(cb: CallbackQuery):
    g = GAMES.get(cb.message.chat.id)
    if not g or g.phase not in ("talk",):
        return await cb.answer("сейчас не время")
    uid = cb.from_user.id
    if uid not in g.voters_now():
        return await cb.answer("ты не играешь (или выбыл) 👻")
    g.ready.add(uid)
    need = len(g.voters_now()) // 2 + 1
    await cb.answer(f"ок! нужно {need}, уже {len(g.ready)}")
    if len(g.ready) >= need:
        g.event.set()
    try:
        await cb.message.edit_reply_markup(reply_markup=_ready_kb(g))
    except TelegramBadRequest:
        pass


def _vote_kb(g: Game):
    tally = Counter(g.votes.values())
    rows = [[(f"{g.players[c]} · {tally.get(c, 0)}", f"pt:v:{c}")] for c in g.cands]
    if g.vote_skip:
        rows.append([(f"🤷 Никого · {tally.get(0, 0)}", "pt:v:0")])
    return kb_rows(*rows)


async def vote(bot: Bot, g: Game, title: str, sec: int, skip: bool) -> int | None:
    g.voters = set(g.voters_now())
    g.cands = list(g.voters)
    g.votes, g.vote_skip = {}, skip
    g.phase = "vote"
    g.event.clear()
    sent = await _say(bot, g, f"{title}\n<i>{sec} сек · голосуют {len(g.voters)}, себя выбрать нельзя</i>",
                      _vote_kb(g))
    g.vote_msg = sent.message_id if sent else None
    await _wait(g, sec)
    g.phase = "after_vote"
    if g.vote_msg:
        try:
            await bot.edit_message_reply_markup(chat_id=g.chat_id, message_id=g.vote_msg, reply_markup=None)
        except TelegramBadRequest:
            pass
    if g.finished:
        return None
    tally = Counter(g.votes.values()).most_common()
    if not tally or (len(tally) > 1 and tally[0][1] == tally[1][1]) or tally[0][0] == 0:
        return None
    return tally[0][0]


@router.callback_query(F.data.startswith("pt:v:"))
async def cb_vote(cb: CallbackQuery):
    g = GAMES.get(cb.message.chat.id)
    if not g or g.phase != "vote" or g.vote_msg != cb.message.message_id:
        return await cb.answer("голосование закрыто")
    uid, target = cb.from_user.id, int(cb.data[5:])
    if uid not in g.voters:
        return await cb.answer("ты не голосуешь 👻")
    if target == uid:
        return await cb.answer("за себя нельзя 😅")
    if target and target not in g.cands or (not target and not g.vote_skip):
        return await cb.answer()
    g.votes[uid] = target
    await cb.answer("голос принят ✅")
    try:
        await cb.message.edit_reply_markup(reply_markup=_vote_kb(g))
    except TelegramBadRequest:
        pass
    if len(g.votes) >= len(g.voters):
        g.event.set()


# ================= 🕵️ шпион =================
async def run_spy(bot: Bot, g: Game):
    g.location = random.choice(LOCATIONS)
    g.spy = random.choice(list(g.players))
    for uid in g.players:
        if uid == g.spy:
            await _dm(bot, uid, f"🕵️ <b>ты — шпион</b> · {escape(g.chat_title)}\n\n"
                                "локацию ты не знаешь. слушай вопросы, отвечай уклончиво и не спались.\n"
                                "догадался — жми «🎯 Угадать локацию». попытка одна!",
                      kb_rows([("🎯 Угадать локацию", f"spy:gl:{g.chat_id}")]))
        else:
            await _dm(bot, uid, f"📍 локация: <b>{g.location}</b> · {escape(g.chat_title)}\n\n"
                                "ты мирный. задавай вопросы и вычисли шпиона, "
                                "но не называй локацию прямо — он подслушивает 🤫")
    order = list(g.players)
    random.shuffle(order)
    g.phase = "talk"
    g.ready = set()
    g.event.clear()
    await _say(bot, g, f"🕵️ <b>игра началась!</b> роли в личке\n{ui.LINE}\n"
                       "по очереди задавайте друг другу вопросы о месте, где вы «находитесь». "
                       "шпион не знает, где он — вычислите его 👀\n\n"
                       f"первым спрашивает {g.link(order[0])}\n"
                       f"⏳ голосование через {SPY_ROUND // 60} мин или раньше, если большинство нажмёт кнопку",
               _ready_kb(g))
    await _wait(g, SPY_ROUND)
    if g.finished:
        return
    target = await vote(bot, g, "🗳 <b>кто шпион?</b>", SPY_VOTE, skip=False)
    if g.finished:
        return
    reveal = f"шпионом был {g.link(g.spy)} · локация — <b>{g.location}</b>"
    if target == g.spy:
        civ = [u for u in g.players if u != g.spy]
        await finish(bot, g, f"🎉 <b>шпион пойман!</b>\n{reveal}", civ, SPY_CITY_PRIZE)
    elif target is None:
        await finish(bot, g, f"🤷 город не договорился — <b>шпион ушёл</b>\n{reveal}", [g.spy], SPY_SPY_PRIZE)
    else:
        await finish(bot, g, f"😬 выгнали {g.link(target)}, а он был мирным!\n<b>шпион победил</b> · {reveal}",
                     [g.spy], SPY_SPY_PRIZE)


def _spy_game(chat_id: int, uid: int) -> Game | None:
    g = GAMES.get(chat_id)
    if g and g.kind == "spy" and g.started and not g.finished and g.spy == uid and not g.guessed:
        return g
    return None


@router.callback_query(F.data.startswith("spy:gl:"))
async def cb_spy_list(cb: CallbackQuery):
    chat_id = int(cb.data.split(":")[2])
    if not _spy_game(chat_id, cb.from_user.id):
        return await cb.answer("игра уже закончилась")
    rows, row = [], []
    for i, loc in enumerate(LOCATIONS):
        row.append((loc, f"spy:gp:{chat_id}:{i}"))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    await cb.message.answer("🎯 <b>где мы?</b> выбирай внимательно — попытка одна", reply_markup=kb_rows(*rows))
    await cb.answer()


@router.callback_query(F.data.startswith("spy:gp:"))
async def cb_spy_guess(cb: CallbackQuery, bot: Bot):
    _, _, chat_id, idx = cb.data.split(":")
    g = _spy_game(int(chat_id), cb.from_user.id)
    if not g:
        return await cb.answer("игра уже закончилась")
    g.guessed = True
    guess = LOCATIONS[int(idx)]
    await cb.answer()
    try:
        await cb.message.edit_text(f"🎯 твой ответ: <b>{guess}</b>")
    except TelegramBadRequest:
        pass
    if guess == g.location:
        await finish(bot, g, f"🕵️ {g.link(g.spy)} — <b>шпион</b>, и он угадал локацию: <b>{g.location}</b>! "
                             "шпион победил 😎", [g.spy], SPY_SPY_PRIZE)
    else:
        civ = [u for u in g.players if u != g.spy]
        await finish(bot, g, f"🕵️ {g.link(g.spy)} раскрылся как шпион и назвал «{guess}»… "
                             f"а мы были тут: <b>{g.location}</b>. город победил 🎉", civ, SPY_CITY_PRIZE)


# ================= 🔪 мафия =================
def _deal(players: list[int]) -> dict[int, str]:
    ids = players[:]
    random.shuffle(ids)
    n = len(ids)
    roles = {}
    k = max(1, n // 4)
    for u in ids[:k]:
        roles[u] = "mafia"
    rest = ids[k:]
    if rest:
        roles[rest.pop(0)] = "doctor"
    if n >= 5 and rest:
        roles[rest.pop(0)] = "sheriff"
    for u in rest:
        roles[u] = "civil"
    return roles


def _mafia_alive(g: Game) -> list[int]:
    return [u for u in g.alive if g.roles[u] == "mafia"]


async def _check_win(bot: Bot, g: Game) -> bool:
    maf = _mafia_alive(g)
    city = [u for u in g.alive if g.roles[u] != "mafia"]
    roles_list = "\n".join(f"{ROLE_INFO[g.roles[u]][0]} — {g.link(u)}{'' if u in g.alive else ' 💀'}"
                           for u in g.players)
    if not maf:
        winners = [u for u in g.players if g.roles[u] != "mafia"]
        await finish(bot, g, f"🎉 <b>город победил!</b> мафии больше нет\n{ui.LINE}\n{roles_list}",
                     winners, MAFIA_PRIZE)
        return True
    if len(maf) >= len(city):
        winners = [u for u in g.players if g.roles[u] == "mafia"]
        await finish(bot, g, f"🔪 <b>мафия победила!</b> город не справился\n{ui.LINE}\n{roles_list}",
                     winners, MAFIA_PRIZE)
        return True
    return False


def _night_actors(g: Game) -> set[int]:
    return {u for u in g.alive if g.roles[u] in ("mafia", "doctor", "sheriff")}


def _night_done(g: Game) -> bool:
    acted = set()
    for d in g.night.values():
        acted |= set(d)
    return _night_actors(g) <= acted


async def run_mafia(bot: Bot, g: Game):
    g.roles = _deal(list(g.players))
    g.alive = list(g.players)
    maf = _mafia_alive(g)
    for u in g.players:
        r = g.roles[u]
        name, info = ROLE_INFO[r]
        text = f"твоя роль: <b>{name}</b> · {escape(g.chat_title)}\n<i>{info}</i>"
        if r == "mafia" and len(maf) > 1:
            text += "\n\nсвои: " + ", ".join(g.name(x) for x in maf if x != u)
        await _dm(bot, u, text)
    has = [f"🔪 мафия ×{len(maf)}", "💉 доктор"] + (["🔎 комиссар"] if "sheriff" in g.roles.values() else [])
    await _say(bot, g, f"🔪 <b>мафия началась!</b> {len(g.players)} игроков\n{ui.LINE}\n"
                       f"в городе: {', '.join(has)}, остальные — мирные\nроли — в личке. "
                       "погибшие молчат до конца игры 🤐")
    while not g.finished and g.day < MAX_DAYS:
        g.day += 1
        # ---- ночь
        g.night = {"kill": {}, "heal": {}, "check": {}}
        g.phase = "night"
        g.event.clear()
        await _say(bot, g, f"🌙 <b>ночь {g.day}</b> · город засыпает… ({MF_NIGHT} сек)")
        for u in list(g.alive):
            r = g.roles[u]
            if r == "mafia":
                targets = [t for t in g.alive if g.roles[t] != "mafia"]
                await _dm(bot, u, "🔪 кого убираем этой ночью?",
                          kb_rows(*[[(g.players[t], f"mf:kill:{g.chat_id}:{t}")] for t in targets]))
            elif r == "doctor":
                targets = [t for t in g.alive if t != g.last_heal]
                await _dm(bot, u, "💉 кого лечишь этой ночью?",
                          kb_rows(*[[(g.players[t] + (" (ты)" if t == u else ""), f"mf:heal:{g.chat_id}:{t}")]
                                    for t in targets]))
            elif r == "sheriff":
                targets = [t for t in g.alive if t != u]
                await _dm(bot, u, "🔎 кого проверяешь?",
                          kb_rows(*[[(g.players[t], f"mf:check:{g.chat_id}:{t}")] for t in targets]))
        await _wait(g, MF_NIGHT)
        if g.finished:
            return
        g.phase = "morning"
        kills = Counter(g.night["kill"].values()).most_common()
        victim = 0
        if kills:
            top = [t for t, c in kills if c == kills[0][1]]
            victim = random.choice(top)
        heal = next(iter(g.night["heal"].values()), 0)
        g.last_heal = heal
        if victim and victim == heal:
            text = "☀️ <b>утро.</b> мафия приходила, но доктор успел 💉 все живы!"
        elif victim:
            g.alive.remove(victim)
            text = (f"☀️ <b>утро.</b> этой ночью погиб(ла) {g.link(victim)} 💀\n"
                    f"роль: {ROLE_INFO[g.roles[victim]][0]}")
            await _dm(bot, victim, "💀 тебя убили этой ночью. дальше — только наблюдать, молча 🤐")
        else:
            text = "☀️ <b>утро.</b> ночь прошла спокойно — мафия никого не тронула"
        await _say(bot, g, text)
        if await _check_win(bot, g):
            return
        # ---- день
        g.phase = "talk"
        g.ready = set()
        g.event.clear()
        alive = ", ".join(g.link(u) for u in g.alive)
        await _say(bot, g, f"💬 <b>день {g.day}</b> · обсуждаем, кто мафия ({MF_DAY} сек)\nживы: {alive}",
                   _ready_kb(g))
        await _wait(g, MF_DAY)
        if g.finished:
            return
        target = await vote(bot, g, "🗳 <b>кого казним?</b>", MF_VOTE, skip=True)
        if g.finished:
            return
        if target:
            g.alive.remove(target)
            await _say(bot, g, f"⚖️ город казнил {g.link(target)} — это был {ROLE_INFO[g.roles[target]][0]}")
            await _dm(bot, target, "⚖️ тебя казнили. дальше — только наблюдать, молча 🤐")
        else:
            await _say(bot, g, "⚖️ город не решился — сегодня никого не казнили")
        if await _check_win(bot, g):
            return
    if not g.finished:
        await finish(bot, g, "⌛ игра затянулась — ничья 🤝", [], 0)


@router.callback_query(F.data.startswith("mf:"))
async def cb_night(cb: CallbackQuery, bot: Bot):
    _, act, chat_id, target = cb.data.split(":")
    g = GAMES.get(int(chat_id))
    uid, target = cb.from_user.id, int(target)
    need = {"kill": "mafia", "heal": "doctor", "check": "sheriff"}[act]
    if (not g or g.kind != "mafia" or g.phase != "night" or uid not in g.alive
            or g.roles.get(uid) != need or target not in g.alive):
        return await cb.answer("уже не актуально")
    if act == "heal" and target == g.last_heal:
        return await cb.answer("его лечил прошлой ночью — нельзя")
    if act == "check" and uid in g.night["check"]:
        return await cb.answer("проверять можно одного за ночь")
    g.night[act][uid] = target
    await cb.answer()
    if act == "kill":
        note = f"🔪 выбор: <b>{g.name(target)}</b>"
        for other in _mafia_alive(g):
            if other != uid:
                await _dm(bot, other, f"🔪 {g.name(uid)} выбрал(а): <b>{g.name(target)}</b>")
    elif act == "heal":
        note = f"💉 лечишь: <b>{g.name(target)}</b>"
    else:
        is_maf = g.roles[target] == "mafia"
        note = f"🔎 {g.name(target)} — {'<b>мафия</b> 🔪' if is_maf else 'мирный 🙂'}"
    try:
        await cb.message.edit_text(note)
    except TelegramBadRequest:
        pass
    if _night_done(g):
        g.event.set()
