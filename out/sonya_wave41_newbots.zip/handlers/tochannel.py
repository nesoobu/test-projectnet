"""📤 «В канал» под скачанным видео/треком: выбрал канал → сейчас / в очередь / с подписью.
Медиа берём из сообщения, под которым нажали кнопку (а потом — из reply выбора)."""
import json
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest

import config
from autopost import store, timeparse
from handlers.ap_common import kb_rows

router = Router()
BTN = ("📤 В канал", "tc:go")
_cap: dict[int, tuple[int, dict, float]] = {}   # uid → (канал, медиа, когда спросили подпись)


async def has_channels(uid: int) -> bool:
    if config.PROFILE != "full":
        return False
    try:
        return bool(await store.channels(uid))
    except Exception:
        return False


def media_of(m: Message | None) -> dict | None:
    if not m:
        return None
    if m.video:
        v = m.video
        return {"type": "video", "src": v.file_id, "duration": v.duration, "width": v.width, "height": v.height}
    if m.audio:
        a = m.audio
        return {"type": "audio", "src": a.file_id, "title": a.title, "performer": a.performer, "duration": a.duration}
    if m.animation:
        return {"type": "animation", "src": m.animation.file_id}
    if m.photo:
        return {"type": "photo", "src": m.photo[-1].file_id}
    return None


def _when_kb(cid: int):
    return kb_rows([("🚀 Сейчас", f"tc:now:{cid}"), ("📅 В очередь", f"tc:q:{cid}")],
                   [("✏️ С подписью", f"tc:cap:{cid}"), ("✖️ Отмена", "tc:x")])


@router.callback_query(F.data == "tc:go")
async def cb_go(cb: CallbackQuery):
    if not media_of(cb.message):
        return await cb.answer("тут нечего публиковать", show_alert=True)
    chs = [c for c in await store.channels(cb.from_user.id) if not c["paused"]] if config.PROFILE == "full" else []
    if not chs:
        return await cb.answer("у тебя нет подключённых каналов — /panel → «Подключить канал»", show_alert=True)
    await cb.answer()
    if len(chs) == 1:
        c = chs[0]
        return await cb.message.reply(f"📤 в <b>{escape(c['title'])}</b> — когда?", reply_markup=_when_kb(c["chat_id"]))
    await cb.message.reply("📤 <b>в какой канал?</b>",
                           reply_markup=kb_rows(*[[(f"📢 {c['title'][:30]}", f"tc:ch:{c['chat_id']}")] for c in chs],
                                                [("✖️ Отмена", "tc:x")]))


async def _own(cb: CallbackQuery) -> tuple[dict, dict] | None:
    cid = int(cb.data.rsplit(":", 1)[1])
    ch = await store.channel(cid, cb.from_user.id)
    media = media_of(cb.message.reply_to_message)
    if not ch or not media:
        await cb.answer("канал или файл не найден", show_alert=True)
        return None
    return ch, media


@router.callback_query(F.data.startswith("tc:ch:"))
async def cb_ch(cb: CallbackQuery):
    if got := await _own(cb):
        await cb.answer()
        await cb.message.edit_text(f"📤 в <b>{escape(got[0]['title'])}</b> — когда?",
                                   reply_markup=_when_kb(got[0]["chat_id"]))


async def publish(uid: int, ch: dict, media: dict, text: str, now: bool) -> int:
    pid = await store.new_post(uid, text, [media], [ch["chat_id"]])
    if now:
        at = int(time.time())
    else:
        busy = await store.busy_times(ch["chat_id"], int(time.time()))
        at = timeparse.next_slot(json.loads(ch["slots"] or "[]"), busy, ch["jitter"])
    await store.schedule(pid, ch["chat_id"], at)
    return at


@router.callback_query(F.data.startswith(("tc:now:", "tc:q:")))
async def cb_when(cb: CallbackQuery):
    got = await _own(cb)
    if not got:
        return
    ch, media = got
    now = cb.data.startswith("tc:now:")
    at = await publish(cb.from_user.id, ch, media, "", now)
    await cb.answer("готово")
    await cb.message.edit_text(f"✅ <b>{escape(ch['title'])}</b>: " +
                               ("выйдет в течение минуты 🚀" if now else f"встал в очередь на {timeparse.fmt(at)} 📅"))


@router.callback_query(F.data.startswith("tc:cap:"))
async def cb_cap(cb: CallbackQuery):
    got = await _own(cb)
    if not got:
        return
    _cap[cb.from_user.id] = (got[0]["chat_id"], got[1], time.time())
    await cb.answer()
    await cb.message.edit_text(f"✏️ напиши подпись для поста в <b>{escape(got[0]['title'])}</b>\n"
                               "<i>в конце можно «/очередь» — тогда не сейчас, а в ближайший слот</i>")


def cap_pending(m: Message) -> bool:
    r = _cap.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[2] < 900 and m.chat.type == "private" and m.text
                and (not m.text.startswith("/") or m.text.strip() == "/очередь"))


@router.message(cap_pending)
async def on_cap(m: Message):
    cid, media, _ = _cap.pop(m.from_user.id)
    ch = await store.channel(cid, m.from_user.id)
    if not ch:
        return await m.reply("канал пропал 🤔")
    text = (m.html_text or "").strip()
    now = not text.endswith("/очередь")
    text = text.removesuffix("/очередь").strip()
    at = await publish(m.from_user.id, ch, media, text, now)
    await m.reply(f"✅ <b>{escape(ch['title'])}</b>: " +
                  ("выйдет в течение минуты 🚀" if now else f"в очереди на {timeparse.fmt(at)} 📅"))


@router.callback_query(F.data == "tc:x")
async def cb_cancel(cb: CallbackQuery):
    _cap.pop(cb.from_user.id, None)
    await cb.answer("отменила")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass
