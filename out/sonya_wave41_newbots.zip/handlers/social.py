import re
from aiogram import Router, F
from aiogram.types import Message

import db
import ui

router = Router()

THANKS = re.compile(r"^\s*(\+|\+1|спасибо|спс|благодарю|респект|thx|thanks)[\s!.)]*$", re.I)


@router.message(F.chat.type.in_({"group", "supergroup"}), F.reply_to_message, F.text.regexp(THANKS))
async def give_rep(m: Message):
    taker = m.reply_to_message.from_user
    if taker.is_bot or taker.id == m.from_user.id:
        return
    await db.touch_user(taker, count=False)
    if not await db.give_rep(m.from_user.id, taker.id, m.chat.id):
        return  # кулдаун — молча
    u = await db.get_user(taker.id)
    await m.reply(f"❤️ {ui.esc(taker.first_name)} +1 репутации (теперь <b>{u['rep']}</b>)")
