"""Рефералка, Соня+ за звёзды, инлайн-режим."""
import asyncio
import hashlib
import logging
import random
import time
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import (Message, CallbackQuery, InlineQuery, InlineQueryResultArticle,
                           InlineQueryResultPhoto, InputTextMessageContent, LabeledPrice)

import config
import db
import limits
import llm
import persona
import ui
from autopost import timeparse
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("extra")

# ================= Соня+ =================
PLUS_PRICE = 99
PLUS_DAYS = 30
PLANS = {7: 29, 30: 99, 365: 799}   # дней: звёзд
PLAN_NAMES = {7: "неделя", 30: "месяц", 365: "год"}
_plus: dict[int, int] = {}   # uid → до какого времени (кэш, чтобы не дёргать базу на каждый кулдаун)


async def load_plus():
    for r in await db.q_all("SELECT id, plus_until FROM users WHERE plus_until>?", int(time.time())):
        _plus[r["id"]] = r["plus_until"]


def active(uid: int) -> bool:
    return uid == config.OWNER_ID or _plus.get(uid, 0) > time.time()


async def grant_plus(uid: int, days: int) -> int:
    u = await db.get_user(uid) or {}
    base = max(int(time.time()), u.get("plus_until") or 0)
    until = base + days * 86400
    await db.q_run("UPDATE users SET plus_until=? WHERE id=?", until, uid)
    _plus[uid] = until
    return until


PLUS_TEXT = (
    ui.head("✨", "Соня+", "больше меня — для своих") + "\n"
    + ui.quote("🎨 рисую, 🗣 озвучиваю и 🎵 ищу треки <b>без ожидания</b>\n"
               f"🧠 <b>{config.AI_DAY_LIMIT_PLUS or 'безлимит'}</b> ИИ-ответов в день вместо {config.AI_DAY_LIMIT}\n"
               "⚡ <b>приоритет</b> в очереди скачивания\n"
               "📺 видео в <b>1080p</b> и выше\n"
               "🎛 эффекты и 🗒 текст из видео <b>без лимита</b> (без Сони+ — 3 в день)\n"
               "🔔 подписки на любое число артистов\n"
               + ("📢 автопостинг: больше каналов и источников\n" if config.FREE_CHANNELS or config.FREE_SOURCES else "")
               + "🎁 ежедневный бонус <b>×2</b> · 🎭 злая, дворовая и психолог в /mode\n"
               "👑 титул «✨ Соня+» и значок в профиле")
    + "\n" + ui.quote("<b>29 ⭐</b> неделя · <b>99 ⭐</b> месяц · <b>799 ⭐</b> год <i>(−33%)</i>\n"
                       "🔁 или подписка <b>99 ⭐/мес</b> — продлевается сама, отменить можно в любой момент")
    + "\n" + ui.hint("🖤 и ты поддерживаешь Соню — сервер и нейросети не бесплатные")
)
SUB_PRICE = 99
_sub_link: list[str] = []


async def sub_link(bot: Bot) -> str | None:
    """Ссылка на подписку звёздами (Telegram сам продлевает каждые 30 дней)."""
    if not _sub_link:
        try:
            link = await bot.create_invoice_link(
                title="Соня+ · подписка", description="каждый месяц сама продлевается — отменить можно в любой момент",
                payload="plussub", currency="XTR", prices=[LabeledPrice(label="Соня+ на месяц", amount=SUB_PRICE)],
                subscription_period=2592000)
            if isinstance(link, str):
                _sub_link.append(link)
        except Exception as e:
            log.info("sub link: %s", e)
    return _sub_link[0] if _sub_link else None


async def plus_view(uid: int, bot: Bot | None = None):
    import premium
    text = PLUS_TEXT
    u = await db.get_user(uid) or {}
    if (u.get("plus_until") or 0) > time.time():
        text += "\n" + ui.quote(f"✅ активна до <b>{timeparse.fmt(u['plus_until'])}</b> — оплата продлит")
    rows = [[(f"{PLAN_NAMES[d]} · {p} ⭐", f"plus:buy:{d}") for d, p in PLANS.items()]]
    link = await sub_link(bot) if bot else None
    if link:
        rows.append([(f"🔁 Подписка · {SUB_PRICE} ⭐/мес", link)])
    if not u.get("plus_trial") and (u.get("plus_until") or 0) < time.time():
        rows.insert(0, [(f"🎁 Попробовать {premium.TRIAL_DAYS} дня бесплатно", "plus:trial")])
    rows += [[("🎁 Подарить другу", "plus:gift")], [("‹ Меню", "m:home")]]
    return text, kb_rows(*rows)


@router.callback_query(F.data == "plus:trial")
async def cb_trial(cb: CallbackQuery):
    import premium
    until = await premium.start_trial(cb.from_user.id)
    if not until:
        return await cb.answer("пробный период уже был 🙃 /plus", show_alert=True)
    await cb.answer("✨ Соня+ включена!")
    await cb.message.answer(f"✨ <b>Соня+ на {premium.TRIAL_DAYS} дня — твоя!</b> до {timeparse.fmt(until)}\n"
                            "без лимитов, без очереди, в HD. понравится — /plus 🖤")


@router.message(Command("plus"))
async def cmd_plus(m: Message, bot: Bot):
    text, kb = await plus_view(m.from_user.id, bot)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "m:plus")
async def cb_plus(cb: CallbackQuery, bot: Bot):
    text, kb = await plus_view(cb.from_user.id, bot)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:
        await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data.startswith("plus:buy"))
async def cb_buy(cb: CallbackQuery, bot: Bot):
    parts = cb.data.split(":")
    days = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else PLUS_DAYS   # старые кнопки — месяц
    if days not in PLANS:
        return await cb.answer()
    await bot.send_invoice(cb.message.chat.id, title=f"Соня+ · {PLAN_NAMES[days]}",
                           description="без ожидания, больше ИИ, бонус ×2, титул и режимы характера",
                           payload=f"plus:{days}", currency="XTR",
                           prices=[LabeledPrice(label="Соня+", amount=PLANS[days])])
    await cb.answer()


# ---------- подарок ----------
GIFT_HINT = ("🎁 <b>Соня+ в подарок</b>\nответь <code>/gift</code> на сообщение друга в группе "
             "или напиши <code>/gift @username</code> (друг должен хоть раз написать мне)")


@router.callback_query(F.data == "plus:gift")
async def cb_gift_hint(cb: CallbackQuery):
    await cb.message.answer(GIFT_HINT)
    await cb.answer()


@router.message(Command("gift", "подарить"))
async def cmd_gift(m: Message, command: CommandObject):
    target = None
    if m.reply_to_message and m.reply_to_message.from_user and not m.reply_to_message.from_user.is_bot:
        target = (m.reply_to_message.from_user.id, m.reply_to_message.from_user.first_name)
    else:
        a = (command.args or "").strip()
        r = None
        if a.startswith("@"):
            r = await db.q_one("SELECT id, name FROM users WHERE lower(username)=?", a[1:].lower())
        elif a.isdigit():
            r = await db.q_one("SELECT id, name FROM users WHERE id=?", int(a))
        if r:
            target = (r["id"], r["name"])
    if not target:
        return await m.reply(GIFT_HINT)
    if target[0] == m.from_user.id:
        return await m.reply("себе — через /plus 😉")
    await m.reply(f"🎁 дарим Соню+ для <b>{escape(target[1] or 'друга')}</b>. на сколько?",
                  reply_markup=kb_rows([(f"{PLAN_NAMES[d]} · {p} ⭐", f"gift:{target[0]}:{d}")
                                        for d, p in PLANS.items()]))


@router.callback_query(F.data.startswith("gift:"))
async def cb_gift(cb: CallbackQuery, bot: Bot):
    _, uid, days = cb.data.split(":")
    days = int(days)
    if days not in PLANS or not await db.get_user(int(uid)):
        return await cb.answer("не нашла получателя", show_alert=True)
    await bot.send_invoice(cb.from_user.id if cb.message.chat.type != "private" else cb.message.chat.id,
                           title=f"Соня+ в подарок · {PLAN_NAMES[days]}",
                           description="другу придёт сообщение, что это от тебя 🎁",
                           payload=f"gift:{uid}:{days}", currency="XTR",
                           prices=[LabeledPrice(label="Соня+ в подарок", amount=PLANS[days])])
    await cb.answer("счёт — у тебя в личке" if cb.message.chat.type != "private" else "")


# ================= рефералка =================
REF_BONUS = 50


async def handle_ref(m: Message, payload: str, bot: Bot) -> bool:
    """/start ref_123 от нового юзера → обоим монетки."""
    if not payload.startswith("ref_") or not payload[4:].isdigit():
        return False
    ref = int(payload[4:])
    u = await db.get_user(m.from_user.id)
    if not u or ref == m.from_user.id or u.get("ref_by") or (u.get("msgs") or 0) > 2 \
            or time.time() - (u.get("joined") or 0) > 600:
        return False
    if not await db.get_user(ref):
        return False
    await db.q_run("UPDATE users SET ref_by=?, coins=coins+? WHERE id=?", ref, REF_BONUS, m.from_user.id)
    await db.q_run("UPDATE users SET refs=refs+1, coins=coins+? WHERE id=?", REF_BONUS, ref)
    await m.answer(f"🎁 тебя пригласил друг — держи <b>{REF_BONUS} 🪙</b> на старт")
    try:
        await bot.send_message(ref, f"🎉 по твоей ссылке пришёл {escape(m.from_user.first_name)}! "
                                    f"+{REF_BONUS} 🪙")
    except Exception:
        pass
    return True


async def ref_view(uid: int, bot: Bot):
    me = await bot.me()
    u = await db.get_user(uid) or {}
    link = f"https://t.me/{me.username}?start=ref_{uid}"
    text = (ui.head("👥", "Позвать друзей", f"за каждого — +{REF_BONUS} 🪙 тебе и ему")
            + "\n" + ui.quote(f"твоя ссылка:\n<code>{link}</code>")
            + "\n" + ui.stats(("👥 приглашено", u.get("refs") or 0))
            + "\n" + ui.hint("нажми на ссылку — скопируется"))
    share = f"https://t.me/share/url?url={quote(link)}&text={quote('залетай к Соне 🖤 качает видео, рисует, играет')}"
    from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
    kb = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="📤 Отправить другу", url=share)],
                                               [InlineKeyboardButton(text="‹ Меню", callback_data="m:home")]])
    return text, kb


@router.message(Command("ref", "invite"))
async def cmd_ref(m: Message, bot: Bot):
    text, kb = await ref_view(m.from_user.id, bot)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "m:ref")
async def cb_ref(cb: CallbackQuery, bot: Bot):
    text, kb = await ref_view(cb.from_user.id, bot)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except Exception:
        await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


# ================= инлайн =================
BALL = ["да, сто процентов", "без сомнений", "скорее да", "звёзды говорят — да ✨", "даже не думай",
        "нет", "скорее нет", "спроси позже, я занята", "лучше не знать 👀", "шансы есть", "50 на 50"]


def _id(*parts) -> str:
    return hashlib.md5("|".join(map(str, parts)).encode()).hexdigest()


_typing: dict[int, str] = {}
INLINE_PAUSE = 0.9   # ждём, пока человек допечатает, — иначе ИИ дёргается на каждую букву


@router.inline_query()
async def on_inline(q: InlineQuery):
    text = (q.query or "").strip()
    if text:
        _typing[q.from_user.id] = q.id
        await asyncio.sleep(INLINE_PAUSE)
        if _typing.get(q.from_user.id) != q.id:
            return   # уже пришёл запрос новее — этот телеграм всё равно выбросит
        _typing.pop(q.from_user.id, None)
    results = []
    if not text:
        results.append(InlineQueryResultArticle(
            id=_id("hint", time.time()), title="💬 начни писать — отвечу, нарисую, погадаю",
            description="например: что посмотреть вечером",
            input_message_content=InputTextMessageContent(message_text="🖤 пиши @ и вопрос — Соня ответит")))
    elif not await limits.take(q.from_user.id):
        results.append(InlineQueryResultArticle(
            id=_id("tired", time.time()), title="🫠 на сегодня я выговорилась", description="приходи завтра или /plus",
            input_message_content=InputTextMessageContent(message_text="🫠 Соня на сегодня выговорилась")))
    else:
        try:
            ans = await asyncio.wait_for(llm.ask(
                [{"role": "system", "content": persona.BASE + "\nОтвечай очень коротко, 1–3 предложения."},
                 {"role": "user", "content": text[:500]}], max_tokens=400, feature="inline"), timeout=7)
            if ans:
                results.append(InlineQueryResultArticle(
                    id=_id("ans", text, time.time()), title="💬 Соня отвечает", description=ans[:120],
                    input_message_content=InputTextMessageContent(
                        message_text=f"❓ {escape(text[:300])}\n\n💬 {escape(ans[:3500])}", parse_mode="HTML")))
        except Exception as e:
            log.info("inline llm: %s", e)
            await limits.give_back(q.from_user.id)
        seed = random.randint(1, 10 ** 6)
        url = (f"https://image.pollinations.ai/prompt/{quote(text[:300])}?width=768&height=768&seed={seed}"
               + ("&nologo=true" if config.POLLINATIONS_TOKEN else ""))   # без токена nologo даёт 402
        results.append(InlineQueryResultPhoto(id=_id("img", text, seed), photo_url=url,
                                              thumbnail_url=url.replace("768", "256"),
                                              title="🎨 нарисовать", caption=f"🎨 {escape(text[:200])}"))
    results.append(InlineQueryResultArticle(
        id=_id("ball", text, time.time()), title="🔮 шар судьбы", description="спроси да/нет",
        input_message_content=InputTextMessageContent(
            message_text=(f"❓ {escape(text[:200])}\n" if text else "") + f"🔮 {random.choice(BALL)}")))
    results.append(InlineQueryResultArticle(
        id=_id("coin", time.time()), title="🪙 подбросить монетку", description="орёл или решка",
        input_message_content=InputTextMessageContent(message_text=f"🪙 {random.choice(['орёл', 'решка'])}!")))
    await q.answer(results, cache_time=0, is_personal=True)
