"""🎮 Угадай мелодию (группы и личка), 📊 мой музыкальный вкус, 🎵 что за песня в видео."""
import asyncio
import difflib
import io
import logging
import random
import re
import time
from collections import Counter
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery, FSInputFile, BufferedInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from autopost import media_dl
from downloader import core, catalog, audiofx
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("melody")

ROUNDS = 5
ROUND_SEC = 30
CLIP_SEC = 15
WIN_COINS = 30
_games: dict[int, dict] = {}


# ================= сравнение ответа =================
def norm(s: str) -> str:
    s = re.sub(r"[\(\[].*?[\)\]]", " ", (s or "").lower().replace("ё", "е"))
    s = re.sub(r"\b(feat|ft)\b.*$", " ", s)
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s]", " ", s)).strip()


def is_right(guess: str, title: str) -> bool:
    g, t = norm(guess), norm(title)
    if not g or not t or len(g) < 2:
        return False
    if t in g or (len(g) >= 4 and g in t and len(g) >= len(t) * 0.6):
        return True
    return difflib.SequenceMatcher(None, g, t).ratio() >= 0.75


def game_on(m: Message) -> bool:
    g = _games.get(m.chat.id)
    return bool(g and g.get("cur") and m.text and not m.text.startswith("/"))


# ================= игра =================
async def _clip(t: dict) -> str:
    raw = audiofx.tmp(".mp3")
    with open(raw, "wb") as f:
        f.write(await core.fetch_bytes(t["preview"]))
    try:
        return await audiofx.voice(raw, random.randint(0, 10), CLIP_SEC)
    finally:
        core.remove(raw)


async def _play(bot: Bot, chat_id: int, tracks: list[dict]):
    g = _games[chat_id]
    try:
        for i in range(1, ROUNDS + 1):
            if g.get("stop") or not tracks:
                break
            t = tracks.pop()
            path = None
            try:
                path = await _clip(t)
                g["cur"], g["solved"] = t, asyncio.Event()
                await bot.send_voice(chat_id, FSInputFile(path),
                                     caption=f"🎮 <b>раунд {i}/{ROUNDS}</b> — что за песня?\n"
                                             f"<i>пиши название в чат · {ROUND_SEC} с</i>",
                                     reply_markup=kb_rows([("💡 Подсказка", "mel:hint"), ("⏹ Стоп", "mel:stop")]))
            except Exception as e:
                log.info("clip: %s", e)
                continue
            finally:
                core.remove(path)
            try:
                await asyncio.wait_for(g["solved"].wait(), ROUND_SEC)
            except asyncio.TimeoutError:
                g["cur"] = None
                await bot.send_message(chat_id, f"⏰ никто не угадал. это было:\n🎵 <b>{escape(catalog.name(t))}</b>")
            await asyncio.sleep(3)
        await bot.send_message(chat_id, await _final(g), reply_markup=kb_rows([("🔁 Ещё игра", "mel:again")]))
    finally:
        _games.pop(chat_id, None)


async def _final(g: dict) -> str:
    sc = sorted(g["score"].items(), key=lambda kv: -kv[1][1])
    if not sc:
        return "🎮 <b>игра окончена</b>\nникто ничего не угадал 🙈 попробуй <code>/melody артист</code> — с любимым проще"
    medals = ["🥇", "🥈", "🥉"]
    lines = ["🏁 <b>итоги «Угадай мелодию»</b>", ui.LINE]
    for i, (uid, (name, pts)) in enumerate(sc[:10]):
        lines.append(f"{medals[i] if i < 3 else '▫️'} {escape(name)} — <b>{pts}</b>")
    if config.PROFILE == "full":
        await db.add_coins(sc[0][0], WIN_COINS, win=True)
        lines.append(ui.hint(f"победителю +{WIN_COINS} 🪙"))
    return "\n".join(lines)


async def start_game(m: Message, bot: Bot, query: str, uid: int):
    if m.chat.id in _games:
        return await m.answer("🎮 игра уже идёт — угадывай!")
    if not audiofx.ok():
        return await m.answer("на сервере нет ffmpeg — игра не запустится")
    _games[m.chat.id] = {"score": {}, "cur": None, "by": uid}
    st = await m.answer("🎮 подбираю песни…" + (f" про «{escape(query)}»" if query else " из чарта"))
    try:
        tracks = await catalog.previews(query, 50)
    except Exception as e:
        log.info("previews: %s", e)
        tracks = []
    if len(tracks) < 3:
        _games.pop(m.chat.id, None)
        return await st.edit_text("😕 не нашла песен для игры. попробуй другого артиста: <code>/melody oxxxymiron</code>")
    random.shuffle(tracks)
    await st.edit_text(f"🎮 <b>Угадай мелодию</b> · {ROUNDS} раундов\n"
                       f"включаю {CLIP_SEC} секунд — пиши название песни. кто первый — тому очко!")
    asyncio.create_task(_play(bot, m.chat.id, tracks))


@router.message(Command("melody", "угадай", "guess"))
async def cmd_melody(m: Message, bot: Bot, command: CommandObject):
    await start_game(m, bot, (command.args or "").strip()[:60], m.from_user.id)


@router.message(game_on)
async def on_guess(m: Message):
    g = _games.get(m.chat.id)
    t = g and g.get("cur")
    if not t or not is_right(m.text, t["title"]):
        return
    g["cur"] = None
    name = (m.from_user.first_name or "кто-то")[:30]
    pts = g["score"].get(m.from_user.id, (name, 0))[1] + 1
    g["score"][m.from_user.id] = (name, pts)
    g["solved"].set()
    await m.reply(f"✅ <b>{escape(name)}</b> угадал(а)! +1 (всего {pts})\n🎵 {escape(catalog.name(t))}")


@router.callback_query(F.data.startswith("mel:"))
async def cb_mel(cb: CallbackQuery, bot: Bot):
    g = _games.get(cb.message.chat.id)
    act = cb.data[4:]
    if act == "again":
        await cb.answer()
        return await start_game(cb.message, bot, "", cb.from_user.id)
    if not g:
        return await cb.answer("игра уже закончилась")
    if act == "stop":
        if cb.from_user.id not in (g["by"], config.OWNER_ID) and cb.message.chat.type != "private":
            return await cb.answer("остановить может тот, кто начал", show_alert=True)
        g["stop"] = True
        if g.get("solved"):
            g["cur"] = None
            g["solved"].set()
        return await cb.answer("останавливаю после раунда")
    t = g.get("cur")
    if not t:
        return await cb.answer("раунд уже закончился")
    title = t["title"]
    await cb.answer(f"🎤 {t['artist']} · «{title[:1]}{'•' * max(0, len(title) - 1)}»", show_alert=True)


# ================= 📊 мой музыкальный вкус =================
def _card(name: str, artists: list[tuple[str, int]], total: int, fav: str, bot_name: str) -> bytes:
    from PIL import Image, ImageDraw
    from handlers.tools import _font
    W, H = 1080, 1350
    im = Image.new("RGB", (W, H))
    d = ImageDraw.Draw(im)
    for y in range(H):   # фиолетово-ночной градиент
        k = y / H
        d.line([(0, y), (W, y)], fill=(int(40 + 60 * k), int(18 + 10 * k), int(70 + 50 * (1 - k))))
    d.text((80, 90), "мой музыкальный вкус", font=_font(44), fill=(220, 200, 255))
    d.text((80, 150), name[:22], font=_font(84, True), fill=(255, 255, 255))
    top = artists[0][1] if artists else 1
    y = 300
    for i, (a, n) in enumerate(artists[:5], 1):
        d.text((80, y), f"{i}", font=_font(64, True), fill=(255, 180, 230))
        d.text((170, y + 4), a[:24], font=_font(50, True), fill=(255, 255, 255))
        w = int(760 * n / top)
        d.rounded_rectangle([170, y + 78, 170 + max(w, 30), y + 96], 9, fill=(255, 140, 210))
        d.text((170 + max(w, 30) + 16, y + 66), str(n), font=_font(32), fill=(230, 210, 255))
        y += 140
    d.text((80, H - 300), f"скачано треков: {total}", font=_font(48, True), fill=(255, 255, 255))
    if fav:
        d.text((80, H - 230), f"любимый: {fav[:34]}", font=_font(38), fill=(230, 210, 255))
    d.text((80, H - 120), f"узнай свой → @{bot_name}", font=_font(40, True), fill=(255, 180, 230))
    out = io.BytesIO()
    im.save(out, "PNG")
    return out.getvalue()


async def taste(m: Message, bot: Bot, uid: int, name: str):
    import json
    rows = await db.q_all("SELECT t.data FROM music_plays p JOIN music_tracks t ON t.key=p.key WHERE p.uid=?", uid)
    tracks = [json.loads(r["data"]) for r in rows]
    if len(tracks) < 3:
        return await m.answer("📊 скачай хотя бы 3 трека — и я покажу твой музыкальный вкус 🎧")
    arts = Counter(a.strip() for t in tracks for a in (t["artist"] or "").split(",")[:1] if a.strip())
    fav = Counter(catalog.name(t) for t in tracks).most_common(1)[0][0]
    me = await bot.me()
    png = await asyncio.to_thread(_card, name, arts.most_common(5), len(tracks), fav, me.username or "")
    await m.answer_photo(BufferedInputFile(png, "taste.png"),
                         caption=f"📊 музыкальный вкус {escape(name)} · через @{me.username}",
                         reply_markup=kb_rows([("📤 Позвать друга узнать свой", "https://t.me/share/url?url="
                                                + quote(f"https://t.me/{me.username}?start=taste")
                                                + "&text=" + quote("а какой у тебя музыкальный вкус? 🎧"))]))


@router.message(Command("taste", "вкус"))
async def cmd_taste(m: Message, bot: Bot):
    await taste(m, bot, m.from_user.id, m.from_user.first_name or "я")


@router.callback_query(F.data == "mx:taste")
async def cb_taste(cb: CallbackQuery, bot: Bot):
    await cb.answer()
    await taste(cb.message, bot, cb.from_user.id, cb.from_user.first_name or "я")


# ================= 🎵 что за песня в видео =================
async def _tiktok_sound(url: str) -> dict:
    import re as _re
    if _re.search(r"//(vt|vm)\.", url):
        url = await core.resolve_redirect(url)
    got = await core.tiktok_photos(url)
    if not got.get("music"):
        raise media_dl.DLError("в посте нет звука")
    path = audiofx.tmp(".mp3")
    with open(path, "wb") as fh:
        fh.write(await core.fetch_bytes(got["music"]))
    return {"path": path}

async def whatsong(m: Message, url: str, status: Message | None = None):
    from handlers import tools, music
    st = status or await m.reply("🎧 слушаю звук из видео…")
    try:
        await st.edit_text("🎧 слушаю звук из видео…")
    except TelegramBadRequest:
        pass
    f = None
    try:
        try:
            f = await core.download(url, "audio")
        except media_dl.DLError:
            if "tiktok" not in url:
                raise
            f = await _tiktok_sound(url)   # фото-карусель: звук берём из поста
        res = await tools.recognize(f["path"])
    except media_dl.DLError as e:
        return await st.edit_text(f"😕 не скачался звук: {escape(str(e))}")
    except Exception as e:
        log.info("whatsong: %s", e)
        res = None
    finally:
        core.remove(f and f.get("path"))
    if not res:
        return await st.edit_text("🤷 не узнала музыку. может, это голос, оригинальный звук или трек слишком тихий")
    await music.found_card(st, res["artist"], res["title"], res["cover"], res["url"])
