"""🎵 Музыка как у больших ботов: нумерованный список «Артист — Трек», страницы, обложки,
❤️ мои треки, 🔁 похожие, 👤 ещё от артиста, 🔥 чарт, 📝 текст."""
import asyncio
import io
import logging
import time
import uuid
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile, BufferedInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from autopost import media_dl
from downloader import core, catalog, audiofx
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("music")
PAGE = 8
_S: dict[str, dict] = {}       # sid → {"title", "keys", "ts"}
_busy: set[int] = set()


# ================= список с номерами =================
def _session(title: str, tracks: list[dict], extra: list | None = None) -> str:
    now = time.time()
    for k, v in list(_S.items()):
        if now - v["ts"] > 6 * 3600:
            _S.pop(k, None)
    sid = uuid.uuid4().hex[:8]
    _S[sid] = {"title": title, "tracks": tracks, "ts": now, "extra": extra or []}
    return sid


def list_view(sid: str, page: int = 0) -> tuple[str, object]:
    s = _S[sid]
    tr = s["tracks"]
    pages = max(1, (len(tr) + PAGE - 1) // PAGE)
    page = max(0, min(page, pages - 1))
    chunk = tr[page * PAGE:(page + 1) * PAGE]
    lines = [s["title"], ui.hint(f"нашла {len(tr)} · жми номер — пришлю трек"
                                 + (f" · стр. {page + 1}/{pages}" if pages > 1 else "")), ""]
    for i, t in enumerate(chunk, page * PAGE + 1):
        d = catalog.mmss(t["dur"])
        who = f"{escape(t['artist'][:40])} — " if t["artist"] else ""
        lines.append(f"<b>{i}.</b> {who}<b>{escape(t['title'][:60])}</b>" + (f" <i>{d}</i>" if d else ""))
    nums = [(str(i), f"mx:get:{t['key']}") for i, t in enumerate(chunk, page * PAGE + 1)]
    rows = [nums[:4], nums[4:8]] if len(nums) > 4 else [nums]
    if pages > 1:
        rows.append([("‹", f"ms:{sid}:{page - 1}" if page else "ms:noop"),
                     (f"{page + 1} / {pages}", "ms:noop"),
                     ("›", f"ms:{sid}:{page + 1}" if page < pages - 1 else "ms:noop")])
    return "\n".join(lines), kb_rows(*[r for r in rows if r], *s.get("extra", []))


async def show_list(m: Message, title: str, tracks: list[dict], status: Message | None = None,
                    extra: list | None = None):
    if not tracks:
        text = "🤷 ничего не нашла. попробуй «артист название» или строчку из песни"
        return await (status.edit_text(text) if status else m.answer(text))
    text, kb = list_view(_session(title, tracks, extra))
    if status:
        try:
            return await status.edit_text(text, reply_markup=kb)
        except TelegramBadRequest:
            pass
    await m.answer(text, reply_markup=kb)


async def search(m: Message, query: str):
    query = query.strip()[:100]
    if len(query) < 2:
        return await m.reply("что ищем? напиши артиста и название, например: <code>oxvgen memory</code>")
    from handlers.tools import too_soon
    if (left := too_soon(m.from_user.id, "find", 3)):
        return await m.reply(f"секунду, ещё {left} с")
    st = await m.reply("🔎 ищу…")
    try:
        res = await catalog.search(query, 32)
    except Exception as e:
        log.warning("search: %s", e)
        res = []
    await show_list(m, f"🔎 <b>{escape(query)}</b>", res, st)


@router.callback_query(F.data.startswith("ms:"))
async def cb_page(cb: CallbackQuery):
    parts = cb.data.split(":")
    if parts[1] == "noop":
        return await cb.answer()
    if parts[1] not in _S:
        return await cb.answer("список устарел — поищи заново", show_alert=True)
    text, kb = list_view(parts[1], int(parts[2]))
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer()


# ================= трек =================
async def is_fav(uid: int, key: str) -> bool:
    return bool(await db.q_one("SELECT 1 FROM music_fav WHERE uid=? AND key=?", uid, key))


def track_kb(t: dict, fav: bool, tc: bool = False):
    rows = [[("📝 Текст", f"mx:ly:{t['key']}"), ("💔 Убрать из моих" if fav else "❤️ В мои", f"mx:fav:{t['key']}")],
            [("🔁 Похожие", f"mx:sim:{t['key']}")]]
    if t["artist"]:
        rows[1].append((f"👤 {t['artist'][:20]}", f"mx:art:{t['key']}"))
    rows.append([("🎛 Эффекты", f"mx:fx:{t['key']}"), ("✂️ Рингтон", f"mx:ring:{t['key']}")])
    if tc:
        from handlers import tochannel
        rows.append([tochannel.BTN])
    return kb_rows(*rows)


async def _kb_for(t: dict, uid: int):
    from handlers import tochannel
    return track_kb(t, await is_fav(uid, t["key"]), await tochannel.has_channels(uid))


async def _thumb(url: str):
    if not url:
        return None
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(await core.fetch_bytes(url))).convert("RGB")
        im.thumbnail((320, 320))
        out = io.BytesIO()
        im.save(out, "JPEG", quality=85)
        return BufferedInputFile(out.getvalue(), "cover.jpg")
    except Exception as e:
        log.info("cover: %s", e)
        return None


async def send_track(m: Message, bot: Bot, key: str, uid: int):
    t = await catalog.get(key)
    if not t:
        return await m.answer("😕 этот трек я забыла — поищи заново")
    me = await bot.me()
    cap = f'<a href="https://t.me/{me.username}">@{me.username}</a>' if me.username else None
    kb = await _kb_for(t, uid)
    c = await db.dl_cache_get(f"audio:{key}")
    if c:
        try:
            await m.answer_audio(c["file_id"], caption=cap, reply_markup=kb)
            return await _done(m, uid, key)
        except TelegramBadRequest:
            pass
    await bot.send_chat_action(m.chat.id, ChatAction.UPLOAD_VOICE)
    f = None
    try:
        f = await core.download(await catalog.audio_url(t), "audio")
        sent = await m.answer_audio(FSInputFile(f["path"]), caption=cap, reply_markup=kb,
                                    title=t["title"] or f.get("title") or None,
                                    performer=t["artist"] or f.get("performer") or None,
                                    duration=f.get("duration") or t["dur"] or None, thumbnail=await _thumb(t["cover"]))
        if sent.audio:
            await db.dl_cache_put(f"audio:{key}", "audio", sent.audio.file_id, catalog.name(t))
        await _done(m, uid, key)
    except media_dl.DLError as e:
        await m.answer(f"😕 не скачалось: {escape(str(e))}")
    except TelegramBadRequest as e:
        await m.answer(f"😕 телеграм не принял файл ({escape(str(e)[:60])})")
    finally:
        core.remove(f and f.get("path"))


async def _done(m: Message, uid: int, key: str = ""):
    if key:
        await db.q_run("INSERT INTO music_plays VALUES(?,?,?)", uid, key, int(time.time()))
    await db.count_dl(uid)
    if config.PROFILE != "full" and m.chat.type == "private":
        from handlers import solo
        await solo.nudge(m, uid)


@router.callback_query(F.data.startswith("mx:get:"))
async def cb_get(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    if uid in _busy:
        return await cb.answer("⏳ ещё качаю прошлый трек", show_alert=True)
    await cb.answer("качаю…")
    _busy.add(uid)
    try:
        await send_track(cb.message, bot, cb.data[7:], uid)
    finally:
        _busy.discard(uid)


@router.callback_query(F.data.startswith("mx:fav:"))
async def cb_fav(cb: CallbackQuery):
    key, uid = cb.data[7:], cb.from_user.id
    t = await catalog.get(key)
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    if await is_fav(uid, key):
        await db.q_run("DELETE FROM music_fav WHERE uid=? AND key=?", uid, key)
        await cb.answer("убрала из твоих треков")
    else:
        await db.q_run("INSERT OR REPLACE INTO music_fav VALUES(?,?,?)", uid, key, int(time.time()))
        await cb.answer("❤️ сохранила — открой /my")
    try:
        await cb.message.edit_reply_markup(reply_markup=await _kb_for(t, uid))
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("mx:ly:"))
async def cb_ly(cb: CallbackQuery):
    t = await catalog.get(cb.data[6:])
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    from handlers import tools
    if (left := tools.too_soon(cb.from_user.id, "lyr", 3)):
        return await cb.answer(f"секунду, ещё {left} с")
    await cb.answer("ищу текст…")
    await tools.send_lyrics(cb.message, f"{t['artist']} {t['title']}")


@router.callback_query(F.data.startswith(("mx:sim:", "mx:art:")))
async def cb_more(cb: CallbackQuery):
    t = await catalog.get(cb.data[7:])
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    await cb.answer("ищу…")
    sim = cb.data.startswith("mx:sim:")
    res = await (catalog.similar(t) if sim else catalog.by_artist(t))
    title = (f"🔁 <b>похожее на</b> {escape(catalog.name(t))}" if sim else f"👤 <b>{escape(t['artist'])}</b>")
    extra = None if sim else [[("🔔 Следить за новыми релизами", f"mx:sub:{t['key']}")]]
    await show_list(cb.message, title, res, extra=extra)


# ================= чарт и мои треки =================
async def chart_list(m: Message):
    st = await m.answer("🔥 собираю чарт…")
    await show_list(m, "🔥 <b>чарт</b> — что слушают сейчас", await catalog.chart(), st)


async def my_list(m: Message, uid: int):
    rows = await db.q_all("SELECT t.data FROM music_fav f JOIN music_tracks t ON t.key=f.key "
                          "WHERE f.uid=? ORDER BY f.ts DESC LIMIT 200", uid)
    if not rows:
        return await m.answer("❤️ <b>твои треки</b>\n" + ui.hint("пока пусто — жми «❤️ В мои» под любым треком"))
    import json
    await show_list(m, "❤️ <b>твои треки</b>", [json.loads(r["data"]) for r in rows])


def _top_cmd(m: Message) -> bool:
    return config.PROFILE == "music"


@router.message(Command("chart", "чарт"))
@router.message(Command("top"), _top_cmd)
async def cmd_chart(m: Message):
    await chart_list(m)


@router.message(Command("my", "mytracks"))
async def cmd_my(m: Message):
    await my_list(m, m.from_user.id)


@router.callback_query(F.data.in_({"mx:top", "mx:my"}))
async def cb_menu(cb: CallbackQuery):
    await cb.answer()
    if cb.data == "mx:top":
        await chart_list(cb.message)
    else:
        await my_list(cb.message, cb.from_user.id)


# ================= шазам → карточка трека =================
async def found_card(st: Message, artist: str, title: str, cover: str, link: str = ""):
    import hashlib
    t = catalog.track("sz", hashlib.md5(f"{artist}|{title}".encode()).hexdigest()[:12], artist, title, cover=cover)
    try:   # если есть в каталоге — берём оттуда: точная длительность, похожие, артист
        for c in await catalog.search(f"{artist} {title}", 5):
            if c["title"].lower().startswith(title.lower()[:12]) and artist.lower()[:6] in c["artist"].lower():
                t = {**c, "cover": c["cover"] or cover}
                break
    except Exception as e:
        log.info("shazam catalog: %s", e)
    await catalog.remember([t])
    text = f"🎵 <b>{escape(artist)}</b> — {escape(title)}"
    if t["album"]:
        text += f"\n💿 <i>{escape(t['album'])}</i>"
    if link:
        text += f'\n<a href="{escape(link, quote=True)}">shazam</a>'
    kb = kb_rows([("⬇️ Скачать трек", f"mx:get:{t['key']}"), ("📝 Текст", f"mx:ly:{t['key']}")],
                 [("🔁 Похожие", f"mx:sim:{t['key']}")])
    if t["cover"]:
        try:
            await st.answer_photo(t["cover"], caption=text, reply_markup=kb)
            return await st.delete()
        except TelegramBadRequest:
            pass
    await st.edit_text(text, reply_markup=kb)


# ================= 🎛 эффекты и 🎙 голосовым =================
async def _src(bot: Bot, key: str) -> str | None:
    """Файл трека с серверов Telegram (он уже скачан — значит, лежит в кэше)."""
    c = await db.dl_cache_get(f"audio:{key}")
    if not c:
        return None
    path = audiofx.tmp(".mp3")
    await bot.download(c["file_id"], destination=path)
    return path


def fx_kb(key: str):
    items = [(v[0], f"mx:fe:{k}:{key}") for k, v in audiofx.FX.items()]
    return kb_rows(items[:2], items[2:4], items[4:] + [("🎙 Голосовым", f"mx:fe:voice:{key}")],
                   [("‹ Назад", f"mx:back:{key}")])


@router.callback_query(F.data.startswith("mx:fx:"))
async def cb_fx(cb: CallbackQuery):
    try:
        await cb.message.edit_reply_markup(reply_markup=fx_kb(cb.data[6:]))
    except TelegramBadRequest:
        pass
    await cb.answer("выбери эффект")


@router.callback_query(F.data.startswith("mx:back:"))
async def cb_back(cb: CallbackQuery):
    key = cb.data[8:]
    t = await catalog.get(key)
    if t:
        try:
            await cb.message.edit_reply_markup(reply_markup=await _kb_for(t, cb.from_user.id))
        except TelegramBadRequest:
            pass
    await cb.answer()


@router.callback_query(F.data.startswith("mx:fe:"))
async def cb_fe(cb: CallbackQuery, bot: Bot):
    _, _, kind, key = cb.data.split(":", 3)
    uid = cb.from_user.id
    t = await catalog.get(key)
    if not t or (kind != "voice" and kind not in audiofx.FX):
        return await cb.answer("трек устарел", show_alert=True)
    if uid in _busy:
        return await cb.answer("⏳ ещё делаю прошлое", show_alert=True)
    cached = await db.dl_cache_get(f"fx:{kind}:{key}")
    if cached:
        await cb.answer()
        fn = cb.message.answer_voice if kind == "voice" else cb.message.answer_audio
        return await fn(cached["file_id"])
    import premium
    if kind != "voice" and not await premium.allow(uid, "fx"):
        await cb.answer()
        return await premium.upsell(cb.message, uid, "fx")
    await cb.answer("колдую… секунд 10–20" if kind != "voice" else "делаю голосовое…")
    _busy.add(uid)
    paths = []
    try:
        src = await _src(bot, key)
        if not src:
            return await cb.message.answer("сначала скачай трек — потом наложу эффект")
        paths.append(src)
        await bot.send_chat_action(cb.message.chat.id, ChatAction.UPLOAD_VOICE)
        if kind == "voice":
            out = await audiofx.voice(src, 0, 600)
            paths.append(out)
            sent = await cb.message.answer_voice(FSInputFile(out))
            fid = sent.voice.file_id if sent.voice else None
        else:
            out = await audiofx.effect(src, kind)
            paths.append(out)
            me = await bot.me()
            sent = await cb.message.answer_audio(
                FSInputFile(out), title=f"{t['title']} ({audiofx.FX[kind][1]})", performer=t["artist"] or None,
                caption=f'<a href="https://t.me/{me.username}">@{me.username}</a>' if me.username else None,
                thumbnail=await _thumb(t["cover"]))
            fid = sent.audio.file_id if sent.audio else None
        if fid:
            await db.dl_cache_put(f"fx:{kind}:{key}", kind, fid, catalog.name(t))
    except media_dl.DLError as e:
        await cb.message.answer(f"😕 не вышло: {escape(str(e))}")
    except TelegramBadRequest as e:
        await cb.message.answer(f"😕 телеграм не принял ({escape(str(e)[:60])})")
    finally:
        _busy.discard(uid)
        for p in paths:
            core.remove(p)


# ================= ✂️ рингтон =================
_ring: dict[int, tuple[str, float]] = {}   # uid → (key, когда спросили)


def ring_pending(m: Message) -> bool:
    r = _ring.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[1] < 600 and m.text and not m.text.startswith("/"))


@router.callback_query(F.data.startswith("mx:ring:"))
async def cb_ring(cb: CallbackQuery):
    key = cb.data[8:]
    t = await catalog.get(key)
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    _ring[cb.from_user.id] = (key, time.time())
    await cb.answer()
    d = catalog.mmss(t["dur"])
    await cb.message.answer(
        f"✂️ <b>рингтон из «{escape(t['title'])}»</b>" + (f" · {d}" if d else "") + "\n"
        f"напиши отрезок, например <code>0:45-1:15</code>\n"
        + ui.hint(f"до {audiofx.RING_MAX} секунд · пришлю mp3 для андроида и m4r для айфона"))


@router.message(ring_pending)
async def on_ring(m: Message, bot: Bot):
    key, _ = _ring.pop(m.from_user.id)
    span = audiofx.parse_span(m.text)
    if not span:
        _ring[m.from_user.id] = (key, time.time())
        return await m.reply("не поняла 🤔 напиши так: <code>0:45-1:15</code>")
    a, b = span
    if b - a > audiofx.RING_MAX:
        b = a + audiofx.RING_MAX
    t = await catalog.get(key)
    if t and t["dur"] and a >= t["dur"]:
        _ring[m.from_user.id] = (key, time.time())
        return await m.reply(f"трек длится всего {catalog.mmss(t['dur'])} 🙃 выбери отрезок внутри")
    paths = []
    try:
        src = await _src(bot, key)
        if not src:
            return await m.reply("сначала скачай трек 🙏")
        paths.append(src)
        st = await m.reply("✂️ режу…")
        mp3, m4r = await audiofx.ringtone(src, a, b)
        paths += [mp3, m4r]
        name_ = (t["title"] if t else "ringtone")[:40]
        await m.answer_audio(FSInputFile(mp3), title=f"{name_} (рингтон)", performer=(t or {}).get("artist") or None,
                             caption=f"🤖 андроид · {catalog.mmss(a) or '0:00'}–{catalog.mmss(b)}")
        await m.answer_document(FSInputFile(m4r, filename=f"{name_}.m4r"),
                                caption="🍏 айфон: сохрани в «Файлы» → GarageBand → поделиться → рингтон")
        await st.delete()
    except media_dl.DLError as e:
        await m.reply(f"😕 не вышло: {escape(str(e))}")
    finally:
        for p in paths:
            core.remove(p)


# ================= 🔔 новые релизы =================
@router.callback_query(F.data.startswith("mx:sub:"))
async def cb_sub(cb: CallbackQuery):
    t = await catalog.get(cb.data[7:])
    if not t or not t["artist"]:
        return await cb.answer("артист не найден", show_alert=True)
    try:
        found = (t["artist_id"], t["artist"]) if t["src"] == "dz" and t["artist_id"] else \
            await catalog.dz_artist_id(t["artist"].split(",")[0])
    except Exception as e:
        log.info("sub: %s", e)
        found = None
    if not found:
        return await cb.answer("не нашла артиста в каталоге релизов 😕", show_alert=True)
    aid, name_ = found
    import premium
    have = (await db.q_one("SELECT COUNT(*) n FROM music_subs WHERE uid=? AND artist_id!=?", cb.from_user.id, aid))["n"]
    if not premium.can_have(cb.from_user.id, "subs", have):
        await cb.answer()
        return await premium.upsell(cb.message, cb.from_user.id, "subs")
    await db.q_run("INSERT OR REPLACE INTO music_subs VALUES(?,?,?)", cb.from_user.id, aid, name_)
    if not await db.q_one("SELECT 1 FROM music_releases WHERE artist_id=?", aid):
        try:   # запоминаем текущий последний релиз, чтобы не прислать старьё
            last = await catalog.dz_latest(aid)
        except Exception:
            last = None
        await db.q_run("INSERT OR REPLACE INTO music_releases VALUES(?,?,?,?,?)", aid,
                       last["id"] if last else "", int(time.time()), last["title"] if last else "", name_)
    await cb.answer(f"🔔 напишу, когда у {name_} выйдет новое", show_alert=True)


async def subs_view(uid: int):
    rows = await db.q_all("SELECT artist_id, name FROM music_subs WHERE uid=? ORDER BY name", uid)
    if not rows:
        return ("🔔 <b>подписки на артистов</b>\n" + ui.hint("пока нет. открой артиста (👤 под треком) → «🔔 Следить»"),
                None)
    text = "🔔 <b>подписки на артистов</b>\n" + ui.hint("пришлю, когда выйдет новый трек или альбом · нажми, чтобы отписаться")
    return text, kb_rows(*[[(f"🔕 {r['name'][:30]}", f"mx:uns:{r['artist_id']}")] for r in rows[:40]])


@router.message(Command("subs", "подписки"))
async def cmd_subs(m: Message):
    text, kb = await subs_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("mx:uns:"))
async def cb_uns(cb: CallbackQuery):
    await db.q_run("DELETE FROM music_subs WHERE uid=? AND artist_id=?", cb.from_user.id, cb.data[7:])
    text, kb = await subs_view(cb.from_user.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer("отписала")


@router.callback_query(F.data.startswith("mx:rl:"))
async def cb_release(cb: CallbackQuery):
    r = await db.q_one("SELECT * FROM music_releases WHERE artist_id=?", cb.data[6:])
    if not r:
        return await cb.answer("релиз устарел", show_alert=True)
    await cb.answer("ищу…")
    await show_list(cb.message, f"🆕 <b>{escape(r['name'] or '')}</b> — {escape(r['title'] or '')}",
                    await catalog.search(f"{r['name']} {r['title']}", 16))


RELEASE_EVERY = 6 * 3600
FRESH_DAYS = 21


async def check_releases(bot: Bot) -> int:
    import datetime as dt
    sent = 0
    arts = await db.q_all("SELECT DISTINCT s.artist_id, s.name FROM music_subs s")
    for a in arts:
        try:
            last = await catalog.dz_latest(a["artist_id"])
        except Exception as e:
            log.info("release %s: %s", a["name"], e)
            continue
        await asyncio.sleep(1)
        if not last:
            continue
        old = await db.q_one("SELECT last_id FROM music_releases WHERE artist_id=?", a["artist_id"])
        if old and old["last_id"] == last["id"]:
            continue
        await db.q_run("INSERT OR REPLACE INTO music_releases VALUES(?,?,?,?,?)", a["artist_id"], last["id"],
                       int(time.time()), last["title"], a["name"])
        try:
            fresh = dt.date.fromisoformat(last["date"]) >= dt.date.today() - dt.timedelta(days=FRESH_DAYS)
        except ValueError:
            fresh = False
        if not old or not fresh:
            continue
        kind = {"single": "сингл", "album": "альбом", "ep": "EP"}.get(last["type"], "релиз")
        text = f"🔔 <b>новый {kind}!</b>\n🎤 {escape(a['name'])} — <b>{escape(last['title'])}</b>\n📅 {last['date']}"
        kb = kb_rows([("🎵 Слушать", f"mx:rl:{a['artist_id']}")])
        for u in await db.q_all("SELECT uid FROM music_subs WHERE artist_id=?", a["artist_id"]):
            try:
                if last["cover"]:
                    await bot.send_photo(u["uid"], last["cover"], caption=text, reply_markup=kb)
                else:
                    await bot.send_message(u["uid"], text, reply_markup=kb)
                sent += 1
            except Exception as e:
                log.info("release send: %s", e)
            await asyncio.sleep(0.05)
    return sent


async def release_loop(bot: Bot):
    await asyncio.sleep(120)
    while True:
        try:
            await check_releases(bot)
        except Exception as e:
            log.warning("releases: %s", e)
        await asyncio.sleep(RELEASE_EVERY)
