"""Характер: режимы личности (/mode) и поиск в интернете («соня, загугли …»)."""
import logging
import re
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery

import db
import limits
import llm
import persona
import ui
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("character")


# ================= режимы личности =================
async def mode_view(uid: int) -> tuple[str, object]:
    from handlers import extra
    u = await db.get_user(uid) or {}
    cur = u.get("mode") or "base"
    plus = extra.active(uid)
    lines = [ui.head("🎭", "Мой характер", "каким тоном мне с тобой говорить")]
    rows = []
    for k, (btn, _p, paid) in persona.MODES.items():
        mark = "✅ " if k == cur else ""
        lock = " ✨" if paid and not plus else ""
        rows.append((f"{mark}{btn}{lock}", f"md:{k}"))
    lines.append(ui.quote(f"сейчас: <b>{persona.MODES.get(cur, persona.MODES['base'])[0]}</b>"))
    lines.append(ui.hint("✨ — режимы с Соней+ (/plus)"))
    return "\n".join(lines), kb_rows(rows[:3], rows[3:], [("‹ Меню", "m:home")])


@router.message(Command("mode", "характер"))
async def cmd_mode(m: Message):
    text, kb = await mode_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data == "m:mode")
async def cb_mode_menu(cb: CallbackQuery):
    text, kb = await mode_view(cb.from_user.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        await cb.message.answer(text, reply_markup=kb)
    await cb.answer()


@router.callback_query(F.data.startswith("md:"))
async def cb_mode(cb: CallbackQuery):
    from handlers import extra
    k = cb.data[3:]
    if k not in persona.MODES:
        return await cb.answer()
    if persona.MODES[k][2] and not extra.active(cb.from_user.id):
        return await cb.answer("этот режим — с Соней+ ✨ /plus", show_alert=True)
    await db.q_run("UPDATE users SET mode=? WHERE id=?", k, cb.from_user.id)
    await cb.answer(f"теперь я {persona.MODES[k][0]}")
    text, kb = await mode_view(cb.from_user.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass


# ================= поиск в интернете =================
SEARCH_RE = re.compile(r"^(?:загугли|погугли|найди в (?:интернете|инете|сети|гугле)|поищи в (?:интернете|инете|сети)|"
                       r"что пишут (?:про|о|об))\s*[:,-]?\s*(.+)$", re.I | re.S)


async def web_search(m: Message, bot: Bot, q: str):
    q = q.strip()
    if len(q) < 3:
        return await m.reply("что ищем? <code>/search курс биткоина сегодня</code>")
    if not await limits.take(m.from_user.id):
        return await m.reply(limits.tired_text(m.from_user.id))
    await bot.send_chat_action(m.chat.id, ChatAction.TYPING)
    st = await m.reply("🔎 гуглю…")
    try:
        out = await llm.search(q)
    except Exception as e:
        log.info("search: %s", e)
        await limits.give_back(m.from_user.id)
        return await st.edit_text("😕 поиск сейчас не работает, попробуй позже")
    try:
        await st.edit_text(f"🔎 <b>{escape(q[:100])}</b>\n\n{escape(out[:3800])}", disable_web_page_preview=True)
    except TelegramBadRequest:
        await m.reply(out[:4000], parse_mode=None)


@router.message(Command("search", "google", "гугл"))
async def cmd_search(m: Message, bot: Bot, command: CommandObject):
    await web_search(m, bot, command.args or "")


async def _search_said(m: Message, bot: Bot) -> bool | dict:
    if not m.text or m.text.startswith("/"):
        return False
    from handlers import chat
    me = await bot.me()
    text = chat._addressed(m, me.id, me.username or "")
    mt = SEARCH_RE.match(text.strip()) if text else None
    return {"q": mt.group(1)} if mt else False


@router.message(_search_said)
async def on_search_said(m: Message, bot: Bot, q: str):
    await web_search(m, bot, q)
