"""ИИ-игры: 🧞 Акинатор, 🐊 крокодил с картинкой, 🎭 правда или действие, 🎵 песня по эмодзи."""
import asyncio
import json
import logging
import random
import re
import time
import uuid
from html import escape
from urllib.parse import quote

from aiogram import Router, F, Bot
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, BufferedInputFile

import db
import limits
import llm
from handlers import games
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("aigames")
GROUPS = {"group", "supergroup"}


def _json(text: str) -> dict:
    m = re.search(r"\{.*\}", text or "", re.S)
    return json.loads(m.group(0)) if m else {}


# ================= 🧞 Акинатор =================
AKI_MAX = 20
AKI_PRIZE = 30
AKI_SYS = ("Ты Соня и играешь в Акинатора: собеседник загадал известного персонажа или человека (реального или "
           "вымышленного). Задавай вопросы, на которые можно ответить да/нет. Когда уверена (или вопросов почти не "
           "осталось) — называй догадку. Вопросы короткие, по-русски, с лёгкой иронией. "
           "Ответ строго JSON: {\"q\": \"вопрос\"} или {\"guess\": \"имя персонажа\"}.")
ANS = {"y": "да", "n": "нет", "p": "скорее да", "m": "скорее нет", "u": "не знаю"}
_aki: dict[str, dict] = {}


def aki_kb(gid: str):
    return kb_rows([("✅ Да", f"ak:{gid}:y"), ("❌ Нет", f"ak:{gid}:n"), ("🤷 Не знаю", f"ak:{gid}:u")],
                   [("👍 Скорее да", f"ak:{gid}:p"), ("👎 Скорее нет", f"ak:{gid}:m")])


async def aki_step(g: dict) -> dict:
    msgs = [{"role": "system", "content": AKI_SYS}]
    for q, a in g["log"]:
        msgs += [{"role": "assistant", "content": json.dumps({"q": q}, ensure_ascii=False)},
                 {"role": "user", "content": a}]
    left = AKI_MAX - len(g["log"])
    msgs.append({"role": "user", "content": f"Осталось вопросов: {left}. Не повторяйся. "
                                            + ("Сейчас обязательно назови догадку." if left <= 1 else "")
                                            + (f" Уже ошиблась с: {', '.join(g['wrong'])}." if g["wrong"] else "")})
    return _json(await llm.ask(msgs, max_tokens=500, temperature=0.7, feature="aki"))


async def aki_send(target: Message, g: dict, edit: bool):
    if g.get("guess"):
        text = f"🧞 <b>я думаю, это… {escape(g['guess'])}!</b>\nугадала?"
        kb = kb_rows([("🎉 Да!", f"ak:{g['id']}:win"), ("😏 Нет", f"ak:{g['id']}:lose")])
    else:
        text = f"🧞 <b>вопрос {len(g['log']) + 1}/{AKI_MAX}</b>\n{escape(g['q'])}"
        kb = aki_kb(g["id"])
    if edit:
        try:
            return await target.edit_text(text, reply_markup=kb)
        except TelegramBadRequest:
            pass
    await target.answer(text, reply_markup=kb)


async def aki_next(target: Message, g: dict, uid: int, edit: bool):
    if not await limits.take(uid):
        return await target.answer(limits.tired_text(uid))
    try:
        step = await aki_step(g)
    except Exception as e:
        log.info("aki: %s", e)
        await limits.give_back(uid)
        return await target.answer("🧞 лампа барахлит — попробуй ещё раз чуть позже")
    if step.get("guess") or not step.get("q") or len(g["log"]) >= AKI_MAX:
        g["guess"] = str(step.get("guess") or "кто-то, кого я не знаю")[:80]
    else:
        g["q"], g["guess"] = str(step["q"])[:200], None
    await games._put("aki", g["id"], g)
    await aki_send(target, g, edit)


@router.message(Command("aki", "акинатор"))
async def cmd_aki(m: Message):
    g = {"id": uuid.uuid4().hex[:8], "uid": m.from_user.id, "log": [], "wrong": [], "q": "", "guess": None}
    _aki[g["id"]] = g
    await m.answer("🧞 загадай персонажа — реального или выдуманного. я угадаю за 20 вопросов 😏")
    await aki_next(m, g, m.from_user.id, False)


@router.callback_query(F.data.startswith("ak:"))
async def cb_aki(cb: CallbackQuery):
    _, gid, a = cb.data.split(":")
    g = await games._get("aki", gid, _aki)
    if not g:
        return await cb.answer("игра закончилась")
    if cb.from_user.id != g["uid"]:
        return await cb.answer("это не твоя игра — начни свою: /aki", show_alert=True)
    if a == "win":
        _aki.pop(gid, None)
        await games._drop("aki", gid)
        db.emit("game", g["uid"])
        await cb.answer("😎")
        return await cb.message.edit_text(f"🧞 конечно, это <b>{escape(g['guess'])}</b>. я всегда угадываю 😎\n"
                                          f"вопросов понадобилось: {len(g['log'])}",
                                          reply_markup=kb_rows([("🧞 Ещё раз", "g:aki")]))
    if a == "lose":
        g["wrong"].append(g["guess"])
        if len(g["log"]) >= AKI_MAX or len(g["wrong"]) >= 3:
            _aki.pop(gid, None)
            await games._drop("aki", gid)
            await db.add_coins(g["uid"], AKI_PRIZE, win=True)
            db.emit("game", g["uid"])
            await cb.answer("сдаюсь 😤")
            return await cb.message.edit_text(f"🧞 сдаюсь, ты меня обыграл(а)! +{AKI_PRIZE} 🪙\nкто это был?",
                                              reply_markup=kb_rows([("🧞 Ещё раз", "g:aki")]))
        g["log"].append((f"Это {g['guess']}?", "нет"))
        g["guess"] = None
        await cb.answer("хм…")
        return await aki_next(cb.message, g, cb.from_user.id, True)
    if a not in ANS or g.get("guess"):
        return await cb.answer()
    g["log"].append((g["q"], ANS[a]))
    await cb.answer("думаю…")
    await aki_next(cb.message, g, cb.from_user.id, True)


@router.callback_query(F.data == "g:aki")
async def cb_aki_new(cb: CallbackQuery):
    await cb.answer()
    g = {"id": uuid.uuid4().hex[:8], "uid": cb.from_user.id, "log": [], "wrong": [], "q": "", "guess": None}
    _aki[g["id"]] = g
    await cb.message.answer("🧞 загадай персонажа — я угадаю за 20 вопросов 😏")
    await aki_next(cb.message, g, cb.from_user.id, False)


# ================= 🎭 правда или действие =================
TRUTH = ["какую песню ты слушаешь втайне от всех?", "самая неловкая ситуация в твоей жизни?",
         "кого из чата ты бы взял(а) на необитаемый остров?", "что ты гуглил(а) последним?",
         "какой у тебя самый странный страх?", "о чём ты врал(а) родителям чаще всего?",
         "твоя самая бесполезная суперспособность?", "чей номер ты бы удалил(а) первым?",
         "что ты делаешь, когда никто не видит?", "самая дурацкая покупка?",
         "кто был твоей первой любовью?", "какое у тебя guilty pleasure?",
         "за что тебе до сих пор стыдно?", "какую привычку ты скрываешь?", "кого ты сталкеришь в соцсетях?"]
DARE = ["пришли последнее фото из галереи", "запиши голосовое с пением припева любимой песни",
        "напиши комплимент следующему, кто напишет в чат", "смени аватарку на картофель на час",
        "расскажи анекдот (смешной!)", "напиши своё имя носом на клавиатуре", "пришли самый старый стикер",
        "признайся в любви Соне голосовым 🖤", "опиши свой день тремя эмодзи", "скинь скрин экрана прямо сейчас",
        "напиши стих из четырёх строк про чат", "поставь странный статус на час", "кинь свой любимый мем"]


def pd_kb():
    return kb_rows([("🤫 Правда", "pd:t"), ("🔥 Действие", "pd:d")])


@router.message(Command("pd", "truth", "правда"))
async def cmd_pd(m: Message):
    await m.answer("🎭 <b>правда или действие?</b>", reply_markup=pd_kb())


@router.callback_query(F.data.in_({"pd:t", "pd:d", "g:pd"}))
async def cb_pd(cb: CallbackQuery):
    await cb.answer()
    if cb.data == "g:pd":
        return await cb.message.answer("🎭 <b>правда или действие?</b>", reply_markup=pd_kb())
    truth = cb.data == "pd:t"
    task = random.choice(TRUTH if truth else DARE)
    name = escape(cb.from_user.first_name or "ты")
    await cb.message.answer(f"{'🤫 правда' if truth else '🔥 действие'} для <b>{name}</b>:\n{task}",
                            reply_markup=pd_kb())
    db.emit("game", cb.from_user.id)


# ================= 🐊 крокодил с картинкой =================
CROC_WORDS = ("кот пицца ракета зонт пингвин дракон торт велосипед маяк кактус робот замок радуга вулкан "
              "медуза снеговик гитара жираф корона подводная-лодка единорог воздушный-шар паук-мститель "
              "чайник ёлка динозавр осьминог самурай пират космонавт лампа-джинна вертолёт черепаха "
              "мороженое фламинго привидение").split()
CROC_SEC = 180
CROC_PRIZE = 25
_croc: dict[int, dict] = {}   # chat_id → {"word", "ts", "msg"}


def guessed(word: str, text: str) -> bool:
    """Слово целиком, без учёта регистра, ё и дефисов: «кот» ≠ «который»."""
    w = re.escape(word.lower().replace("ё", "е")).replace(r"\ ", r"[\s-]+")
    return bool(re.search(rf"(?<![а-яa-z]){w}(?![а-яa-z])", text.lower().replace("ё", "е")))


async def croc_start(m: Message, bot: Bot):
    if m.chat.type not in GROUPS:
        return await m.answer("🐊 крокодил — игра для группы: я рисую, все угадывают")
    if m.chat.id in _croc and time.time() - _croc[m.chat.id]["ts"] < CROC_SEC:
        return await m.answer("🐊 уже угадываем! смотрите на картинку выше")
    word = random.choice(CROC_WORDS).replace("-", " ")
    seed = random.randint(1, 10 ** 6)
    from handlers import tools
    url = (f"https://image.pollinations.ai/prompt/{quote(word + ', simple cartoon illustration, no text')}"
           f"?width=640&height=640&nologo=true&seed={seed}")
    hint = f"{len(word.replace(' ', ''))} букв, начинается на «{word[0].upper()}»"
    g = {"word": word, "ts": time.time()}
    _croc[m.chat.id] = g
    await games._put("croc", str(m.chat.id), g)
    try:
        data = await tools.fetch_image(url)
        await m.answer_photo(BufferedInputFile(data, "croc.jpg"),
                             caption=f"🐊 <b>что я нарисовала?</b> пишите ответ в чат\n<i>подсказка: {hint}</i>")
    except Exception as e:
        log.info("croc image: %s", e)
        await m.answer(f"🐊 кисточка сломалась, играем на словах: угадайте слово — {hint}")
    asyncio.create_task(_croc_timeout(bot, m.chat.id, g))


async def _croc_timeout(bot: Bot, chat_id: int, g: dict):
    await asyncio.sleep(CROC_SEC)
    if _croc.get(chat_id) is g:
        _croc.pop(chat_id, None)
        await games._drop("croc", str(chat_id))
        try:
            await bot.send_message(chat_id, f"⌛ никто не угадал! это был(а) <b>{escape(g['word'])}</b>",
                                   reply_markup=kb_rows([("🐊 Ещё раз", "g:croc")]))
        except Exception:
            pass


async def load():
    """После перезапуска: поднять незавершённые крокодилы (таймер начнётся заново)."""
    for r in await db.q_all("SELECT id, data FROM game_state WHERE kind='croc'"):
        try:
            _croc[int(r["id"].split(":", 1)[1])] = json.loads(r["data"])
        except (ValueError, IndexError):
            pass


def _croc_guess(m: Message) -> bool:
    g = _croc.get(m.chat.id) if m.chat.type in GROUPS else None
    return bool(g and m.text and guessed(g["word"], m.text) and time.time() - g["ts"] < CROC_SEC + 600)


@router.message(F.text, _croc_guess)
async def on_croc_guess(m: Message):
    g = _croc.pop(m.chat.id, None)
    if not g:
        return
    await games._drop("croc", str(m.chat.id))
    bal = await db.add_coins(m.from_user.id, CROC_PRIZE, win=True)
    db.emit("game", m.from_user.id)
    await m.reply(f"🎉 да! это <b>{escape(g['word'])}</b>. {games.name_of(m.from_user)} +{CROC_PRIZE} 🪙 (всего {bal})",
                  reply_markup=kb_rows([("🐊 Ещё раз", "g:croc")]))


@router.message(Command("croc", "крокодил"))
async def cmd_croc(m: Message, bot: Bot):
    await croc_start(m, bot)


@router.callback_query(F.data == "g:croc")
async def cb_croc(cb: CallbackQuery, bot: Bot):
    if cb.message.chat.type not in GROUPS:
        return await cb.answer("🐊 крокодил — для группы", show_alert=True)
    await cb.answer()
    await croc_start(cb.message, bot)


# ================= 🎵 песня по эмодзи =================
EMOJI_LOCAL = [("🌊🚢💔🎻", ["My Heart Will Go On", "Titanium", "Believer", "Shape of You"], 0),
               ("🐝👑💛", ["Formation", "Halo", "Queen Bee", "Single Ladies"], 2),
               ("❄️👸🏼🚪", ["Let It Go", "Frozen Heart", "Snowman", "Ice Ice Baby"], 0),
               ("🌧💜", ["Purple Rain", "Purple Haze", "Rain on Me", "Umbrella"], 0),
               ("🚀👨‍🚀🌑", ["Rocket Man", "Space Oddity", "Starman", "Moonlight"], 1)]


async def make_emoji_quiz() -> tuple[str, list[str], int, str]:
    try:
        out = await llm.ask([{"role": "system", "content":
                              "Загадай известную песню (русскую или зарубежную) с помощью 3–5 эмодзи. "
                              "Ответ строго JSON: {\"emoji\": \"…\", \"options\": [4 варианта «Исполнитель — Песня»], "
                              "\"answer\": индекс 0-3, \"fact\": \"короткий факт о песне\"}. Только JSON."},
                             {"role": "user", "content": f"Случайное число: {random.randint(1, 99999)}"}],
                            max_tokens=500, temperature=1.0, feature="quiz")
        d = _json(out)
        opts = [str(o)[:40] for o in d["options"]][:4]
        ans = int(d["answer"])
        if len(opts) == 4 and 0 <= ans < 4 and d.get("emoji"):
            return f"🎵 угадай песню: {d['emoji']}", opts, ans, str(d.get("fact") or "")[:200]
    except Exception:
        pass
    e, opts, ans = random.choice(EMOJI_LOCAL)
    return f"🎵 угадай песню: {e}", opts, ans, ""


@router.message(Command("emoji", "эмодзи"))
async def cmd_emoji(m: Message):
    await games.send_quiz(m, make_emoji_quiz)


@router.callback_query(F.data == "g:emoji")
async def cb_emoji(cb: CallbackQuery):
    await cb.answer("загадываю…")
    await games.send_quiz(cb.message, make_emoji_quiz)
