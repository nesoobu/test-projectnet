"""Напоминания: «напомни через 2 часа выпить воды», «каждый день в 9:00 зарядка»."""
import asyncio
import logging
import re
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandObject
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError

import db
import ui
from autopost import timeparse
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("remind")
MAX_ACTIVE = 30
WORDS_NUM = {"час": "1ч", "полчаса": "30м", "минуту": "1м", "день": "1д", "неделю": "7д"}


def _norm(t: str) -> str:
    t = t.lower().replace("ё", "е")
    t = re.sub(r"\bчерез\s+(час|полчаса|минуту|день|неделю)\b", lambda m: "через " + WORDS_NUM[m.group(1)], t)
    t = re.sub(r"\bчерез\s+(\d+)\s+", r"через \1", t)       # «через 2 часа» → «через 2часа»
    t = re.sub(r"\b(сегодня|завтра|послезавтра)\s+в\s+", r"\1 ", t)
    t = re.sub(r"^в\s+(\d{1,2}[:.]\d{2})", r"\1", t)
    t = re.sub(r"\b(\d{1,2}\.\d{1,2})\s+в\s+", r"\1 ", t)
    return t


def split_time(text: str) -> tuple[int | None, str, int]:
    """«каждый день в 9:00 зарядка» → (ts, «зарядка», 24). Пробует самый длинный префикс-время."""
    orig = text.strip()
    repeat = 0
    m = re.match(r"^каждый\s+день\s+(в\s+)?", orig, re.I)
    if m:
        repeat, orig = 24, orig[m.end():]
    owords = orig.split()
    for k in range(min(5, len(owords)), 0, -1):  # самый длинный префикс, который читается как время
        ts = timeparse.parse(_norm(" ".join(owords[:k])))
        if ts:
            body = " ".join(owords[k:]).strip(" ,.-—:")
            return ts, body, repeat
    return None, text, repeat


HINT = ("<b>⏰ напоминания</b>\n"
        "<code>/remind через 30 минут чайник</code>\n"
        "<code>/remind завтра в 10:00 созвон</code>\n"
        "<code>/remind 25.12 18:00 купить подарки</code>\n"
        "<code>/remind каждый день в 9:00 зарядка</code>\n"
        "или просто: «соня, напомни через 2 часа выпить воды»\n"
        "/reminders — мои напоминания")


async def create(m: Message, raw: str):
    if not raw.strip():
        return await m.reply(HINT)
    ts, body, rep = split_time(raw)
    if not ts:
        return await m.reply("не поняла, когда напомнить 🤔\n\n" + HINT)
    if not body:
        body = "ты просил напомнить 🙂"
    n = await db.q_one("SELECT COUNT(*) n FROM reminders WHERE uid=? AND done=0", m.from_user.id)
    if n["n"] >= MAX_ACTIVE:
        return await m.reply(f"у тебя уже {MAX_ACTIVE} напоминаний — удали лишние в /reminders")
    await db.q_run("INSERT INTO reminders(uid,chat_id,at,text,repeat_h) VALUES(?,?,?,?,?)",
                   m.from_user.id, m.chat.id, ts, body[:500], rep)
    rep_t = " · 🔁 каждый день" if rep else ""
    await m.reply(f"⏰ напомню <b>{timeparse.fmt(ts)}</b>{rep_t}\n<i>{escape(body[:200])}</i>")


@router.message(Command("remind", "напомни"))
async def cmd_remind(m: Message, command: CommandObject):
    await create(m, command.args or "")


async def list_view(uid: int):
    rows = await db.q_all("SELECT * FROM reminders WHERE uid=? AND done=0 ORDER BY at LIMIT 20", uid)
    lines = ["<b>⏰ мои напоминания</b>", ui.LINE]
    if not rows:
        lines.append("<i>пусто. «соня, напомни через час …»</i>")
    btns = []
    for r in rows:
        rep = "🔁 " if r["repeat_h"] else ""
        lines.append(f"{rep}<b>{timeparse.fmt(r['at'])}</b> — {escape(r['text'][:60])}")
        btns.append([(f"🗑 {timeparse.fmt(r['at'])} {r['text'][:20]}", f"rm:del:{r['id']}")])
    return "\n".join(lines), kb_rows(*btns) if btns else None


@router.message(Command("reminders", "напоминания"))
async def cmd_list(m: Message):
    text, kb = await list_view(m.from_user.id)
    await m.reply(text, reply_markup=kb)


@router.callback_query(F.data.startswith("rm:del:"))
async def cb_del(cb: CallbackQuery):
    rid = int(cb.data.split(":")[2])
    await db.q_run("UPDATE reminders SET done=1 WHERE id=? AND uid=?", rid, cb.from_user.id)
    text, kb = await list_view(cb.from_user.id)
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer("удалено")


SNOOZE = {"10": (10, "через 10 минут"), "60": (60, "через час"), "15": (15, "через 15 минут")}


def snooze_kb(rid: int):
    return kb_rows([("💤 10 мин", f"rm:snz:{rid}:10"), ("⏰ 1 час", f"rm:snz:{rid}:60"),
                    ("📅 Завтра", f"rm:snz:{rid}:tm")], [("✅ Готово", f"rm:ok:{rid}")])


@router.callback_query(F.data.startswith("rm:snz:"))
async def cb_snooze(cb: CallbackQuery):
    parts = cb.data.split(":")
    rid = int(parts[2])
    how = parts[3] if len(parts) > 3 else "15"   # старые кнопки — 15 минут
    r = await db.q_one("SELECT * FROM reminders WHERE id=? AND uid=?", rid, cb.from_user.id)
    if not r:
        return await cb.answer("это не твоё напоминание", show_alert=True)
    if how == "tm":   # завтра в то же время
        ts = int(time.time()) + 86400
        label = "завтра в это же время"
    else:
        mins, label = SNOOZE.get(how, SNOOZE["15"])
        ts = int(time.time()) + mins * 60
    await db.q_run("INSERT INTO reminders(uid,chat_id,at,text) VALUES(?,?,?,?)", r["uid"], r["chat_id"], ts, r["text"])
    await cb.answer(f"напомню {label}")
    try:
        await cb.message.edit_text(cb.message.html_text + f"\n<i>💤 отложено — {label}</i>", reply_markup=None)
    except (TelegramBadRequest, AttributeError):
        pass


@router.callback_query(F.data.startswith("rm:ok:"))
async def cb_done(cb: CallbackQuery):
    rid = int(cb.data.split(":")[2])
    if not await db.q_one("SELECT 1 FROM reminders WHERE id=? AND uid=?", rid, cb.from_user.id):
        return await cb.answer("это не твоё напоминание", show_alert=True)
    await cb.answer("умничка ✨")
    try:
        await cb.message.edit_text(cb.message.html_text + "\n<i>✅ сделано</i>", reply_markup=None)
    except (TelegramBadRequest, AttributeError):
        pass


async def tick(bot: Bot):
    now = int(time.time())
    for r in await db.q_all("SELECT * FROM reminders WHERE done=0 AND at<=? LIMIT 50", now):
        if r["repeat_h"]:
            nxt = r["at"] + r["repeat_h"] * 3600
            while nxt <= now:
                nxt += r["repeat_h"] * 3600
            await db.q_run("UPDATE reminders SET at=? WHERE id=?", nxt, r["id"])
        else:
            await db.q_run("UPDATE reminders SET done=1 WHERE id=?", r["id"])
        mention = "" if r["chat_id"] == r["uid"] else f'<a href="tg://user?id={r["uid"]}">⏰</a> '
        try:
            await bot.send_message(r["chat_id"], f"{mention}⏰ <b>напоминаю:</b> {escape(r['text'])}",
                                   reply_markup=snooze_kb(r["id"]))
        except (TelegramForbiddenError, TelegramBadRequest) as e:
            log.info("remind %s: %s", r["id"], e)


async def loop(bot: Bot):
    while True:
        try:
            await tick(bot)
        except Exception:
            log.exception("remind tick")
        await asyncio.sleep(20)
