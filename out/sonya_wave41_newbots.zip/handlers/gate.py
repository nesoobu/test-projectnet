"""Обязательная подписка на канал владельца (REQUIRED_CHANNEL в .env)."""
import logging
import time

from aiogram import BaseMiddleware, Bot, Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

import config

router = Router()
log = logging.getLogger("gate")
OK_TTL = 1800          # подписан — не проверяем полчаса
_ok: dict[int, float] = {}
_broken = [0.0]        # бот не может проверить (не админ в канале) — пускаем всех, напоминаем владельцу


def channel_link() -> str:
    ch = config.REQUIRED_CHANNEL
    return f"https://t.me/{ch.lstrip('@')}" if ch.startswith("@") else ch if ch.startswith("http") else ""


async def subscribed(bot: Bot, uid: int) -> bool:
    if uid == config.OWNER_ID or time.time() - _ok.get(uid, 0) < OK_TTL:
        return True
    try:
        m = await bot.get_chat_member(config.REQUIRED_CHANNEL, uid)
    except Exception as e:
        if time.time() - _broken[0] > 3600:
            _broken[0] = time.time()
            log.error("обязательная подписка не работает: не могу проверить %s (%s) — сделай бота админом канала",
                      config.REQUIRED_CHANNEL, e)
        return True
    if m.status in ("left", "kicked"):
        return False
    _ok[uid] = time.time()
    return True


def gate_kb():
    rows = []
    if channel_link():
        rows.append([InlineKeyboardButton(text="📢 Подписаться", url=channel_link())])
    rows.append([InlineKeyboardButton(text="✅ Я подписался", callback_data="sub:check")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


GATE_TEXT = "🖤 чтобы пользоваться Соней, подпишись на канал — там новости и обновления. потом жми «✅ Я подписался»"


class SubGate(BaseMiddleware):
    async def __call__(self, handler, event, data):
        if not config.REQUIRED_CHANNEL:
            return await handler(event, data)
        u = getattr(event, "from_user", None)
        if not u or u.is_bot:
            return await handler(event, data)
        if isinstance(event, Message):
            if (event.chat.type != "private" or event.successful_payment
                    or (event.text or "").startswith("/start")):   # /start пускаем: рефералка и меню
                return await handler(event, data)
        elif isinstance(event, CallbackQuery):
            if event.data == "sub:check" or not event.message or event.message.chat.type != "private":
                return await handler(event, data)
        else:
            return await handler(event, data)
        if await subscribed(data["bot"], u.id):
            return await handler(event, data)
        if isinstance(event, CallbackQuery):
            return await event.answer("сначала подпишись на канал 🙏", show_alert=True)
        await event.answer(GATE_TEXT, reply_markup=gate_kb())


@router.callback_query(F.data == "sub:check")
async def cb_check(cb: CallbackQuery, bot: Bot):
    _ok.pop(cb.from_user.id, None)
    if await subscribed(bot, cb.from_user.id):
        await cb.answer("спасибо! 🖤")
        try:
            await cb.message.edit_text("✅ подписка есть — пиши, я тут 🖤")
        except Exception:
            pass
    else:
        await cb.answer("не вижу подписки 👀 подпишись и нажми ещё раз", show_alert=True)
