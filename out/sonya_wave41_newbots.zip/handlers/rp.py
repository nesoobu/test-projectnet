"""Группы: РП-действия ответом («обнять», «кусь»…) и «… дня» — пара дня и звезда дня."""
import logging
import random
import re
import time
from html import escape

from aiogram import Router, Bot
from aiogram.filters import Command
from aiogram.types import Message

import db
import ui

router = Router()
log = logging.getLogger("rp")
GROUPS = {"group", "supergroup"}

# слово в начале сообщения → (эмодзи, что произошло). Формат «A → B · действие» — без падежей и родов
ACTIONS = [
    (r"обнять|обнимаю|обнимашки", "🤗", "обнимашки"),
    (r"поцеловать|чмок|целую", "😘", "чмок"),
    (r"укусить|кусь", "😬", "кусь!"),
    (r"погладить|глажу", "🫳", "погладили по голове"),
    (r"дать пять|дай пять", "🙌", "дай пять!"),
    (r"пнуть|пинок", "🦶", "пинок"),
    (r"ударить|леща|подзатыльник", "🫲", "лёгкий подзатыльник"),
    (r"похвалить|хвалю", "👏", "похвала"),
    (r"пожать руку|рукопожатие", "🤝", "крепкое рукопожатие"),
    (r"прижать|прижаться", "🫂", "крепко прижали к себе"),
    (r"попить чай|на чай|чаю\?", "☕", "зовут на чай"),
    (r"цветы|подарить цветы", "🌷", "дарят цветы"),
    (r"тыкнуть|тык", "👉", "тык"),
    (r"испугать|бу", "👻", "БУ!"),
    (r"накормить|покормить", "🍕", "кормят пиццей"),
    (r"уложить спать", "😴", "укладывают спать"),
]
_RX = [(re.compile(rf"^(?:{pat})(?:\s+(.{{1,60}}))?$", re.I | re.S), emo, act) for pat, emo, act in ACTIONS]


def _link(u) -> str:
    return f'<a href="tg://user?id={u.id}">{escape(u.first_name or "кто-то")}</a>'


def rp_match(text: str) -> tuple[str, str, str] | None:
    t = (text or "").strip().lower().replace("ё", "е")
    for rx, emo, act in _RX:
        mt = rx.match(t)
        if mt:
            return emo, act, (mt.group(1) or "").strip()
    return None


async def _rp_filter(m: Message, bot: Bot) -> bool | dict:
    if m.chat.type not in GROUPS or not m.text or not m.reply_to_message or not m.reply_to_message.from_user:
        return False
    target = m.reply_to_message.from_user
    if target.id == m.from_user.id:
        return False
    hit = rp_match(m.text)
    if not hit or not await db.chat_flag(m.chat.id, "rp"):
        return False
    return {"rp": hit}


@router.message(_rp_filter)
async def on_rp(m: Message, bot: Bot, rp: tuple):
    emo, act, note = rp
    target = m.reply_to_message.from_user
    me = await bot.me()
    if target.id == me.id:
        act += random.choice([" — соня смущена 🙈", " — соня не против 🖤", " — эй, полегче 😳"])
    text = f"{emo} {_link(m.from_user)} → {_link(target)} · {act}"
    if note:
        text += f"\n<i>«{escape(note)}»</i>"
    await m.answer(text)


# ================= «… дня» =================
async def _active(chat_id: int) -> list[dict]:
    week = int(time.time()) - 7 * 86400
    return await db.q_all("SELECT u.id, u.name FROM chat_members cm JOIN users u ON u.id=cm.uid "
                          "WHERE cm.chat_id=? AND cm.last>? AND u.banned=0", chat_id, week)


async def day_pick(chat_id: int, kind: str, n: int) -> list[dict] | None:
    """Выбор на день: один раз в сутки (МСК) на чат, дальше показываем того же."""
    key = f"day:{kind}:{chat_id}:{db._day()}"
    saved = await db.kv_get(key)
    if saved:
        ids = [int(x) for x in saved.split(",")]
        users = [await db.get_user(i) for i in ids]
        if all(users):
            return users
    pool = await _active(chat_id)
    if len(pool) < n:
        return None
    pick = random.sample(pool, n)
    await db.kv_set(key, ",".join(str(p["id"]) for p in pick))
    return pick


def _ulink(u: dict) -> str:
    return f'<a href="tg://user?id={u["id"]}">{escape(u["name"] or "кто-то")}</a>'


PAIR_LINES = ["вам суждено сегодня переписываться до утра 💌", "звёзды сошлись, отпираться бесполезно ✨",
              "сегодня вы — лучший дуэт чата 🎶", "держитесь за ручки, это приказ 🤝"]
HERO_LINES = ["сегодня всё получается, остальным — завидовать 😎", "чат официально в восторге 🌟",
              "можно ходить важно весь день 👑", "сегодня тебя слушаются даже коты 🐈‍⬛"]


@router.message(Command("pair", "пара"))
async def cmd_pair(m: Message):
    if m.chat.type not in GROUPS:
        return await m.reply("💞 пара дня выбирается в группах")
    pick = await day_pick(m.chat.id, "pair", 2)
    if not pick:
        return await m.reply("💞 мало активных — нужно хотя бы двое, кто писал на этой неделе")
    await m.answer(ui.head("💞", "Пара дня") + "\n" + ui.quote(f"{_ulink(pick[0])} + {_ulink(pick[1])}") + "\n"
                   + ui.hint(random.Random(m.chat.id + int(db._day().replace("-", ""))).choice(PAIR_LINES)))


@router.message(Command("hero", "звезда"))
async def cmd_hero(m: Message):
    if m.chat.type not in GROUPS:
        return await m.reply("⭐ звезда дня выбирается в группах")
    pick = await day_pick(m.chat.id, "hero", 1)
    if not pick:
        return await m.reply("⭐ пока некого выбирать — пусть кто-нибудь напишет")
    await m.answer(ui.head("⭐", "Звезда дня") + "\n" + ui.quote(_ulink(pick[0])) + "\n"
                   + ui.hint(random.Random(m.chat.id * 7 + int(db._day().replace("-", ""))).choice(HERO_LINES)))
