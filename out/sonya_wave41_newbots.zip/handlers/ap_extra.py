"""Автопостинг, волна 17: водяной знак, отсев похожих картинок, контент-план от ИИ."""
import logging
import re
from html import escape

from aiogram import Router, F
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery

import llm
from autopost import store
from handlers.ap_common import show, kb_rows, cancel_kb

router = Router()
log = logging.getLogger("ap_extra")


class APX(StatesGroup):
    watermark = State()


async def _own(cb: CallbackQuery) -> int | None:
    cid = int(cb.data.rsplit(":", 1)[1])
    if not await store.channel(cid, cb.from_user.id):
        await cb.answer("канал не найден", show_alert=True)
        return None
    return cid


async def _settings(target, cid: int):
    from handlers import ap_panel
    await show(target, *await ap_panel.channel_view(cid))


# ================= 💧 водяной знак =================
@router.callback_query(F.data.startswith("ap:x_wm:"))
async def cb_wm(cb: CallbackQuery, state: FSMContext):
    if cid := await _own(cb):
        await state.set_state(APX.watermark)
        await state.update_data(cid=cid)
        await show(cb, "<b>💧 водяной знак</b>\nнапишу этот текст полупрозрачно в углу каждой картинки поста.\n"
                       "пример: <code>@mychannel</code>\n\n«-» — убрать", cancel_kb(f"ap:cs:{cid}"))


@router.message(APX.watermark, F.text)
async def st_wm(m: Message, state: FSMContext):
    cid = (await state.get_data())["cid"]
    text = "" if m.text.strip() == "-" else m.text.strip()[:40]
    await store.set_channel(cid, watermark=text)
    await state.clear()
    await _settings(m, cid)


# ================= 🧬 похожие картинки =================
@router.callback_query(F.data.startswith("ap:x_dup:"))
async def cb_dup(cb: CallbackQuery):
    if cid := await _own(cb):
        c = await store.channel(cid)
        await store.set_channel(cid, dedupe_img=0 if c.get("dedupe_img", 1) else 1)
        await _settings(cb, cid)


# ================= 🗓 контент-план =================
PLAN_SYS = ("Ты контент-менеджер Telegram-канала. Составь контент-план на 7 дней: на каждый день 2 идеи постов "
            "(рубрика + о чём пост одной строкой + формат: текст/картинка/видео/опрос). Учитывай тему канала и что "
            "уже выходило, не повторяйся. Пиши по-русски, коротко, списком по дням (Пн…Вс). Без вступлений.")


async def plan_text(cid: int, owner: int) -> str:
    c = await store.channel(cid)
    import db
    recent = await db.q_all("SELECT p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                            "WHERE s.chat_id=? AND s.status='sent' ORDER BY s.sent_at DESC LIMIT 15", cid)
    rules = await store.rules_of(owner, cid)
    about = [f"Канал: {c['title']}" + (f" (@{c['username']})" if c.get("username") else "")]
    if rules:
        about.append("Автоисточники: " + ", ".join(f"{r['type']}: {r['title']}" for r in rules[:10]))
    snippets = []
    for p in recent:
        t = re.sub(r"<[^>]+>", "", p.get("text") or "")[:80]
        if t:
            snippets.append(t)
    if snippets:
        about.append("Недавние посты: " + " | ".join(snippets[:10]))
    return await llm.ask([{"role": "system", "content": PLAN_SYS}, {"role": "user", "content": "\n".join(about)}],
                         max_tokens=1500, temperature=0.8, feature="plan")


@router.callback_query(F.data.startswith("ap:x_plan:"))
async def cb_plan(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    import limits
    if not await limits.take(cb.from_user.id):
        return await cb.answer("на сегодня ИИ-лимит исчерпан", show_alert=True)
    await cb.answer("думаю над планом…")
    try:
        out = await plan_text(cid, cb.from_user.id)
    except Exception as e:
        log.info("plan: %s", e)
        await limits.give_back(cb.from_user.id)
        return await cb.message.answer("😕 ИИ не ответил, попробуй ещё раз")
    await cb.message.answer(f"🗓 <b>контент-план на неделю</b>\n\n{escape(out[:3800])}",
                            reply_markup=kb_rows([("🔁 Другой план", f"ap:x_plan:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")]))


# ================= 📊 статистика канала =================
WEEKDAYS = "пн вт ср чт пт сб вс".split()


async def stats_data(cid: int, days: int = 30) -> dict:
    """Реакции подписчиков на кнопки Сони под постами → топ постов, лучшие часы и дни (по МСК)."""
    import json
    import time
    import db
    since = int(time.time()) - days * 86400
    rows = await db.q_all("SELECT s.id, s.msg_ids, s.sent_at, p.text FROM ap_schedule s JOIN ap_posts p ON p.id=s.post_id "
                          "WHERE s.chat_id=? AND s.status='sent' AND s.sent_at>?", cid, since)
    posts = []
    for r in rows:
        ids = json.loads(r["msg_ids"] or "[]")
        n = 0
        if ids:
            marks = ",".join("?" * len(ids))
            n = (await db.q_one(f"SELECT COUNT(*) AS n FROM ap_reacts WHERE chat_id=? AND msg_id IN ({marks})",
                                cid, *ids))["n"]
        t = time.gmtime(r["sent_at"] + 3 * 3600)
        posts.append({"reacts": n, "hour": t.tm_hour, "wd": t.tm_wday, "msg": ids[-1] if ids else 0,
                      "text": re.sub(r"<[^>]+>", "", r["text"] or "").strip()})
    by_hour, by_wd = {}, {}
    for p in posts:
        by_hour.setdefault(p["hour"], []).append(p["reacts"])
        by_wd.setdefault(p["wd"], []).append(p["reacts"])
    avg = lambda d: sorted(((sum(v) / len(v), k) for k, v in d.items() if len(v) >= 2), reverse=True)
    return {"posts": posts, "total": len(posts), "reacts": sum(p["reacts"] for p in posts),
            "hours": avg(by_hour)[:3], "days": avg(by_wd)[:2],
            "top": sorted((p for p in posts if p["reacts"]), key=lambda p: -p["reacts"])[:5]}


async def stats_text(cid: int) -> str:
    import ui
    c = await store.channel(cid)
    d = await stats_data(cid)
    lines = [ui.head("📊", f"Статистика · {escape(c['title'])}", "за 30 дней, по реакциям на кнопки Сони")]
    lines.append(ui.stats(("📤 постов", d["total"]), ("❤️ реакций", d["reacts"]),
                          ("⚡ в среднем на пост", f"{d['reacts'] / d['total']:.1f}" if d["total"] else "—")))
    if d["top"]:
        top = []
        for i, p in enumerate(d["top"]):
            snip = escape((p["text"] or "без текста")[:40])
            if c.get("username") and p["msg"]:
                snip = f'<a href="https://t.me/{c["username"]}/{p["msg"]}">{snip}</a>'
            top.append(f"{ui.MEDALS[i] if i < 3 else '▫️'} {snip} — <b>{p['reacts']}</b>")
        lines.append("🏆 <b>лучшие посты</b>\n" + ui.quote("\n".join(top)))
    if d["hours"]:
        hrs = " · ".join(f"<b>{h}:00</b> ({a:.1f})" for a, h in d["hours"])
        wds = " · ".join(f"<b>{WEEKDAYS[w]}</b>" for _a, w in d["days"])
        lines.append("🕐 <b>лучшее время</b>\n" + ui.quote(f"часы: {hrs}" + (f"\nдни: {wds}" if wds else "")))
    if not d["reacts"]:
        lines.append(ui.hint("реакций пока нет. включи кнопки-реакции в «🎨 Оформлении» источника или поста — "
                             "по ним я считаю, что заходит"))
    else:
        lines.append(ui.hint("ставь посты на лучшие часы: «⚙️ Настройки» канала → слоты"))
    return "\n".join(lines)


@router.callback_query(F.data.startswith("ap:x_stat:"))
async def cb_stat(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    await show(cb, await stats_text(cid), kb_rows([("🔄", f"ap:x_stat:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")]))
