"""Общее для панели автопостинга."""
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message
from aiogram.exceptions import TelegramBadRequest
from aiogram.utils.keyboard import InlineKeyboardBuilder

import config

MAX_CHANNELS = 10
MAX_RULES = 15


def is_owner(uid: int) -> bool:
    return uid == config.OWNER_ID


class AP(StatesGroup):
    channel_add = State()
    ch_slots = State()
    ch_sign = State()
    post_wait = State()
    ed_text = State()
    ed_media = State()
    ed_buttons = State()
    ed_time = State()
    q_time = State()
    rule_source = State()
    rule_filter = State()
    rule_footer = State()
    rule_token = State()
    rule_times = State()
    rule_hours = State()
    rule_interval = State()
    rule_template = State()
    rule_tags = State()
    pool_add = State()


async def show(target: Message | CallbackQuery, text: str, kb=None):
    """Редактирует сообщение колбэка или шлёт новое."""
    if isinstance(target, CallbackQuery):
        try:
            await target.message.edit_text(text, reply_markup=kb,
                                           disable_web_page_preview=True)
        except TelegramBadRequest as e:
            if "not modified" not in str(e):
                await target.message.answer(text, reply_markup=kb, disable_web_page_preview=True)
        try:
            await target.answer()
        except TelegramBadRequest:
            pass
    else:
        await target.answer(text, reply_markup=kb, disable_web_page_preview=True)


def kb_rows(*rows: list[tuple[str, str]]):
    kb = InlineKeyboardBuilder()
    sizes = []
    for row in rows:
        row = [b for b in row if b]
        for t, d in row:
            if d.startswith(("https://", "http://", "tg://")):   # ссылка, а не колбэк
                kb.button(text=t, url=d)
            else:
                kb.button(text=t, callback_data=d)
        if row:
            sizes.append(len(row))
    kb.adjust(*sizes)
    return kb.as_markup()


def cancel_kb(back: str = "ap:home"):
    return kb_rows([("✖️ Отмена", back)])


def on(v) -> str:
    return "вкл" if v else "выкл"
