"""Суточный лимит ИИ-ответов на человека: чтобы один упорный не съел квоту Groq за всех."""
import random

import config
import db

TIRED = [
    "всё, я на сегодня выговорилась 🫠 приходи завтра",
    "лимит болтовни на сегодня исчерпан. у меня тоже есть личная жизнь 💅",
    "язык устал, мозг перегрелся. до завтра 🖤",
]


def cap(uid: int) -> int:
    """0 — без лимита."""
    from handlers import extra
    if uid == config.OWNER_ID:
        return 0
    return config.AI_DAY_LIMIT_PLUS if extra.active(uid) else config.AI_DAY_LIMIT


async def used(uid: int) -> int:
    r = await db.q_one("SELECT n FROM ai_usage WHERE uid=? AND day=?", uid, db._day())
    return r["n"] if r else 0


async def take(uid: int) -> bool:
    """Списать один ИИ-ответ. False — на сегодня всё."""
    limit = cap(uid)
    day = db._day()
    if limit and await used(uid) >= limit:
        return False
    await db.q_run("INSERT INTO ai_usage VALUES(?,?,1) ON CONFLICT(uid, day) DO UPDATE SET n=n+1", uid, day)
    return True


async def give_back(uid: int):
    """Ответ не получился — не считаем."""
    await db.q_run("UPDATE ai_usage SET n=MAX(0, n-1) WHERE uid=? AND day=?", uid, db._day())


def tired_text(uid: int) -> str:
    from handlers import extra
    text = random.choice(TIRED)
    if extra.active(uid):
        return text
    if not config.AI_DAY_LIMIT_PLUS:
        text += "\n\n✨ с Соней+ болтаю без лимита — /plus"
    elif config.AI_DAY_LIMIT_PLUS > config.AI_DAY_LIMIT:
        text += f"\n\n✨ с Соней+ — {config.AI_DAY_LIMIT_PLUS} ответов в день — /plus"
    return text


async def status(uid: int) -> str:
    limit = cap(uid)
    if not limit:
        return ""
    return f"🧠 ИИ сегодня: <b>{await used(uid)}/{limit}</b>"
