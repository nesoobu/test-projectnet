"""Достижения: значки за дела, с наградой в монетках. Проверяются по ходу общения."""
import logging
import time

from aiogram import Bot

import db
import ui

log = logging.getLogger("ach")

# code: (значок и название, как получить, награда 🪙, поле users и порог — или None для ручных)
ACH = {
    "msgs_100": ("💬 Болтушка", "100 сообщений", 30, ("msgs", 100)),
    "msgs_1000": ("🗣 Не заткнуть", "1000 сообщений", 150, ("msgs", 1000)),
    "wins_10": ("🏅 Везунчик", "10 побед в играх", 30, ("wins", 10)),
    "wins_100": ("🏆 Чемпион", "100 побед в играх", 200, ("wins", 100)),
    "coins_1000": ("💰 Копилка", "1000 🪙 на счету", 50, ("coins", 1000)),
    "coins_10000": ("💎 Олигарх", "10 000 🪙 на счету", 300, ("coins", 10000)),
    "streak_7": ("🔥 Неделя подряд", "бонус 7 дней подряд", 50, ("streak", 7)),
    "streak_30": ("☄️ Месяц подряд", "бонус 30 дней подряд", 300, ("streak", 30)),
    "rep_10": ("❤️ Уважаемый", "10 репутации", 50, ("rep", 10)),
    "refs_1": ("🤝 Привёл друга", "1 друг по ссылке", 30, ("refs", 1)),
    "refs_5": ("👥 Вожак стаи", "5 друзей по ссылке", 150, ("refs", 5)),
    "dl_1": ("⬇️ Первая загрузка", "скачать что-нибудь", 10, ("dls", 1)),
    "dl_50": ("🎬 Киноман", "50 загрузок", 100, ("dls", 50)),
    "night": ("🦉 Ночная сова", "написать мне с 3 до 5 утра", 30, None),
    "bday": ("🎂 Именинник", "отметить ДР со мной", 50, None),
    "plus": ("✨ Меценат", "подключить Соню+", 100, None),
}

_have: dict[int, set[str]] = {}   # кэш: что уже есть у юзера


async def owned(uid: int) -> set[str]:
    if uid not in _have:
        _have[uid] = {r["code"] for r in await db.q_all("SELECT code FROM ach WHERE uid=?", uid)}
    return _have[uid]


async def _grant(uid: int, code: str) -> bool:
    if code not in ACH or code in await owned(uid):
        return False
    _have[uid].add(code)
    c = await db.db()
    cur = await c.execute("INSERT OR IGNORE INTO ach VALUES(?,?,?)", (uid, code, int(time.time())))
    await c.commit()
    if not cur.rowcount:
        return False
    await db.add_coins(uid, ACH[code][2])
    return True


async def _notify(bot: Bot, uid: int, codes: list[str], chat_id: int | None):
    if not codes:
        return
    lines = [f"🏅 <b>{'достижение' if len(codes) == 1 else 'достижения'}!</b>"]
    for c in codes:
        name, how, prize, _ = ACH[c]
        lines.append(f"{name} — <i>{how}</i> · +{prize} 🪙")
    try:
        await bot.send_message(chat_id or uid, "\n".join(lines), disable_notification=True)
    except Exception as e:
        log.info("ach notify %s: %s", uid, e)


async def give(bot: Bot, uid: int, code: str, chat_id: int | None = None) -> bool:
    """Выдать, если ещё нет. Сообщение — в chat_id (или в личку)."""
    if not await _grant(uid, code):
        return False
    await _notify(bot, uid, [code], chat_id)
    return True


async def check(bot: Bot, user: dict, chat_id: int | None = None, night: bool = False):
    """Пороговые достижения по полям users. Дёшево: кэш + сравнение чисел."""
    have = await owned(user["id"])
    new = []
    for code, (*_x, rule) in ACH.items():
        if code in have:
            continue
        if ((rule and (user.get(rule[0]) or 0) >= rule[1]) or (code == "night" and night)
                or (code == "plus" and (user.get("plus_until") or 0) > time.time())):
            if await _grant(user["id"], code):
                new.append(code)
    await _notify(bot, user["id"], new, chat_id)


async def view(uid: int) -> str:
    have = await owned(uid)
    u = await db.get_user(uid) or {}
    lines = [f"<b>🏅 достижения</b> · {len(have)}/{len(ACH)}", ui.LINE]
    for code, (name, how, prize, rule) in ACH.items():
        if code in have:
            lines.append(f"✅ <b>{name}</b> — {how}")
        else:
            prog = f" ({min(u.get(rule[0]) or 0, rule[1])}/{rule[1]})" if rule else ""
            lines.append(f"▫️ {name} — <i>{how}{prog}</i> · {prize} 🪙")
    return "\n".join(lines)


def short(have: set[str]) -> str:
    """Строка для профиля: значки полученных."""
    icons = [ACH[c][0].split(" ", 1)[0] for c in ACH if c in have]
    return f"🏅 достижения: <b>{len(have)}/{len(ACH)}</b> " + "".join(icons[-8:]) if have else ""

