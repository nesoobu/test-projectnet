"""✨ Монетизация: мягкие суточные лимиты на «дорогие» функции, пробная Соня+, приглашение купить.
Бесплатное не отнимаем — лимиты только на то, что жрёт сервер и нейросети. Узкие боты (dl/music) — без лимитов."""
import time

import config
import db

# что сколько раз в день бесплатно (0 — только с Соней+)
DAILY = {"fx": 3, "vtxt": 3, "hd": 0}
# сколько штук можно иметь бесплатно (0 — без лимита; каналы и источники — из .env)
COUNT = {"subs": 3}
TRIAL_DAYS = 3
NAMES = {
    "fx": "эффекты (slowed, 8D, бас…)", "vtxt": "текст из видео", "hd": "видео 1080p и выше",
    "subs": "подписки на артистов", "ap_channels": "каналы в автопостинге", "ap_rules": "автоисточники",
}


def plus(uid: int) -> bool:
    from handlers import extra
    return config.PROFILE != "full" or extra.active(uid)


async def used(uid: int, feat: str) -> int:
    r = await db.q_one("SELECT n FROM feat_usage WHERE uid=? AND day=? AND feat=?", uid, db._day(), feat)
    return r["n"] if r else 0


async def allow(uid: int, feat: str) -> bool:
    """Списать одно использование. False — бесплатное на сегодня кончилось."""
    if plus(uid):
        return True
    if await used(uid, feat) >= DAILY.get(feat, 0):
        return False
    await db.q_run("INSERT INTO feat_usage VALUES(?,?,?,1) ON CONFLICT(uid, day, feat) DO UPDATE SET n=n+1",
                   uid, db._day(), feat)
    return True


def limit_of(feat: str) -> int:
    if feat == "ap_rules":
        return config.FREE_SOURCES
    if feat == "ap_channels":
        return config.FREE_CHANNELS
    return COUNT.get(feat, 0)


def can_have(uid: int, feat: str, have: int) -> bool:
    lim = limit_of(feat)
    return plus(uid) or not lim or have < lim


async def trial_used(uid: int) -> bool:
    u = await db.get_user(uid) or {}
    return bool(u.get("plus_trial"))


async def upsell_kb(uid: int):
    from handlers.ap_common import kb_rows
    rows = [[("✨ Соня+ от 29 ⭐", "m:plus")]]
    if not await trial_used(uid):
        rows.insert(0, [(f"🎁 {TRIAL_DAYS} дня бесплатно", "plus:trial")])
    return kb_rows(*rows)


async def upsell_text(uid: int, feat: str) -> str:
    import ui
    if feat in DAILY and DAILY[feat]:
        head = f"⏳ <b>{NAMES[feat]}</b>: {DAILY[feat]} в день бесплатно — на сегодня всё"
    elif limit_of(feat):
        head = f"🔒 <b>{NAMES[feat]}</b>: бесплатно до {limit_of(feat)}"
    else:
        head = f"💎 <b>{NAMES[feat]}</b> — только с Соней+"
    return head + "\n" + ui.hint("с ✨ Соней+ — без лимитов, плюс приоритет в очереди и HD. завтра лимит обновится")


async def upsell(m, uid: int, feat: str):
    """m — Message, куда ответить."""
    await m.answer(await upsell_text(uid, feat), reply_markup=await upsell_kb(uid))


async def start_trial(uid: int) -> int | None:
    if await trial_used(uid):
        return None
    from handlers import extra
    await db.q_run("UPDATE users SET plus_trial=? WHERE id=?", int(time.time()), uid)
    return await extra.grant_plus(uid, TRIAL_DAYS)
