"""Распознаём ссылки: откуда и что это — видео, музыка, картинка, канал/плейлист."""
import re
from dataclasses import dataclass

URL_RE = re.compile(r"https?://[^\s<>\"')\]]+|(?<![\w/])(?:www\.)?(?:youtu\.be|youtube\.com|tiktok\.com|vm\.tiktok\.com|"
                    r"instagram\.com|pin\.it|pinterest\.\w+|vk\.com|vkvideo\.ru|rutube\.ru|x\.com|twitter\.com|"
                    r"reddit\.com|soundcloud\.com|open\.spotify\.com|music\.yandex\.\w+|likee\.video|threads\.\w+)"
                    r"/[^\s<>\"')\]]+", re.I)


@dataclass
class Link:
    url: str
    platform: str      # youtube, tiktok, instagram…
    kind: str          # video | audio | music_search | pin | collection | skip
    label: str         # для подписи: «YouTube», «TikTok»…


PLATFORMS = [
    # (regex по url, platform, label, kind)
    (r"music\.youtube\.com/watch", "ytmusic", "YouTube Music", "audio"),
    (r"(youtube\.com/(watch|shorts/|live/)|youtu\.be/)", "youtube", "YouTube", "video"),
    (r"youtube\.com/(@|channel/|c/|user/|playlist)", "youtube", "YouTube", "collection"),
    (r"(vm\.|vt\.)?tiktok\.com/(@[\w.]+/(video|photo)/|\w{6,}/?$|t/)", "tiktok", "TikTok", "video"),
    (r"tiktok\.com/@[\w.]+/?$", "tiktok", "TikTok", "collection"),
    (r"instagram\.com/(reel|reels|p|tv|stories)/", "instagram", "Instagram", "video"),
    (r"instagram\.com/[\w.]+/?$", "instagram", "Instagram", "collection"),
    (r"(pinterest\.[\w.]+/pin/|pin\.it/)", "pinterest", "Pinterest", "pin"),
    (r"(vk\.com|vkvideo\.ru)/(video|clip|wall)-?\d", "vk", "VK", "video"),
    (r"vk\.com/(video\?z=|clips)", "vk", "VK", "video"),
    (r"rutube\.ru/(video|shorts)/", "rutube", "RuTube", "video"),
    (r"rutube\.ru/(channel|plst)/", "rutube", "RuTube", "collection"),
    (r"(x|twitter)\.com/\w+/status/", "twitter", "X", "video"),
    (r"reddit\.com/r/\w+/(comments|s)/|v\.redd\.it/", "reddit", "Reddit", "video"),
    (r"soundcloud\.com/[\w-]+/sets/", "soundcloud", "SoundCloud", "collection"),
    (r"soundcloud\.com/[\w-]+/[\w-]+", "soundcloud", "SoundCloud", "audio"),
    (r"open\.spotify\.com/(intl-\w+/)?track/", "spotify", "Spotify", "music_search"),
    (r"music\.yandex\.\w+/(album/\d+/)?track/\d+", "yamusic", "Яндекс Музыка", "music_search"),
    (r"music\.apple\.com/.+\?i=\d+", "apple", "Apple Music", "music_search"),
    (r"likee\.video/", "likee", "Likee", "video"),
    (r"threads\.(net|com)/@[\w.]+/post/", "threads", "Threads", "video"),
    (r"(facebook\.com|fb\.watch)/.*(videos?|reel|watch)", "facebook", "Facebook", "video"),
    (r"twitch\.tv/\w+/clip/|clips\.twitch\.tv/", "twitch", "Twitch", "video"),
    (r"coub\.com/view/", "coub", "Coub", "video"),
    (r"dzen\.ru/(video|shorts)/", "dzen", "Дзен", "video"),
]
_COMPILED = [(re.compile(p, re.I), pl, lb, k) for p, pl, lb, k in PLATFORMS]


def classify(url: str) -> Link | None:
    u = url.strip().rstrip(".,!?)")
    if not u.lower().startswith("http"):
        u = "https://" + u
    for rx, pl, lb, k in _COMPILED:
        if rx.search(u):
            return Link(u, pl, k, lb)
    return None


def find_links(text: str) -> list[Link]:
    out, seen = [], set()
    for m in URL_RE.finditer(text or ""):
        link = classify(m.group(0))
        if link and link.url not in seen:
            seen.add(link.url)
            out.append(link)
    return out
