"""ffmpeg: эффекты (slowed, sped up, 8D, bass), рингтон, «как голосовое», отрывок для игры."""
import asyncio
import shutil
import uuid

from autopost import media_dl
from autopost.media_dl import DLError

FX = {
    "slow": ("🐌 Slowed + reverb", "slowed + reverb",
             "aresample=44100,asetrate=44100*0.85,aresample=44100,aecho=0.8:0.85:60|120:0.35|0.25"),
    "fast": ("⚡ Sped up", "sped up", "aresample=44100,asetrate=44100*1.25,aresample=44100"),
    "8d": ("🎧 8D", "8D", "aresample=44100,apulsator=hz=0.09:amount=0.85"),
    "bass": ("🔊 Bass boost", "bass boosted", "bass=g=12:f=90,alimiter=limit=0.95"),
    "night": ("🌙 Nightcore", "nightcore", "aresample=44100,asetrate=44100*1.3,aresample=44100,bass=g=3"),
}
RING_MAX = 40   # айфон не берёт рингтоны длиннее 40 с


def tmp(ext: str) -> str:
    media_dl._dir()
    return str(media_dl.DL / (uuid.uuid4().hex + ext))


def ok() -> bool:
    return bool(shutil.which("ffmpeg"))


async def run(*args: str):
    if not ok():
        raise DLError("на сервере нет ffmpeg")
    p = await asyncio.create_subprocess_exec("ffmpeg", "-y", "-loglevel", "error", *args,
                                             stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE)
    _, err = await asyncio.wait_for(p.communicate(), 180)
    if p.returncode != 0:
        raise DLError(f"ffmpeg: {err.decode(errors='ignore')[-120:]}")


async def effect(src: str, kind: str) -> str:
    out = tmp(".mp3")
    await run("-i", src, "-vn", "-af", FX[kind][2], "-b:a", "192k", out)
    return out


async def ringtone(src: str, a: int, b: int) -> tuple[str, str]:
    """→ (mp3 для андроида, m4r для айфона), с плавным началом и концом."""
    d = b - a
    fade = f"afade=t=in:d=1,afade=t=out:st={max(0, d - 1.5)}:d=1.5"
    mp3, m4r = tmp(".mp3"), tmp(".m4r")
    await run("-ss", str(a), "-t", str(d), "-i", src, "-vn", "-af", fade, "-b:a", "192k", mp3)
    await run("-i", mp3, "-c:a", "aac", "-b:a", "192k", "-f", "ipod", m4r)
    return mp3, m4r


async def voice(src: str, start: int = 0, dur: int | None = None) -> str:
    out = tmp(".ogg")
    args = ["-ss", str(start)] + (["-t", str(dur)] if dur else []) + ["-i", src, "-vn", "-ac", "1",
                                                                      "-c:a", "libopus", "-b:a", "64k", out]
    await run(*args)
    return out


def parse_span(text: str) -> tuple[int, int] | None:
    """«0:45-1:15», «45 75», «1:00 — 1:30» → секунды."""
    import re
    parts = re.findall(r"\d+(?::\d{1,2})?", text or "")
    if len(parts) != 2:
        return None
    sec = []
    for p in parts:
        if ":" in p:
            mm, ss = p.split(":")
            sec.append(int(mm) * 60 + int(ss))
        else:
            sec.append(int(p))
    a, b = sec
    return (a, b) if 0 <= a < b else None


# ================= видео =================
async def video_note(src: str, max_sec: int = 60) -> str:
    out = tmp(".mp4")
    await run("-i", src, "-t", str(max_sec), "-vf", "crop='min(iw,ih)':'min(iw,ih)',scale=480:480,setsar=1",
              "-c:v", "libx264", "-preset", "veryfast", "-crf", "26", "-c:a", "aac", "-b:a", "96k",
              "-movflags", "+faststart", out)
    return out


async def gif(src: str, max_sec: int = 30) -> str:
    out = tmp(".mp4")
    await run("-i", src, "-t", str(max_sec), "-an", "-vf", "fps=20,scale='min(480,iw)':-2", "-c:v", "libx264",
              "-preset", "veryfast", "-crf", "28", "-movflags", "+faststart", out)
    return out


async def cut_video(src: str, a: int, b: int) -> str:
    import os
    out = tmp(".mp4")
    await run("-ss", str(a), "-to", str(b), "-i", src, "-c:v", "libx264", "-preset", "veryfast", "-crf", "23",
              "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out)
    if os.path.getsize(out) < 1000:
        raise DLError("в этом отрезке пусто — видео короче?")
    return out


async def cut_audio(src: str, a: int, b: int) -> str:
    out = tmp(".mp3")
    await run("-ss", str(a), "-to", str(b), "-i", src, "-vn", "-b:a", "192k", out)
    return out
