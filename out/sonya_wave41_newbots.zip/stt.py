"""Речь → текст через Whisper (Groq, OpenAI-совместимый /audio/transcriptions)."""
import logging
from pathlib import Path

import aiohttp

import config

log = logging.getLogger("stt")
OK_EXT = {".flac", ".mp3", ".mp4", ".mpeg", ".mpga", ".m4a", ".ogg", ".wav", ".webm"}


class STTError(Exception):
    pass


async def transcribe(path: str) -> str:
    if not config.STT_KEY:
        raise STTError("нет ключа для расшифровки (LLM_KEY / STT_KEY)")
    p = Path(path)
    name = p.name
    if p.suffix.lower() == ".oga":  # голосовые телеги — это ogg, Whisper не любит .oga
        name = p.stem + ".ogg"
    elif p.suffix.lower() not in OK_EXT:
        name = p.stem + ".mp4"
    form = aiohttp.FormData()
    form.add_field("model", config.STT_MODEL)
    form.add_field("response_format", "json")
    form.add_field("file", p.read_bytes(), filename=name, content_type="application/octet-stream")
    headers = {"Authorization": f"Bearer {config.STT_KEY}"}
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=120)) as s:
            async with s.post(config.STT_URL, data=form, headers=headers) as r:
                data = await r.json(content_type=None)
    except Exception as e:
        raise STTError(f"сервис не ответил: {str(e)[:100]}")
    if not isinstance(data, dict) or "text" not in data:
        err = (data or {}).get("error", {}) if isinstance(data, dict) else {}
        raise STTError(f"{r.status} {err.get('message') or data}"[:200])
    return (data.get("text") or "").strip()
