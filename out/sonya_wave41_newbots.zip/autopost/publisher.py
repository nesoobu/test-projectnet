"""Отрисовка и отправка поста в канал/превью."""
import logging
import re
from html import escape
from aiogram import Bot
from aiogram.types import (InlineKeyboardMarkup, InlineKeyboardButton, LinkPreviewOptions,
                           FSInputFile, InputMediaPhoto, InputMediaVideo, InputMediaDocument,
                           InputMediaAudio, InputMediaAnimation)

from autopost import timeparse

log = logging.getLogger("publisher")

CAPTION_LIMIT = 1024
TEXT_LIMIT = 4096
SEND = {"photo": "send_photo", "video": "send_video", "animation": "send_animation",
        "document": "send_document", "audio": "send_audio"}
INPUT = {"photo": InputMediaPhoto, "video": InputMediaVideo, "document": InputMediaDocument,
         "audio": InputMediaAudio, "animation": InputMediaAnimation}
REACTION_SETS = [
    [],
    ["👍", "👎"],
    ["❤️", "🔥", "😂", "😢"],
    ["🔥", "🗿", "💀"],
]


def _src(it: dict):
    """file_id / URL / локальный путь → то, что принимает Bot API."""
    src = it["src"]
    if not isinstance(src, str):
        return src   # уже готовый файл (водяной знак)
    if src.startswith("/"):
        return FSInputFile(src)
    return src


def _extra(it: dict) -> dict:
    """Метаданные для аудио/видео."""
    kw = {}
    if it["type"] == "audio":
        for k in ("title", "performer", "duration"):
            if it.get(k):
                kw[k] = it[k]
        if it.get("thumb") and str(it["thumb"]).startswith("/"):
            kw["thumbnail"] = FSInputFile(it["thumb"])
    elif it["type"] == "video":
        kw["supports_streaming"] = True
        for k in ("duration", "width", "height"):
            if it.get(k):
                kw[k] = it[k]
    return kw


def _file_id(msg, kind: str) -> str | None:
    if kind == "photo" and msg.photo:
        return msg.photo[-1].file_id
    obj = getattr(msg, kind, None)
    return getattr(obj, "file_id", None)


def _remember(it: dict, msg) -> bool:
    """После первой отправки локального файла запоминаем file_id — дальше шлём без загрузки."""
    if it.get("_wm"):
        return False   # с водяным знаком — это копия, оригинал не трогаем
    if isinstance(it.get("src"), str) and it["src"].startswith("/"):
        fid = _file_id(msg, it["type"])
        if fid:
            it["src"] = fid
            return True
    return False


def parse_buttons(text: str) -> list[list[dict]] | None:
    """Строки 'Текст - https://ссылка', несколько в ряд через |."""
    rows = []
    for line in text.strip().splitlines():
        row = []
        for part in line.split("|"):
            m = re.match(r"^\s*(.+?)\s*[-—–]\s*((?:https?://|tg://|t\.me/)\S+)\s*$", part)
            if not m:
                return None
            url = m.group(2)
            if url.startswith("t.me/"):
                url = "https://" + url
            row.append({"t": m.group(1)[:40], "u": url})
        if row:
            rows.append(row[:4])
    return rows[:8] or None


def keyboard(post: dict, counts: dict | None = None) -> InlineKeyboardMarkup | None:
    rows = []
    reacts = post.get("reactions") or []
    if reacts:
        counts = counts or {}
        rows.append([InlineKeyboardButton(
            text=f"{e} {counts[i]}" if counts.get(i) else e, callback_data=f"rx:{i}")
            for i, e in enumerate(reacts)])
    for row in post.get("buttons") or []:
        rows.append([InlineKeyboardButton(text=b["t"], url=b["u"]) for b in row])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


def render_text(post: dict, channel: dict | None) -> str:
    text = post.get("text") or ""
    opts = post.get("opts") or {}
    if channel and channel.get("signature") and opts.get("sign", True):
        text = (text + "\n\n" if text else "") + escape(channel["signature"])
    return text


async def _watermarked(bot: Bot, media: list[dict], text: str) -> list[dict]:
    """Копия media, где фото заменены на версию с водяным знаком. Не вышло — оставляем как было."""
    from aiogram.types import BufferedInputFile
    from autopost import imgtools
    import asyncio
    out = []
    for it in media:
        if it.get("type") == "photo":
            data = await imgtools.fetch_bytes(bot, it.get("src"))
            if data:
                try:
                    wm = await asyncio.to_thread(imgtools.watermark, data, text)
                    it = {**it, "src": BufferedInputFile(wm, "wm.jpg"), "_wm": True}
                except Exception as e:
                    log.info("watermark: %s", e)
        out.append(it)
    return out


async def send(bot: Bot, post: dict, chat_id: int, channel: dict | None = None,
               preview: bool = False) -> list[int]:
    """Отправляет пост. preview=True — в личку автору (без закрепа, всегда со звуком)."""
    opts = post.get("opts") or {}
    media = post.get("media") or []
    if channel and channel.get("watermark") and any(it.get("type") == "photo" for it in media):
        media = await _watermarked(bot, media, channel["watermark"])
    text = render_text(post, channel)
    kb = keyboard(post)
    silent = bool(opts.get("silent"))
    if channel and channel.get("night_silent") and timeparse.is_night():
        silent = True
    if preview:
        silent = False
    common = dict(disable_notification=silent, protect_content=bool(opts.get("protect")))
    ids: list[int] = []

    if not media:
        lp = LinkPreviewOptions(is_disabled=not opts.get("link_preview", True))
        m = await bot.send_message(chat_id, text[:TEXT_LIMIT] or "…", reply_markup=kb,
                                   link_preview_options=lp, **common)
        ids.append(m.message_id)
    elif len(media) == 1:
        it = media[0]
        fn = getattr(bot, SEND[it["type"]])
        if len(text) <= CAPTION_LIMIT:
            m = await fn(chat_id, _src(it), caption=text or None, reply_markup=kb, **_extra(it), **common)
            ids.append(m.message_id)
            post["_first_fid"] = _file_id(m, it["type"])   # для «трек в подписи»
            if _remember(it, m):
                post["_changed"] = True
        else:  # длинный текст — медиа отдельно, текст с кнопками следом
            m = await fn(chat_id, _src(it), **_extra(it), **common)
            ids.append(m.message_id)
            if _remember(it, m):
                post["_changed"] = True
            m = await bot.send_message(chat_id, text[:TEXT_LIMIT], reply_markup=kb,
                                       link_preview_options=LinkPreviewOptions(is_disabled=True),
                                       **common)
            ids.append(m.message_id)
    else:
        group = []
        for i, it in enumerate(media[:10]):
            cap = text[:CAPTION_LIMIT] if i == 0 and len(text) <= CAPTION_LIMIT else None
            extra = _extra(it)
            if it["type"] == "video":
                extra.pop("supports_streaming", None)
            group.append(INPUT[it["type"]](media=_src(it), caption=cap, **extra))
        msgs = await bot.send_media_group(chat_id, group, **common)
        ids.extend(m.message_id for m in msgs)
        for it, m in zip(media, msgs):
            if _remember(it, m):
                post["_changed"] = True
        if len(text) > CAPTION_LIMIT or kb:
            m = await bot.send_message(chat_id, text[:TEXT_LIMIT] if len(text) > CAPTION_LIMIT else "👇",
                                       reply_markup=kb, **common)
            ids.append(m.message_id)

    if opts.get("pin") and not preview and ids:
        try:
            await bot.pin_chat_message(chat_id, ids[0], disable_notification=True)
        except Exception:
            pass
    return ids


def album_ok(media: list[dict]) -> bool:
    """В альбоме Telegram нельзя смешивать аудио/документы с фото/видео."""
    kinds = {m["type"] for m in media}
    if len(media) < 2:
        return True
    if "animation" in kinds:
        return False
    return kinds <= {"photo", "video"} or kinds == {"document"} or kinds == {"audio"}


def snippet(post_text: str, media: list | str | None, n: int = 40) -> str:
    import json
    if isinstance(media, str):
        try:
            media = json.loads(media)
        except Exception:
            media = []
    icon = {"photo": "🖼", "video": "🎬", "animation": "🎞", "document": "📎", "audio": "🎵"}
    pre = ""
    if media:
        pre = icon.get(media[0]["type"], "📎") + (f"×{len(media)} " if len(media) > 1 else " ")
    t = re.sub(r"<[^>]+>", "", post_text or "").replace("\n", " ").strip()
    t = t[:n] + "…" if len(t) > n else t
    return (pre + (t or "без текста")).strip()
