"""Картинки для автопостинга: водяной знак и «похожесть» (dHash), чтобы не постить одно и то же дважды."""
import io
import logging

import aiohttp

log = logging.getLogger("imgtools")
DUP_DIST = 5          # из 64 бит: ≤5 отличий — та же картинка (пережатая, другой размер)
KEEP_HASHES = 3000


async def fetch_bytes(bot, src) -> bytes | None:
    """Локальный путь / URL / file_id → байты. None — не вышло."""
    try:
        if isinstance(src, str) and src.startswith("/"):
            with open(src, "rb") as f:
                return f.read()
        if isinstance(src, str) and src.startswith("http"):
            async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=20)) as s:
                async with s.get(src) as r:
                    if r.status == 200 and int(r.headers.get("Content-Length") or 0) < 20 * 1024 * 1024:
                        return await r.read()
            return None
        if isinstance(src, str) and bot is not None:
            buf = io.BytesIO()
            await bot.download(src, destination=buf)
            return buf.getvalue()
    except Exception as e:
        log.info("fetch image: %s", e)
    return None


def dhash(data: bytes) -> int | None:
    """64-битный разностный хэш. None — картинка однотонная (сравнивать бессмысленно)."""
    from PIL import Image
    im = Image.open(io.BytesIO(data)).convert("L").resize((9, 8))
    px = list(im.getdata())
    if max(px) - min(px) < 12:
        return None
    h = 0
    for row in range(8):
        for col in range(8):
            h = (h << 1) | (px[row * 9 + col] > px[row * 9 + col + 1])
    return h


def distance(a: int, b: int) -> int:
    return bin(a ^ b).count("1")


def watermark(data: bytes, text: str) -> bytes:
    """Полупрозрачная надпись в правом нижнем углу."""
    from PIL import Image, ImageDraw
    from handlers.tools import _font
    im = Image.open(io.BytesIO(data)).convert("RGBA")
    w, h = im.size
    size = max(14, min(w, h) // 22)
    font = _font(size, bold=True)
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    tw = d.textlength(text, font=font)
    pad = max(8, size // 2)
    x, y = w - tw - pad, h - size - pad * 1.4
    d.text((x, y), text, font=font, fill=(255, 255, 255, 170), stroke_width=max(1, size // 14),
           stroke_fill=(0, 0, 0, 120))
    out = io.BytesIO()
    Image.alpha_composite(im, layer).convert("RGB").save(out, "JPEG", quality=92)
    return out.getvalue()


# ---------- база похожих ----------
MASK = (1 << 64) - 1


def _signed(h: int) -> int:
    """SQLite INTEGER — знаковый 64-бит: храним со сдвигом."""
    return h - (1 << 64) if h >= (1 << 63) else h


async def is_dup(chat_id: int, h: int) -> bool:
    import db
    rows = await db.q_all("SELECT h FROM ap_phash WHERE chat_id=?", chat_id)
    return any(distance(h, r["h"] & MASK) <= DUP_DIST for r in rows)


async def remember(chat_id: int, h: int):
    import time
    import db
    await db.q_run("INSERT OR IGNORE INTO ap_phash VALUES(?,?,?)", chat_id, _signed(h), int(time.time()))
    await db.q_run("DELETE FROM ap_phash WHERE chat_id=? AND rowid NOT IN "
                   "(SELECT rowid FROM ap_phash WHERE chat_id=? ORDER BY ts DESC LIMIT ?)", chat_id, chat_id, KEEP_HASHES)


async def first_photo_hash(bot, media: list[dict]) -> int | None:
    for it in media or []:
        if it.get("type") == "photo":
            data = await fetch_bytes(bot, it.get("src"))
            if data:
                try:
                    import asyncio
                    return await asyncio.to_thread(dhash, data)
                except Exception as e:
                    log.info("dhash: %s", e)
            return None
    return None
