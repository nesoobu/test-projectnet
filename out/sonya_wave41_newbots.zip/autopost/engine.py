"""Фоновый движок: публикует очередь, удаляет по таймеру, крутит авто-источники."""
import asyncio
import logging
import time
from html import escape
from aiogram import Bot
from aiogram.exceptions import TelegramBadRequest, TelegramForbiddenError, TelegramRetryAfter
from aiogram.utils.keyboard import InlineKeyboardBuilder

import llm
from autopost import store, sources, publisher, timeparse

log = logging.getLogger("autopost")
TICK = 20
_lock = asyncio.Lock()
_rules_lock = asyncio.Lock()

from autopost.rules import AI_MODES, inbox_kb, run_rule, persist_media, next_run  # noqa: F401
from autopost import media_dl


async def publish_row(bot: Bot, s: dict):
    post = await store.post(s["post_id"])
    ch = await store.channel(s["chat_id"])
    if not post or not ch:
        return await store.mark(s["id"], "failed", "пост или канал удалён")
    try:
        try:
            ids = await publisher.send(bot, post, s["chat_id"], ch)
        except TelegramBadRequest as e:
            # картинка по ссылке не загрузилась — шлём без неё
            if post["media"] and str(post["media"][0]["src"]).startswith("http"):
                log.warning("media url failed (%s), sending text only", e)
                post["media"] = []
                ids = await publisher.send(bot, post, s["chat_id"], ch)
            else:
                raise
    except TelegramRetryAfter as e:
        await store.set_at(s["id"], time.time() + e.retry_after + 1)
        return
    except (TelegramBadRequest, TelegramForbiddenError) as e:
        await store.mark(s["id"], "failed", str(e)[:300])
        try:
            await bot.send_message(ch["owner_id"],
                                   f"⚠️ не смогла опубликовать в «{escape(ch['title'])}»:\n"
                                   f"<code>{escape(str(e)[:300])}</code>")
        except Exception:
            pass
        return
    del_h = (post["opts"] or {}).get("del_after") or 0
    delete_at = int(time.time() + del_h * 3600) if del_h else None
    await persist_media(post)
    await store.mark_sent(s["id"], ids, delete_at)
    if ch.get("auto_react") and ids:
        await auto_react(bot, s["chat_id"], ids[0], ch["auto_react"])
    if ch.get("cap_track") and ids and post.get("_first_fid") and len(post.get("media") or []) == 1 \
            and post["media"][0]["type"] in ("video", "animation"):
        asyncio.create_task(caption_track(bot, s["chat_id"], ids[0], post, ch))
    await store.set_post(post["id"], status="sent")
    if s["repeat_h"]:
        nxt = s["at"] + s["repeat_h"] * 3600
        while nxt <= time.time():
            nxt += s["repeat_h"] * 3600
        await store.schedule(post["id"], s["chat_id"], nxt, s["repeat_h"])


async def caption_track(bot: Bot, chat_id: int, msg_id: int, post: dict, ch: dict):
    """Узнаём музыку в только что вышедшем видео и дописываем «🎵 Артист — Трек» в подпись."""
    try:
        from handlers import comments
        from aiogram.types import Video
        obj = Video(file_id=post["_first_fid"], file_unique_id="x", width=1, height=1, duration=1)
        res = await comments.recognize_media(bot, obj)
        if not res:
            return
        text = publisher.render_text(post, ch)
        line = f"🎵 {escape(res['artist'])} — {escape(res['title'])}"
        cap = f"{text}\n\n{line}" if text else line
        if len(cap) > publisher.CAPTION_LIMIT:
            return
        await bot.edit_message_caption(chat_id=chat_id, message_id=msg_id, caption=cap,
                                       reply_markup=publisher.keyboard(post))
    except Exception as e:
        log.info("caption track: %s", e)


REACT_POOL = ["🔥", "❤️", "👍", "🤩", "😍", "💯", "⚡", "🥰"]
REACT_SAFE = ["👍", "❤️", "🔥"]


async def auto_react(bot: Bot, chat_id: int, msg_id: int, mode: str):
    """Соня ставит свою реакцию под постом. Если эмодзи запрещён в канале — пробует базовые."""
    from aiogram.types import ReactionTypeEmoji
    import random
    first = random.choice(REACT_POOL) if mode == "random" else mode
    for emoji in [first] + [e for e in REACT_SAFE if e != first]:
        try:
            await bot.set_message_reaction(chat_id, msg_id, [ReactionTypeEmoji(emoji=emoji)])
            return
        except TelegramBadRequest as e:
            if "REACTION_INVALID" not in str(e).upper() and "REACTION" not in str(e).upper():
                log.info("auto react: %s", e)
                return
        except Exception as e:
            log.info("auto react: %s", e)
            return


async def tick(bot: Bot):
    await publish_due(bot)
    if not _rules_lock.locked():
        asyncio.create_task(_rules_bg(bot))


async def _rules_bg(bot: Bot):
    async with _rules_lock:
        try:
            await _rules(bot)
        except Exception:
            log.exception("rules")


async def publish_due(bot: Bot):
    async with _lock:
        await _publish(bot)


async def _publish(bot: Bot):
    now = int(time.time())
    for s in await store.due(now):
        await store.mark(s["id"], "sending")
        try:
            await publish_row(bot, s)
        except Exception as e:
            log.exception("publish %s", s["id"])
            await store.mark(s["id"], "failed", str(e)[:300])
    for s in await store.to_delete(now):
        for mid in store.L(s["msg_ids"]):
            try:
                await bot.delete_message(s["chat_id"], mid)
            except Exception:
                pass
        await store.mark_deleted(s["id"])


async def _rules(bot: Bot):
    now = int(time.time())
    for r in await store.due_rules(now):
        ch = await store.channel(r["chat_id"])
        await store.set_rule(r["id"], next_run=next_run(r, store.cfg_of(r), ch, now))
        try:
            await run_rule(bot, r)
        except Exception as e:
            log.exception("rule %s", r["id"])
            await store.set_rule(r["id"], last_error=str(e)[:200])


async def loop(bot: Bot):
    n = 0
    while True:
        try:
            await tick(bot)
            n += 1
            if n % 180 == 0:
                await asyncio.to_thread(media_dl.cleanup)
            if n % 4000 == 0:
                await store.cleanup_seen()
        except Exception:
            log.exception("tick")
        await asyncio.sleep(TICK)
