"""Разбор времени от человека и подбор свободного слота. Всё в МСК."""
import random
import re
from datetime import datetime, timedelta, timezone

MSK = timezone(timedelta(hours=3))


def now() -> datetime:
    return datetime.now(MSK)


def fmt(ts: int) -> str:
    d = datetime.fromtimestamp(ts, MSK)
    today = now().date()
    if d.date() == today:
        day = "сегодня"
    elif d.date() == today + timedelta(days=1):
        day = "завтра"
    else:
        day = d.strftime("%d.%m")
    return f"{day} {d:%H:%M}"


REL = re.compile(r"^(?:через\s*)?\+?\s*(\d+)\s*(м|мин|минут[уы]?|ч|час|часа|часов|д|дн|день|дня|дней)$")
HM = re.compile(r"(\d{1,2})[:.](\d{2})$")


def parse(text: str) -> int | None:
    """'18:30' · 'завтра 10:00' · '25.10 18:00' · '+2ч' · 'через 30м' → unix ts (в будущем)."""
    t = text.strip().lower().replace("ё", "е")
    n = now()
    m = REL.match(t)
    if m:
        v, u = int(m.group(1)), m.group(2)
        mult = 60 if u.startswith("м") else 3600 if u.startswith("ч") else 86400
        return int(n.timestamp()) + v * mult
    base = n.date()
    m = re.match(r"^(сегодня|завтра|послезавтра)\s+(.+)$", t)
    if m:
        base = base + timedelta(days={"сегодня": 0, "завтра": 1, "послезавтра": 2}[m.group(1)])
        t = m.group(2)
        explicit_day = True
    else:
        explicit_day = False
        m = re.match(r"^(\d{1,2})\.(\d{1,2})(?:\.(\d{2,4}))?\s+(.+)$", t)
        if m:
            y = int(m.group(3)) if m.group(3) else base.year
            if y < 100:
                y += 2000
            try:
                base = datetime(y, int(m.group(2)), int(m.group(1))).date()
            except ValueError:
                return None
            if not m.group(3) and base < n.date():
                base = base.replace(year=base.year + 1)
            t = m.group(4)
            explicit_day = True
    m = HM.fullmatch(t.strip())
    if not m:
        return None
    h, mi = int(m.group(1)), int(m.group(2))
    if h > 23 or mi > 59:
        return None
    d = datetime(base.year, base.month, base.day, h, mi, tzinfo=MSK)
    if d <= n:
        if explicit_day:
            return None
        d += timedelta(days=1)
    return int(d.timestamp())


def parse_slots(text: str) -> list[str] | None:
    out = []
    for p in re.split(r"[\s,;]+", text.strip()):
        if not p:
            continue
        m = HM.fullmatch(p.replace(".", ":"))
        if not m or int(m.group(1)) > 23 or int(m.group(2)) > 59:
            return None
        out.append(f"{int(m.group(1)):02d}:{m.group(2)}")
    return sorted(set(out)) or None


def next_slot(slots: list[str], busy_minutes: set[int], jitter: int = 0, days: int = 30) -> int:
    """Ближайший свободный слот канала. busy_minutes — занятые ts//60."""
    n = now()
    slots = slots or ["12:00"]
    for d in range(days):
        day = (n + timedelta(days=d)).date()
        for s in sorted(slots):
            h, mi = map(int, s.split(":"))
            dt = datetime(day.year, day.month, day.day, h, mi, tzinfo=MSK)
            if dt <= n + timedelta(minutes=1):
                continue
            ts = int(dt.timestamp())
            sm = ts // 60
            if any(abs(b - sm) <= jitter for b in busy_minutes):
                continue
            if jitter:
                ts += random.randint(-jitter, jitter) * 60
                ts = max(ts, int(n.timestamp()) + 60)
            return ts
    return int(n.timestamp()) + 3600


def is_night(ts: int | None = None) -> bool:
    h = datetime.fromtimestamp(ts, MSK).hour if ts else now().hour
    return h >= 23 or h < 8
