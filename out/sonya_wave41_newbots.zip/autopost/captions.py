"""Живые подписи и популярные хэштеги."""
import logging
import random
import re
from urllib.parse import unquote

import llm

log = logging.getLogger("captions")

CAPTION_STYLES = {
    "none": "без подписи",
    "vibe": "живая · атмосфера",
    "fun": "живая · с юмором",
    "sonya": "живая · от Сони",
}
STYLE_HINT = {
    "vibe": "спокойно, по-человечески, как в личном эстетичном канале — простая мысль или настроение",
    "fun": "с лёгким юмором и самоиронией, как мемная подпись у друга в канале",
    "sonya": "от лица Сони — девушки-альтушки: дерзко, иронично, по-свойски",
}
CAPTION_RULES = (
    "Пиши как обычный человек в своём канале, простыми словами, будто скинул другу. "
    "Одна короткая строка, 3–10 слов. Строчные буквы — норм. Без кавычек и хэштегов. "
    "Максимум один эмодзи, чаще вообще без. "
    "НЕ пиши поэзией и метафорами: предметы не «шепчут», не «дышат», не «танцуют»; "
    "никаких «сердце города», «бесконечность», «тихий бунт», «магия», «огни зовут», «мгновение». "
    "Запрещены слова: погрузитесь, невероятный, атмосферный, волшебный, встречайте, вот, "
    "эта картинка, на фото, этот трек, это видео. "
    "Можно: личная мысль («я бы сейчас туда»), бытовая ситуация («когда сбежал от всех на ночь»), "
    "вопрос подписчикам («кто тоже залипает на такое?»), короткая реакция («ну это база»). "
    "Не описывай что видно — скажи, что чувствуешь или когда это заходит. "
    "Ответ — только сама подпись."
)
GOOD_EXAMPLES = [
    "я бы сейчас туда, без телефона", "кто тоже сохраняет такое в 3 ночи?", "ну это база",
    "мой вайб на всю осень", "смотрю уже минут десять", "когда наконец выключил уведомления",
    "хочу жить внутри этого кадра", "поставь на повтор и не благодари", "идеально под дорогу домой",
]

# популярные теги по темам: то, что реально ищут
GENRE_TAGS = {
    "rap": ["#рэп", "#rap"], "rusrap": ["#рэп", "#русскийрэп"], "hiphop": ["#хипхоп", "#hiphop"],
    "pop": ["#поп", "#pop"], "ruspop": ["#попса", "#русскаямузыка"], "rock": ["#рок", "#rock"],
    "rusrock": ["#рок", "#русскийрок"], "electronics": ["#электроника", "#electronic"],
    "dance": ["#dance", "#танцевальная"], "phonk": ["#phonk", "#фонк"], "indie": ["#инди", "#indie"],
    "alternative": ["#альтернатива", "#alternative"], "metal": ["#метал", "#metal"],
    "rnb": ["#rnb", "#рнб"], "soul": ["#soul"], "jazz": ["#джаз", "#jazz"], "house": ["#house"],
    "techno": ["#techno", "#техно"], "lofi": ["#lofi"], "postpunk": ["#постпанк", "#postpunk"],
    "trap": ["#trap", "#трэп"], "drill": ["#drill"], "kpop": ["#kpop"], "anime": ["#аниме", "#anime"],
    "soundtrack": ["#саундтрек", "#ost"], "classical": ["#классика", "#classical"],
}
BASE_TAGS = {
    "yamusic": ["#музыка", "#music", "#newmusic"],
    "music": ["#музыка", "#music"],
    "pinterest": ["#эстетика", "#aesthetic", "#вайб"],
    "video": ["#видео", "#video"],
}
POPULAR_HINT = (
    "Подбери 4–6 ПОПУЛЯРНЫХ хэштегов, по которым реально ищут в Telegram, Pinterest и TikTok. "
    "Короткие, 1–2 слова, общеупотребимые, без выдуманных и длинных. Смешай русские и английские. "
    "Хорошие примеры: #эстетика #aesthetic #вайб #vibe #музыка #рэп #rap #newmusic #ночь #осень "
    "#мемы #кино #аниме #мотивация #природа #город #любовь. "
    "Плохие: #КрасивыйВечерВГороде #ЭстетикаНочногоНеба. "
    "Ответ — только хэштеги через пробел, строчными."
)


def _garbage(w: str) -> bool:
    return bool(re.search(r"[0-9A-Fa-f]{6,}", w)) and not re.search(r"[а-яё]", w, re.I)


def clean_tag(word: str, lower: bool = True) -> str:
    w = unquote(word or "").strip().lstrip("#")
    w = re.sub(r"[\s\-]+", "_", w)
    w = re.sub(r"[^\w]", "", w).strip("_")
    if lower:
        w = w.lower()
    if len(w) < 2 or len(w) > 25 or w.isdigit() or not re.search(r"[^\W\d_]", w) or _garbage(w):
        return ""
    if "_" in w and any(len(p) < 2 for p in w.split("_")):
        return ""
    return "#" + w


def board_name(source: str) -> str:
    if "/" not in source:
        return ""
    return unquote(source.split("/", 1)[1]).replace("-", " ").replace("_", " ").strip()


def genre_tags(genre: str) -> list[str]:
    g = (genre or "").lower().replace("-", "").replace(" ", "")
    if g in GENRE_TAGS:
        return GENRE_TAGS[g]
    for k, v in GENRE_TAGS.items():
        if k in g:
            return v
    t = clean_tag(genre)
    return [t] if t else []


def dedup(tags: list[str], limit: int = 8) -> list[str]:
    seen, out = set(), []
    for t in tags:
        if t and t.lower() not in seen:
            seen.add(t.lower())
            out.append(t)
    return out[:limit]


def context_line(rule: dict, item: dict) -> str:
    bits = []
    if item.get("artist"):
        bits.append(f"исполнитель: {item['artist']}")
    if item.get("title"):
        bits.append(f"название: {item['title']}")
    if item.get("genre"):
        bits.append(f"жанр: {item['genre']}")
    if rule["type"] == "pinterest":
        b = board_name(rule["source"])
        if b:
            bits.append(f"тема доски: {b}")
    if item.get("text"):
        bits.append(f"описание: {item['text'][:300]}")
    kind = {"yamusic": "трек", "music": "трек", "video": "видео", "pinterest": "пин из pinterest"}
    bits.insert(0, f"тип: {kind.get(rule['type'], 'пост')}")
    return "; ".join(bits)


async def popular_tags(rule: dict, item: dict, caption: str = "") -> list[str]:
    ctx = context_line(rule, item) + (f"; подпись: {caption}" if caption else "")
    out = await llm.ask([{"role": "system", "content": POPULAR_HINT},
                         {"role": "user", "content": ctx}], max_tokens=400, temperature=0.5)
    return [t for t in (clean_tag(w) for w in out.split() if w.startswith("#")) if t]


def meta_tags(rule: dict, item: dict) -> list[str]:
    tags = []
    for a in re.split(r",|&| feat\.? | ft\.? | x ", item.get("artist") or ""):
        t = clean_tag(a.strip(), lower=False)
        if t:
            tags.append(t)
    tags += genre_tags(item.get("genre") or "")
    if rule["type"] == "reddit":
        tags.append(clean_tag(rule["source"]))
    if rule["type"] == "pinterest":
        b = board_name(rule["source"])
        if b and len(b.split()) <= 2 and all(len(w) >= 3 for w in b.split()):
            tags.append(clean_tag(b))
    tags += BASE_TAGS.get(rule["type"], [])[:2]
    return [t for t in tags if t]


async def live_caption(rule: dict, cfg: dict, item: dict, media: list) -> str:
    style = cfg.get("caption", "none")
    if style == "none":
        return ""
    recent = cfg.get("recent_caps") or []
    system = (f"Ты ведёшь Telegram-канал и пишешь подпись к посту. Тон: {STYLE_HINT[style]}. "
              + CAPTION_RULES + " Примеры по духу (не копируй): " + " | ".join(random.sample(GOOD_EXAMPLES, 4)))
    if recent:
        system += " Не повторяй по смыслу и словам прошлые подписи: " + " | ".join(recent[-8:])
    ctx = context_line(rule, item)
    img = next((m["src"] for m in media if m.get("type") == "photo"
                and str(m.get("src", "")).startswith("http")), None) or item.get("image")
    if img and not str(img).startswith("http"):
        img = None
    out = ""
    if img:
        try:
            out = await llm.ask_vision(system, f"Напиши подпись к этой картинке. Контекст: {ctx}", img)
        except Exception as e:
            log.info("vision недоступен (%s), пишу по контексту", e)
    if not out.strip():
        out = await llm.ask([{"role": "system", "content": system},
                             {"role": "user", "content": f"Напиши подпись. Контекст: {ctx}"}],
                            max_tokens=400, temperature=1.0)
    cap = polish(out)
    if cap and not too_poetic(cap):
        return cap
    # вторая попытка — жёстче
    out = await llm.ask([{"role": "system", "content": system + " Предыдущий вариант был слишком "
                          "пафосный. Напиши проще, разговорно, без метафор."},
                         {"role": "user", "content": f"Напиши подпись. Контекст: {ctx}"}],
                        max_tokens=400, temperature=1.0)
    cap = polish(out)
    return "" if too_poetic(cap) else cap


BANNED = re.compile(r"шепч|шепот|шёпот|сердц\w* город|бесконечн|тих\w* бунт|магия|магич|погрузи|"
                    r"невероятн|атмосферн|волшебн|мгновени|дыша|танцу|зову|встречайте|на фото|"
                    r"эта картинка|этот трек|это видео", re.I)


def too_poetic(s: str) -> bool:
    return bool(BANNED.search(s or ""))


def polish(s: str) -> str:
    s = (s or "").strip().split("\n")[0].strip()
    s = re.sub(r"(^|\s)#\S+", "", s).strip()
    s = s.strip("«»\"'“”„ ")
    if len(s) > 160:
        s = s[:160].rsplit(" ", 1)[0] + "…"
    return s


FALLBACK_CAPS = {
    "vibe": ["сохраню себе, пусть будет", "вот такое настроение сегодня", "тихо, красиво, без слов",
             "для тех, кто тоже не спит", "кусочек вечера"],
    "fun": ["я в 3 ночи вместо сна", "когда обещал себе лечь пораньше", "моё лицо, когда понедельник",
            "без комментариев, просто смотри"],
    "sonya": ["ну красиво же, не спорьте", "сохранила, потому что могу", "это я, только в лучшей версии"],
}


def fallback_caption(style: str) -> str:
    return random.choice(FALLBACK_CAPS.get(style, [""]))
