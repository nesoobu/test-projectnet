"""БД автопостинга: каналы, посты, расписание, реакции, авто-источники, модерация."""
import json
import time
from db import db

SCHEMA = """
CREATE TABLE IF NOT EXISTS ap_channels(
    chat_id INTEGER PRIMARY KEY,
    owner_id INTEGER, title TEXT, username TEXT,
    slots TEXT DEFAULT '["10:00","14:00","19:00"]',
    signature TEXT DEFAULT '',
    night_silent INTEGER DEFAULT 1,
    jitter INTEGER DEFAULT 0,
    paused INTEGER DEFAULT 0,
    added INTEGER
);
CREATE TABLE IF NOT EXISTS ap_posts(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER,
    text TEXT DEFAULT '',
    media TEXT DEFAULT '[]',
    buttons TEXT DEFAULT '[]',
    reactions TEXT DEFAULT '[]',
    opts TEXT DEFAULT '{}',
    channels TEXT DEFAULT '[]',
    status TEXT DEFAULT 'draft',
    created INTEGER
);
CREATE TABLE IF NOT EXISTS ap_schedule(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER, chat_id INTEGER,
    at INTEGER, repeat_h INTEGER DEFAULT 0,
    status TEXT DEFAULT 'queued',
    msg_ids TEXT DEFAULT '[]',
    sent_at INTEGER, delete_at INTEGER, err TEXT
);
CREATE INDEX IF NOT EXISTS ix_sched ON ap_schedule(status, at);
CREATE TABLE IF NOT EXISTS ap_reacts(
    chat_id INTEGER, msg_id INTEGER, user_id INTEGER, idx INTEGER,
    PRIMARY KEY(chat_id, msg_id, user_id)
);
CREATE TABLE IF NOT EXISTS ap_rules(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    owner_id INTEGER, chat_id INTEGER,
    type TEXT, source TEXT, title TEXT,
    every_min INTEGER DEFAULT 180,
    next_run INTEGER DEFAULT 0,
    ai_mode TEXT DEFAULT 'none',
    moderation INTEGER DEFAULT 1,
    with_media INTEGER DEFAULT 1,
    include TEXT DEFAULT '', exclude TEXT DEFAULT '',
    footer TEXT DEFAULT '',
    active INTEGER DEFAULT 1,
    posted INTEGER DEFAULT 0,
    last_error TEXT DEFAULT '',
    created INTEGER
);
CREATE TABLE IF NOT EXISTS ap_seen(
    rule_id INTEGER, key TEXT, ts INTEGER,
    PRIMARY KEY(rule_id, key)
);
CREATE TABLE IF NOT EXISTS ap_inbox(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id INTEGER, owner_id INTEGER, chat_id INTEGER,
    post_id INTEGER, status TEXT DEFAULT 'pending', created INTEGER
);
"""

SCHEMA_V3 = """
CREATE TABLE IF NOT EXISTS ap_pool(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    rule_id INTEGER, post_id INTEGER,
    used INTEGER DEFAULT 0, added INTEGER
);
CREATE INDEX IF NOT EXISTS ix_pool ON ap_pool(rule_id, used);
CREATE TABLE IF NOT EXISTS ap_hashes(
    chat_id INTEGER, h TEXT, ts INTEGER, rule_id INTEGER DEFAULT 0, PRIMARY KEY(chat_id, h)
);
CREATE TABLE IF NOT EXISTS ap_phash(chat_id INTEGER, h INTEGER, ts INTEGER, PRIMARY KEY(chat_id, h));
"""

J = json.dumps


def L(s, default=None):
    try:
        return json.loads(s) if s else (default if default is not None else [])
    except Exception:
        return default if default is not None else []


async def init():
    c = await db()
    await c.executescript(SCHEMA)
    cols = {r[1] for r in await (await c.execute("PRAGMA table_info(ap_rules)")).fetchall()}
    ch_cols = {r[1] for r in await (await c.execute("PRAGMA table_info(ap_channels)")).fetchall()}
    if "auto_react" not in ch_cols:
        await c.execute("ALTER TABLE ap_channels ADD COLUMN auto_react TEXT DEFAULT ''")
    if "watermark" not in ch_cols:   # волна 17
        await c.execute("ALTER TABLE ap_channels ADD COLUMN watermark TEXT DEFAULT ''")
    if "dedupe_img" not in ch_cols:
        await c.execute("ALTER TABLE ap_channels ADD COLUMN dedupe_img INTEGER DEFAULT 1")
    if "cfg" not in cols:
        await c.execute("ALTER TABLE ap_rules ADD COLUMN cfg TEXT DEFAULT '{}'")
    await c.executescript(SCHEMA_V3)
    # волна 4: pinterest-источникам — живые подписи и популярные теги
    rows = await (await c.execute("SELECT id, cfg FROM ap_rules WHERE type='pinterest'")).fetchall()
    for rid_, cfg_ in rows:
        cc = L(cfg_, {})
        if "caption" not in cc:
            cc.update(caption="vibe", tags="ai")
            await c.execute("UPDATE ap_rules SET cfg=? WHERE id=?", (J(cc, ensure_ascii=False), rid_))
    # после падения: недоотправленное вернуть в очередь
    await c.execute("UPDATE ap_schedule SET status='queued' WHERE status='sending'")
    await c.commit()


async def _all(sql, *a) -> list[dict]:
    c = await db()
    cur = await c.execute(sql, a)
    return [dict(r) for r in await cur.fetchall()]


async def _one(sql, *a) -> dict | None:
    c = await db()
    cur = await c.execute(sql, a)
    r = await cur.fetchone()
    return dict(r) if r else None


async def _run(sql, *a) -> int:
    c = await db()
    cur = await c.execute(sql, a)
    await c.commit()
    return cur.lastrowid


# ---------------- каналы ----------------
async def add_channel(chat_id, owner_id, title, username):
    await _run(
        "INSERT INTO ap_channels(chat_id,owner_id,title,username,added) VALUES(?,?,?,?,?) "
        "ON CONFLICT(chat_id) DO UPDATE SET owner_id=excluded.owner_id, title=excluded.title, "
        "username=excluded.username",
        chat_id, owner_id, title, username, int(time.time()))


async def channels(owner_id) -> list[dict]:
    return await _all("SELECT * FROM ap_channels WHERE owner_id=? ORDER BY added", owner_id)


async def channel(chat_id, owner_id=None) -> dict | None:
    if owner_id is None:
        return await _one("SELECT * FROM ap_channels WHERE chat_id=?", chat_id)
    return await _one("SELECT * FROM ap_channels WHERE chat_id=? AND owner_id=?", chat_id, owner_id)


CH_FIELDS = {"auto_react", "slots", "signature", "night_silent", "jitter", "paused", "title", "username",
             "watermark", "dedupe_img"}


async def set_channel(chat_id, **kw):
    for k, v in kw.items():
        assert k in CH_FIELDS
        await _run(f"UPDATE ap_channels SET {k}=? WHERE chat_id=?", v, chat_id)


async def del_channel(chat_id):
    await _run("DELETE FROM ap_channels WHERE chat_id=?", chat_id)
    await _run("UPDATE ap_schedule SET status='cancelled' WHERE chat_id=? AND status='queued'", chat_id)
    await _run("UPDATE ap_rules SET active=0 WHERE chat_id=?", chat_id)


# ---------------- посты ----------------
POST_FIELDS = {"text", "media", "buttons", "reactions", "opts", "channels", "status"}
JSON_FIELDS = {"media", "buttons", "reactions", "opts", "channels"}


def _post(r: dict | None) -> dict | None:
    if not r:
        return None
    for k in JSON_FIELDS:
        r[k] = L(r[k], {} if k == "opts" else [])
    return r


async def new_post(owner_id, text="", media=None, channels=None, opts=None) -> int:
    return await _run(
        "INSERT INTO ap_posts(owner_id,text,media,channels,opts,created) VALUES(?,?,?,?,?,?)",
        owner_id, text or "", J(media or []), J(channels or []), J(opts or {}), int(time.time()))


async def post(pid, owner_id=None) -> dict | None:
    if owner_id is None:
        return _post(await _one("SELECT * FROM ap_posts WHERE id=?", pid))
    return _post(await _one("SELECT * FROM ap_posts WHERE id=? AND owner_id=?", pid, owner_id))


async def set_post(pid, **kw):
    for k, v in kw.items():
        assert k in POST_FIELDS
        await _run(f"UPDATE ap_posts SET {k}=? WHERE id=?", J(v) if k in JSON_FIELDS else v, pid)


# ---------------- расписание ----------------
async def schedule(post_id, chat_id, at, repeat_h=0) -> int:
    return await _run("INSERT INTO ap_schedule(post_id,chat_id,at,repeat_h) VALUES(?,?,?,?)",
                      post_id, chat_id, int(at), repeat_h)


async def due(now) -> list[dict]:
    return await _all(
        "SELECT s.* FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
        "WHERE s.status='queued' AND s.at<=? AND c.paused=0 ORDER BY s.at LIMIT 20", now)


async def to_delete(now) -> list[dict]:
    return await _all("SELECT * FROM ap_schedule WHERE status='sent' AND delete_at IS NOT NULL "
                      "AND delete_at<=? LIMIT 20", now)


async def sched(sid) -> dict | None:
    return await _one("SELECT * FROM ap_schedule WHERE id=?", sid)


async def mark_sent(sid, msg_ids, delete_at):
    await _run("UPDATE ap_schedule SET status='sent', msg_ids=?, sent_at=?, delete_at=? WHERE id=?",
               J(msg_ids), int(time.time()), delete_at, sid)


async def mark(sid, status, err=None):
    await _run("UPDATE ap_schedule SET status=?, err=? WHERE id=?", status, err, sid)


async def set_at(sid, at):
    await _run("UPDATE ap_schedule SET at=? WHERE id=?", int(at), sid)


async def mark_deleted(sid):
    await _run("UPDATE ap_schedule SET delete_at=NULL, status='deleted' WHERE id=?", sid)


async def queue(owner_id, limit=30) -> list[dict]:
    return await _all(
        "SELECT s.*, c.title AS ch_title, p.text AS ptext, p.media AS pmedia "
        "FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
        "JOIN ap_posts p ON p.id=s.post_id "
        "WHERE c.owner_id=? AND s.status='queued' ORDER BY s.at LIMIT ?", owner_id, limit)


async def busy_times(chat_id, since) -> set[int]:
    rows = await _all("SELECT at FROM ap_schedule WHERE chat_id=? AND status='queued' AND at>=?",
                      chat_id, since)
    return {r["at"] // 60 for r in rows}


async def last_sent(owner_id, limit=10) -> list[dict]:
    return await _all(
        "SELECT s.*, c.title AS ch_title FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
        "WHERE c.owner_id=? AND s.status IN ('sent','failed','deleted') ORDER BY s.sent_at DESC, s.id DESC LIMIT ?",
        owner_id, limit)


async def counts(owner_id) -> dict:
    q = lambda sql: _one(sql, owner_id)
    ch = (await q("SELECT COUNT(*) n FROM ap_channels WHERE owner_id=?"))["n"]
    qu = (await q("SELECT COUNT(*) n FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
                  "WHERE c.owner_id=? AND s.status='queued'"))["n"]
    ru = (await q("SELECT COUNT(*) n FROM ap_rules WHERE owner_id=? AND active=1"))["n"]
    ib = (await q("SELECT COUNT(*) n FROM ap_inbox WHERE owner_id=? AND status='pending'"))["n"]
    day = int(time.time()) - 86400
    sent = (await _one("SELECT COUNT(*) n FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
                       "WHERE c.owner_id=? AND s.status IN ('sent','deleted') AND s.sent_at>?",
                       owner_id, day))["n"]
    return dict(channels=ch, queue=qu, rules=ru, inbox=ib, sent24=sent)


# ---------------- реакции ----------------
async def react(chat_id, msg_id, user_id, idx) -> bool:
    """Ставит/снимает реакцию. True — поставлена."""
    cur = await _one("SELECT idx FROM ap_reacts WHERE chat_id=? AND msg_id=? AND user_id=?",
                     chat_id, msg_id, user_id)
    if cur and cur["idx"] == idx:
        await _run("DELETE FROM ap_reacts WHERE chat_id=? AND msg_id=? AND user_id=?",
                   chat_id, msg_id, user_id)
        return False
    await _run("INSERT OR REPLACE INTO ap_reacts VALUES(?,?,?,?)", chat_id, msg_id, user_id, idx)
    return True


async def react_counts(chat_id, msg_id) -> dict[int, int]:
    rows = await _all("SELECT idx, COUNT(*) n FROM ap_reacts WHERE chat_id=? AND msg_id=? GROUP BY idx",
                      chat_id, msg_id)
    return {r["idx"]: r["n"] for r in rows}


async def post_by_msg(chat_id, msg_id) -> dict | None:
    rows = await _all("SELECT post_id, msg_ids FROM ap_schedule WHERE chat_id=? AND status='sent' "
                      "ORDER BY id DESC LIMIT 200", chat_id)
    for r in rows:
        if msg_id in L(r["msg_ids"]):
            return await post(r["post_id"])
    return None


# ---------------- правила (авто-источники) ----------------
RULE_FIELDS = {"cfg", "source", "every_min", "next_run", "ai_mode", "moderation", "with_media", "include",
               "exclude", "footer", "active", "posted", "last_error", "title", "chat_id"}


async def add_rule(owner_id, chat_id, type_, source, title, every_min=180) -> int:
    return await _run(
        "INSERT INTO ap_rules(owner_id,chat_id,type,source,title,every_min,next_run,created) "
        "VALUES(?,?,?,?,?,?,?,?)",
        owner_id, chat_id, type_, source, title, every_min, int(time.time()), int(time.time()))


async def rules(owner_id) -> list[dict]:
    return await _all("SELECT r.*, c.title AS ch_title FROM ap_rules r "
                      "LEFT JOIN ap_channels c ON c.chat_id=r.chat_id WHERE r.owner_id=? ORDER BY r.id",
                      owner_id)


async def rule(rid, owner_id=None) -> dict | None:
    if owner_id is None:
        return await _one("SELECT * FROM ap_rules WHERE id=?", rid)
    return await _one("SELECT r.*, c.title AS ch_title FROM ap_rules r LEFT JOIN ap_channels c "
                      "ON c.chat_id=r.chat_id WHERE r.id=? AND r.owner_id=?", rid, owner_id)


async def set_rule(rid, **kw):
    for k, v in kw.items():
        assert k in RULE_FIELDS
        await _run(f"UPDATE ap_rules SET {k}=? WHERE id=?", v, rid)


async def del_rule(rid):
    await _run("DELETE FROM ap_rules WHERE id=?", rid)
    await _run("DELETE FROM ap_seen WHERE rule_id=?", rid)
    await _run("DELETE FROM ap_pool WHERE rule_id=?", rid)


async def due_rules(now) -> list[dict]:
    return await _all("SELECT r.* FROM ap_rules r JOIN ap_channels c ON c.chat_id=r.chat_id "
                      "WHERE r.active=1 AND r.next_run<=? AND c.paused=0 LIMIT 10", now)


async def seen(rule_id, key) -> bool:
    return bool(await _one("SELECT 1 FROM ap_seen WHERE rule_id=? AND key=?", rule_id, key))


async def mark_seen(rule_id, key):
    await _run("INSERT OR IGNORE INTO ap_seen VALUES(?,?,?)", rule_id, key, int(time.time()))


async def cleanup_seen(days=120):
    await _run("DELETE FROM ap_seen WHERE ts<?", int(time.time()) - days * 86400)


# ---------------- модерация ----------------
async def add_inbox(rule_id, owner_id, chat_id, post_id) -> int:
    return await _run("INSERT INTO ap_inbox(rule_id,owner_id,chat_id,post_id,created) VALUES(?,?,?,?,?)",
                      rule_id, owner_id, chat_id, post_id, int(time.time()))


async def inbox_item(iid, owner_id) -> dict | None:
    return await _one("SELECT * FROM ap_inbox WHERE id=? AND owner_id=?", iid, owner_id)


async def inbox_pending(owner_id, limit=10) -> list[dict]:
    return await _all("SELECT * FROM ap_inbox WHERE owner_id=? AND status='pending' ORDER BY id LIMIT ?",
                      owner_id, limit)


async def set_inbox(iid, status):
    await _run("UPDATE ap_inbox SET status=? WHERE id=?", status, iid)


# ---------------- гибкие настройки правила ----------------
DEFAULT_CFG = {
    "sched": "interval",      # interval | slots | times
    "times": ["12:00"],       # для sched=times
    "days": [0, 1, 2, 3, 4, 5, 6],
    "hours": None,            # [с, до) — окно активности
    "per_run": 1,
    "order": "new",           # new | random | old
    "template": "",           # пусто — оформление по умолчанию
    "tags": "none",           # none | meta | ai (популярные)
    "caption": "none",        # none | vibe | fun | sonya — живая подпись от ИИ
    "media_kind": "all",      # all | video | photo | none
    "extra_tags": "",
    "reacts": 0,              # индекс набора реакций
    "link_style": "text",     # text — словом «источник» в тексте | button | none
    "silent": False,
    "only_media": False,
    "as_media": "auto",       # auto | link (для видео/аудио источников)
    "loop": False,            # когда всё выложено — начать заново (у копилки вкл)
    "token": "",              # яндекс музыка
    "max_len": 0,             # обрезать текст до N символов (0 — без)
}


def cfg_of(rule: dict) -> dict:
    c = dict(DEFAULT_CFG)
    stored = L(rule.get("cfg"), {})
    c.update(stored)
    if "link_style" not in stored:  # старые источники: кнопку меняем на слово в тексте
        c["link_style"] = "none" if rule.get("type") in ("yamusic", "pool", "ai") and not stored.get("link_btn") else "text"
    return c


async def set_cfg(rid, **kw):
    r = await rule(rid)
    c = L(r.get("cfg"), {})
    c.update(kw)
    await set_rule(rid, cfg=J(c, ensure_ascii=False))


# ---------------- копилка ----------------
async def pool_add(rule_id, post_id):
    await _run("INSERT INTO ap_pool(rule_id,post_id,added) VALUES(?,?,?)", rule_id, post_id, int(time.time()))


async def pool_counts(rule_id) -> tuple[int, int]:
    r = await _one("SELECT COUNT(*) n, COALESCE(SUM(used=0),0) f FROM ap_pool WHERE rule_id=?", rule_id)
    return r["n"], r["f"]


async def pool_pick(rule_id, order: str, n: int) -> list[dict]:
    o = {"random": "RANDOM()", "old": "id", "new": "id DESC"}.get(order, "id")
    return await _all(f"SELECT * FROM ap_pool WHERE rule_id=? AND used=0 ORDER BY {o} LIMIT ?", rule_id, n)


async def pool_use(pid_):
    await _run("UPDATE ap_pool SET used=1 WHERE id=?", pid_)


async def pool_reset(rule_id):
    await _run("UPDATE ap_pool SET used=0 WHERE rule_id=?", rule_id)


async def pool_clear(rule_id):
    await _run("DELETE FROM ap_pool WHERE rule_id=?", rule_id)


# ---------------- дедуп по содержимому в канале ----------------
async def hash_seen(chat_id, h, rule_id=0) -> bool:
    """Уже было в канале из ДРУГОГО источника (свой источник сам решает через seen/по кругу)."""
    return bool(await _one("SELECT 1 FROM ap_hashes WHERE chat_id=? AND h=? AND rule_id!=?",
                           chat_id, h, rule_id))


async def hash_add(chat_id, h, rule_id=0):
    await _run("INSERT OR IGNORE INTO ap_hashes(chat_id,h,ts,rule_id) VALUES(?,?,?,?)",
               chat_id, h, int(time.time()), rule_id)


async def seen_keys(rule_id) -> set[str]:
    return {r["key"] for r in await _all("SELECT key FROM ap_seen WHERE rule_id=?", rule_id)}


async def reset_seen(rule_id):
    await _run("DELETE FROM ap_seen WHERE rule_id=?", rule_id)


# ---------------- волна 7: каналы-хабы, обнуление, копии ----------------
async def rules_of(owner_id, chat_id) -> list[dict]:
    return await _all("SELECT * FROM ap_rules WHERE owner_id=? AND chat_id=? ORDER BY id", owner_id, chat_id)


async def queue_of(owner_id, chat_id, limit=30) -> list[dict]:
    return await _all(
        "SELECT s.*, c.title AS ch_title, p.text AS ptext, p.media AS pmedia "
        "FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id JOIN ap_posts p ON p.id=s.post_id "
        "WHERE c.owner_id=? AND s.chat_id=? AND s.status='queued' ORDER BY s.at LIMIT ?",
        owner_id, chat_id, limit)


async def history_of(owner_id, chat_id=None, limit=12) -> list[dict]:
    extra, args = ("AND s.chat_id=?", (chat_id,)) if chat_id else ("", ())
    return await _all(
        "SELECT s.*, c.title AS ch_title FROM ap_schedule s JOIN ap_channels c ON c.chat_id=s.chat_id "
        f"WHERE c.owner_id=? {extra} AND s.status IN ('sent','failed','deleted') "
        "ORDER BY s.sent_at DESC, s.id DESC LIMIT ?", owner_id, *args, limit)


async def channel_stats(chat_id) -> dict:
    day = int(time.time()) - 86400
    sent = (await _one("SELECT COUNT(*) n FROM ap_schedule WHERE chat_id=? AND status IN ('sent','deleted') "
                       "AND sent_at>?", chat_id, day))["n"]
    total = (await _one("SELECT COUNT(*) n FROM ap_schedule WHERE chat_id=? AND status IN ('sent','deleted')",
                        chat_id))["n"]
    q = await _one("SELECT COUNT(*) n, MIN(at) nxt FROM ap_schedule WHERE chat_id=? AND status='queued'", chat_id)
    nr = await _one("SELECT MIN(next_run) nxt FROM ap_rules WHERE chat_id=? AND active=1", chat_id)
    return dict(sent24=sent, total=total, queue=q["n"], next_post=q["nxt"], next_rule=nr["nxt"])


async def errors_of(owner_id=None) -> list[dict]:
    if owner_id is None:
        return await _all("SELECT r.*, c.title AS ch_title FROM ap_rules r LEFT JOIN ap_channels c "
                          "ON c.chat_id=r.chat_id WHERE r.last_error!='' ORDER BY r.id")
    return await _all("SELECT r.*, c.title AS ch_title FROM ap_rules r LEFT JOIN ap_channels c "
                      "ON c.chat_id=r.chat_id WHERE r.owner_id=? AND r.last_error!='' ORDER BY r.id", owner_id)


async def reset_rule_history(rid):
    """Забыть, что источник уже выкладывал: снова сможет брать те же записи."""
    await _run("DELETE FROM ap_seen WHERE rule_id=?", rid)
    await _run("DELETE FROM ap_hashes WHERE rule_id=?", rid)
    await _run("UPDATE ap_pool SET used=0 WHERE rule_id=?", rid)
    await set_rule(rid, last_error="")


async def reset_channel_history(chat_id):
    for r in await _all("SELECT id FROM ap_rules WHERE chat_id=?", chat_id):
        await reset_rule_history(r["id"])
    await _run("DELETE FROM ap_hashes WHERE chat_id=?", chat_id)
    await _run("DELETE FROM ap_phash WHERE chat_id=?", chat_id)


async def copy_rule(rid, chat_id) -> int:
    r = await rule(rid)
    new = await add_rule(r["owner_id"], chat_id, r["type"], r["source"], r["title"], r["every_min"])
    for k in ("ai_mode", "moderation", "with_media", "include", "exclude", "footer", "cfg"):
        await _run(f"UPDATE ap_rules SET {k}=? WHERE id=?", r[k], new)
    if r["type"] == "pool":  # копилку копируем вместе с содержимым
        for p in await _all("SELECT post_id FROM ap_pool WHERE rule_id=?", rid):
            await pool_add(new, p["post_id"])
    return new


async def all_channels() -> list[dict]:
    return await _all("SELECT c.*, (SELECT COUNT(*) FROM ap_rules r WHERE r.chat_id=c.chat_id) AS nrules "
                      "FROM ap_channels c ORDER BY added")


async def global_counts() -> dict:
    day = int(time.time()) - 86400
    g = lambda sql, *a: _one(sql, *a)
    return dict(
        channels=(await g("SELECT COUNT(*) n FROM ap_channels"))["n"],
        rules=(await g("SELECT COUNT(*) n FROM ap_rules"))["n"],
        active=(await g("SELECT COUNT(*) n FROM ap_rules WHERE active=1"))["n"],
        errors=(await g("SELECT COUNT(*) n FROM ap_rules WHERE last_error!=''"))["n"],
        sent24=(await g("SELECT COUNT(*) n FROM ap_schedule WHERE status IN ('sent','deleted') AND sent_at>?", day))["n"],
        queue=(await g("SELECT COUNT(*) n FROM ap_schedule WHERE status='queued'"))["n"],
    )
