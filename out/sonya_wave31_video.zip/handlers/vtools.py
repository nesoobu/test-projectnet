"""🛠 Инструменты под скачанным видео: качество, без сжатия, кружок, GIF, обрезка, обложка, инфо, текст.
Плюс 🕘 /history и еженедельное автообновление yt-dlp."""
import asyncio
import datetime as dt
import logging
import os
import sys
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from autopost import media_dl
from downloader import core, audiofx
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("vtools")
KEEP_SEC = 20 * 60
NOTE_MAX = 60       # кружок — до минуты
GIF_MAX = 30
CUT_MAX = 10 * 60
_keep: dict[str, tuple[str, float]] = {}   # tok → (путь к mp4, когда скачан)
_busy: set[int] = set()
_cut: dict[int, tuple[str, float]] = {}


# ================= файл под рукой =================
def keep(tok: str, path: str):
    now = time.time()
    for k, (p, ts) in list(_keep.items()):
        if now - ts > KEEP_SEC or k == tok:
            if p != path:
                core.remove(p)
            _keep.pop(k, None)
    _keep[tok] = (path, now)


async def local(tok: str, url: str) -> str:
    rec = _keep.get(tok)
    if rec and os.path.exists(rec[0]):
        return rec[0]
    f = await core.download(url, "video")
    keep(tok, f["path"])
    return f["path"]


def more_kb(tok: str):
    return kb_rows([("📺 Качество", f"vt:q:{tok}"), ("📦 Без сжатия", f"vt:doc:{tok}")],
                   [("⭕ Кружок", f"vt:note:{tok}"), ("🎞 GIF", f"vt:gif:{tok}"), ("✂️ Обрезать", f"vt:cut:{tok}")],
                   [("ℹ️ Инфо", f"vt:info:{tok}"), ("🖼 Обложка", f"vt:cover:{tok}"), ("🗒 Текст", f"vt:txt:{tok}")],
                   [("‹ Назад", f"vt:back:{tok}")])


async def _rec(cb: CallbackQuery, tok: str):
    from handlers import media
    rec = await media.get_token(tok)
    if not rec:
        await cb.answer("ссылка устарела — пришли её ещё раз", show_alert=True)
    return rec


@router.callback_query(F.data.startswith(("vt:more:", "vt:back:")))
async def cb_more(cb: CallbackQuery):
    from handlers import media
    tok = cb.data.split(":")[2]
    kb = more_kb(tok) if cb.data.startswith("vt:more:") else media.video_kb(tok)
    try:
        await cb.message.edit_reply_markup(reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer()


def _mb(n: int) -> str:
    return f"{n / 1024 / 1024:.0f} МБ" if n else "?"


async def _work(cb: CallbackQuery, what: str):
    """Общая обёртка: один процесс на человека, ответ на кнопку, ошибки — по-человечески."""
    if cb.from_user.id in _busy:
        await cb.answer("⏳ ещё делаю прошлое", show_alert=True)
        return False
    await cb.answer(what)
    _busy.add(cb.from_user.id)
    return True


# ================= 📺 качество =================
@router.callback_query(F.data.startswith("vt:q:"))
async def cb_quality(cb: CallbackQuery):
    tok = cb.data[5:]
    rec = await _rec(cb, tok)
    if not rec:
        return
    await cb.answer("смотрю, какое есть…")
    try:
        info = await core.probe(rec[0])
    except media_dl.DLError as e:
        return await cb.message.answer(f"😕 {escape(str(e))}")
    qs = info.get("qualities") or []
    if not qs:
        return await cb.message.answer("у этого видео нет выбора качества 🤷")
    rows, line = [], []
    for h, size in qs:
        fits = not size or size <= media_dl.MAX_BYTES
        line.append((f"{h}p · {_mb(size)}" + ("" if fits else " ⛔"), f"vt:qh:{h}:{tok}" if fits else "ms:noop"))
        if len(line) == 2:
            rows.append(line)
            line = []
    if line:
        rows.append(line)
    await cb.message.answer("📺 <b>выбери качество</b>\n" + ui.hint("⛔ — больше 50 МБ, телеграм не даст отправить ботом"),
                            reply_markup=kb_rows(*rows))


@router.callback_query(F.data.startswith("vt:qh:"))
async def cb_quality_go(cb: CallbackQuery, bot: Bot):
    _, _, h, tok = cb.data.split(":")
    rec = await _rec(cb, tok)
    if not rec or not await _work(cb, f"качаю {h}p…"):
        return
    f = None
    try:
        key = f"video{h}:{rec[0]}"
        c = await db.dl_cache_get(key)
        if c:
            return await cb.message.answer_video(c["file_id"], caption=f"📺 {h}p")
        await bot.send_chat_action(cb.message.chat.id, ChatAction.UPLOAD_VIDEO)
        f = await core.download(rec[0], "video", max_h=int(h))
        sent = await cb.message.answer_video(FSInputFile(f["path"]), caption=f"📺 {f.get('height') or h}p",
                                             supports_streaming=True, width=f.get("width"), height=f.get("height"),
                                             duration=f.get("duration") or None)
        if sent.video:
            await db.dl_cache_put(key, "video", sent.video.file_id, f.get("title") or "")
    except media_dl.DLError as e:
        await cb.message.answer(f"😕 {escape(str(e))}")
    except TelegramBadRequest as e:
        await cb.message.answer(f"😕 телеграм не принял ({escape(str(e)[:60])})")
    finally:
        _busy.discard(cb.from_user.id)
        core.remove(f and f.get("path"))


# ================= 📦 без сжатия · ⭕ кружок · 🎞 GIF =================
@router.callback_query(F.data.startswith(("vt:doc:", "vt:note:", "vt:gif:")))
async def cb_convert(cb: CallbackQuery, bot: Bot):
    act, tok = cb.data.split(":")[1:3]
    rec = await _rec(cb, tok)
    if not rec or not await _work(cb, {"doc": "отправляю файлом…", "note": "делаю кружок…", "gif": "делаю GIF…"}[act]):
        return
    out = None
    try:
        src = await local(tok, rec[0])
        await bot.send_chat_action(cb.message.chat.id, ChatAction.UPLOAD_DOCUMENT if act == "doc"
                                   else ChatAction.UPLOAD_VIDEO_NOTE if act == "note" else ChatAction.UPLOAD_VIDEO)
        if act == "doc":
            await cb.message.answer_document(FSInputFile(src, filename=f"{rec[1]}_{tok}.mp4"),
                                             caption="📦 оригинал файлом — телеграм не пережимает",
                                             disable_content_type_detection=True)
        elif act == "note":
            out = audiofx.tmp(".mp4")
            await audiofx.run("-i", src, "-t", str(NOTE_MAX), "-vf",
                              "crop='min(iw,ih)':'min(iw,ih)',scale=480:480,setsar=1", "-c:v", "libx264",
                              "-preset", "veryfast", "-crf", "26", "-c:a", "aac", "-b:a", "96k",
                              "-movflags", "+faststart", out)
            await cb.message.answer_video_note(FSInputFile(out), length=480)
        else:
            out = audiofx.tmp(".mp4")
            await audiofx.run("-i", src, "-t", str(GIF_MAX), "-an", "-vf", "fps=20,scale='min(480,iw)':-2",
                              "-c:v", "libx264", "-preset", "veryfast", "-crf", "28", "-movflags", "+faststart", out)
            await cb.message.answer_animation(FSInputFile(out))
    except media_dl.DLError as e:
        await cb.message.answer(f"😕 {escape(str(e))}")
    except TelegramBadRequest as e:
        await cb.message.answer(f"😕 телеграм не принял ({escape(str(e)[:60])})")
    finally:
        _busy.discard(cb.from_user.id)
        core.remove(out)


# ================= ✂️ обрезка =================
def cut_pending(m: Message) -> bool:
    r = _cut.get(m.from_user.id) if m.from_user else None
    return bool(r and time.time() - r[1] < 600 and m.text and not m.text.startswith("/"))


@router.callback_query(F.data.startswith("vt:cut:"))
async def cb_cut(cb: CallbackQuery):
    tok = cb.data[7:]
    if not await _rec(cb, tok):
        return
    _cut[cb.from_user.id] = (tok, time.time())
    await cb.answer()
    await cb.message.answer("✂️ <b>какой кусок вырезать?</b>\nнапиши, например, <code>0:10-0:25</code>\n"
                            + ui.hint("пришлю видео ровно с этого места до этого"))


@router.message(cut_pending)
async def on_cut(m: Message, bot: Bot):
    from handlers import media
    tok, _ = _cut.pop(m.from_user.id)
    span = audiofx.parse_span(m.text)
    if not span:
        _cut[m.from_user.id] = (tok, time.time())
        return await m.reply("не поняла 🤔 напиши так: <code>0:10-0:25</code>")
    a, b = span
    b = min(b, a + CUT_MAX)
    rec = await media.get_token(tok)
    if not rec:
        return await m.reply("ссылка устарела — пришли её ещё раз")
    if m.from_user.id in _busy:
        return await m.reply("⏳ ещё делаю прошлое")
    _busy.add(m.from_user.id)
    out = None
    try:
        st = await m.reply("✂️ режу…")
        src = await local(tok, rec[0])
        out = audiofx.tmp(".mp4")
        await audiofx.run("-ss", str(a), "-to", str(b), "-i", src, "-c:v", "libx264", "-preset", "veryfast",
                          "-crf", "23", "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", out)
        if os.path.getsize(out) < 1000:
            raise media_dl.DLError("в этом отрезке пусто — видео короче?")
        await m.answer_video(FSInputFile(out), caption=f"✂️ {a // 60}:{a % 60:02d}–{b // 60}:{b % 60:02d}",
                             supports_streaming=True)
        await st.delete()
    except media_dl.DLError as e:
        await m.reply(f"😕 {escape(str(e))}")
    except TelegramBadRequest as e:
        await m.reply(f"😕 телеграм не принял ({escape(str(e)[:60])})")
    finally:
        _busy.discard(m.from_user.id)
        core.remove(out)


# ================= ℹ️ инфо · 🖼 обложка =================
def _num(n) -> str:
    if n is None:
        return "—"
    return f"{n / 1e6:.1f} млн" if n >= 1e6 else f"{n / 1e3:.1f} тыс" if n >= 1e3 else str(n)


@router.callback_query(F.data.startswith(("vt:info:", "vt:cover:")))
async def cb_info(cb: CallbackQuery):
    act, tok = cb.data.split(":")[1:3]
    rec = await _rec(cb, tok)
    if not rec:
        return
    await cb.answer("смотрю…")
    try:
        info = await core.probe(rec[0])
    except media_dl.DLError as e:
        return await cb.message.answer(f"😕 {escape(str(e))}")
    if act == "cover":
        if not info.get("thumbnail"):
            return await cb.message.answer("у видео нет обложки 🤷")
        try:
            return await cb.message.answer_document(info["thumbnail"], caption="🖼 обложка в полном качестве")
        except TelegramBadRequest:
            return await cb.message.answer_photo(info["thumbnail"], caption="🖼 обложка")
    d = info.get("date") or ""
    date = f"{d[6:8]}.{d[4:6]}.{d[:4]}" if len(d) == 8 else "—"
    dur = info.get("duration") or 0
    lines = [f"ℹ️ <b>{escape(info.get('title', '')[:150])}</b>",
             ui.stats(("👤 автор", escape(info.get("uploader") or "—")), ("📅 дата", date),
                      ("⏱ длина", f"{dur // 60}:{dur % 60:02d}" if dur else "—")),
             ui.stats(("👁 просмотры", _num(info.get("views"))), ("❤️ лайки", _num(info.get("likes"))),
                      ("💬 комменты", _num(info.get("comments"))))]
    desc = (info.get("description") or "").strip()
    if desc:
        lines.append(f"<blockquote expandable>{escape(desc[:3000])}</blockquote>")
        tags = " ".join(w for w in desc.split() if w.startswith("#"))[:500]
        if tags:
            lines.append(f"🏷 <code>{escape(tags)}</code> <i>(нажми — скопируется)</i>")
    await cb.message.answer("\n".join(lines)[:4000])


# ================= 🗒 текст из видео =================
@router.callback_query(F.data.startswith("vt:txt:"))
async def cb_text(cb: CallbackQuery):
    tok = cb.data[7:]
    rec = await _rec(cb, tok)
    if not rec or not await _work(cb, "слушаю и записываю…"):
        return
    from handlers import media
    import stt
    a = None
    try:
        src = await local(tok, rec[0])
        a = await media._extract_audio(src)
        text = await stt.transcribe(a)
    except (media_dl.DLError, stt.STTError) as e:
        return await cb.message.answer(f"😕 не расшифровала: {escape(str(e)[:150])}")
    except Exception as e:
        log.info("vtxt: %s", e)
        return await cb.message.answer("😕 не получилось расшифровать")
    finally:
        _busy.discard(cb.from_user.id)
        if a and a != (_keep.get(tok) or ("",))[0]:
            core.remove(a)
    if not text:
        return await cb.message.answer("🤐 в видео нет речи — только музыка или тишина")
    import uuid
    body = escape(text)[:3800]
    kb = None
    if len(text) > 400:
        t = uuid.uuid4().hex[:10]
        media._texts[t] = (text, time.time())
        kb = kb_rows([("✨ О чём видео — кратко", f"vt:sum:{t}")])
    await cb.message.answer(f"🗒 <b>текст из видео</b>\n<blockquote expandable>{body}</blockquote>", reply_markup=kb)


# ================= 🕘 история =================
async def history_view(uid: int, page: int = 0):
    rows = await db.q_all("SELECT tok, kind, file_id, title, MAX(ts) ts FROM dl_hist WHERE uid=? "
                          "GROUP BY file_id ORDER BY ts DESC LIMIT 40", uid)
    if not rows:
        return "🕘 <b>история пуста</b>\n" + ui.hint("кинь ссылку — и всё скачанное будет тут"), None
    per = 8
    pages = (len(rows) + per - 1) // per
    page = max(0, min(page, pages - 1))
    chunk = rows[page * per:(page + 1) * per]
    lines = ["🕘 <b>что ты качал</b>", ui.hint("жми номер — пришлю снова, мгновенно"), ""]
    btns = []
    for i, r in enumerate(chunk, page * per + 1):
        icon = "🎬" if r["kind"].startswith("video") else "🎵"
        when = dt.datetime.fromtimestamp(r["ts"]).strftime("%d.%m")
        lines.append(f"<b>{i}.</b> {icon} {escape((r['title'] or '')[:55])} <i>{when}</i>")
        btns.append((str(i), f"vh:{r['tok']}:{r['kind'][:5]}"))
    rows_kb = [btns[:4], btns[4:]] if len(btns) > 4 else [btns]
    if pages > 1:
        rows_kb.append([("‹", f"vh:p:{page - 1}" if page else "ms:noop"), (f"{page + 1} / {pages}", "ms:noop"),
                        ("›", f"vh:p:{page + 1}" if page < pages - 1 else "ms:noop")])
    return "\n".join(lines), kb_rows(*[r for r in rows_kb if r])


@router.message(Command("history", "история"))
async def cmd_history(m: Message):
    text, kb = await history_view(m.from_user.id)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("vh:"))
async def cb_history(cb: CallbackQuery):
    from handlers import media
    _, a, b = cb.data.split(":")
    if a == "p":
        text, kb = await history_view(cb.from_user.id, int(b))
        try:
            await cb.message.edit_text(text, reply_markup=kb)
        except TelegramBadRequest:
            pass
        return await cb.answer()
    r = await db.q_one("SELECT kind, file_id FROM dl_hist WHERE uid=? AND tok=? AND kind LIKE ? ORDER BY ts DESC",
                       cb.from_user.id, a, b + "%")
    if not r:
        return await cb.answer("не нашла 🤔", show_alert=True)
    await cb.answer()
    try:
        if r["kind"].startswith("video"):
            await cb.message.answer_video(r["file_id"], reply_markup=media.video_kb(a))
        else:
            await cb.message.answer_audio(r["file_id"])
    except TelegramBadRequest:
        await cb.message.answer("😕 телеграм забыл этот файл — пришли ссылку заново")


# ================= ⬆️ yt-dlp сам обновляется раз в неделю =================
def _ytv_disk() -> str:
    import importlib
    import importlib.metadata as md
    importlib.invalidate_caches()
    try:
        return md.version("yt-dlp")
    except md.PackageNotFoundError:
        return ""


def _ytv_loaded() -> str:
    try:
        import yt_dlp
        return yt_dlp.version.__version__
    except Exception:
        return ""


async def pip_update() -> bool:
    proc = await asyncio.create_subprocess_exec(sys.executable, "-m", "pip", "install", "-U", "--quiet", "yt-dlp",
                                                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    try:
        await asyncio.wait_for(proc.wait(), 300)
    except asyncio.TimeoutError:
        proc.kill()
        return False
    return proc.returncode == 0


def _norm(v: str) -> str:
    return ".".join(str(int(x)) for x in v.split(".") if x.isdigit())


async def ytdlp_loop(bot: Bot):
    """Ночью по понедельникам основная Соня обновляет yt-dlp. Каждый процесс (и помощники), заметив новую
    версию на диске, тихо перезапускает себя в 4–5 утра — без systemctl."""
    while True:
        await asyncio.sleep(1800)
        try:
            msk = dt.datetime.utcnow() + dt.timedelta(hours=3)
            if not 4 <= msk.hour < 5:
                continue
            if config.PROFILE == "full" and msk.weekday() == 0 and await db.kv_get("ytup_day") != msk.date().isoformat():
                await db.kv_set("ytup_day", msk.date().isoformat())
                await pip_update()
            disk, loaded = _ytv_disk(), _ytv_loaded()
            if disk and loaded and _norm(disk) != _norm(loaded) and not _busy:
                log.info("yt-dlp %s → %s, перезапускаюсь", loaded, disk)
                if config.OWNER_ID and config.PROFILE == "full":
                    try:
                        await bot.send_message(config.OWNER_ID, f"⬆️ yt-dlp обновился: {loaded} → <b>{disk}</b>")
                    except Exception:
                        pass
                os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception as e:
            log.warning("ytdlp loop: %s", e)
