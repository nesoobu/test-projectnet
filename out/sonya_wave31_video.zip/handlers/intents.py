"""Живые фразы вместо команд: «озвучь…», «нарисуй…», «найди трек…», «погода…», фото, приветствия."""
import asyncio
import random
import re

from aiogram import Router, F, Bot, BaseMiddleware
from aiogram.types import Message, ReactionTypeEmoji

import db
import llm
from handlers import chat, games, tools

router = Router()

INTENTS = [
    (re.compile(r"^(?:озвучь|скажи голосом|зачитай)\s*[:,-]?\s*(.*)$", re.I | re.S), "voice"),
    (re.compile(r"^(?:нарисуй|сгенерируй(?: картинку)?|нарисуй мне)\s*[:,-]?\s*(.+)$", re.I | re.S), "draw"),
    (re.compile(r"^(?:найди|поищи|скачай)\s+(?:трек|песню|музыку|песня)?\s*[:,-]?\s*(.+)$", re.I), "find"),
    (re.compile(r"^погода(?:\s+в)?\s*(.*)$", re.I), "weather"),
    (re.compile(r"^(?:курс|курс валют|какой курс)\??$", re.I), "rate"),
    (re.compile(r"^(?:бонус|дай бонус|ежедневный бонус)$", re.I), "bonus"),
    (re.compile(r"^(?:игры|поиграем|давай поиграем|во что поиграть)\??$", re.I), "games"),
    (re.compile(r"^(?:квиз|викторина|вопрос)$", re.I), "quiz"),
    (re.compile(r"^(?:кинь кубик|кости|брось кубик)$", re.I), "dice"),
    (re.compile(r"^(?:казино|крути|слоты)$", re.I), "slots"),
    (re.compile(r"^(?:виселица)$", re.I), "hang"),
    (re.compile(r"^(?:что за трек|что за песня|шазам|shazam)\??$", re.I), "shazam"),
    (re.compile(r"^(?:цитата|в цитатник|цитатни)$", re.I), "quote"),
    (re.compile(r"^напомни(?:\s+мне)?\s*[:,-]?\s*(.*)$", re.I | re.S), "remind"),
    (re.compile(r"^(?:что я пропустил|что пропустил|сводка|о ч[её]м (?:тут )?говорили)\??$", re.I), "summary"),
    (re.compile(r"^(?:переведи|перевод)$", re.I), "translate"),
    (re.compile(r"^(?:магазин|шоп)$", re.I), "shop"),
]


async def detect(m: Message, bot: Bot) -> bool | dict:
    if not m.text or m.text.startswith("/"):
        return False
    me = await bot.me()
    text = chat._addressed(m, me.id, me.username or "")
    if text is None:
        return False
    for rx, kind in INTENTS:
        mt = rx.match(text.strip())
        if mt:
            return {"intent": kind, "arg": (mt.group(1) if mt.groups() else "").strip()}
    return False


@router.message(detect)
async def on_intent(m: Message, bot: Bot, intent: str, arg: str):
    if intent == "voice":
        if not arg and m.reply_to_message:
            arg = m.reply_to_message.text or m.reply_to_message.caption or ""
        return await tools.say(m, bot, arg)
    if intent == "draw":
        return await tools.draw(m, bot, arg)
    if intent == "find":
        return await tools.find_music(m, arg)
    if intent == "weather":
        try:
            return await m.reply(await tools.weather(arg or "Москва"))
        except Exception:
            return await m.reply("😕 погода не ответила")
    if intent == "rate":
        try:
            return await m.reply(await tools.rates())
        except Exception:
            return await m.reply("😕 курс не ответил")
    if intent == "bonus":
        import ui
        return await ui.personal(m, await games.bonus_text(m.from_user.id))
    if intent == "games":
        return await m.answer(games.GAMES_TEXT, reply_markup=games.games_kb())
    if intent == "quiz":
        return await games.send_quiz(m)
    if intent in ("dice", "slots"):
        return await m.answer(await games.play_dice(bot, m.chat.id, m.from_user, "🎲" if intent == "dice" else "🎰",
                                                    m.message_id))
    if intent == "hang":
        return await games.new_hang(m)
    if intent == "shazam":
        if m.reply_to_message:
            return await tools.shazam(m, bot, m.reply_to_message)
        return await m.reply("ответь «что за трек» на видео, аудио или кружок 🎧")
    if intent == "quote":
        return await tools.cmd_quote(m, bot)
    if intent == "remind":
        from handlers import remind
        return await remind.create(m, arg)
    if intent == "summary":
        from handlers import groupmod
        return await groupmod.summary(m)
    if intent == "translate":
        from handlers import groupmod
        return await groupmod.translate(m, m.reply_to_message)
    if intent == "shop":
        text, kb = await games.shop_view(m.from_user.id)
        return await m.answer(text, reply_markup=kb)


# ================= фото =================
@router.message(F.photo)
async def on_photo(m: Message, bot: Bot):
    if m.chat.type == "private":
        return await tools.look(m, bot, (m.caption or "").strip())
    me = await bot.me()
    cap = m.caption or ""
    addressed = (chat.TRIGGER.match(cap) or (me.username and f"@{me.username.lower()}" in cap.lower())
                 or (m.reply_to_message and m.reply_to_message.from_user.id == me.id))
    if addressed and await db.chat_flag(m.chat.id, "ai_on"):
        q = chat.TRIGGER.sub("", cap).strip()
        await tools.look(m, bot, q)


# ================= группы: приветствия =================
WELCOME = ["о, новенький 👀 привет, {n}!", "{n}, заходи, не стесняйся 🖤", "добро пожаловать, {n}! чай, кофе, мемы?",
           "{n} теперь с нами. держись, тут весело 😏"]


@router.message(F.new_chat_members)
async def on_join(m: Message, bot: Bot):
    me = await bot.me()
    for u in m.new_chat_members:
        if u.id == me.id:
            await db.add_chat(m.chat.id, m.chat.title or "")
            return await m.answer(
                "хей, я соня 🖤\n"
                "• позови «Соня, …» — поболтаем\n"
                "• кидайте ссылки — скачаю видео\n"
                "• голосовые и кружки — расшифрую\n"
                "• /games — игры на монетки, /quote — цитаты-стикеры\n"
                "админы: /settings — что включить/выключить")
    from handlers import community
    await community.clean_service(m)
    if not await db.chat_flag(m.chat.id, "greet"):
        return
    humans = [u for u in m.new_chat_members if not u.is_bot]
    if not humans:
        return
    names = ", ".join(u.first_name for u in humans)
    custom = await community.get_welcome(m.chat.id)
    if custom:   # своё приветствие админов — без ИИ
        kb = community.rules_kb() if await community.get_rules(m.chat.id) else None
        return await m.answer(community.render_welcome(custom, humans, m.chat.title or ""), reply_markup=kb)
    text = random.choice(WELCOME).format(n=names)
    try:
        out = await llm.ask([{"role": "system", "content": "Ты Соня, дерзкая и дружелюбная альтушка из чата. "
                                                           "Поприветствуй новичка одной короткой живой фразой, по-свойски, "
                                                           "без пафоса, максимум один эмодзи."},
                             {"role": "user", "content": f"Новичок: {names}. Чат: {m.chat.title}"}],
                            max_tokens=300, temperature=1.0)
        if out and 3 < len(out) < 200:
            text = out.strip()
    except Exception:
        pass
    kb = community.rules_kb() if await community.get_rules(m.chat.id) else None
    await m.answer(text, parse_mode=None, reply_markup=kb)


# ================= группы: живые реакции =================
MOODS = [
    (re.compile(r"ахах|хаха|лол|ржу|😂|🤣|кек", re.I), ["😁", "🤣"]),
    (re.compile(r"люблю|обожаю|❤️|🥰|милот", re.I), ["❤️", "🥰"]),
    (re.compile(r"грустн|плохо|устал|😢|😭|печаль", re.I), ["😢", "🤗"]),
    (re.compile(r"круто|огонь|топ|имба|🔥|вау|офиг", re.I), ["🔥", "⚡"]),
    (re.compile(r"\?$"), ["🤔"]),
]


class GroupLife(BaseMiddleware):
    """Иногда (~4%) Соня ставит реакцию на сообщение по настроению — как живой участник."""

    def __init__(self, chance: float = 0.04):
        self.chance = chance

    async def __call__(self, handler, event, data):
        res = await handler(event, data)
        try:
            if (isinstance(event, Message) and event.chat.type in ("group", "supergroup") and event.text
                    and not event.text.startswith("/") and random.random() < self.chance
                    and await db.chat_flag(event.chat.id, "reacts")):
                emoji = None
                for rx, opts in MOODS:
                    if rx.search(event.text):
                        emoji = random.choice(opts)
                        break
                emoji = emoji or random.choice(["👍", "❤️", "🔥", "👀"])
                bot: Bot = data["bot"]
                asyncio.create_task(_react(bot, event.chat.id, event.message_id, emoji))
        except Exception:
            pass
        return res


async def _react(bot: Bot, chat_id: int, msg_id: int, emoji: str):
    await asyncio.sleep(random.uniform(1, 6))
    try:
        await bot.set_message_reaction(chat_id, msg_id, [ReactionTypeEmoji(emoji=emoji)])
    except Exception:
        pass
