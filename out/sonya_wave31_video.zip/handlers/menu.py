from aiogram import Router, F, Bot
from aiogram.filters import Command, CommandStart
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest
from aiogram.fsm.context import FSMContext

import config
import db
import ui

router = Router()


async def _edit(cb: CallbackQuery, text: str, kb):
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer()


@router.message(CommandStart())
@router.message(Command("menu"))
async def cmd_start(m: Message, state: FSMContext, bot: Bot):
    await state.clear()
    parts = (m.text or "").split(maxsplit=1)
    if len(parts) > 1:
        from handlers import extra
        await extra.handle_ref(m, parts[1].strip(), bot)
    await m.answer(ui.start_text(m.from_user.first_name), reply_markup=ui.main_menu(m.from_user.id == config.OWNER_ID))


@router.message(Command("help"))
async def cmd_help(m: Message):
    await m.answer(ui.HELP, reply_markup=ui.help_kb())


async def _profile(uid: int, own: bool = True) -> str:
    u = await db.get_user(uid)
    from handlers.games import title_of
    import achievements
    import limits
    text = ui.profile_text(u, await db.rank_of(uid), await db.user_donated(uid), title_of(u))
    extra = [achievements.short(await achievements.owned(uid))]
    from handlers import fun
    extra.append(await fun.marriage_line(uid))
    pet = await fun.get_pet(uid)
    if pet and pet["alive"]:
        extra.append(f"{fun.PETS.get(pet['kind'], ('🐾',))[0]} питомец: <b>{ui.esc(pet['name'])}</b>, "
                     f"ур. {fun.pet_state(pet)[2]}")
    if u.get("bday"):
        from handlers.life import bday_human
        extra.append(f"🎂 ДР: <b>{bday_human(u['bday'])}</b>")
    if own:
        extra.append(await limits.status(uid))
    extra = [x for x in extra if x]
    return text + ("\n" + ui.quote("\n".join(extra)) if extra else "")


@router.message(Command("me", "profile"))
async def cmd_me(m: Message):
    target = m.reply_to_message.from_user if m.reply_to_message else m.from_user
    if target.is_bot or not await db.get_user(target.id):
        return await m.answer("про этого персонажа я ничего не знаю")
    if target.id == m.from_user.id:   # свой профиль в группе — видишь только ты
        return await ui.personal(m, await _profile(target.id, True))
    await m.answer(await _profile(target.id, False))


@router.message(Command("top"))
async def cmd_top(m: Message):
    await m.answer(ui.top_text("xp", await db.top("xp")), reply_markup=ui.top_kb("xp"))


def _facts_text(facts: list[str]) -> str:
    if not facts:
        return ("<b>🧠 что я о тебе помню</b>\n" + ui.LINE +
                "\n<i>пока ничего. скажи «соня, запомни: …»</i>")
    body = "\n".join(f"• {ui.esc(f)}" for f in facts)
    return f"<b>🧠 что я о тебе помню</b>\n{ui.LINE}\n{body}"


@router.message(Command("memory"))
async def cmd_memory(m: Message):
    await ui.personal(m, _facts_text(await db.get_facts(m.from_user.id)))   # личное — не на весь чат


@router.message(Command("forget"))
async def cmd_forget(m: Message):
    await db.clear_facts(m.from_user.id)
    await m.answer("всё, стёрла. кто ты вообще? 👀")


@router.message(Command("reset"))
async def cmd_reset(m: Message):
    await db.clear_history(m.chat.id)
    await m.answer("начнём с чистого листа ✨")


# ---------- inline-меню ----------
@router.callback_query(F.data == "m:home")
async def cb_home(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await _edit(cb, ui.start_text(cb.from_user.first_name), ui.main_menu(cb.from_user.id == config.OWNER_ID))


@router.callback_query(F.data == "m:profile")
async def cb_profile(cb: CallbackQuery):
    await _edit(cb, await _profile(cb.from_user.id),
                ui.back_kb([("🏅 Достижения", "m:ach"), ("📋 Задания", "g:quests"), ("🎂 ДР", "m:bday")]))


@router.callback_query(F.data == "m:bday")
async def cb_bday(cb: CallbackQuery):
    u = await db.get_user(cb.from_user.id) or {}
    if u.get("bday"):
        from handlers.life import bday_human
        text = f"🎂 твой ДР: <b>{bday_human(u['bday'])}</b>\nпоменять: <code>/bday 12.05</code> · стереть: <code>/bday -</code>"
    else:
        text = ("🎂 когда у тебя день рождения?\nнапиши <code>/bday 12.05</code> или «у меня др 12 мая» — "
                "в этот день поздравлю и подарю 🪙")
    await _edit(cb, text, ui.back_kb([("‹ Профиль", "m:profile")]))


@router.callback_query(F.data.startswith("m:top:"))
async def cb_top(cb: CallbackQuery):
    field = cb.data.split(":")[2]
    if field not in ui.TOP_TITLES:
        return await cb.answer()
    await _edit(cb, ui.top_text(field, await db.top(field)), ui.top_kb(field))


@router.callback_query(F.data == "m:facts")
async def cb_facts(cb: CallbackQuery):
    facts = await db.get_facts(cb.from_user.id)
    extra = [("🗑 Забыть всё", "m:forget")] if facts else []
    await _edit(cb, _facts_text(facts), ui.back_kb(extra))


@router.callback_query(F.data == "m:forget")
async def cb_forget(cb: CallbackQuery):
    await db.clear_facts(cb.from_user.id)
    await _edit(cb, _facts_text([]), ui.back_kb())


@router.callback_query(F.data == "m:help")
async def cb_help(cb: CallbackQuery):
    await _edit(cb, ui.HELP, ui.help_kb())


@router.callback_query(F.data.startswith("m:help:"))
async def cb_help_section(cb: CallbackQuery):
    key = cb.data.split(":", 2)[2]
    if key not in ui.HELP_SECTIONS:
        return await cb.answer()
    from handlers.ap_common import kb_rows
    await _edit(cb, ui.help_section(key), kb_rows([("‹ Разделы", "m:help"), ("‹ Меню", "m:home")]))
