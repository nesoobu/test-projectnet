"""Розыгрыши в каналах: приз, число победителей, срок, проверка подписки, честный выбор."""
import asyncio
import logging
import random
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter

import db
import ui
from autopost import store, timeparse
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("giveaway")
_rng = random.SystemRandom()
_last_edit: dict[int, float] = {}


class GW(StatesGroup):
    prize = State()
    time = State()


DURATIONS = [("1 час", 3600), ("6 часов", 6 * 3600), ("1 день", 86400), ("3 дня", 3 * 86400), ("7 дней", 7 * 86400)]


def post_text(g: dict, n: int) -> str:
    end = timeparse.fmt(g["ends"])
    need = "\n📌 условие: быть подписанным на канал" if g["need_sub"] else ""
    return (f"🎁 <b>РОЗЫГРЫШ</b>\n\n{escape(g['prize'])}\n\n"
            f"🏆 победителей: <b>{g['winners']}</b>\n⏳ итоги: <b>{end}</b> (мск){need}\n\n"
            f"👥 участников: <b>{n}</b>")


def join_kb(gid: int, n: int):
    return kb_rows([(f"🎉 Участвовать · {n}", f"gw:j:{gid}")])


# ================= создание =================
async def start_create(target, state: FSMContext, uid: int, cid: int):
    await state.set_state(GW.prize)
    await state.update_data(cid=cid)
    await show(target, "<b>🎁 новый розыгрыш</b>\n" + ui.LINE +
               "\nнапиши, что разыгрываем:\n<code>3 месяца Telegram Premium</code>",
               kb_rows([("✖️ Отмена", f"ap:ch:{cid}")]))


@router.callback_query(F.data.startswith("ap:gw:"))
async def cb_new(cb: CallbackQuery, state: FSMContext):
    cid = int(cb.data.split(":")[2])
    if not await store.channel(cid, cb.from_user.id):
        return await cb.answer("канал не найден", show_alert=True)
    await start_create(cb, state, cb.from_user.id, cid)


@router.message(Command("giveaway", "розыгрыш"), F.chat.type == "private")
async def cmd_new(m: Message, state: FSMContext):
    chs = await store.channels(m.from_user.id)
    if not chs:
        return await m.answer("сначала подключи канал: /panel → ➕ Канал")
    if len(chs) == 1:
        return await start_create(m, state, m.from_user.id, chs[0]["chat_id"])
    await m.answer("<b>🎁 в каком канале розыгрыш?</b>",
                   reply_markup=kb_rows(*[[(c["title"][:30], f"ap:gw:{c['chat_id']}")] for c in chs]))


@router.message(GW.prize, F.text)
async def st_prize(m: Message, state: FSMContext):
    await state.update_data(prize=m.text.strip()[:500])
    await m.answer("сколько победителей?",
                   reply_markup=kb_rows([(str(n), f"gw:w:{n}") for n in (1, 2, 3, 5, 10)]))


@router.callback_query(F.data.startswith("gw:w:"))
async def cb_winners(cb: CallbackQuery, state: FSMContext):
    await state.update_data(winners=int(cb.data.split(":")[2]))
    await state.set_state(GW.time)
    btns = [(t, f"gw:d:{s}") for t, s in DURATIONS]
    await show(cb, "сколько длится? или напиши время итогов: <code>завтра 20:00</code>",
               kb_rows(btns[:3], btns[3:]))


async def _preview(target, state: FSMContext, ends: int):
    await state.update_data(ends=ends, need_sub=True)
    d = await state.get_data()
    g = {"prize": d["prize"], "winners": d["winners"], "ends": ends, "need_sub": 1}
    await show(target, "👀 <b>так будет выглядеть:</b>\n\n" + post_text(g, 0),
               kb_rows([("🚀 Опубликовать", "gw:go")], [("✖️ Отмена", f"ap:ch:{d['cid']}")]))


@router.callback_query(F.data.startswith("gw:d:"))
async def cb_dur(cb: CallbackQuery, state: FSMContext):
    await _preview(cb, state, int(time.time()) + int(cb.data.split(":")[2]))


@router.message(GW.time, F.text)
async def st_time(m: Message, state: FSMContext):
    ts = timeparse.parse(m.text)
    if not ts or ts < time.time() + 300:
        return await m.answer("не поняла время (или раньше чем через 5 минут). пример: <code>завтра 20:00</code>")
    await _preview(m, state, ts)


@router.callback_query(F.data == "gw:go")
async def cb_go(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    if not d.get("ends"):
        return await cb.answer("начни заново", show_alert=True)
    await state.clear()
    gid = await db.q_run("INSERT INTO giveaways(owner_id,chat_id,prize,winners,ends,need_sub) VALUES(?,?,?,?,?,1)",
                         cb.from_user.id, d["cid"], d["prize"], d["winners"], d["ends"])
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    try:
        msg = await bot.send_message(d["cid"], post_text(g, 0), reply_markup=join_kb(gid, 0))
    except TelegramBadRequest as e:
        await db.q_run("UPDATE giveaways SET status='failed' WHERE id=?", gid)
        return await show(cb, f"😕 не смогла опубликовать: {escape(str(e)[:120])}")
    await db.q_run("UPDATE giveaways SET msg_id=? WHERE id=?", msg.message_id, gid)
    await show(cb, f"🎁 розыгрыш опубликован! итоги {timeparse.fmt(d['ends'])}\n"
                   "победителей выберу сама и пришлю тебе список",
               kb_rows([("📋 Мои розыгрыши", "gw:list")], [("‹ К каналу", f"ap:ch:{d['cid']}")]))


# ================= участие =================
@router.callback_query(F.data.startswith("gw:j:"))
async def cb_join(cb: CallbackQuery, bot: Bot):
    gid = int(cb.data.split(":")[2])
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    if not g or g["status"] != "active":
        return await cb.answer("розыгрыш уже закончился", show_alert=True)
    uid = cb.from_user.id
    if await db.q_one("SELECT 1 FROM giveaway_users WHERE gid=? AND uid=?", gid, uid):
        return await cb.answer("ты уже участвуешь 🍀", show_alert=True)
    if g["need_sub"]:
        try:
            mem = await bot.get_chat_member(g["chat_id"], uid)
            if mem.status in ("left", "kicked"):
                return await cb.answer("сначала подпишись на канал 👆", show_alert=True)
        except TelegramBadRequest:
            return await cb.answer("сначала подпишись на канал 👆", show_alert=True)
    await db.q_run("INSERT OR IGNORE INTO giveaway_users VALUES(?,?,?)", gid, uid, cb.from_user.full_name[:40])
    n = (await db.q_one("SELECT COUNT(*) n FROM giveaway_users WHERE gid=?", gid))["n"]
    await cb.answer(f"ты в игре! участников: {n} 🍀", show_alert=True)
    # обновляем счётчик не чаще раза в 5 секунд — иначе телеграм ругается
    if time.time() - _last_edit.get(gid, 0) > 5:
        _last_edit[gid] = time.time()
        try:
            await cb.message.edit_text(post_text(g, n), reply_markup=join_kb(gid, n))
        except (TelegramBadRequest, TelegramRetryAfter):
            pass


# ================= итоги =================
async def finish(bot: Bot, g: dict):
    users = await db.q_all("SELECT uid, name FROM giveaway_users WHERE gid=?", g["id"])
    pool = users[:]
    winners = []
    while pool and len(winners) < g["winners"]:
        u = pool.pop(_rng.randrange(len(pool)))
        if g["need_sub"]:  # к моменту итогов мог отписаться — пропускаем
            try:
                mem = await bot.get_chat_member(g["chat_id"], u["uid"])
                if mem.status in ("left", "kicked"):
                    continue
            except TelegramBadRequest:
                continue
        winners.append(u)
    await db.q_run("UPDATE giveaways SET status='done', result=? WHERE id=?",
                   ",".join(str(w["uid"]) for w in winners), g["id"])
    names = "\n".join(f"{i + 1}. <a href=\"tg://user?id={w['uid']}\">{escape(w['name'])}</a>"
                      for i, w in enumerate(winners)) or "никто не участвовал 🥲"
    text = (f"🎁 <b>РОЗЫГРЫШ ЗАВЕРШЁН</b>\n\n{escape(g['prize'])}\n\n👥 участников: {len(users)}\n"
            f"🏆 <b>победители:</b>\n{names}")
    try:
        await bot.edit_message_text(text, chat_id=g["chat_id"], message_id=g["msg_id"])
    except TelegramBadRequest:
        pass
    try:
        await bot.send_message(g["chat_id"], f"🎉 итоги розыгрыша!\n{names}",
                               reply_to_message_id=g["msg_id"])
    except TelegramBadRequest:
        pass
    try:
        await bot.send_message(g["owner_id"], f"🎁 розыгрыш завершён\n<i>{escape(g['prize'][:100])}</i>\n\n"
                                              f"победители:\n{names}\n\nсвяжись с ними для вручения приза")
    except Exception:
        pass


async def tick(bot: Bot):
    for g in await db.q_all("SELECT * FROM giveaways WHERE status='active' AND ends<=? AND msg_id IS NOT NULL",
                            int(time.time())):
        try:
            await finish(bot, g)
        except Exception:
            log.exception("giveaway %s", g["id"])


async def loop(bot: Bot):
    while True:
        await tick(bot)
        await asyncio.sleep(30)


# ================= список =================
@router.callback_query(F.data == "gw:list")
@router.message(Command("giveaways", "розыгрыши"))
async def gw_list(ev, bot: Bot = None):
    uid = ev.from_user.id
    rows = await db.q_all("SELECT g.*, (SELECT COUNT(*) FROM giveaway_users u WHERE u.gid=g.id) n "
                          "FROM giveaways g WHERE owner_id=? ORDER BY id DESC LIMIT 10", uid)
    lines = ["<b>🎁 мои розыгрыши</b>", ui.LINE]
    if not rows:
        lines.append("<i>пока нет. /panel → канал → 🎁 Розыгрыш</i>")
    btns = []
    for g in rows:
        st = {"active": "🟢", "done": "✅", "failed": "⚠️"}.get(g["status"], "•")
        lines.append(f"{st} {escape(g['prize'][:40])} · 👥{g['n']} · {timeparse.fmt(g['ends'])}")
        if g["status"] == "active":
            btns.append([(f"⏩ Подвести итоги сейчас: {g['prize'][:18]}", f"gw:end:{g['id']}")])
    await show(ev, "\n".join(lines), kb_rows(*btns, [("‹ Автопостинг", "ap:home")]))


@router.callback_query(F.data.startswith("gw:end:"))
async def cb_end(cb: CallbackQuery, bot: Bot):
    g = await db.q_one("SELECT * FROM giveaways WHERE id=? AND owner_id=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not g or g["status"] != "active":
        return await cb.answer("уже завершён", show_alert=True)
    await cb.answer("подвожу итоги…")
    await finish(bot, g)
    await gw_list(cb)
