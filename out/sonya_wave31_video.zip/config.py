import os
from pathlib import Path

BASE = Path(__file__).parent


def _load_env():
    p = BASE / ".env"
    if not p.exists():
        return
    for line in p.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_env()

BOT_TOKEN = os.getenv("BOT_TOKEN", "")
OWNER_ID = int(os.getenv("OWNER_ID", "0") or 0)
# узкие боты на том же коде: full — Соня целиком, dl — только скачивание, music — только музыка
PROFILE = os.getenv("BOT_PROFILE", "full").strip().lower() or "full"
MAIN_BOT = os.getenv("MAIN_BOT", "Sonya_rubot").lstrip("@")   # куда зовут узкие боты
DB_PATH = str(BASE / "data" / (os.getenv("DB_FILE", "") or "sonya.db"))

# LLM: любой OpenAI-совместимый провайдер (groq / deepseek / gemini)
LLM_URL = os.getenv("LLM_URL", "https://api.groq.com/openai/v1/chat/completions")
LLM_KEY = os.getenv("LLM_KEY", "")
LLM_MODEL = os.getenv("LLM_MODEL", "openai/gpt-oss-120b")
LLM_MODEL_FALLBACK = os.getenv("LLM_MODEL_FALLBACK", "qwen/qwen3-32b")
# модель, которая видит картинки (для живых подписей к фото); пусто — без зрения
# llama-4-scout Groq убрал; сейчас картинки понимает qwen3.8-27b (думающая — размышления отключаем)
LLM_VISION_MODEL = os.getenv("LLM_VISION_MODEL", "qwen/qwen3.8-27b")
# второй провайдер — если Groq лёг или упёрся в лимит (OpenRouter, Gemini, DeepSeek…)
LLM_URL_2 = os.getenv("LLM_URL_2", "")
LLM_KEY_2 = os.getenv("LLM_KEY_2", "")
LLM_MODEL_2 = os.getenv("LLM_MODEL_2", "")

# поиск в интернете (Groq compound сам ищет); пусто — выключен
SEARCH_MODEL = os.getenv("SEARCH_MODEL", "groq/compound-mini")
# отвечать в личке по мере набора текста (0 — выключить)
STREAM = os.getenv("STREAM", "1") != "0"

# токен pollinations.ai (рисование без водяного знака и без лимитов); пусто — бесплатно, со знаком
POLLINATIONS_TOKEN = os.getenv("POLLINATIONS_TOKEN", "")

# сервисный ключ VK — для автоисточника «VK-паблик»
VK_TOKEN = os.getenv("VK_TOKEN", "")

# обязательная подписка на канал (@username или -100…); пусто — выключено
REQUIRED_CHANNEL = os.getenv("REQUIRED_CHANNEL", "")
# сколько каналов автопостинга без Соня+ (0 — без ограничений)
FREE_CHANNELS = int(os.getenv("FREE_CHANNELS", "0") or 0)

# сколько ИИ-ответов в сутки на человека (болтовня, фото, инлайн); 0 — без лимита
AI_DAY_LIMIT = int(os.getenv("AI_DAY_LIMIT", "100") or 0)
AI_DAY_LIMIT_PLUS = int(os.getenv("AI_DAY_LIMIT_PLUS", "500") or 0)

# расшифровка голосовых (Groq Whisper); по умолчанию тот же ключ, что у LLM
STT_URL = os.getenv("STT_URL", LLM_URL.replace("chat/completions", "audio/transcriptions"))
STT_KEY = os.getenv("STT_KEY", LLM_KEY)
STT_MODEL = os.getenv("STT_MODEL", "whisper-large-v3-turbo")

HISTORY_LEN = 12          # сколько последних реплик помнит в диалоге
GROUP_TRIGGERS = ("соня", "сонь", "сонька", "sonya")
