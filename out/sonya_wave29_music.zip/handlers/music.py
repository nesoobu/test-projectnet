"""🎵 Музыка как у больших ботов: нумерованный список «Артист — Трек», страницы, обложки,
❤️ мои треки, 🔁 похожие, 👤 ещё от артиста, 🔥 чарт, 📝 текст."""
import io
import logging
import time
import uuid
from html import escape

from aiogram import Router, F, Bot
from aiogram.enums import ChatAction
from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, FSInputFile, BufferedInputFile
from aiogram.exceptions import TelegramBadRequest

import config
import db
import ui
from autopost import media_dl
from downloader import core, catalog
from handlers.ap_common import kb_rows

router = Router()
log = logging.getLogger("music")
PAGE = 8
_S: dict[str, dict] = {}       # sid → {"title", "keys", "ts"}
_busy: set[int] = set()


# ================= список с номерами =================
def _session(title: str, tracks: list[dict]) -> str:
    now = time.time()
    for k, v in list(_S.items()):
        if now - v["ts"] > 6 * 3600:
            _S.pop(k, None)
    sid = uuid.uuid4().hex[:8]
    _S[sid] = {"title": title, "tracks": tracks, "ts": now}
    return sid


def list_view(sid: str, page: int = 0) -> tuple[str, object]:
    s = _S[sid]
    tr = s["tracks"]
    pages = max(1, (len(tr) + PAGE - 1) // PAGE)
    page = max(0, min(page, pages - 1))
    chunk = tr[page * PAGE:(page + 1) * PAGE]
    lines = [s["title"], ui.hint(f"нашла {len(tr)} · жми номер — пришлю трек"
                                 + (f" · стр. {page + 1}/{pages}" if pages > 1 else "")), ""]
    for i, t in enumerate(chunk, page * PAGE + 1):
        d = catalog.mmss(t["dur"])
        who = f"{escape(t['artist'][:40])} — " if t["artist"] else ""
        lines.append(f"<b>{i}.</b> {who}<b>{escape(t['title'][:60])}</b>" + (f" <i>{d}</i>" if d else ""))
    nums = [(str(i), f"mx:get:{t['key']}") for i, t in enumerate(chunk, page * PAGE + 1)]
    rows = [nums[:4], nums[4:8]] if len(nums) > 4 else [nums]
    if pages > 1:
        rows.append([("‹", f"ms:{sid}:{page - 1}" if page else "ms:noop"),
                     (f"{page + 1} / {pages}", "ms:noop"),
                     ("›", f"ms:{sid}:{page + 1}" if page < pages - 1 else "ms:noop")])
    return "\n".join(lines), kb_rows(*[r for r in rows if r])


async def show_list(m: Message, title: str, tracks: list[dict], status: Message | None = None):
    if not tracks:
        text = "🤷 ничего не нашла. попробуй «артист название» или строчку из песни"
        return await (status.edit_text(text) if status else m.answer(text))
    text, kb = list_view(_session(title, tracks))
    if status:
        try:
            return await status.edit_text(text, reply_markup=kb)
        except TelegramBadRequest:
            pass
    await m.answer(text, reply_markup=kb)


async def search(m: Message, query: str):
    query = query.strip()[:100]
    if len(query) < 2:
        return await m.reply("что ищем? напиши артиста и название, например: <code>oxvgen memory</code>")
    from handlers.tools import too_soon
    if (left := too_soon(m.from_user.id, "find", 3)):
        return await m.reply(f"секунду, ещё {left} с")
    st = await m.reply("🔎 ищу…")
    try:
        res = await catalog.search(query, 32)
    except Exception as e:
        log.warning("search: %s", e)
        res = []
    await show_list(m, f"🔎 <b>{escape(query)}</b>", res, st)


@router.callback_query(F.data.startswith("ms:"))
async def cb_page(cb: CallbackQuery):
    parts = cb.data.split(":")
    if parts[1] == "noop":
        return await cb.answer()
    if parts[1] not in _S:
        return await cb.answer("список устарел — поищи заново", show_alert=True)
    text, kb = list_view(parts[1], int(parts[2]))
    try:
        await cb.message.edit_text(text, reply_markup=kb)
    except TelegramBadRequest:
        pass
    await cb.answer()


# ================= трек =================
async def is_fav(uid: int, key: str) -> bool:
    return bool(await db.q_one("SELECT 1 FROM music_fav WHERE uid=? AND key=?", uid, key))


def track_kb(t: dict, fav: bool):
    rows = [[("📝 Текст", f"mx:ly:{t['key']}"), ("💔 Убрать из моих" if fav else "❤️ В мои", f"mx:fav:{t['key']}")],
            [("🔁 Похожие", f"mx:sim:{t['key']}")]]
    if t["artist"]:
        rows[1].append((f"👤 {t['artist'][:20]}", f"mx:art:{t['key']}"))
    return kb_rows(*rows)


async def _thumb(url: str):
    if not url:
        return None
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(await core.fetch_bytes(url))).convert("RGB")
        im.thumbnail((320, 320))
        out = io.BytesIO()
        im.save(out, "JPEG", quality=85)
        return BufferedInputFile(out.getvalue(), "cover.jpg")
    except Exception as e:
        log.info("cover: %s", e)
        return None


async def send_track(m: Message, bot: Bot, key: str, uid: int):
    t = await catalog.get(key)
    if not t:
        return await m.answer("😕 этот трек я забыла — поищи заново")
    me = await bot.me()
    cap = f'<a href="https://t.me/{me.username}">@{me.username}</a>' if me.username else None
    kb = track_kb(t, await is_fav(uid, key))
    c = await db.dl_cache_get(f"audio:{key}")
    if c:
        try:
            await m.answer_audio(c["file_id"], caption=cap, reply_markup=kb)
            return await _done(m, uid)
        except TelegramBadRequest:
            pass
    await bot.send_chat_action(m.chat.id, ChatAction.UPLOAD_VOICE)
    f = None
    try:
        f = await core.download(await catalog.audio_url(t), "audio")
        sent = await m.answer_audio(FSInputFile(f["path"]), caption=cap, reply_markup=kb,
                                    title=t["title"] or f.get("title") or None,
                                    performer=t["artist"] or f.get("performer") or None,
                                    duration=f.get("duration") or t["dur"] or None, thumbnail=await _thumb(t["cover"]))
        if sent.audio:
            await db.dl_cache_put(f"audio:{key}", "audio", sent.audio.file_id, catalog.name(t))
        await _done(m, uid)
    except media_dl.DLError as e:
        await m.answer(f"😕 не скачалось: {escape(str(e))}")
    except TelegramBadRequest as e:
        await m.answer(f"😕 телеграм не принял файл ({escape(str(e)[:60])})")
    finally:
        core.remove(f and f.get("path"))


async def _done(m: Message, uid: int):
    await db.count_dl(uid)
    if config.PROFILE != "full" and m.chat.type == "private":
        from handlers import solo
        await solo.nudge(m, uid)


@router.callback_query(F.data.startswith("mx:get:"))
async def cb_get(cb: CallbackQuery, bot: Bot):
    uid = cb.from_user.id
    if uid in _busy:
        return await cb.answer("⏳ ещё качаю прошлый трек", show_alert=True)
    await cb.answer("качаю…")
    _busy.add(uid)
    try:
        await send_track(cb.message, bot, cb.data[7:], uid)
    finally:
        _busy.discard(uid)


@router.callback_query(F.data.startswith("mx:fav:"))
async def cb_fav(cb: CallbackQuery):
    key, uid = cb.data[7:], cb.from_user.id
    t = await catalog.get(key)
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    if await is_fav(uid, key):
        await db.q_run("DELETE FROM music_fav WHERE uid=? AND key=?", uid, key)
        await cb.answer("убрала из твоих треков")
    else:
        await db.q_run("INSERT OR REPLACE INTO music_fav VALUES(?,?,?)", uid, key, int(time.time()))
        await cb.answer("❤️ сохранила — открой /my")
    try:
        await cb.message.edit_reply_markup(reply_markup=track_kb(t, await is_fav(uid, key)))
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("mx:ly:"))
async def cb_ly(cb: CallbackQuery):
    t = await catalog.get(cb.data[6:])
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    from handlers import tools
    if (left := tools.too_soon(cb.from_user.id, "lyr", 3)):
        return await cb.answer(f"секунду, ещё {left} с")
    await cb.answer("ищу текст…")
    await tools.send_lyrics(cb.message, f"{t['artist']} {t['title']}")


@router.callback_query(F.data.startswith(("mx:sim:", "mx:art:")))
async def cb_more(cb: CallbackQuery):
    t = await catalog.get(cb.data[7:])
    if not t:
        return await cb.answer("трек устарел", show_alert=True)
    await cb.answer("ищу…")
    sim = cb.data.startswith("mx:sim:")
    res = await (catalog.similar(t) if sim else catalog.by_artist(t))
    title = (f"🔁 <b>похожее на</b> {escape(catalog.name(t))}" if sim else f"👤 <b>{escape(t['artist'])}</b>")
    await show_list(cb.message, title, res)


# ================= чарт и мои треки =================
async def chart_list(m: Message):
    st = await m.answer("🔥 собираю чарт…")
    await show_list(m, "🔥 <b>чарт</b> — что слушают сейчас", await catalog.chart(), st)


async def my_list(m: Message, uid: int):
    rows = await db.q_all("SELECT t.data FROM music_fav f JOIN music_tracks t ON t.key=f.key "
                          "WHERE f.uid=? ORDER BY f.ts DESC LIMIT 200", uid)
    if not rows:
        return await m.answer("❤️ <b>твои треки</b>\n" + ui.hint("пока пусто — жми «❤️ В мои» под любым треком"))
    import json
    await show_list(m, "❤️ <b>твои треки</b>", [json.loads(r["data"]) for r in rows])


def _top_cmd(m: Message) -> bool:
    return config.PROFILE == "music"


@router.message(Command("chart", "чарт"))
@router.message(Command("top"), _top_cmd)
async def cmd_chart(m: Message):
    await chart_list(m)


@router.message(Command("my", "mytracks"))
async def cmd_my(m: Message):
    await my_list(m, m.from_user.id)


@router.callback_query(F.data.in_({"mx:top", "mx:my"}))
async def cb_menu(cb: CallbackQuery):
    await cb.answer()
    if cb.data == "mx:top":
        await chart_list(cb.message)
    else:
        await my_list(cb.message, cb.from_user.id)


# ================= шазам → карточка трека =================
async def found_card(st: Message, artist: str, title: str, cover: str, link: str = ""):
    import hashlib
    t = catalog.track("sz", hashlib.md5(f"{artist}|{title}".encode()).hexdigest()[:12], artist, title, cover=cover)
    try:   # если есть в каталоге — берём оттуда: точная длительность, похожие, артист
        for c in await catalog.search(f"{artist} {title}", 5):
            if c["title"].lower().startswith(title.lower()[:12]) and artist.lower()[:6] in c["artist"].lower():
                t = {**c, "cover": c["cover"] or cover}
                break
    except Exception as e:
        log.info("shazam catalog: %s", e)
    await catalog.remember([t])
    text = f"🎵 <b>{escape(artist)}</b> — {escape(title)}"
    if t["album"]:
        text += f"\n💿 <i>{escape(t['album'])}</i>"
    if link:
        text += f'\n<a href="{escape(link, quote=True)}">shazam</a>'
    kb = kb_rows([("⬇️ Скачать трек", f"mx:get:{t['key']}"), ("📝 Текст", f"mx:ly:{t['key']}")],
                 [("🔁 Похожие", f"mx:sim:{t['key']}")])
    if t["cover"]:
        try:
            await st.answer_photo(t["cover"], caption=text, reply_markup=kb)
            return await st.delete()
        except TelegramBadRequest:
            pass
    await st.edit_text(text, reply_markup=kb)
