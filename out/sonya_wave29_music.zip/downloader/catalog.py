"""Музыкальный каталог: настоящие «Артист — Трек», обложки, похожие и чарт.
Яндекс Музыка (без токена, только метаданные) → Deezer → YouTube. Сам звук — с YouTube, подбором по длительности."""
import asyncio
import json
import logging
import re
import time

import aiohttp

import db

log = logging.getLogger("catalog")
TIMEOUT = aiohttp.ClientTimeout(total=10)
STATUS: dict[str, str] = {}          # провайдер → последняя ошибка (для админки)
BAD_WORDS = ("slowed", "sped up", "speed up", "reverb", "nightcore", "8d", "karaoke", "караоке", "минус",
             "instrumental", "cover", "кавер", "remix", "ремикс", "live", "концерт", "lyrics video", "1 hour",
             "1 час", "tiktok version", "bass boosted", "перевод", "reaction", "реакция")


def track(src: str, id_, artist: str, title: str, dur: int = 0, cover: str = "", album: str = "",
          artist_id: str = "") -> dict:
    return {"key": f"{src}:{id_}", "src": src, "id": str(id_), "artist": (artist or "").strip(),
            "title": (title or "").strip(), "dur": int(dur or 0), "cover": cover or "", "album": album or "",
            "artist_id": str(artist_id or "")}


def name(t: dict) -> str:
    return f"{t['artist']} — {t['title']}" if t["artist"] else t["title"]


def mmss(sec: int) -> str:
    return f"{sec // 60}:{sec % 60:02d}" if sec else ""


# ---------- память о треках: кнопки под аудио живут и после перезапуска ----------
async def remember(tracks: list[dict]):
    now = int(time.time())
    for t in tracks:
        await db.q_run("INSERT OR REPLACE INTO music_tracks VALUES(?,?,?)", t["key"], json.dumps(t, ensure_ascii=False), now)


async def get(key: str) -> dict | None:
    r = await db.q_one("SELECT data FROM music_tracks WHERE key=?", key)
    return json.loads(r["data"]) if r else None


# ================= Яндекс Музыка =================
def _ym(t) -> dict | None:
    if not t or t.available is False or not t.title:
        return None
    title = t.title + (f" ({t.version})" if getattr(t, "version", None) else "")
    al = t.albums[0] if t.albums else None
    cover = f"https://{t.cover_uri.replace('%%', '400x400')}" if t.cover_uri else ""
    return track("ym", t.id, ", ".join(t.artists_name()) if t.artists else "", title, (t.duration_ms or 0) // 1000,
                 cover, al.title if al else "", t.artists[0].id if t.artists else "")


def _ym_client():
    from yandex_music import ClientAsync
    return ClientAsync()   # без токена: поиск, чарт и похожие доступны, скачивание — нет (берём с YouTube)


async def ym_search(q: str, n: int) -> list[dict]:
    r = await _ym_client().search(q, type_="track")
    res = r.tracks.results if r and r.tracks else []
    return [x for x in map(_ym, res[:n]) if x]


async def ym_similar(t: dict) -> list[dict]:
    r = await _ym_client().tracks_similar(t["id"])
    return [x for x in map(_ym, (r.similar_tracks if r else [])[:30]) if x]


async def ym_artist(t: dict) -> list[dict]:
    r = await _ym_client().artists_tracks(t["artist_id"], page_size=30)
    return [x for x in map(_ym, r.tracks if r else []) if x]


async def ym_chart() -> list[dict]:
    r = await _ym_client().chart("russia")
    items = r.chart.tracks if r and r.chart else []
    return [x for x in (_ym(i.track) for i in items[:50]) if x]


# ================= Deezer (бесплатное API без ключа) =================
async def _dz(path: str, **params) -> dict:
    async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
        async with s.get(f"https://api.deezer.com/{path}", params=params) as r:
            d = await r.json(content_type=None)
    if isinstance(d, dict) and d.get("error"):
        raise RuntimeError(str(d["error"])[:80])
    return d


def _dzt(x: dict) -> dict:
    a, al = x.get("artist") or {}, x.get("album") or {}
    return track("dz", x["id"], a.get("name", ""), x.get("title") or "", x.get("duration") or 0,
                 al.get("cover_medium") or "", al.get("title") or "", a.get("id") or "")


async def dz_search(q: str, n: int) -> list[dict]:
    return [_dzt(x) for x in (await _dz("search", q=q, limit=n)).get("data", []) if x.get("id")]


async def dz_similar(t: dict) -> list[dict]:
    rel = (await _dz(f"artist/{t['artist_id']}/related", limit=8)).get("data", [])
    tops = await asyncio.gather(*[_dz(f"artist/{a['id']}/top", limit=3) for a in rel], return_exceptions=True)
    return [_dzt(x) for d in tops if isinstance(d, dict) for x in d.get("data", [])]


async def dz_artist(t: dict) -> list[dict]:
    return [_dzt(x) for x in (await _dz(f"artist/{t['artist_id']}/top", limit=30)).get("data", [])]


async def dz_chart() -> list[dict]:
    return [_dzt(x) for x in (await _dz("chart/0/tracks", limit=50)).get("data", [])]


# ================= YouTube (запасной) =================
def _yt_flat(q: str, n: int) -> list[dict]:
    import yt_dlp
    with yt_dlp.YoutubeDL({"quiet": True, "no_warnings": True, "extract_flat": True}) as y:
        info = y.extract_info(f"ytsearch{n}:{q}", download=False)
    return [e for e in (info.get("entries") or []) if e and e.get("id")]


def split_title(raw: str, channel: str = "") -> tuple[str, str]:
    from handlers.tools import clean_title
    t = clean_title(raw)
    for sep in (" - ", " — ", " – "):
        if sep in t:
            a, b = t.split(sep, 1)
            return a.strip(), b.strip()
    return re.sub(r"\s*-\s*Topic$", "", channel or "").strip(), t


async def yt_search(q: str, n: int) -> list[dict]:
    out = []
    for e in await asyncio.to_thread(_yt_flat, q, n + 4):
        dur = int(e.get("duration") or 0)
        if dur > 10 * 60:
            continue   # 13-минутные разборы и миксы — не песни
        a, ti = split_title(e.get("title") or "", e.get("channel") or e.get("uploader") or "")
        out.append(track("yt", e["id"], a, ti, dur))
    return out[:n]


# ================= общий вход =================
PROVIDERS = [("ym", "Яндекс Музыка"), ("dz", "Deezer"), ("yt", "YouTube")]


async def _chain(fn: str, *args) -> list[dict]:
    for src, _ in PROVIDERS:
        f = globals().get(f"{src}_{fn}")
        if not f:
            continue
        try:
            res = await asyncio.wait_for(f(*args), 25)
            STATUS[src] = ""
            if res:
                return res
        except Exception as e:
            STATUS[src] = str(e)[:100] or type(e).__name__
            log.info("%s %s: %s", src, fn, STATUS[src])
    return []


async def search(q: str, n: int = 30) -> list[dict]:
    res = await _chain("search", q, n)
    await remember(res)
    return res


async def chart() -> list[dict]:
    res = await _chain("chart")
    await remember(res)
    return res


async def similar(t: dict) -> list[dict]:
    f = {"ym": ym_similar, "dz": dz_similar}.get(t["src"])
    res = []
    if f and t.get("id"):
        try:
            res = await asyncio.wait_for(f(t), 25)
        except Exception as e:
            log.info("similar: %s", e)
    if not res and t["artist"]:   # нет похожих — ищем по артисту, без самого трека
        res = [x for x in await _chain("search", t["artist"], 20) if x["title"].lower() != t["title"].lower()]
    await remember(res)
    return res


async def by_artist(t: dict) -> list[dict]:
    f = {"ym": ym_artist, "dz": dz_artist}.get(t["src"])
    res = []
    if f and t.get("artist_id"):
        try:
            res = await asyncio.wait_for(f(t), 25)
        except Exception as e:
            log.info("artist: %s", e)
    if not res and t["artist"]:
        res = await _chain("search", t["artist"], 30)
    await remember(res)
    return res


async def diag(q: str = "oxvgen memory") -> list[tuple[str, str]]:
    out = []
    for src, title in PROVIDERS:
        try:
            r = await asyncio.wait_for(globals()[f"{src}_search"](q, 5), 25)
            out.append((title, f"✅ {len(r)} · {name(r[0])[:40]}" if r else "⚠️ пусто"))
        except Exception as e:
            out.append((title, f"❌ {str(e)[:80] or type(e).__name__}"))
    return out


# ================= подбор звука на YouTube под трек из каталога =================
def _score(e: dict, t: dict) -> float:
    title = (e.get("title") or "").lower()
    ch = (e.get("channel") or e.get("uploader") or "").lower()
    want = f"{t['artist']} {t['title']}".lower()
    s = 0.0
    for w in re.findall(r"\w+", want):
        if len(w) > 1 and w in title + " " + ch:
            s += 1
    for b in BAD_WORDS:
        if b in title and b not in want:
            s -= 4
    if ch.endswith("- topic") or "official audio" in title or "audio" in title:
        s += 2
    dur = int(e.get("duration") or 0)
    if t["dur"] and dur:
        diff = abs(dur - t["dur"])
        s += 3 if diff <= 3 else 1.5 if diff <= 10 else -3 if diff > 30 else 0
    return s


async def audio_url(t: dict) -> str:
    if t["src"] == "yt":
        return f"https://youtu.be/{t['id']}"
    q = f"{t['artist']} - {t['title']}" if t["artist"] else t["title"]
    try:
        cands = await asyncio.to_thread(_yt_flat, q, 8)
    except Exception as e:
        log.info("match: %s", e)
        cands = []
    if not cands:
        return f"ytsearch1:{q} audio"
    best = max(cands, key=lambda e: _score(e, t))
    return f"https://youtu.be/{best['id']}"
