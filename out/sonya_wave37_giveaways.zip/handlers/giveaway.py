"""🎁 Розыгрыши: приз (текст / подарок на N ⭐ / конкретный подарок), каналы-спонсоры, только Premium,
билеты за друзей, итоги по времени или числу участников, картинка, честный взвешенный выбор,
перевыбор победителя, отмена с возвратом звёзд, список участников файлом."""
import asyncio
import hashlib
import io
import json
import logging
import random
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery, BufferedInputFile
from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter

import db
import ui
from autopost import store, timeparse
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("giveaway")
_rng = random.SystemRandom()
_last_edit: dict[int, float] = {}
MAX_SPONSORS = 5
MAX_REF_TICKETS = 10


class GW(StatesGroup):
    prize = State()
    time = State()
    sponsor = State()
    photo = State()
    connect = State()


DURATIONS = [("1 час", 3600), ("6 часов", 6 * 3600), ("1 день", 86400), ("3 дня", 3 * 86400), ("7 дней", 7 * 86400)]


# ================= текст поста =================
def _extra(g: dict) -> list[dict]:
    try:
        return json.loads(g.get("extra_chats") or "[]")
    except ValueError:
        return []


def post_text(g: dict, n: int) -> str:
    conds = []
    if g["need_sub"]:
        conds.append("быть подписанным на этот канал")
    for c in _extra(g):
        conds.append(f"подписка на {('@' + c['u']) if c.get('u') else escape(c['t'])}")
    if g.get("premium_only"):
        conds.append("Telegram Premium ⭐")
    end = []
    if g["ends"]:
        end.append(f"⏳ итоги: <b>{timeparse.fmt(g['ends'])}</b> (мск)")
    if g.get("max_users"):
        end.append(f"🏁 или когда наберётся <b>{g['max_users']}</b> участников")
    text = f"🎁 <b>РОЗЫГРЫШ</b>\n\n{escape(g['prize'])}\n\n🏆 победителей: <b>{g['winners']}</b>\n" + "\n".join(end)
    if conds:
        text += "\n\n📌 <b>условия:</b>\n" + "\n".join(f"• {c}" for c in conds)
    if g.get("ref_bonus"):
        text += f"\n\n🎟 зови друзей — за каждого +1 билет (до {MAX_REF_TICKETS})"
    return text + f"\n\n👥 участников: <b>{n}</b>"


def join_kb(gid: int, n: int, bot_username: str = "", ref: bool = False):
    rows = [[(f"🎉 Участвовать · {n}", f"gw:j:{gid}")]]
    if ref and bot_username:
        rows.append([("🎟 Больше шансов: позвать друзей", f"https://t.me/{bot_username}?start=gwr_{gid}")])
    return kb_rows(*rows)


async def _kb(bot: Bot, g: dict, n: int):
    me = await bot.me()
    return join_kb(g["id"], n, me.username or "", bool(g.get("ref_bonus")))


# ================= подключение канала прямо из розыгрыша =================
CONNECT_HINT = ("📢 <b>в каком канале разыгрываем?</b>\n"
                "1. добавь меня в канал админом с правом «публиковать сообщения»\n"
                "2. перешли сюда любой пост из канала — или пришли его @username")


@router.message(GW.connect)
async def st_connect(m: Message, state: FSMContext, bot: Bot):
    ref = None
    fo = m.forward_origin
    if fo is not None and getattr(fo, "chat", None):
        ref = fo.chat.id
    elif m.text and m.text.strip().startswith("@"):
        ref = m.text.strip().split()[0]
    if ref is None:
        return await m.answer(CONNECT_HINT)
    try:
        chat = await bot.get_chat(ref)
        me = await bot.get_chat_member(chat.id, (await bot.me()).id)
        you = await bot.get_chat_member(chat.id, m.from_user.id)
    except Exception:
        return await m.answer("не вижу этот канал 🤔 я точно там админ?")
    if you.status not in ("administrator", "creator"):
        return await m.answer("ты не админ этого канала 🤨")
    if chat.type == "channel" and (me.status != "administrator" or not getattr(me, "can_post_messages", False)):
        return await m.answer("дай мне право «публиковать сообщения» и пришли ещё раз")
    exist = await store.channel(chat.id)
    if exist and exist["owner_id"] != m.from_user.id:
        return await m.answer("этот канал уже подключил другой админ")
    if not exist:
        await store.add_channel(chat.id, m.from_user.id, chat.title or "канал", chat.username)
    await m.answer(f"✅ <b>{escape(chat.title or '')}</b> подключён")
    await start_create(m, state, m.from_user.id, chat.id)


# ================= создание =================
async def start_create(target, state: FSMContext, uid: int, cid: int):
    from handlers import gifts
    await state.clear()
    await state.update_data(cid=cid)
    await show(target, "<b>🎁 новый розыгрыш</b>\n" + ui.LINE + "\nчто разыгрываем?\n"
               + ui.hint(f"⭐ на подарки у тебя: {await gifts.balance(uid)} — пополнить: /fund"),
               kb_rows([("⭐ Подарок на N звёзд — победитель выберет", "gw:pt:stars")],
                       [("🎁 Конкретный подарок", "gw:pt:exact"), ("✍️ Свой приз", "gw:pt:text")],
                       [("✖️ Отмена", "gw:cancelnew")]))


@router.callback_query(F.data == "gw:cancelnew")
async def cb_cancel_new(cb: CallbackQuery, state: FSMContext):
    await state.clear()
    await cb.answer("отменила")
    try:
        await cb.message.delete()
    except TelegramBadRequest:
        pass


@router.callback_query(F.data.startswith("ap:gw:"))
async def cb_new(cb: CallbackQuery, state: FSMContext):
    cid = int(cb.data.split(":")[2])
    if not await store.channel(cid, cb.from_user.id):
        return await cb.answer("канал не найден", show_alert=True)
    await cb.answer()
    await start_create(cb, state, cb.from_user.id, cid)


@router.callback_query(F.data == "gw:addch")
async def cb_addch(cb: CallbackQuery, state: FSMContext):
    await state.set_state(GW.connect)
    await cb.answer()
    await cb.message.answer(CONNECT_HINT)


@router.message(Command("giveaway", "розыгрыш"), F.chat.type == "private")
async def cmd_new(m: Message, state: FSMContext):
    chs = await store.channels(m.from_user.id)
    if not chs:
        await state.set_state(GW.connect)
        return await m.answer(CONNECT_HINT)
    if len(chs) == 1:
        return await start_create(m, state, m.from_user.id, chs[0]["chat_id"])
    await m.answer("<b>🎁 в каком канале розыгрыш?</b>",
                   reply_markup=kb_rows(*[[(c["title"][:30], f"ap:gw:{c['chat_id']}")] for c in chs],
                                        [("➕ Другой канал", "gw:addch")]))


@router.callback_query(F.data.startswith("gw:pt:"))
async def cb_prize_type(cb: CallbackQuery, state: FSMContext, bot: Bot):
    from handlers import gifts
    kind = cb.data[6:]
    d = await state.get_data()
    if not d.get("cid"):
        return await cb.answer("начни заново: /giveaway", show_alert=True)
    await cb.answer()
    if kind == "text":
        await state.set_state(GW.prize)
        return await show(cb, "напиши, что разыгрываем:\n<code>3 месяца Telegram Premium</code>",
                          kb_rows([("✖️ Отмена", "gw:cancelnew")]))
    gl = await gifts.catalog(bot)
    if not gl:
        return await cb.message.answer("Telegram не отдал список подарков — попробуй позже")
    if kind == "stars":
        ps = await gifts.prices(bot)
        return await show(cb, "⭐ <b>на сколько звёзд подарок?</b>\nпобедитель сам выберет подарок такой цены",
                          kb_rows([(f"{p} ⭐", f"gw:ps:{p}") for p in ps[:4]], [(f"{p} ⭐", f"gw:ps:{p}") for p in ps[4:8]]))
    rows, line = [], []
    for g in gl[:24]:
        line.append((f"{g['emoji']} {g['stars']}⭐", f"gw:pe:{g['id']}"))
        if len(line) == 4:
            rows.append(line)
            line = []
    if line:
        rows.append(line)
    await show(cb, "🎁 <b>какой подарок разыгрываем?</b>\n" + ui.hint("цена — за одного победителя"), kb_rows(*rows))


def _winners_kb():
    return kb_rows([(str(n), f"gw:w:{n}") for n in (1, 2, 3, 5, 10)])


@router.callback_query(F.data.startswith(("gw:ps:", "gw:pe:")))
async def cb_prize_pick(cb: CallbackQuery, state: FSMContext, bot: Bot):
    from handlers import gifts
    val = cb.data[6:]
    if cb.data.startswith("gw:ps:"):
        stars = int(val)
        await state.update_data(gift_kind="stars", gift_stars=stars, gift_id="",
                                prize=f"🎁 подарок Telegram на {stars} ⭐ — победитель сам выберет, какой")
    else:
        g = next((x for x in await gifts.catalog(bot) if x["id"] == val), None)
        if not g:
            return await cb.answer("этот подарок закончился", show_alert=True)
        await state.update_data(gift_kind="exact", gift_stars=g["stars"], gift_id=g["id"],
                                prize=f"🎁 подарок Telegram {g['emoji']} ({g['stars']} ⭐)")
    await cb.answer()
    await cb.message.answer("сколько победителей?", reply_markup=_winners_kb())


@router.message(GW.prize, F.text)
async def st_prize(m: Message, state: FSMContext):
    await state.update_data(prize=m.text.strip()[:500])
    await m.answer("сколько победителей?", reply_markup=_winners_kb())


@router.callback_query(F.data.startswith("gw:w:"))
async def cb_winners(cb: CallbackQuery, state: FSMContext):
    n = int(cb.data.split(":")[2])
    d = await state.get_data()
    if d.get("gift_kind"):
        from handlers import gifts
        need, have = d["gift_stars"] * n, await gifts.balance(cb.from_user.id)
        if have < need:
            await cb.answer()
            return await cb.message.answer(
                f"⭐ на {n} × {d['gift_stars']} ⭐ нужно <b>{need} ⭐</b>, а у тебя {have} ⭐",
                reply_markup=kb_rows([("➕ Пополнить звёзды", "m:fund")],
                                     [(f"{k} победит.", f"gw:w:{k}") for k in (1, 2, 3) if d['gift_stars'] * k <= have]))
    await state.update_data(winners=n)
    await state.set_state(GW.time)
    btns = [(t, f"gw:d:{s}") for t, s in DURATIONS]
    await show(cb, "⏳ когда итоги? выбери или напиши время: <code>завтра 20:00</code>\n"
                   + ui.hint("или «🏁 по числу участников» — итоги, как только наберётся нужное количество"),
               kb_rows(btns[:3], btns[3:], [("🏁 По числу участников", "gw:mx")]))


@router.callback_query(F.data == "gw:mx")
async def cb_max_menu(cb: CallbackQuery):
    await cb.answer()
    await cb.message.answer("🏁 сколько участников наберём?",
                            reply_markup=kb_rows([(str(n), f"gw:mxn:{n}") for n in (50, 100, 300, 500, 1000)]))


@router.callback_query(F.data.startswith("gw:mxn:"))
async def cb_max(cb: CallbackQuery, state: FSMContext):
    await state.update_data(max_users=int(cb.data.split(":")[2]))
    await cb.answer()
    await _preview(cb, state, 0)


@router.callback_query(F.data.startswith("gw:d:"))
async def cb_dur(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    await _preview(cb, state, int(time.time()) + int(cb.data.split(":")[2]))


@router.message(GW.time, F.text)
async def st_time(m: Message, state: FSMContext):
    ts = timeparse.parse(m.text)
    if not ts or ts < time.time() + 300:
        return await m.answer("не поняла время (или раньше чем через 5 минут). пример: <code>завтра 20:00</code>")
    await _preview(m, state, ts)


# ================= настройки перед публикацией =================
def _draft(d: dict) -> dict:
    return {"id": 0, "prize": d["prize"], "winners": d["winners"], "ends": d.get("ends") or 0, "need_sub": 1,
            "extra_chats": json.dumps(d.get("extra") or []), "premium_only": d.get("premium_only", 0),
            "ref_bonus": d.get("ref_bonus", 0), "max_users": d.get("max_users", 0)}


async def _preview(target, state: FSMContext, ends: int | None = None):
    if ends is not None:
        await state.update_data(ends=ends)
    await state.set_state(None)
    d = await state.get_data()
    g = _draft(d)
    tog = ui.tog
    kb = kb_rows([(f"{tog(d.get('ref_bonus'))} 🎟 Билеты за друзей", "gw:o:ref"),
                  (f"{tog(d.get('premium_only'))} ⭐ Только Premium", "gw:o:prem")],
                 [(f"📢 Спонсоры · {len(d.get('extra') or [])}", "gw:o:sp"),
                  ("🖼 Картинка" + (" ✅" if d.get("photo") else ""), "gw:o:ph")],
                 [("🚀 Опубликовать", "gw:go")], [("✖️ Отмена", "gw:cancelnew")])
    await show(target, "👀 <b>так будет выглядеть:</b>\n\n" + post_text(g, 0) + "\n\n"
               + ui.hint("настрой условия кнопками ниже и жми «Опубликовать»"), kb)


@router.callback_query(F.data.startswith("gw:o:"))
async def cb_opt(cb: CallbackQuery, state: FSMContext):
    opt = cb.data[5:]
    d = await state.get_data()
    if "prize" not in d:
        return await cb.answer("начни заново: /giveaway", show_alert=True)
    await cb.answer()
    if opt == "ref":
        await state.update_data(ref_bonus=0 if d.get("ref_bonus") else 1)
    elif opt == "prem":
        await state.update_data(premium_only=0 if d.get("premium_only") else 1)
    elif opt == "sp":
        await state.set_state(GW.sponsor)
        return await cb.message.answer(
            "📢 пришли @username канала-спонсора (до 5). я должна быть там админом, чтобы проверять подписку\n"
            + ui.hint("«готово» — вернуться · «очистить» — убрать всех"))
    elif opt == "ph":
        await state.set_state(GW.photo)
        return await cb.message.answer("🖼 пришли картинку для поста (или «без картинки»)")
    await _preview(cb, state)


@router.message(GW.sponsor, F.text)
async def st_sponsor(m: Message, state: FSMContext, bot: Bot):
    t = m.text.strip()
    d = await state.get_data()
    extra = d.get("extra") or []
    if t.lower() in ("готово", "всё", "все", "назад"):
        return await _preview(m, state)
    if t.lower() == "очистить":
        await state.update_data(extra=[])
        return await _preview(m, state)
    if len(extra) >= MAX_SPONSORS:
        return await m.answer(f"максимум {MAX_SPONSORS} спонсоров. «готово» — вернуться")
    try:
        chat = await bot.get_chat(t.split()[0])
        me = await bot.get_chat_member(chat.id, (await bot.me()).id)
        if me.status not in ("administrator", "creator"):
            raise ValueError
    except Exception:
        return await m.answer("не могу проверить подписку на этот канал — добавь меня туда админом и пришли ещё раз")
    if any(c["id"] == chat.id for c in extra) or chat.id == d["cid"]:
        return await m.answer("этот канал уже в условиях")
    extra.append({"id": chat.id, "t": chat.title or "", "u": chat.username or ""})
    await state.update_data(extra=extra)
    await m.answer(f"✅ добавила <b>{escape(chat.title or '')}</b>. ещё один — или «готово»")


@router.message(GW.photo)
async def st_photo(m: Message, state: FSMContext):
    if m.photo:
        await state.update_data(photo=m.photo[-1].file_id)
    elif m.text and "без" in m.text.lower():
        await state.update_data(photo="")
    else:
        return await m.answer("пришли картинку или напиши «без картинки»")
    await _preview(m, state)


@router.callback_query(F.data == "gw:go")
async def cb_go(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    if not d.get("prize") or not d.get("winners") or not (d.get("ends") or d.get("max_users")):
        return await cb.answer("начни заново: /giveaway", show_alert=True)
    await state.clear()
    kind, stars = d.get("gift_kind") or "", d.get("gift_stars") or 0
    if kind:
        from handlers import gifts
        if not await gifts.change(cb.from_user.id, -stars * d["winners"], "розыгрыш"):
            return await cb.answer("не хватает звёзд на подарки — /fund", show_alert=True)
    gid = await db.q_run(
        "INSERT INTO giveaways(owner_id,chat_id,prize,winners,ends,need_sub,gift_kind,gift_stars,gift_id,"
        "extra_chats,premium_only,ref_bonus,max_users,photo) VALUES(?,?,?,?,?,1,?,?,?,?,?,?,?,?)",
        cb.from_user.id, d["cid"], d["prize"], d["winners"], d.get("ends") or 0, kind, stars, d.get("gift_id") or "",
        json.dumps(d.get("extra") or []), d.get("premium_only", 0), d.get("ref_bonus", 0), d.get("max_users", 0),
        d.get("photo") or "")
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    await cb.answer()
    try:
        kb = await _kb(bot, g, 0)
        if g["photo"]:
            msg = await bot.send_photo(d["cid"], g["photo"], caption=post_text(g, 0)[:1024], reply_markup=kb)
        else:
            msg = await bot.send_message(d["cid"], post_text(g, 0), reply_markup=kb)
    except TelegramBadRequest as e:
        await db.q_run("UPDATE giveaways SET status='failed' WHERE id=?", gid)
        if kind:
            from handlers import gifts
            await gifts.change(cb.from_user.id, stars * d["winners"], "возврат: розыгрыш не вышел")
        return await show(cb, f"😕 не смогла опубликовать: {escape(str(e)[:120])}")
    await db.q_run("UPDATE giveaways SET msg_id=? WHERE id=?", msg.message_id, gid)
    when = f"итоги {timeparse.fmt(g['ends'])}" if g["ends"] else f"итоги при {g['max_users']} участниках"
    await show(cb, f"🎁 розыгрыш опубликован! {when}\nпобедителей выберу сама и пришлю тебе список",
               kb_rows([("📋 Мои розыгрыши", "gw:list")]))


# ================= участие =================
async def check_conditions(bot: Bot, g: dict, user) -> str | None:
    """None — всё ок, иначе текст, чего не хватает."""
    if g.get("premium_only") and not getattr(user, "is_premium", False):
        return "этот розыгрыш только для Telegram Premium ⭐"
    chats = ([g["chat_id"]] if g["need_sub"] else []) + [c["id"] for c in _extra(g)]
    for cid in chats:
        try:
            mem = await bot.get_chat_member(cid, user.id)
            if mem.status in ("left", "kicked"):
                raise ValueError
        except Exception:
            names = [c for c in _extra(g) if c["id"] == cid]
            who = ("@" + names[0]["u"]) if names and names[0].get("u") else "канал"
            return f"сначала подпишись на {who} 👆"
    return None


async def join(bot: Bot, g: dict, user, ref: int | None = None) -> tuple[bool, str]:
    gid, uid = g["id"], user.id
    if g["status"] != "active":
        return False, "розыгрыш уже закончился"
    if await db.q_one("SELECT 1 FROM giveaway_users WHERE gid=? AND uid=?", gid, uid):
        t = (await db.q_one("SELECT tickets FROM giveaway_users WHERE gid=? AND uid=?", gid, uid))["tickets"]
        return False, f"ты уже участвуешь 🍀 билетов: {t}"
    why = await check_conditions(bot, g, user)
    if why:
        return False, why
    ref = ref if g.get("ref_bonus") and ref and ref != uid else None
    await db.q_run("INSERT OR IGNORE INTO giveaway_users(gid, uid, name, tickets, ref_by) VALUES(?,?,?,1,?)",
                   gid, uid, (user.full_name or "")[:40], ref or 0)
    if ref:
        await db.q_run("UPDATE giveaway_users SET tickets=MIN(tickets+1, ?) WHERE gid=? AND uid=?",
                       MAX_REF_TICKETS + 1, gid, ref)
    n = (await db.q_one("SELECT COUNT(*) n FROM giveaway_users WHERE gid=?", gid))["n"]
    await _refresh(bot, g, n)
    return True, f"ты в игре! участников: {n} 🍀"


async def _refresh(bot: Bot, g: dict, n: int, force: bool = False):
    """Счётчик в посте — не чаще раза в 5 секунд, иначе телеграм ругается."""
    if not force and time.time() - _last_edit.get(g["id"], 0) < 5:
        return
    _last_edit[g["id"]] = time.time()
    try:
        kb = await _kb(bot, g, n)
        if g.get("photo"):
            await bot.edit_message_caption(chat_id=g["chat_id"], message_id=g["msg_id"],
                                           caption=post_text(g, n)[:1024], reply_markup=kb)
        else:
            await bot.edit_message_text(post_text(g, n), chat_id=g["chat_id"], message_id=g["msg_id"], reply_markup=kb)
    except (TelegramBadRequest, TelegramRetryAfter):
        pass


@router.callback_query(F.data.startswith("gw:j:"))
async def cb_join(cb: CallbackQuery, bot: Bot):
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", int(cb.data.split(":")[2]))
    if not g:
        return await cb.answer("розыгрыш не найден", show_alert=True)
    ok, text = await join(bot, g, cb.from_user)
    if ok and g.get("ref_bonus"):
        text += "\n🎟 больше шансов — кнопка «позвать друзей» под постом"
    await cb.answer(text, show_alert=True)


async def ref_view(bot: Bot, gid: int, uid: int) -> str:
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    if not g:
        return "розыгрыш не найден 🤔"
    me = await bot.me()
    row = await db.q_one("SELECT tickets FROM giveaway_users WHERE gid=? AND uid=?", gid, uid)
    friends = (await db.q_one("SELECT COUNT(*) n FROM giveaway_users WHERE gid=? AND ref_by=?", gid, uid))["n"]
    head = f"🎁 <b>{escape(g['prize'][:100])}</b>\n"
    if g["status"] != "active":
        return head + "розыгрыш уже закончился"
    if not row:
        return head + "ты ещё не участвуешь — жми «🎉 Участвовать» ниже"
    link = f"https://t.me/{me.username}?start=gwj_{gid}_{uid}"
    return (head + f"🎟 твои билеты: <b>{row['tickets']}</b> · друзей пришло: <b>{friends}</b>\n\n"
            f"кидай другу ссылку — он участвует, а у тебя +1 билет (до {MAX_REF_TICKETS}):\n<code>{link}</code>")


async def deep_link(m: Message, bot: Bot, arg: str) -> bool:
    """/start gwr_ID — мои билеты и ссылка · /start gwj_ID_REF — участие по приглашению."""
    try:
        if arg.startswith("gwr_"):
            gid = int(arg[4:])
            await m.answer(await ref_view(bot, gid, m.from_user.id),
                           reply_markup=kb_rows([("🎉 Участвовать", f"gw:jb:{gid}:0")]))
            return True
        if arg.startswith("gwj_"):
            gid, ref = (int(x) for x in arg[4:].split("_")[:2])
            g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
            if not g:
                return False
            await m.answer(f"🎁 тебя позвали в розыгрыш:\n<b>{escape(g['prize'][:200])}</b>",
                           reply_markup=kb_rows([("🎉 Участвовать", f"gw:jb:{gid}:{ref}")]))
            return True
    except ValueError:
        return False
    return False


@router.callback_query(F.data.startswith("gw:jb:"))
async def cb_join_bot(cb: CallbackQuery, bot: Bot):
    _, _, gid, ref = cb.data.split(":")
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", int(gid))
    if not g:
        return await cb.answer("розыгрыш не найден", show_alert=True)
    ok, text = await join(bot, g, cb.from_user, int(ref) or None)
    await cb.answer(text, show_alert=True)
    if ok or "уже участвуешь" in text:
        await cb.message.answer(await ref_view(bot, g["id"], cb.from_user.id))


# ================= итоги =================
def draw(users: list[dict], k: int, seed: str) -> list[dict]:
    """Взвешенный выбор без повторов: чем больше билетов, тем больше шанс. seed — для проверки честности."""
    r = random.Random(seed)
    pool = [u for u in users]
    out = []
    while pool and len(out) < k:
        total = sum(max(1, u.get("tickets") or 1) for u in pool)
        x = r.uniform(0, total)
        acc = 0.0
        for i, u in enumerate(pool):
            acc += max(1, u.get("tickets") or 1)
            if x <= acc:
                out.append(pool.pop(i))
                break
        else:
            out.append(pool.pop())
    return out


async def _eligible(bot: Bot, g: dict, u: dict) -> bool:
    class _U:   # к моменту итогов мог отписаться — проверяем условия заново (кроме Premium)
        id = u["uid"]
        is_premium = True
    return await check_conditions(bot, {**g, "premium_only": 0}, _U) is None


async def finish(bot: Bot, g: dict):
    users = await db.q_all("SELECT uid, name, tickets FROM giveaway_users WHERE gid=? ORDER BY uid", g["id"])
    seed = hashlib.sha256(f"{g['id']}|{time.time_ns()}|{_rng.random()}".encode()).hexdigest()[:16]
    order = draw(users, len(users), seed)
    winners = []
    for u in order:
        if len(winners) >= g["winners"]:
            break
        if await _eligible(bot, g, u):
            winners.append(u)
    await db.q_run("UPDATE giveaways SET status='done', result=?, seed=? WHERE id=?",
                   ",".join(str(w["uid"]) for w in winners), seed, g["id"])
    await _announce(bot, g, users, winners, seed)
    claim_kb = None
    if g.get("gift_kind"):
        from handlers import gifts
        await gifts.deliver_wins(bot, g, winners)
        me = await bot.me()
        if g["gift_kind"] == "stars" and winners and me.username:
            claim_kb = kb_rows([("🎁 Победителям: забрать подарок", f"https://t.me/{me.username}?start=gwc")])
    names = _names(winners)
    try:
        await bot.send_message(g["chat_id"], f"🎉 итоги розыгрыша!\n{names}",
                               reply_to_message_id=g["msg_id"], reply_markup=claim_kb)
    except TelegramBadRequest:
        pass
    await _report(bot, g, users, winners, seed)


def _names(winners: list[dict]) -> str:
    return "\n".join(f"{i + 1}. <a href=\"tg://user?id={w['uid']}\">{escape(w['name'])}</a>"
                     for i, w in enumerate(winners)) or "никто не участвовал 🥲"


async def _announce(bot: Bot, g: dict, users: list, winners: list, seed: str):
    text = (f"🎁 <b>РОЗЫГРЫШ ЗАВЕРШЁН</b>\n\n{escape(g['prize'])}\n\n👥 участников: {len(users)}\n"
            f"🏆 <b>победители:</b>\n{_names(winners)}\n\n<i>🔍 проверка честности: seed {seed}</i>")
    try:
        if g.get("photo"):
            await bot.edit_message_caption(chat_id=g["chat_id"], message_id=g["msg_id"], caption=text[:1024])
        else:
            await bot.edit_message_text(text, chat_id=g["chat_id"], message_id=g["msg_id"])
    except TelegramBadRequest:
        pass


async def _report(bot: Bot, g: dict, users: list, winners: list, seed: str):
    tail = "подарки вручаю сама 🎁" if g.get("gift_kind") else "свяжись с ними для вручения приза"
    rows = [[(f"🔁 Перевыбрать №{i + 1}", f"gw:rr:{g['id']}:{w['uid']}")] for i, w in enumerate(winners[:10])]
    try:
        await bot.send_message(g["owner_id"], f"🎁 розыгрыш завершён\n<i>{escape(g['prize'][:100])}</i>\n\n"
                                              f"победители:\n{_names(winners)}\n\n{tail}\n"
                                              + ui.hint("победитель не отвечает или схитрил — перевыбери его кнопкой"),
                               reply_markup=kb_rows(*rows) if rows else None)
        csv = "uid;name;tickets\n" + "\n".join(f"{u['uid']};{u['name']};{u.get('tickets') or 1}" for u in users)
        await bot.send_document(g["owner_id"], BufferedInputFile(csv.encode("utf-8-sig"), f"giveaway_{g['id']}.csv"),
                                caption=f"📄 все участники · seed {seed}")
    except Exception as e:
        log.info("report: %s", e)


@router.callback_query(F.data.startswith("gw:rr:"))
async def cb_reroll(cb: CallbackQuery, bot: Bot):
    _, _, gid, old = cb.data.split(":")
    g = await db.q_one("SELECT * FROM giveaways WHERE id=? AND owner_id=?", int(gid), cb.from_user.id)
    if not g or g["status"] != "done":
        return await cb.answer("розыгрыш не найден", show_alert=True)
    current = [int(x) for x in (g["result"] or "").split(",") if x]
    old = int(old)
    if old not in current:
        return await cb.answer("этот победитель уже заменён", show_alert=True)
    if g.get("gift_kind"):
        w = await db.q_one("SELECT * FROM gift_wins WHERE gid=? AND uid=?", g["id"], old)
        if w and w["status"] == "done":
            return await cb.answer("подарок уже вручён — перевыбрать нельзя", show_alert=True)
    users = await db.q_all("SELECT uid, name, tickets FROM giveaway_users WHERE gid=?", g["id"])
    rest = [u for u in users if u["uid"] not in current]
    new = None
    for u in draw(rest, len(rest), f"{g['seed']}|{old}"):
        if await _eligible(bot, g, u):
            new = u
            break
    if not new:
        return await cb.answer("больше некого выбрать 🤷", show_alert=True)
    current[current.index(old)] = new["uid"]
    await db.q_run("UPDATE giveaways SET result=? WHERE id=?", ",".join(map(str, current)), g["id"])
    if g.get("gift_kind"):
        from handlers import gifts
        await db.q_run("UPDATE gift_wins SET status='void' WHERE gid=? AND uid=? AND status='pending'", g["id"], old)
        await gifts.deliver_wins(bot, {**g, "winners": 1}, [new])
    await cb.answer("перевыбрала ✅")
    link = f"<a href=\"tg://user?id={new['uid']}\">{escape(new['name'])}</a>"
    try:
        await bot.send_message(g["chat_id"], f"🔁 победитель перевыбран: {link}", reply_to_message_id=g["msg_id"])
    except TelegramBadRequest:
        pass
    await cb.message.answer(f"🔁 новый победитель: {link}")


async def tick(bot: Bot):
    now = int(time.time())
    rows = await db.q_all(
        "SELECT g.*, (SELECT COUNT(*) FROM giveaway_users u WHERE u.gid=g.id) n FROM giveaways g "
        "WHERE status='active' AND msg_id IS NOT NULL", )
    for g in rows:
        due = (g["ends"] and g["ends"] <= now) or (g.get("max_users") and g["n"] >= g["max_users"])
        if not due:
            continue
        try:
            await finish(bot, g)
        except Exception:
            log.exception("giveaway %s", g["id"])


async def loop(bot: Bot):
    n = 0
    while True:
        await tick(bot)
        n += 1
        if n % 120 == 0:   # раз в час: невыбранные подарки дарю сама
            from handlers import gifts
            try:
                await gifts.auto_claim(bot)
            except Exception as e:
                log.warning("auto claim: %s", e)
        await asyncio.sleep(30)


# ================= список, досрочные итоги, отмена =================
@router.callback_query(F.data == "gw:list")
@router.message(Command("giveaways", "розыгрыши"))
async def gw_list(ev, bot: Bot = None):
    uid = ev.from_user.id
    rows = await db.q_all("SELECT g.*, (SELECT COUNT(*) FROM giveaway_users u WHERE u.gid=g.id) n "
                          "FROM giveaways g WHERE owner_id=? ORDER BY id DESC LIMIT 10", uid)
    lines = ["<b>🎁 мои розыгрыши</b>", ui.LINE]
    if not rows:
        lines.append("<i>пока нет. создать: /giveaway</i>")
    btns = []
    for g in rows:
        st = {"active": "🟢", "done": "✅", "failed": "⚠️", "cancelled": "✖️"}.get(g["status"], "•")
        when = timeparse.fmt(g["ends"]) if g["ends"] else f"до {g['max_users']} уч."
        lines.append(f"{st} {escape(g['prize'][:40])} · 👥{g['n']} · {when}")
        if g["status"] == "active":
            btns.append([(f"⏩ Итоги сейчас: {g['prize'][:14]}", f"gw:end:{g['id']}"), ("✖️ Отменить", f"gw:cx:{g['id']}")])
    if isinstance(ev, CallbackQuery):
        await ev.answer()
    await show(ev, "\n".join(lines), kb_rows(*btns, [("➕ Новый розыгрыш", "gw:newbtn")]))


@router.callback_query(F.data == "gw:newbtn")
async def cb_newbtn(cb: CallbackQuery, state: FSMContext):
    await cb.answer()
    chs = await store.channels(cb.from_user.id)
    if len(chs) == 1:
        return await start_create(cb.message, state, cb.from_user.id, chs[0]["chat_id"])
    if not chs:
        await state.set_state(GW.connect)
        return await cb.message.answer(CONNECT_HINT)
    await cb.message.answer("<b>🎁 в каком канале розыгрыш?</b>",
                            reply_markup=kb_rows(*[[(c["title"][:30], f"ap:gw:{c['chat_id']}")] for c in chs],
                                                 [("➕ Другой канал", "gw:addch")]))


@router.callback_query(F.data.startswith("gw:end:"))
async def cb_end(cb: CallbackQuery, bot: Bot):
    g = await db.q_one("SELECT * FROM giveaways WHERE id=? AND owner_id=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not g or g["status"] != "active":
        return await cb.answer("уже завершён", show_alert=True)
    await cb.answer("подвожу итоги…")
    await finish(bot, g)
    await gw_list(cb)


@router.callback_query(F.data.startswith("gw:cx:"))
async def cb_cancel(cb: CallbackQuery, bot: Bot):
    g = await db.q_one("SELECT * FROM giveaways WHERE id=? AND owner_id=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not g or g["status"] != "active":
        return await cb.answer("уже завершён", show_alert=True)
    await db.q_run("UPDATE giveaways SET status='cancelled' WHERE id=?", g["id"])
    if g.get("gift_kind"):
        from handlers import gifts
        await gifts.change(g["owner_id"], g["gift_stars"] * g["winners"], f"отмена розыгрыша #{g['id']}")
    text = f"✖️ <b>розыгрыш отменён</b>\n\n<s>{escape(g['prize'])}</s>"
    try:
        if g.get("photo"):
            await bot.edit_message_caption(chat_id=g["chat_id"], message_id=g["msg_id"], caption=text)
        else:
            await bot.edit_message_text(text, chat_id=g["chat_id"], message_id=g["msg_id"])
    except TelegramBadRequest:
        pass
    await cb.answer("отменила" + (", звёзды вернула" if g.get("gift_kind") else ""), show_alert=True)
    await gw_list(cb)
