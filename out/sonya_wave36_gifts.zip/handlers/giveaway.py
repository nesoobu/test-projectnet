"""Розыгрыши в каналах: приз, число победителей, срок, проверка подписки, честный выбор."""
import asyncio
import logging
import random
import time
from html import escape

from aiogram import Router, F, Bot
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import Message, CallbackQuery
from aiogram.exceptions import TelegramBadRequest, TelegramRetryAfter

import db
import ui
from autopost import store, timeparse
from handlers.ap_common import kb_rows, show

router = Router()
log = logging.getLogger("giveaway")
_rng = random.SystemRandom()
_last_edit: dict[int, float] = {}


class GW(StatesGroup):
    prize = State()
    time = State()


DURATIONS = [("1 час", 3600), ("6 часов", 6 * 3600), ("1 день", 86400), ("3 дня", 3 * 86400), ("7 дней", 7 * 86400)]


def post_text(g: dict, n: int) -> str:
    end = timeparse.fmt(g["ends"])
    need = "\n📌 условие: быть подписанным на канал" if g["need_sub"] else ""
    return (f"🎁 <b>РОЗЫГРЫШ</b>\n\n{escape(g['prize'])}\n\n"
            f"🏆 победителей: <b>{g['winners']}</b>\n⏳ итоги: <b>{end}</b> (мск){need}\n\n"
            f"👥 участников: <b>{n}</b>")


def join_kb(gid: int, n: int):
    return kb_rows([(f"🎉 Участвовать · {n}", f"gw:j:{gid}")])


# ================= создание =================
async def start_create(target, state: FSMContext, uid: int, cid: int):
    from handlers import gifts
    await state.clear()
    await state.update_data(cid=cid)
    await show(target, "<b>🎁 новый розыгрыш</b>\n" + ui.LINE + "\nчто разыгрываем?\n"
               + ui.hint(f"⭐ на подарки у тебя: {await gifts.balance(uid)} — пополнить: /fund"),
               kb_rows([("⭐ Подарок на N звёзд — победитель выберет", "gw:pt:stars")],
                       [("🎁 Конкретный подарок", "gw:pt:exact"), ("✍️ Свой приз", "gw:pt:text")],
                       [("✖️ Отмена", f"ap:ch:{cid}")]))


@router.callback_query(F.data.startswith("gw:pt:"))
async def cb_prize_type(cb: CallbackQuery, state: FSMContext, bot: Bot):
    from handlers import gifts
    kind = cb.data[6:]
    d = await state.get_data()
    if not d.get("cid"):
        return await cb.answer("начни заново: /giveaway", show_alert=True)
    if kind == "text":
        await state.set_state(GW.prize)
        return await show(cb, "напиши, что разыгрываем:\n<code>3 месяца Telegram Premium</code>",
                          kb_rows([("✖️ Отмена", f"ap:ch:{d['cid']}")]))
    gl = await gifts.catalog(bot)
    if not gl:
        return await cb.answer("Telegram не отдал список подарков — попробуй позже", show_alert=True)
    if kind == "stars":
        ps = await gifts.prices(bot)
        return await show(cb, "⭐ <b>на сколько звёзд подарок?</b>\nпобедитель сам выберет подарок такой цены",
                          kb_rows([(f"{p} ⭐", f"gw:ps:{p}") for p in ps[:4]], [(f"{p} ⭐", f"gw:ps:{p}") for p in ps[4:8]]))
    rows, line = [], []
    for g in gl[:24]:
        line.append((f"{g['emoji']} {g['stars']}⭐", f"gw:pe:{g['id']}"))
        if len(line) == 4:
            rows.append(line)
            line = []
    if line:
        rows.append(line)
    await show(cb, "🎁 <b>какой подарок разыгрываем?</b>\n" + ui.hint("цена — за одного победителя"), kb_rows(*rows))


@router.callback_query(F.data.startswith(("gw:ps:", "gw:pe:")))
async def cb_prize_pick(cb: CallbackQuery, state: FSMContext, bot: Bot):
    from handlers import gifts
    val = cb.data[6:]
    if cb.data.startswith("gw:ps:"):
        stars = int(val)
        await state.update_data(gift_kind="stars", gift_stars=stars, gift_id="",
                                prize=f"🎁 подарок Telegram на {stars} ⭐ — победитель сам выберет, какой")
    else:
        g = next((x for x in await gifts.catalog(bot) if x["id"] == val), None)
        if not g:
            return await cb.answer("этот подарок закончился", show_alert=True)
        await state.update_data(gift_kind="exact", gift_stars=g["stars"], gift_id=g["id"],
                                prize=f"🎁 подарок Telegram {g['emoji']} ({g['stars']} ⭐)")
    await cb.answer()
    await cb.message.answer("сколько победителей?",
                            reply_markup=kb_rows([(str(n), f"gw:w:{n}") for n in (1, 2, 3, 5, 10)]))


@router.callback_query(F.data.startswith("ap:gw:"))
async def cb_new(cb: CallbackQuery, state: FSMContext):
    cid = int(cb.data.split(":")[2])
    if not await store.channel(cid, cb.from_user.id):
        return await cb.answer("канал не найден", show_alert=True)
    await start_create(cb, state, cb.from_user.id, cid)


@router.message(Command("giveaway", "розыгрыш"), F.chat.type == "private")
async def cmd_new(m: Message, state: FSMContext):
    chs = await store.channels(m.from_user.id)
    if not chs:
        return await m.answer("сначала подключи канал: /panel → ➕ Канал")
    if len(chs) == 1:
        return await start_create(m, state, m.from_user.id, chs[0]["chat_id"])
    await m.answer("<b>🎁 в каком канале розыгрыш?</b>",
                   reply_markup=kb_rows(*[[(c["title"][:30], f"ap:gw:{c['chat_id']}")] for c in chs]))


@router.message(GW.prize, F.text)
async def st_prize(m: Message, state: FSMContext):
    await state.update_data(prize=m.text.strip()[:500])
    await m.answer("сколько победителей?",
                   reply_markup=kb_rows([(str(n), f"gw:w:{n}") for n in (1, 2, 3, 5, 10)]))


@router.callback_query(F.data.startswith("gw:w:"))
async def cb_winners(cb: CallbackQuery, state: FSMContext):
    n = int(cb.data.split(":")[2])
    d = await state.get_data()
    if d.get("gift_kind"):
        from handlers import gifts
        need, have = d["gift_stars"] * n, await gifts.balance(cb.from_user.id)
        if have < need:
            await cb.answer()
            return await cb.message.answer(
                f"⭐ на {n} × {d['gift_stars']} ⭐ нужно <b>{need} ⭐</b>, а у тебя {have} ⭐",
                reply_markup=kb_rows([("➕ Пополнить звёзды", "m:fund")],
                                     [(f"{k} победит.", f"gw:w:{k}") for k in (1, 2, 3) if d['gift_stars'] * k <= have]))
    await state.update_data(winners=n)
    await state.set_state(GW.time)
    btns = [(t, f"gw:d:{s}") for t, s in DURATIONS]
    await show(cb, "сколько длится? или напиши время итогов: <code>завтра 20:00</code>",
               kb_rows(btns[:3], btns[3:]))


async def _preview(target, state: FSMContext, ends: int):
    await state.update_data(ends=ends, need_sub=True)
    d = await state.get_data()
    g = {"prize": d["prize"], "winners": d["winners"], "ends": ends, "need_sub": 1}
    await show(target, "👀 <b>так будет выглядеть:</b>\n\n" + post_text(g, 0),
               kb_rows([("🚀 Опубликовать", "gw:go")], [("✖️ Отмена", f"ap:ch:{d['cid']}")]))


@router.callback_query(F.data.startswith("gw:d:"))
async def cb_dur(cb: CallbackQuery, state: FSMContext):
    await _preview(cb, state, int(time.time()) + int(cb.data.split(":")[2]))


@router.message(GW.time, F.text)
async def st_time(m: Message, state: FSMContext):
    ts = timeparse.parse(m.text)
    if not ts or ts < time.time() + 300:
        return await m.answer("не поняла время (или раньше чем через 5 минут). пример: <code>завтра 20:00</code>")
    await _preview(m, state, ts)


@router.callback_query(F.data == "gw:go")
async def cb_go(cb: CallbackQuery, state: FSMContext, bot: Bot):
    d = await state.get_data()
    if not d.get("ends"):
        return await cb.answer("начни заново", show_alert=True)
    await state.clear()
    kind, stars = d.get("gift_kind") or "", d.get("gift_stars") or 0
    if kind:
        from handlers import gifts
        if not await gifts.change(cb.from_user.id, -stars * d["winners"], "розыгрыш"):
            return await cb.answer("не хватает звёзд на подарки — /fund", show_alert=True)
    gid = await db.q_run("INSERT INTO giveaways(owner_id,chat_id,prize,winners,ends,need_sub,gift_kind,gift_stars,gift_id) "
                         "VALUES(?,?,?,?,?,1,?,?,?)", cb.from_user.id, d["cid"], d["prize"], d["winners"], d["ends"],
                         kind, stars, d.get("gift_id") or "")
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    try:
        msg = await bot.send_message(d["cid"], post_text(g, 0), reply_markup=join_kb(gid, 0))
    except TelegramBadRequest as e:
        await db.q_run("UPDATE giveaways SET status='failed' WHERE id=?", gid)
        if kind:
            from handlers import gifts
            await gifts.change(cb.from_user.id, stars * d["winners"], "возврат: розыгрыш не вышел")
        return await show(cb, f"😕 не смогла опубликовать: {escape(str(e)[:120])}")
    await db.q_run("UPDATE giveaways SET msg_id=? WHERE id=?", msg.message_id, gid)
    await show(cb, f"🎁 розыгрыш опубликован! итоги {timeparse.fmt(d['ends'])}\n"
                   "победителей выберу сама и пришлю тебе список",
               kb_rows([("📋 Мои розыгрыши", "gw:list")], [("‹ К каналу", f"ap:ch:{d['cid']}")]))


# ================= участие =================
@router.callback_query(F.data.startswith("gw:j:"))
async def cb_join(cb: CallbackQuery, bot: Bot):
    gid = int(cb.data.split(":")[2])
    g = await db.q_one("SELECT * FROM giveaways WHERE id=?", gid)
    if not g or g["status"] != "active":
        return await cb.answer("розыгрыш уже закончился", show_alert=True)
    uid = cb.from_user.id
    if await db.q_one("SELECT 1 FROM giveaway_users WHERE gid=? AND uid=?", gid, uid):
        return await cb.answer("ты уже участвуешь 🍀", show_alert=True)
    if g["need_sub"]:
        try:
            mem = await bot.get_chat_member(g["chat_id"], uid)
            if mem.status in ("left", "kicked"):
                return await cb.answer("сначала подпишись на канал 👆", show_alert=True)
        except TelegramBadRequest:
            return await cb.answer("сначала подпишись на канал 👆", show_alert=True)
    await db.q_run("INSERT OR IGNORE INTO giveaway_users VALUES(?,?,?)", gid, uid, cb.from_user.full_name[:40])
    n = (await db.q_one("SELECT COUNT(*) n FROM giveaway_users WHERE gid=?", gid))["n"]
    await cb.answer(f"ты в игре! участников: {n} 🍀", show_alert=True)
    # обновляем счётчик не чаще раза в 5 секунд — иначе телеграм ругается
    if time.time() - _last_edit.get(gid, 0) > 5:
        _last_edit[gid] = time.time()
        try:
            await cb.message.edit_text(post_text(g, n), reply_markup=join_kb(gid, n))
        except (TelegramBadRequest, TelegramRetryAfter):
            pass


# ================= итоги =================
async def finish(bot: Bot, g: dict):
    users = await db.q_all("SELECT uid, name FROM giveaway_users WHERE gid=?", g["id"])
    pool = users[:]
    winners = []
    while pool and len(winners) < g["winners"]:
        u = pool.pop(_rng.randrange(len(pool)))
        if g["need_sub"]:  # к моменту итогов мог отписаться — пропускаем
            try:
                mem = await bot.get_chat_member(g["chat_id"], u["uid"])
                if mem.status in ("left", "kicked"):
                    continue
            except TelegramBadRequest:
                continue
        winners.append(u)
    await db.q_run("UPDATE giveaways SET status='done', result=? WHERE id=?",
                   ",".join(str(w["uid"]) for w in winners), g["id"])
    names = "\n".join(f"{i + 1}. <a href=\"tg://user?id={w['uid']}\">{escape(w['name'])}</a>"
                      for i, w in enumerate(winners)) or "никто не участвовал 🥲"
    text = (f"🎁 <b>РОЗЫГРЫШ ЗАВЕРШЁН</b>\n\n{escape(g['prize'])}\n\n👥 участников: {len(users)}\n"
            f"🏆 <b>победители:</b>\n{names}")
    try:
        await bot.edit_message_text(text, chat_id=g["chat_id"], message_id=g["msg_id"])
    except TelegramBadRequest:
        pass
    claim_kb = None
    if g.get("gift_kind"):
        from handlers import gifts
        await gifts.deliver_wins(bot, g, winners)
        me = await bot.me()
        if g["gift_kind"] == "stars" and winners and me.username:
            claim_kb = kb_rows([("🎁 Победителям: забрать подарок", f"https://t.me/{me.username}?start=gwc")])
    try:
        await bot.send_message(g["chat_id"], f"🎉 итоги розыгрыша!\n{names}",
                               reply_to_message_id=g["msg_id"], reply_markup=claim_kb)
    except TelegramBadRequest:
        pass
    try:
        tail = ("подарки вручаю сама 🎁" if g.get("gift_kind") else "свяжись с ними для вручения приза")
        await bot.send_message(g["owner_id"], f"🎁 розыгрыш завершён\n<i>{escape(g['prize'][:100])}</i>\n\n"
                                              f"победители:\n{names}\n\n{tail}")
    except Exception:
        pass


async def tick(bot: Bot):
    for g in await db.q_all("SELECT * FROM giveaways WHERE status='active' AND ends<=? AND msg_id IS NOT NULL",
                            int(time.time())):
        try:
            await finish(bot, g)
        except Exception:
            log.exception("giveaway %s", g["id"])


async def loop(bot: Bot):
    n = 0
    while True:
        await tick(bot)
        n += 1
        if n % 120 == 0:   # раз в час: невыбранные подарки дарю сама
            from handlers import gifts
            try:
                await gifts.auto_claim(bot)
            except Exception as e:
                log.warning("auto claim: %s", e)
        await asyncio.sleep(30)


# ================= список =================
@router.callback_query(F.data == "gw:list")
@router.message(Command("giveaways", "розыгрыши"))
async def gw_list(ev, bot: Bot = None):
    uid = ev.from_user.id
    rows = await db.q_all("SELECT g.*, (SELECT COUNT(*) FROM giveaway_users u WHERE u.gid=g.id) n "
                          "FROM giveaways g WHERE owner_id=? ORDER BY id DESC LIMIT 10", uid)
    lines = ["<b>🎁 мои розыгрыши</b>", ui.LINE]
    if not rows:
        lines.append("<i>пока нет. /panel → канал → 🎁 Розыгрыш</i>")
    btns = []
    for g in rows:
        st = {"active": "🟢", "done": "✅", "failed": "⚠️"}.get(g["status"], "•")
        lines.append(f"{st} {escape(g['prize'][:40])} · 👥{g['n']} · {timeparse.fmt(g['ends'])}")
        if g["status"] == "active":
            btns.append([(f"⏩ Подвести итоги сейчас: {g['prize'][:18]}", f"gw:end:{g['id']}")])
    await show(ev, "\n".join(lines), kb_rows(*btns, [("‹ Автопостинг", "ap:home")]))


@router.callback_query(F.data.startswith("gw:end:"))
async def cb_end(cb: CallbackQuery, bot: Bot):
    g = await db.q_one("SELECT * FROM giveaways WHERE id=? AND owner_id=?", int(cb.data.split(":")[2]), cb.from_user.id)
    if not g or g["status"] != "active":
        return await cb.answer("уже завершён", show_alert=True)
    await cb.answer("подвожу итоги…")
    await finish(bot, g)
    await gw_list(cb)
