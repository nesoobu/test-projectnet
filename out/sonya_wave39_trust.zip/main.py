import asyncio
import logging
from aiogram import Bot, Dispatcher, Router
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.types import BotCommand, ChatMemberUpdated

import config
import db
import llm
from middlewares import UserMiddleware
from handlers import admin, menu, donate, social, chat, ap_panel, ap_editor, ap_rules, media, games, tools, intents, remind, giveaway, groupmod, extra, party, morning, design, life, fun, aigames, character, community, studio, ap_extra, gate, luck, rp, solo, music, melody, vtools, comments, tochannel, gifts
import system
import uikit
from autopost import store as ap_store, engine as ap_engine

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("sonya")

def _cmds(*pairs) -> list[BotCommand]:
    return [BotCommand(command=c, description=d) for c, d in pairs]


# личка: самое нужное, остальное — в /menu и /help
PRIVATE = _cmds(
    ("menu", "🏠 меню"), ("help", "❔ что я умею"),
    ("draw", "🎨 нарисовать"), ("find", "🎵 найти трек"), ("voice", "🗣 озвучить текст"),
    ("search", "🔎 поиск в интернете"), ("remind", "⏰ напоминание"),
    ("games", "🎮 игры"), ("bonus", "🎁 ежедневный бонус"), ("wheel", "🎡 колесо фортуны"), ("quests", "📋 задания дня"),
    ("pet", "🐾 питомец"), ("horo", "🔮 гороскоп"), ("me", "👤 профиль"), ("mode", "🎭 мой характер"),
    ("panel", "📢 автопостинг"), ("plus", "✨ Соня+"),
)
# группы: игры и полезное для всех
GROUP = _cmds(
    ("help", "❔ что я умею"), ("games", "🎮 игры"), ("spy", "🕵️ шпион"), ("mafia", "🔪 мафия"),
    ("croc", "🐊 крокодил"), ("duel", "⚔️ дуэль на ставку"), ("lottery", "🎟 лотерея дня"),
    ("pair", "💞 пара дня"), ("hero", "⭐ звезда дня"),
    ("summary", "🧾 что я пропустил"), ("stats", "📊 статистика чата"), ("tr", "🌍 перевести (ответом)"),
    ("quote", "💬 цитата-стикер (ответом)"), ("bday", "🎂 дни рождения"), ("rules", "📜 правила"),
    ("notes", "📝 заметки"), ("report", "🚨 пожаловаться (ответом)"), ("stopgame", "⏹ остановить игру"),
)
# админам групп — плюс модерация
GROUP_ADMIN = GROUP + _cmds(
    ("settings", "⚙️ настройки группы"), ("warn", "⚠️ предупреждение (ответом)"),
    ("mute", "🤐 мут (ответом)"), ("quiet", "🌙 ночная тишина"), ("note", "📝 добавить заметку"),
    ("welcome", "👋 своё приветствие"),
)
# владельцу в личке — всё своё
OWNER = PRIVATE + _cmds(("admin", "⚙️ админка"), ("user", "👤 карточка юзера"), ("ui", "🎨 конструктор интерфейса"), ("backup", "💾 бэкап базы"))
COMMANDS = PRIVATE   # для совместимости


def routers_for(profile: str) -> list:
    """Порядок важен: chat — последний (ловит весь текст)."""
    if profile == "gw":   # бот розыгрышей
        return [groups, admin.router, gifts.router, giveaway.router, donate.router, solo.router]
    if profile in ("dl", "music"):
        return [groups, admin.router, vtools.router, melody.router, music.router, solo.router, media.router,
                tools.router]
    return [groups, gate.router, comments.router, tochannel.router, gifts.router, ap_extra.router, design.router, admin.router, vtools.router, melody.router,
            music.router,
            menu.router, donate.router,
            ap_panel.router, ap_editor.router, ap_rules.router, giveaway.router,
            groupmod.router, media.router, games.router, tools.router, remind.router,
            extra.router, party.router, morning.router, life.router, fun.router, aigames.router, luck.router,
            rp.router, character.router, community.router, studio.router, intents.router, social.router,
            chat.router]


SOLO_CMDS = {
    "dl": _cmds(("start", "⬇️ как скачать"), ("history", "🕘 что я качал"), ("help", "❔ что умею")),
    "gw": _cmds(("start", "🎁 как это работает"), ("giveaway", "🎁 новый розыгрыш"), ("giveaways", "📋 мои розыгрыши"),
                ("fund", "⭐ звёзды на подарки"), ("check", "🔍 проверить честность"), ("help", "❔ что умею")),
    "music": _cmds(("start", "🎵 как найти песню"), ("find", "🔎 найти трек"), ("top", "🔥 чарт"),
                   ("my", "❤️ мои треки"), ("melody", "🎮 угадай мелодию"), ("taste", "📊 мой вкус"),
                   ("subs", "🔔 подписки на артистов"), ("shazam", "🎧 что играет (ответом)"),
                   ("help", "❔ что умею")),
}


async def setup_commands(bot: Bot):
    """Стираем старые списки (в т.ч. языковые и персональные — они перекрывают общий) и ставим свои."""
    from aiogram.types import (BotCommandScopeDefault, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats,
                               BotCommandScopeAllChatAdministrators, BotCommandScopeChat)
    scopes = [BotCommandScopeDefault(), BotCommandScopeAllPrivateChats(), BotCommandScopeAllGroupChats(),
              BotCommandScopeAllChatAdministrators()]
    if config.OWNER_ID:
        scopes.append(BotCommandScopeChat(chat_id=config.OWNER_ID))
    for sc in scopes:
        for lang in (None, "ru", "en", "uk"):
            try:
                await bot.delete_my_commands(scope=sc, language_code=lang)
            except Exception as e:
                log.info("delete commands: %s", e)
    if config.PROFILE in SOLO_CMDS:
        await bot.set_my_commands(SOLO_CMDS[config.PROFILE], scope=BotCommandScopeDefault())
        if config.OWNER_ID:
            try:
                await bot.set_my_commands(SOLO_CMDS[config.PROFILE] + _cmds(("admin", "⚙️ админка")),
                                          scope=BotCommandScopeChat(chat_id=config.OWNER_ID))
            except Exception as e:
                log.info("owner commands: %s", e)
        return
    await bot.set_my_commands(PRIVATE, scope=BotCommandScopeDefault())
    await bot.set_my_commands(PRIVATE, scope=BotCommandScopeAllPrivateChats())
    await bot.set_my_commands(GROUP, scope=BotCommandScopeAllGroupChats())
    await bot.set_my_commands(GROUP_ADMIN, scope=BotCommandScopeAllChatAdministrators())
    if config.OWNER_ID:
        try:
            await bot.set_my_commands(OWNER, scope=BotCommandScopeChat(chat_id=config.OWNER_ID))
        except Exception as e:
            log.info("owner commands: %s", e)

groups = Router()


@groups.my_chat_member()
async def on_membership(e: ChatMemberUpdated):
    if e.chat.type not in ("group", "supergroup"):
        return
    if e.new_chat_member.status in ("left", "kicked"):
        await db.remove_chat(e.chat.id)
    else:
        await db.add_chat(e.chat.id, e.chat.title or "")


async def cleanup_loop():
    while True:
        try:
            await db.cleanup(30)
        except Exception as e:
            log.warning("cleanup: %s", e)
        await asyncio.sleep(86400)


async def main():
    if not config.BOT_TOKEN:
        raise SystemExit("нет BOT_TOKEN в .env")
    (config.BASE / "data").mkdir(exist_ok=True)
    await db.init()
    await ap_store.init()

    session = None
    if config.BOT_API_URL:   # свой сервер Bot API — можно слать файлы до 2 ГБ
        from aiogram.client.session.aiohttp import AiohttpSession
        from aiogram.client.telegram import TelegramAPIServer
        session = AiohttpSession(api=TelegramAPIServer.from_base(config.BOT_API_URL, is_local=True), timeout=600)
    bot = Bot(config.BOT_TOKEN, session=session, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    dp.message.outer_middleware(UserMiddleware())
    dp.callback_query.outer_middleware(UserMiddleware())
    dp.message.outer_middleware(gate.SubGate())
    dp.callback_query.outer_middleware(gate.SubGate())

    dp.include_routers(*routers_for(config.PROFILE))
    if config.PROFILE == "full":
        dp.message.outer_middleware(community.AntiSpam())
    dp.message.outer_middleware(groupmod.GroupGuard())
    if config.PROFILE == "full":
        dp.message.outer_middleware(intents.GroupLife())

    system.install_alerts(bot)
    await extra.load_plus()
    await uikit.load()
    bot.session.middleware(uikit.UiMiddleware())
    await setup_commands(bot)
    asyncio.create_task(cleanup_loop())
    if config.PROFILE in ("full", "music"):
        asyncio.create_task(music.release_loop(bot))
    if config.PROFILE != "gw":
        asyncio.create_task(vtools.ytdlp_loop(bot))
    if config.PROFILE == "gw":
        asyncio.create_task(giveaway.loop(bot))
    if config.PROFILE != "full":   # узкий бот: без фоновых циклов Сони (иначе всё задвоится)
        log.info("бот-помощник (%s) проснулся", config.PROFILE)
        try:
            await dp.start_polling(bot)
        finally:
            await llm.close()
            await db.close()
        return
    asyncio.create_task(ap_engine.loop(bot))
    asyncio.create_task(remind.loop(bot))
    asyncio.create_task(giveaway.loop(bot))
    asyncio.create_task(system.backup_loop(bot))
    asyncio.create_task(morning.loop(bot))
    asyncio.create_task(life.loop(bot))
    fun.BOT = bot
    await aigames.load()
    asyncio.create_task(fun.loop(bot))
    asyncio.create_task(community.loop(bot))
    asyncio.create_task(party.recover(bot))
    log.info("соня проснулась")
    try:
        await dp.start_polling(bot)
    finally:
        await llm.close()
        await db.close()


if __name__ == "__main__":
    asyncio.run(main())
