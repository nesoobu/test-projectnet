"""Авто-источники: RSS, YouTube, Reddit, публичные Telegram-каналы.
Каждый fetch → список item: {key, title, text, link, image}. Новые — первыми."""
import html
import logging
import re
from urllib.parse import urljoin

import aiohttp
import feedparser

import netguard

log = logging.getLogger("sources")
UA = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    "Chrome/124.0 Safari/537.36"}
TIMEOUT = aiohttp.ClientTimeout(total=25)

TYPES = {
    "yamusic": ("🎵", "Яндекс Музыка"),
    "music": ("🎧", "Музыка по ссылке"),
    "video": ("🎬", "Видео"),
    "pinterest": ("📌", "Pinterest"),
    "tg": ("✈️", "Telegram-канал"),
    "reddit": ("👽", "Reddit"),
    "vk": ("🟦", "VK-паблик"),
    "rss": ("📰", "RSS / сайт"),
    "pool": ("📦", "Копилка"),
    "ai": ("🧠", "ИИ-рубрика"),
    "youtube": ("▶️", "YouTube ссылкой"),  # старый тип, новые — через «Видео»
}
NEW_TYPES = ["yamusic", "music", "video", "pinterest", "tg", "vk", "reddit", "rss", "pool", "ai"]
TYPE_INFO = {
    "yamusic": "треки файлами с обложкой: твои лайки, плейлист, альбом, артист или чарт",
    "music": "аудио из SoundCloud, YouTube-плейлистов и др. (через yt-dlp)",
    "video": "видео файлами: YouTube, Shorts, RuTube, VK Видео и сотни сайтов",
    "pinterest": "картинки по поиску, похожие на пин или с доски",
    "tg": "посты публичного канала",
    "reddit": "топ сабреддита за день",
    "vk": "посты открытого паблика ВКонтакте (нужен VK_TOKEN в .env)",
    "rss": "новости любого сайта с RSS",
    "pool": "загрузи пачку постов/треков — буду выкладывать по расписанию",
    "ai": "ИИ пишет пост на твою тему: факт дня, цитата, гороскоп…",
}


class SourceError(Exception):
    pass


FEED_MAX = 15 * 1024 * 1024   # лента/страница больше — не читаем (волна 61)


async def _get(url: str) -> tuple[int, bytes]:
    """Волна 61: адрес и каждый редирект проверяем (не во внутреннюю сеть), тело — с потолком FEED_MAX."""
    try:
        async with aiohttp.ClientSession(timeout=TIMEOUT, headers=UA) as s:
            async with netguard.get(s, url) as r:
                return r.status, await netguard.read_limited(r, FEED_MAX)
    except netguard.Blocked as e:
        raise SourceError(str(e))


def _web(u, base: str = "") -> str | None:
    """Только http(s)-ссылка. Путь «/home/…» из чужой ленты иначе ушёл бы в канал как локальный файл сервера."""
    if not isinstance(u, str) or not u.strip():
        return None
    u = u.strip()
    if u.startswith("//"):
        u = "https:" + u
    elif not u.lower().startswith(("http://", "https://")) and base.lower().startswith(("http://", "https://")):
        u = urljoin(base, u)   # относительная картинка в ленте → от адреса статьи
    return u if u.lower().startswith(("http://", "https://")) else None


async def fetch(type_: str, source: str, limit: int = 10) -> list[dict]:
    items = await _fetch(type_, source, limit)
    for it in items:
        base = it.get("link") or ""
        for k in ("image", "video", "audio", "video_page"):
            if it.get(k) is not None:
                it[k] = _web(it[k], base)
        if it.get("images"):
            it["images"] = [u for u in (_web(x, base) for x in it["images"]) if u]
    return items


_TAG = re.compile(r"<[^>]+>")
_IMG = re.compile(r"""<img[^>]+src=["']([^"']+)""", re.I)


def clean(s: str, limit: int = 0) -> str:
    s = re.sub(r"<br\s*/?>|</p>", "\n", s or "", flags=re.I)
    s = html.unescape(_TAG.sub("", s))
    s = re.sub(r"[ \t]+", " ", s)
    s = re.sub(r"\n\s*\n+", "\n\n", s).strip()
    if limit and len(s) > limit:
        s = s[:limit].rsplit(" ", 1)[0] + "…"
    return s


# ---------- нормализация ввода ----------
def normalize(type_: str, raw: str) -> tuple[str, str]:
    """→ (source, человекочитаемое название). Бросает SourceError."""
    raw = raw.strip()
    if type_ == "rss":
        if not re.match(r"^https?://", raw):
            raw = "https://" + raw
        return raw, re.sub(r"^https?://(www\.)?", "", raw).split("/")[0]
    if type_ == "reddit":
        m = re.search(r"(?:r/)?([A-Za-z0-9_]{2,21})/?$", raw.replace("https://www.reddit.com/", ""))
        if not m:
            raise SourceError("не понял сабреддит. пример: r/aww")
        return m.group(1), f"r/{m.group(1)}"
    if type_ == "tg":
        m = re.search(r"(?:t\.me/(?:s/)?|@)?([A-Za-z][A-Za-z0-9_]{3,31})/?$", raw)
        if not m:
            raise SourceError("не понял канал. пример: @durov")
        return m.group(1), f"@{m.group(1)}"
    if type_ == "vk":
        m = re.search(r"(?:vk\.com/|vk\.ru/|@)?([A-Za-z0-9_.]{2,64})/?$", raw)
        if not m:
            raise SourceError("пришли ссылку на паблик: vk.com/name")
        return m.group(1), f"vk/{m.group(1)}"
    if type_ == "pinterest":
        pm = re.search(r"pinterest\.[a-z.]+/pin/(?:[\w-]*--)?(\d+)", raw)
        if pm:   # ссылка на пин → похожие на него, по цепочке
            return f"rel:{pm.group(1)}", f"🧲 похожие на пин {pm.group(1)}"
        if re.search(r"pin\.it/", raw):
            raise SourceError("короткая ссылка pin.it не подойдёт — открой пин в браузере и скопируй полную ссылку")
        q = re.sub(r"^(?:поиск|search|найди)\s*[:\-]?\s*", "", raw, flags=re.I) if re.match(
            r"^(?:поиск|search|найди)\b", raw, re.I) else ""
        if q or (" " in raw.strip() and "/" not in raw) or (re.search(r"[а-яё]", raw, re.I) and "/" not in raw):
            q = (q or raw).strip()[:80]
            if len(q) < 2:
                raise SourceError("что ищем? пример: <code>парные аватарки аниме</code>")
            return f"q:{q}", f"🔎 {q}"
        m = re.search(r"pinterest\.[a-z.]+/([\w.-]+)(?:/([\w%.-]+))?", raw)
        if not m:
            m = re.fullmatch(r"@?([\w.-]+)(?:/([\w%.-]+))?/?", raw)
        if not m:
            raise SourceError("пришли ссылку на доску: pinterest.com/user/board")
        user, board = m.group(1), m.group(2)
        if board in (None, "", "_saved", "_created", "pins"):
            return user, user
        return f"{user}/{board}", board
    if type_ in ("video", "music"):
        from autopost import media_dl
        url = media_dl.normalize_url(raw, "audio" if type_ == "music" else "video")
        title = re.sub(r"^https?://(www\.|m\.)?", "", url)
        return url, title[:40]
    if type_ == "yamusic":
        from autopost import media_dl
        try:
            src = media_dl.ym_parse(raw)
        except media_dl.DLError as e:
            raise SourceError(str(e))
        return src, media_dl.ym_title(src)
    if type_ == "pool":
        return raw[:40] or "копилка", raw[:40] or "копилка"
    if type_ == "ai":
        if len(raw) < 5:
            raise SourceError("опиши тему подробнее")
        return raw[:500], raw[:30]
    if type_ == "youtube":
        if re.fullmatch(r"UC[\w-]{22}", raw):
            return raw, raw
        m = re.search(r"youtube\.com/channel/(UC[\w-]{22})", raw)
        if m:
            return m.group(1), m.group(1)
        m = re.search(r"@([\w.-]+)", raw)
        if m:
            return "@" + m.group(1), "@" + m.group(1)
        raise SourceError("дай ссылку на канал или @handle")
    raise SourceError("неизвестный тип")


async def _yt_channel_id(handle: str) -> str:
    st, body = await _get(f"https://www.youtube.com/{handle}")
    m = re.search(rb'"(?:channelId|externalId)":"(UC[\w-]{22})"', body)
    if st != 200 or not m:
        raise SourceError("не нашла такой YouTube-канал")
    return m.group(1).decode()


# ---------- fetchers ----------
def _from_feed(body: bytes, limit: int) -> list[dict]:
    f = feedparser.parse(body)
    if f.bozo and not f.entries:
        raise SourceError("это не RSS-лента")
    out = []
    for e in f.entries[:limit]:
        content = ""
        if e.get("content"):
            content = e.content[0].get("value", "")
        summary = content or e.get("summary", "")
        img = video = audio = None
        for enc in e.get("enclosures", []) or []:
            et, href = (enc.get("type") or ""), enc.get("href")
            if not href:
                continue
            if et.startswith("image") and not img:
                img = href
            elif et.startswith("video") and not video:
                video = href
            elif et.startswith("audio") and not audio:
                audio = href
        if not img and e.get("media_content"):
            img = e.media_content[0].get("url")
        if not img and e.get("media_thumbnail"):
            img = e.media_thumbnail[0].get("url")
        if not img:
            m = _IMG.search(summary or "")
            img = m.group(1) if m else None
        link = e.get("link", "")
        out.append({
            "key": e.get("id") or link or e.get("title", ""),
            "title": clean(e.get("title", ""), 200),
            "text": clean(summary, 700),
            "link": link,
            "image": html.unescape(img) if img else None,
            "video": video,
            "audio": audio,
            "raw": summary or "",
        })
    return out


def vk_items(posts: list[dict], limit: int) -> list[dict]:
    """Ответ wall.get → item'ы. Без закрепов и рекламы."""
    out = []
    for p in posts:
        if p.get("is_pinned") or p.get("marked_as_ads"):
            continue
        img = None
        for a in p.get("attachments") or []:
            if a.get("type") == "photo":
                sizes = a["photo"].get("sizes") or []
                if sizes:
                    img = max(sizes, key=lambda s: s.get("width", 0) * s.get("height", 0)).get("url")
                    break
        text = clean(p.get("text") or "", 3000)
        if not text and not img:
            continue
        key = f"vk:{p['owner_id']}_{p['id']}"
        out.append({"key": key, "title": "", "text": text, "image": img,
                    "link": f"https://vk.com/wall{p['owner_id']}_{p['id']}"})
    return out[:limit]


async def _vk(source: str, limit: int) -> list[dict]:
    import config
    if not getattr(config, "VK_TOKEN", ""):
        raise SourceError("нужен VK_TOKEN в .env (сервисный ключ приложения VK)")
    params = {"domain": source, "count": min(100, limit + 5), "access_token": config.VK_TOKEN, "v": "5.199"}
    if re.fullmatch(r"(?:club|public)\d+", source):
        params.pop("domain")
        params["owner_id"] = "-" + re.sub(r"\D", "", source)
    async with aiohttp.ClientSession(timeout=TIMEOUT) as s:
        async with s.get("https://api.vk.com/method/wall.get", params=params) as r:
            data = await r.json(content_type=None)
    if "error" in data:
        raise SourceError(f"VK: {data['error'].get('error_msg', 'ошибка')}")
    return vk_items(data["response"]["items"], limit)


# ---------- Pinterest без своей доски: поиск и «похожие» (внутренний API, как в gallery-dl) ----------
async def _pin_api(resource: str, options: dict) -> dict:
    import json as _json
    import secrets
    csrf = secrets.token_hex(16)
    hdr = {**UA, "Accept": "application/json, text/javascript, */*, q=0.01", "X-Requested-With": "XMLHttpRequest",
           "X-Pinterest-AppState": "active", "X-Pinterest-PWS-Handler": "www/[username].js",
           "X-CSRFToken": csrf, "Cookie": f"csrftoken={csrf}"}
    params = {"data": _json.dumps({"options": options}), "source_url": ""}
    async with aiohttp.ClientSession(timeout=TIMEOUT, headers=hdr) as s:
        async with s.get(f"https://www.pinterest.com/resource/{resource}Resource/get/", params=params) as r:
            if r.status >= 400:
                raise SourceError(f"pinterest ответил {r.status}")
            return await r.json(content_type=None)


def _pin_results(data: dict) -> list[dict]:
    res = ((data or {}).get("resource_response") or {}).get("data") or []
    if isinstance(res, dict):
        res = res.get("results") or []
    return [p for p in res if isinstance(p, dict) and p.get("id") and (p.get("type") in (None, "pin"))]


def pin_item(p: dict) -> dict | None:
    """Пин из API → item источника (с каруселью, если есть)."""
    from autopost import media_dl
    img = media_dl.best_pin_image(p.get("images"))
    if not img:
        return None
    title = clean(p.get("grid_title") or p.get("title") or "", 200)
    desc = clean(p.get("description") or p.get("auto_alt_text") or "", 500)
    link = f"https://www.pinterest.com/pin/{p['id']}/"
    item = {"key": f"pin:{p['id']}", "title": title, "text": desc if desc != title else "", "link": link,
            "image": img, "video_page": link, "is_video": media_dl.pin_is_video(p)}
    vl = media_dl._video_list(p)
    if vl:   # волна 77: ссылки на видео уже в данных доски — качаем сразу, без лишних запросов
        item["video_list"] = vl
    many = media_dl.pinterest_images(p)
    if len(many) > 1:
        item["images"] = many
    return item


STOP_WORDS = set("и в на с для по из от до the a an of and for to in with my your this that pin pinterest идеи".split())


def pin_keywords(p: dict) -> str:
    """Ключевые слова пина для поиска похожих: разметка Pinterest → доска → заголовок → описание."""
    ann = ((p.get("pin_join") or {}).get("visual_annotation") or [])
    words = [str(a) for a in ann if a][:4]
    if not words:
        for src in ((p.get("board") or {}).get("name"), p.get("grid_title"), p.get("title"), p.get("description"),
                    p.get("auto_alt_text")):
            words = [w for w in re.findall(r"[\w-]{3,}", clean(str(src or ""))) if w.lower() not in STOP_WORDS][:4]
            if words:
                break
    return " ".join(words)[:60]


async def _search(query: str) -> list[dict]:
    """Поиск пинов с листанием: каждый вызов — следующая страница, кончилось — сначала."""
    import db
    key = f"pinbm:{query}"
    bm = await db.kv_get(key)
    opts = {"query": query, "scope": "pins", "rs": "typed"}
    if bm:
        opts["bookmarks"] = [bm]
    data = await _pin_api("BaseSearch", opts)
    pins = _pin_results(data)
    nxt = (((data or {}).get("resource") or {}).get("options") or {}).get("bookmarks") or [""]
    await db.kv_set(key, "" if not nxt[0] or nxt[0] == "-end-" else nxt[0])
    if not pins and bm:
        pins = _pin_results(await _pin_api("BaseSearch", {"query": query, "scope": "pins", "rs": "typed"}))
    return pins


_board_cache: dict[str, tuple[float, list]] = {}
BOARD_PAGES = 16          # до ~400 пинов
BOARD_TTL = 20 * 60


def _bookmark(data: dict) -> str | None:
    bm = ((data or {}).get("resource_response") or {}).get("bookmark")
    if not bm:
        bms = (((data or {}).get("resource") or {}).get("options") or {}).get("bookmarks") or []
        bm = bms[0] if bms else None
    if not bm or bm == "-end-" or str(bm).startswith("Y2JOb25lO"):
        return None
    return bm


async def pinterest_board(source: str) -> list[dict]:
    """Все пины доски user/board: Board → id, потом BoardFeed постранично (как gallery-dl). Кэш 20 минут."""
    import time as _t
    from urllib.parse import unquote
    hit = _board_cache.get(source)
    if hit and _t.time() - hit[0] < BOARD_TTL:
        return hit[1]
    user, slug = source.split("/", 1)
    slug = unquote(slug).strip("/")
    data = await _pin_api("Board", {"username": user, "slug": slug, "field_set_key": "detailed"})
    board = ((data or {}).get("resource_response") or {}).get("data") or {}
    bid = board.get("id")
    if not bid:
        raise SourceError("доска не найдена или закрыта")
    pins, bm = [], None
    for _ in range(BOARD_PAGES):
        opts = {"board_id": bid, "board_url": f"/{user}/{slug}/", "field_set_key": "react_grid_pin",
                "prepend": False, "page_size": 25, "bookmarks": [bm] if bm else None}
        d = await _pin_api("BoardFeed", opts)
        pins += _pin_results(d)
        bm = _bookmark(d)
        if not bm:
            break
    items = [i for i in (pin_item(p) for p in pins) if i]
    if not items:
        raise SourceError("pinterest не отдал пины доски")
    vids = sum(1 for i in items if i.get("is_video"))
    cars = sum(1 for i in items if len(i.get("images") or []) > 1)
    log.info("pinterest доска %s: %s пинов (видео %s, каруселей %s)", source, len(items), vids, cars)
    _board_cache[source] = (_t.time(), items)
    return items


async def pinterest_discover(source: str, limit: int) -> list[dict]:
    import random
    import db
    if source.startswith("q:"):
        pins = await _search(source[2:])
    else:
        # «похожие»: Pinterest без входа рекомендации не отдаёт — ищем по словам из пина, потом из найденных
        seed = source[4:]
        key = f"pinq:{seed}"
        queries = [q for q in (await db.kv_get(key)).split("|") if q]
        if not queries:
            from autopost import media_dl
            try:
                first = pin_keywords(await media_dl.pinterest_pin(f"https://www.pinterest.com/pin/{seed}/"))
            except media_dl.DLError as e:
                raise SourceError(f"не открыла пин: {e}")
            if not first:
                raise SourceError("у пина нет ни описания, ни доски — дай лучше слова для поиска")
            queries = [first]
        query = queries[0] if len(queries) == 1 or random.random() < 0.4 else random.choice(queries[1:])
        pins = await _search(query)
        found = [pin_keywords(p) for p in pins[:6]]
        queries = list(dict.fromkeys(queries + [q for q in found if q]))[:30]   # снежный ком запросов
        await db.kv_set(key, "|".join(queries))
    items = [i for i in (pin_item(p) for p in pins) if i]
    if not items:
        raise SourceError("pinterest ничего не отдал — попробуй другие слова или пин")
    return items[:max(limit, 20)]


async def _fetch(type_: str, source: str, limit: int = 10) -> list[dict]:
    if type_ == "vk":
        return await _vk(source, limit)
    if type_ == "rss":
        st, body = await _get(source)
        if st != 200:
            raise SourceError(f"сайт ответил {st}")
        return _from_feed(body, limit)

    if type_ == "youtube":
        cid = source if source.startswith("UC") else await _yt_channel_id(source)
        st, body = await _get(f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}")
        if st != 200:
            raise SourceError(f"youtube ответил {st}")
        items = _from_feed(body, limit)
        for it in items:
            it["text"] = ""  # описания на ютубе — спам из ссылок
            it["image"] = None  # превью ссылки покажет плеер
        return items

    if type_ == "reddit":
        st, body = await _get(f"https://www.reddit.com/r/{source}/top/.rss?t=day")
        if st != 200:
            raise SourceError(f"reddit ответил {st} (возможно, блокирует сервер)")
        items = _from_feed(body, limit)
        for it in items:
            reddit_media(it)
            it["text"] = re.sub(r"submitted by.*$", "", it["text"], flags=re.S).strip()
            it["text"] = re.sub(r"\[link\]|\[comments\]", "", it["text"]).strip()
        return items

    if type_ == "pinterest" and source.startswith(("q:", "rel:")):
        return await pinterest_discover(source, limit)
    if type_ == "pinterest" and "/" in source:
        try:   # волна 77: доска целиком через API (RSS отдаёт только ~25 последних и без видео/каруселей)
            return await pinterest_board(source)
        except SourceError as e:
            log.warning("pinterest board %s через API: %s — читаю RSS (там только последние ~25)", source, e)
    if type_ == "pinterest":
        url = (f"https://www.pinterest.com/{source}.rss" if "/" in source
               else f"https://www.pinterest.com/{source}/feed.rss")
        st, body = await _get(url)
        if st != 200:
            raise SourceError(f"pinterest ответил {st}")
        items = _from_feed(body, limit * 2)
        for it in items:
            if it["image"]:
                if it["image"].lower().endswith(".gif"):
                    it["image"] = re.sub(r"/(?:236x|474x|170x|736x|60x60)/", "/originals/", it["image"])
                else:
                    it["image"] = re.sub(r"/(?:236x|474x|170x|60x60)/", "/736x/", it["image"])
            # видео-пин узнаём только открыв сам пин — это сделает yt-dlp при публикации
            it["video_page"] = it["link"]
            if it["title"].strip().lower() == "pinterest":
                it["title"] = ""
        return [i for i in items if i["image"]][:limit]

    if type_ in ("video", "music"):
        from autopost import media_dl
        try:
            return await media_dl.ytdlp_list(source, limit)
        except media_dl.DLError as e:
            raise SourceError(str(e))

    if type_ == "tg":
        st, body = await _get(f"https://t.me/s/{source}")
        if st != 200:
            raise SourceError(f"telegram ответил {st}")
        return _parse_tg(body.decode("utf-8", "ignore"), source, limit)

    raise SourceError("неизвестный тип")


_TG_MSG = re.compile(r'<div class="tgme_widget_message [^"]*"[^>]*data-post="([^"]+)"(.*?)(?=<div class="tgme_widget_message_wrap|\Z)', re.S)
_TG_TEXT = re.compile(r'<div class="tgme_widget_message_text[^"]*"[^>]*>(.*?)</div>', re.S)
_TG_PHOTO = re.compile(r"tgme_widget_message_photo_wrap[^>]*background-image:url\('([^']+)'\)")
_TG_VIDEO = re.compile(r'<video[^>]+src="([^"]+)"')
_TG_VTHUMB = re.compile(r"tgme_widget_message_video_thumb[^>]*background-image:url\('([^']+)'\)")


def _parse_tg(page: str, source: str, limit: int) -> list[dict]:
    if "tgme_channel_info" not in page and "tgme_widget_message" not in page:
        raise SourceError("канал закрыт или не существует")
    out = []
    for post_id, chunk in _TG_MSG.findall(page):
        tm = _TG_TEXT.search(chunk)
        photos = _TG_PHOTO.findall(chunk)
        vid = _TG_VIDEO.search(chunk)
        vthumb = _TG_VTHUMB.search(chunk)
        text = clean(tm.group(1), 900) if tm else ""
        if not text and not photos and not vid and not vthumb:
            continue
        cover = photos[0] if photos else (vthumb.group(1) if vthumb else None)
        out.append({"key": post_id, "title": "", "text": text,
                    "link": f"https://t.me/{post_id}", "image": cover,
                    "images": photos[:10], "video": html.unescape(vid.group(1)) if vid else None,
                    # видео без прямой ссылки (большие) — пробуем yt-dlp по ссылке на пост
                    "video_page": f"https://t.me/{post_id}" if (vthumb and not vid) else None})
    out.reverse()  # на странице старые сверху
    return out[:limit]


# ---------- фильтры ----------
def passes(item: dict, include: str, exclude: str) -> bool:
    blob = f"{item.get('title', '')} {item.get('text', '')}".lower()
    inc = [w.strip().lower() for w in include.split(",") if w.strip()]
    exc = [w.strip().lower() for w in exclude.split(",") if w.strip()]
    if inc and not any(w in blob for w in inc):
        return False
    return not any(w in blob for w in exc)


_REDDIT_LINK = re.compile(r'<a href="([^"]+)">\[link\]</a>')


def reddit_media(it: dict):
    """Достаёт настоящий медиа-файл поста реддита из ссылки [link]."""
    m = _REDDIT_LINK.search(it.get("raw") or "")
    if not m:
        return
    url = html.unescape(m.group(1))
    low = url.lower().split("?")[0]
    if "i.redd.it" in low or re.search(r"\.(jpe?g|png|webp|gif)$", low):
        it["image"] = url
    elif "v.redd.it" in low:
        it["video_page"] = it.get("link") or url
    elif low.endswith(".gifv"):
        it["video"] = url[:-5] + ".mp4"
    elif low.endswith(".mp4"):
        it["video"] = url
