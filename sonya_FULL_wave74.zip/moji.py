"""Волна 70: премиум-эмодзи везде. Перед отправкой в Telegram обычные эмодзи в текстах бота меняются на анимированные
из паков Сони (<tg-emoji>), а эмодзи в начале кнопок — на премиум-иконку кнопки. Работает во всех ботах:
второстепенные берут id из базы основной Сони. Telegram не принял (у владельца нет Premium и т.п.) — шлю как было
и выключаю подмену на 6 часов, чтобы не тратить запросы.
Плюс лицо Сони с эмоцией в ответах чата — иногда, по настроению разговора."""
import html
import json
import logging
import random
import re
import sqlite3
import time

from aiogram.client.session.middlewares.base import BaseRequestMiddleware
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import (SendMessage, EditMessageText, SendPhoto, SendVideo, SendAnimation, EditMessageCaption,
                             EditMessageMedia)
from aiogram.types import InlineKeyboardMarkup

import config
import db

log = logging.getLogger("moji")

MAP: dict[str, str] = {}          # эмодзи (без FE0F) → custom_emoji_id
FACES: dict[str, str] = {}        # эмоция Сони → её эмодзи-символ (тот, что в MAP)
OPT = {"text": True, "btn": True}
OFF = {"until": 0.0}
MAX_PER_MSG = 40                  # больше — Telegram может не принять, да и рябит
OFF_FOR = 6 * 3600
CHAT_CHANCE = 0.35                # как часто Соня ставит своё лицо в ответ
_loaded = {"at": 0.0}
_rx: list = [None]


def norm(e: str) -> str:
    return e.replace("\uFE0F", "")


def _compile():
    if not MAP:
        _rx[0] = None
        return
    keys = sorted(MAP, key=len, reverse=True)
    # необязательный FE0F после каждого символа ключа: ❤ и ❤+FE0F — одно и то же
    pat = "|".join("".join(re.escape(ch) + "\\uFE0F?" for ch in k) for k in keys)
    _rx[0] = re.compile(f"(?:{pat})")


def set_map(own: dict, extra: dict | None = None, opts: dict | None = None):
    MAP.clear()
    MAP.update({norm(k): v for k, v in (extra or {}).items() if v})
    MAP.update({norm(k): v for k, v in (own or {}).items() if v})
    if opts:
        OPT.update(opts)
    import sonyamoji
    FACES.clear()
    for emo, (ch, _) in sonyamoji.EMOTIONS.items():
        if norm(ch) in MAP:
            FACES[emo] = ch
    _compile()


def _read_main(keys: list[str]) -> dict:
    """Второстепенные боты читают настройки из базы основной Сони (только чтение)."""
    out = {}
    try:
        c = sqlite3.connect(f"file:{config.MAIN_DB_PATH}?mode=ro", uri=True, timeout=3)
        try:
            for k in keys:
                r = c.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
                out[k] = r[0] if r else ""
        finally:
            c.close()
    except Exception as e:
        log.info("moji: main db: %s", e)
    return out


KEYS = ["moji:map", "moji:extra", "moji:on", "moji:btn"]


async def load():
    if config.PROFILE == "full":
        vals = {k: await db.kv_get(k) for k in KEYS}
    else:
        import asyncio
        vals = await asyncio.to_thread(_read_main, KEYS)
    try:
        own = json.loads(vals.get("moji:map") or "{}")
        extra = json.loads(vals.get("moji:extra") or "{}")
    except ValueError:
        own, extra = {}, {}
    set_map(own, extra, {"text": vals.get("moji:on", "") != "0", "btn": vals.get("moji:btn", "") != "0"})
    _loaded["at"] = time.time()


async def loop():
    """Подхватываю новые паки без перезапуска (раз в 5 минут)."""
    import asyncio
    while True:
        await asyncio.sleep(300)
        try:
            await load()
        except Exception as e:
            log.info("moji reload: %s", e)


def active() -> bool:
    return bool(MAP) and time.time() >= OFF["until"]


# ================= подмена =================
_SKIP_TAGS = ("code", "pre", "tg-emoji")


def html_text(text: str) -> tuple[str, int]:
    """HTML-текст: эмодзи вне тегов (и не внутри code/pre/tg-emoji) → <tg-emoji>. → (текст, сколько заменено)."""
    rx = _rx[0]
    if not rx or not text:
        return text, 0
    out, n, depth = [], 0, 0
    for part in re.split(r"(<[^>]+>)", text):
        if part.startswith("<") and part.endswith(">"):
            m = re.match(r"<\s*(/)?\s*([a-zA-Z-]+)", part)
            if m and m.group(2).lower() in _SKIP_TAGS:
                depth += -1 if m.group(1) else 1
                depth = max(depth, 0)
            out.append(part)
            continue
        if depth or n >= MAX_PER_MSG:
            out.append(part)
            continue

        def sub(mt):
            nonlocal n
            if n >= MAX_PER_MSG:
                return mt.group(0)
            cid = MAP.get(norm(mt.group(0)))
            if not cid:
                return mt.group(0)
            n += 1
            return f'<tg-emoji emoji-id="{cid}">{mt.group(0)}</tg-emoji>'
        out.append(rx.sub(sub, part))
    return "".join(out), n


def plain_text(text: str) -> tuple[str, int]:
    """Обычный текст (без разметки) → HTML с премиум-эмодзи; если менять нечего — как был."""
    rx = _rx[0]
    if not rx or not text or not rx.search(text):
        return text, 0
    return html_text(html.escape(text, quote=False))


def _is_html(pm) -> bool:
    if pm is None:
        return False
    return pm.lower() == "html" if isinstance(pm, str) else True


def _lead(text: str) -> tuple[str | None, str]:
    """«🎮 Игры» → (id, «Игры»): эмодзи в начале кнопки, у которого есть премиум-версия."""
    rx = _rx[0]
    if not rx:
        return None, text
    m = rx.match(text)
    if not m:
        return None, text
    rest = text[m.end():].lstrip("\uFE0F ").strip()
    cid = MAP.get(norm(m.group(0)))
    if not cid or not rest:
        return None, text
    return cid, rest


def buttons(mk):
    if not isinstance(mk, InlineKeyboardMarkup) or not OPT["btn"]:
        return mk, 0
    rows, n = [], 0
    for row in mk.inline_keyboard:
        out = []
        for b in row:
            if not getattr(b, "icon_custom_emoji_id", None) and b.text:
                cid, rest = _lead(b.text)
                if cid:
                    b = b.model_copy(update={"icon_custom_emoji_id": cid, "text": rest})
                    n += 1
            out.append(b)
        rows.append(out)
    return (InlineKeyboardMarkup(inline_keyboard=rows), n) if n else (mk, 0)


def _text_upd(text, pm, entities) -> dict:
    if not OPT["text"] or not isinstance(text, str) or entities:
        return {}
    if _is_html(pm):
        new, n = html_text(text)
        return {"_t": new, "_pm": pm} if n else {}
    if pm is None:
        new, n = plain_text(text)
        return {"_t": new, "_pm": "HTML"} if n else {}
    return {}   # Markdown — не трогаю


def transform(method):
    """Вернуть изменённую копию метода или None, если менять нечего."""
    upd = {}
    if isinstance(method, (SendMessage, EditMessageText)):
        u = _text_upd(method.text, method.parse_mode, method.entities)
        if u:
            upd.update(text=u["_t"], parse_mode=u["_pm"])
    elif isinstance(method, (SendPhoto, SendVideo, SendAnimation, EditMessageCaption)):
        u = _text_upd(method.caption, method.parse_mode, method.caption_entities)
        if u:
            upd.update(caption=u["_t"], parse_mode=u["_pm"])
    elif isinstance(method, EditMessageMedia) and method.media is not None:
        md = method.media
        u = _text_upd(getattr(md, "caption", None), getattr(md, "parse_mode", None), getattr(md, "caption_entities", None))
        if u:
            upd["media"] = md.model_copy(update={"caption": u["_t"], "parse_mode": u["_pm"]})
    mk = getattr(method, "reply_markup", None)
    if isinstance(mk, InlineKeyboardMarkup):
        new_mk, n = buttons(mk)
        if n:
            upd["reply_markup"] = new_mk
    return method.model_copy(update=upd) if upd else None


class MojiMiddleware(BaseRequestMiddleware):
    """Самый внутренний слой: меняет уже готовый запрос. Ошибка из-за подмены → шлю исходный и отключаюсь на 6 ч."""

    async def __call__(self, make_request, bot, method):
        if not active():
            return await make_request(bot, method)
        try:
            new = transform(method)
        except Exception:
            log.exception("moji transform")
            new = None
        if new is None:
            return await make_request(bot, method)
        try:
            return await make_request(bot, new)
        except TelegramBadRequest as e:
            if "not modified" in str(e).lower():
                raise
            res = await make_request(bot, method)   # исходный прошёл — значит, дело в премиум-эмодзи
            OFF["until"] = time.time() + OFF_FOR
            log.warning("moji: Telegram не принял премиум-эмодзи (%s) — выключаю на 6 ч", e)
            return res


# ================= лицо Сони в ответах =================
MOODS = [   # (эмоция, слова в ответе или сообщении человека)
    ("laugh", r"ахах|хаха|ржу|лол|ору|смешн|😂|🤣"),
    ("love", r"люблю|обожаю|милаш|❤|💕|😍|🥰|мур"),
    ("cry", r"плачу|рыдаю|😭"),
    ("sad", r"грустн|печаль|жаль|сочувств|обидн|к сожалению|😢|😔"),
    ("angry", r"бесит|злюсь|достал|ненавиж|😡|🤬"),
    ("shock", r"ого|вау|офиге|ничего себе|серь[её]зно\?|😮|😱"),
    ("think", r"хм+|думаю|интересный вопрос|если подумать|🤔"),
    ("sleepy", r"спать|сплю|сонн|устал|спокойной ночи|😴"),
    ("blush", r"спасибо|красив|комплимент|смущ|😳"),
    ("party", r"поздравля|ура+|день рождения|праздник|🥳|🎉"),
    ("cool", r"легко|изи|красава|круто|😎"),
    ("smirk", r"ну-ну|ну конечно|хитр|😏"),
]
_MOODS = [(e, re.compile(p, re.I)) for e, p in MOODS]


def mood(user_text: str, answer: str) -> str:
    for src in (answer, user_text):
        for emo, rx in _MOODS:
            if rx.search(src or ""):
                return emo
    return random.choice(["happy", "happy", "wink", "smirk", "cool"])


def decorate(user_text: str, answer: str, chance: float | None = None) -> str:
    """Иногда добавляю к ответу своё лицо с подходящей эмоцией (если пак уже собран)."""
    if not answer or not FACES or not active() or not OPT["text"]:
        return answer
    if random.random() >= (CHAT_CHANCE if chance is None else chance):
        return answer
    emo = mood(user_text, answer)
    ch = FACES.get(emo) or FACES.get("happy")
    if not ch:
        return answer
    if answer.rstrip().endswith(ch):
        return answer
    return answer.rstrip() + " " + ch
