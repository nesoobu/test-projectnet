"""Волна 70: премиум-эмодзи везде. Лицо Сони с эмоциями, анимированные версии всех эмодзи бота (несколько паков),
автоподмена в текстах и кнопках (middleware), откат при отказе Telegram, лицо в ответах чата, импорт чужого пака,
второстепенные боты берут id из базы основной Сони.
python test_w70.py ../sonya full"""
import asyncio, json, os, sqlite3, subprocess, sys, tempfile
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"
config.STREAM = False
from aiogram.exceptions import TelegramBadRequest
from aiogram.methods import SendMessage, SendPhoto, EditMessageText
from aiogram.types import StickerSet, Sticker, MessageEntity


async def main():
    M, bot, dp = await setup()
    import sonyamoji, moji, uikit, llm
    from handlers import admin, games

    # ---------- рисунки ----------
    emos = list(sonyamoji.EMOTIONS)
    ok = True
    for n in ["sonya", "wink"] + emos:
        for t in (0.1, 0.6):
            f = sonyamoji.SET[n][0](t).resize((100, 100))
            ok &= f.mode == "RGBA" and f.getpixel((0, 0))[3] == 0 and max(f.split()[3].getdata()) == 255
    check(f"лицо Сони: {len(emos) + 2} эмоций рисуются, фон прозрачный", ok and len(emos) >= 13)
    inv = sonyamoji.inventory()
    check(f"все эмодзи из кода найдены ({len(inv)}), у каждого есть рисунок",
          len(inv) > 250 and "🎮" in inv and "🎰" in inv and all(sonyamoji.has_glyph(e) for e in inv))
    check("ручные и служебные не дублируются: 🎲/😂 — свои, ♠/▫ не трогаю",
          "🎲" not in inv and "😂" not in inv and "♠" not in inv and "▫" not in inv)
    fr = sonyamoji.frames("🎮")
    check("значок анимирован (кадры разные), 100×100", len(fr) == 60 and fr[0].size == (100, 100)
          and fr[0].tobytes() != fr[20].tobytes())
    for key in ("laugh", "🎮", "✂", "👥"):
        data = sonyamoji.webm(key)
        p = os.path.join(tempfile.mkdtemp(), "e.webm")
        open(p, "wb").write(data)
        j = json.loads(subprocess.run(["ffprobe", "-v", "error", "-show_entries", "stream=codec_name,width,height:"
                                       "stream_tags=alpha_mode:format=duration", "-of", "json", p],
                                      capture_output=True, text=True).stdout)
        st = j["streams"][0]
        check(f"WEBM {key}: VP9 100×100 альфа ≤3 с ≤64 КБ ({len(data) // 1024} КБ)", st["codec_name"] == "vp9" and st["width"] == 100
              and st.get("tags", {}).get("alpha_mode") == "1" and float(j["format"]["duration"]) <= 3
              and len(data) <= 64 * 1024)

    gif = sonyamoji.preview_gif(["sonya", "laugh"] + inv[:3], 8)
    check("превью «Все эмодзи» (ручные + значки) рисуется", gif[:3] == b"GIF")

    # ---------- сборка паков ----------
    sonyamoji.webm = lambda k, limit=None: b"SMALL" if limit else b"WEBM"
    big = {"create": 1, "add": 1}   # первый create и первый add Telegram отвергает: «file is too big»
    packs, calls = {}, {"create": 0, "add": 0}

    def mk(name):
        return StickerSet(name=name, title="t", sticker_type="custom_emoji", stickers=[
            Sticker(file_id=f"f{i}", file_unique_id=f"u{i}", type="custom_emoji", width=100, height=100,
                    is_animated=False, is_video=True, custom_emoji_id=f"{name[:12]}#{i}") for i in range(len(packs[name]))])

    async def create(user_id, name, title, stickers, sticker_type):
        assert len(stickers) <= 50 and sticker_type == "custom_emoji" and user_id == 1
        if big["create"] and stickers[0].sticker.data == b"WEBM":
            big["create"] = 0
            raise TelegramBadRequest(method=None, message="Bad Request: file is too big")
        calls["create"] += 1
        packs[name] = [s.emoji_list[0] for s in stickers]
        return True

    async def add(user_id, name, sticker):
        calls["add"] += 1
        assert len(packs[name]) < 200
        if big["add"] and sticker.sticker.data == b"WEBM":
            big["add"] = 0
            raise TelegramBadRequest(method=None, message="Bad Request: file is too big")
        packs[name].append(sticker.emoji_list[0])
        return True

    async def getset(name):
        if name not in packs:
            raise TelegramBadRequest(method=None, message="STICKERSET_INVALID")
        return mk(name)
    bot.create_new_sticker_set, bot.add_sticker_to_set, bot.get_sticker_set = create, add, getset
    SENT.clear()
    await admin._make_pack(bot, 1, 1)
    names = sorted(packs)
    mp = json.loads(await db.kv_get("moji:map"))
    ids = json.loads(await db.kv_get("moji:ids"))
    p0 = "sonya_emoji_by_Sonya_rubot"
    check(f"паки: {len(packs)} (лицо + {len(packs) - 1} со значками), в каждом ≤200",
          p0 in packs and len(packs) >= 3 and all(len(v) <= 200 for v in packs.values())
          and sum(len(v) for v in packs.values()) == len(sonyamoji.SET) + len(inv))
    check("создание по 50, остальное — добавлением", calls["create"] == len(packs) and calls["add"] > 200)
    check("«file is too big» → жму сильнее и продолжаю (и create, и add)", big == {"create": 0, "add": 0})
    check("сопоставление: 😂 → лицо «хохочет», 🎲 → фирменный кубик, 💜 → сердечко, 🎮 → значок",
          mp["😂"] == ids["laugh"] and mp["🎲"] == ids["dice"] and mp["💜"] == ids["heart"]
          and mp["🎮"].startswith("sonya_moji1"))
    check("эмодзи пака = сам эмодзи (поиск в Telegram)", packs[p0][list(sonyamoji.SET).index("laugh")] == "😂"
          and "🎮" in packs["sonya_moji1_by_Sonya_rubot"])
    check("владельцу — прогресс и «паки готовы» со ссылками",
          any("рисую и загружаю" in t for t in H.texts()) and any("паки готовы" in t and "addemoji" in t for t in H.texts()))
    c0 = dict(calls)
    await admin._make_pack(bot, 1, 1)
    check("повторно — ничего не перезаливаю", calls == c0 and json.loads(await db.kv_get("moji:map")) == mp)
    # обрыв на середине → «дособрать» продолжает с места
    del packs["sonya_moji2_by_Sonya_rubot"]
    await db.kv_set("moji:order:sonya_moji2_by_Sonya_rubot", "[]")
    packs["sonya_moji1_by_Sonya_rubot"] = packs["sonya_moji1_by_Sonya_rubot"][:120]
    o = json.loads(await db.kv_get("moji:order:sonya_moji1_by_Sonya_rubot"))
    await db.kv_set("moji:order:sonya_moji1_by_Sonya_rubot", json.dumps(o[:120]))
    await admin._make_pack(bot, 1, 1)
    check("после обрыва — дозагрузка с места", len(packs["sonya_moji1_by_Sonya_rubot"]) == 200
          and "sonya_moji2_by_Sonya_rubot" in packs)

    # ---------- подмена в текстах и кнопках ----------
    bot.session.middleware(uikit.UiMiddleware())
    bot.session.middleware(moji.MojiMiddleware())
    SENT.clear()
    await dp.feed_update(bot, msg("/start", 80, 80))
    m = (H.sent(SendMessage) or H.sent(SendPhoto))[-1]
    btns = {b.callback_data: b for row in m.reply_markup.inline_keyboard for b in row}
    g = btns["g:menu"]
    check("кнопки: эмодзи → премиум-иконка, в тексте без двойного значка",
          g.icon_custom_emoji_id == mp["🎮"] and g.text == "Игры")
    SENT.clear()
    await dp.feed_update(bot, cbq("g:menu", 80, 80))
    t = "\n".join((getattr(x, "text", None) or getattr(x, "caption", None) or "") for x in SENT)
    check("экран игр: эмодзи в тексте — анимированные <tg-emoji>", f'<tg-emoji emoji-id="{mp["🎮"]}">' in t)
    h, n = moji.html_text('<code>🎮</code> <a href="https://x.y/🎮">🎮</a>')
    check("в <code> и в ссылках-адресах не трогаю", h.startswith("<code>🎮</code>") and 'href="https://x.y/🎮"' in h and n == 1)
    h, n = moji.html_text("🎮" * 60)
    check("не больше 40 на сообщение", n == 40)
    h, n = moji.plain_text("a<b ❤️")
    check("обычный текст → экранирую и HTML", h == f'a&lt;b <tg-emoji emoji-id="{mp["❤"]}">❤️</tg-emoji>' and n == 1)

    # ---------- лицо Сони в чате ----------
    moji.CHAT_CHANCE = 1.0
    llm.ask = lambda *a, **k: asyncio.sleep(0, "ахаха, вот это ты выдал")
    SENT.clear()
    await dp.feed_update(bot, msg("расскажи анекдот", 81, 81))
    r = [x for x in H.sent(SendMessage) if "выдал" in (x.text or "")]
    check("в ответе — лицо Сони по настроению (смех)", r and f'<tg-emoji emoji-id="{ids["laugh"]}">' in r[-1].text
          and r[-1].parse_mode == "HTML")
    check("настроение: грусть / сон / мысль", moji.mood("мне грустно", "жаль, что так") == "sad"
          and moji.mood("", "иди спать") == "sleepy" and moji.mood("", "хм, думаю да") == "think")
    moji.CHAT_CHANCE = 0.0
    SENT.clear()
    await dp.feed_update(bot, msg("ещё", 81, 81))
    check("не каждый раз", not any("tg-emoji" in (x.text or "") for x in H.sent(SendMessage)))

    # ---------- Telegram не принял ----------
    real = H.Mock._make
    rejected = []

    async def picky(self, bot_, method):
        if "tg-emoji" in str(getattr(method, "text", "") or "") or "icon_custom_emoji_id='" in str(getattr(method, "reply_markup", "")):
            rejected.append(1)
            raise TelegramBadRequest(method=method, message="Bad Request: custom emoji not allowed")
        return await real(self, bot_, method)
    H.Mock._make = picky
    SENT.clear()
    await dp.feed_update(bot, cbq("g:menu", 82, 82))
    ok_sent = [x for x in SENT if "tg-emoji" not in str(getattr(x, "text", "") or "")]
    check("отказ → шлю обычный вариант и ставлю паузу 6 ч", rejected and ok_sent and moji.OFF["until"] > 0 and not moji.active())
    rejected.clear()
    SENT.clear()
    await dp.feed_update(bot, cbq("g:menu", 82, 82))
    check("на паузе — не пробую (без лишних запросов)", not rejected)
    H.Mock._make = real
    moji.OFF["until"] = 0

    # ---------- админка: переключатели, импорт ----------
    SENT.clear()
    await dp.feed_update(bot, cbq("em:home", 1, 1))
    check("админ-экран: паки, счётчик, кнопки", "premium" not in "\n".join(H.texts()) and "премиум-версий" in "\n".join(H.texts())
          and "em:imp" in str([getattr(x, "reply_markup", "") for x in SENT]))
    await dp.feed_update(bot, cbq("em:tt", 1, 1))
    check("⏸ замена в текстах выключается", moji.OPT["text"] is False and await db.kv_get("moji:on") == "0"
          and moji.transform(SendMessage(chat_id=1, text="🎮 x", parse_mode="HTML")) is None)
    await dp.feed_update(bot, cbq("em:tt", 1, 1))
    check("▶️ и включается", moji.OPT["text"] is True)

    async def ces(custom_emoji_ids):
        return [Sticker(file_id="z", file_unique_id="z", type="custom_emoji", width=100, height=100, is_animated=False,
                        is_video=True, custom_emoji_id=custom_emoji_ids[0], set_name="CoolPack")]

    async def getset2(name):
        if name == "CoolPack":
            return StickerSet(name=name, title="Cool", sticker_type="custom_emoji", stickers=[
                Sticker(file_id="a", file_unique_id="a", type="custom_emoji", width=100, height=100, is_animated=False,
                        is_video=True, custom_emoji_id="X1", emoji="🦖"),
                Sticker(file_id="b", file_unique_id="b", type="custom_emoji", width=100, height=100, is_animated=False,
                        is_video=True, custom_emoji_id="X2", emoji="🎮")])
        return await getset(name)
    bot.get_custom_emoji_stickers, bot.get_sticker_set = ces, getset2
    await dp.feed_update(bot, cbq("em:imp", 1, 1))
    SENT.clear()
    await dp.feed_update(bot, msg("вот", 1, 1, entities=[MessageEntity(type="custom_emoji", offset=0, length=2,
                                                                         custom_emoji_id="X1")]))
    ex = json.loads(await db.kv_get("moji:extra") or "{}")
    check("импорт: берёт недостающие (🦖), свои не перебивает (🎮)", ex == {"🦖": "X1"} and moji.MAP["🦖"] == "X1"
          and moji.MAP["🎮"] == mp["🎮"] and any("взяла" in t for t in H.texts()))

    # ---------- /emoji ----------
    SENT.clear()
    await dp.feed_update(bot, msg("/emoji", 83, 83))
    kb = str((H.sent(SendMessage) or H.sent(SendPhoto))[-1].reply_markup)
    check("/emoji — ссылки на все паки", all(f"addemoji/{n}" in kb for n in packs))

    # ---------- второстепенные боты ----------
    tmp = os.path.join(tempfile.mkdtemp(), "main.db")
    c = sqlite3.connect(tmp)
    c.execute("CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT)")
    c.execute("INSERT INTO kv VALUES('moji:map', ?)", (json.dumps({"🎁": "G1", "😊": "F1"}),))
    c.commit()
    c.close()
    old = config.MAIN_DB_PATH, config.PROFILE
    config.MAIN_DB_PATH, config.PROFILE = tmp, "gw"
    await moji.load()
    check("помощник (gw) берёт эмодзи из базы основной Сони", moji.MAP == {"🎁": "G1", "😊": "F1"}
          and moji.FACES.get("happy") == "😊")
    config.MAIN_DB_PATH, config.PROFILE = old
    await moji.load()

    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
