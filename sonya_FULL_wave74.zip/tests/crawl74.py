"""Волна 74: обход ВСЕХ экранов кнопками (BFS) — у какого экрана нет картинки. python crawl74.py ../sonya full"""
import asyncio, re, sys
from harness import *  # noqa
import harness as H
import config
config.PROFILE = sys.argv[2] if len(sys.argv) > 2 else "full"
config.BANNERS = True
from aiogram.methods import SendMessage, SendPhoto, EditMessageText, EditMessageMedia, EditMessageCaption
from aiogram.types import InlineKeyboardMarkup

SKIP = re.compile(r"^(em:(make|pv|pa)|bn:(d|draw|all|r)|adm:(ytup|mus|bak|bc)|ui:|uipg:|stk:pd|.*:del|.*:rm|.*:y:|noop)")


def screens(start):
    out = []
    for m in SENT[start:]:
        mk = getattr(m, "reply_markup", None)
        if isinstance(m, (SendMessage, EditMessageText)):
            out.append(("text", m.text or "", mk))
        elif isinstance(m, SendPhoto):
            out.append(("photo", m.caption or "", mk))
        elif isinstance(m, EditMessageMedia):
            out.append(("photo", getattr(m.media, "caption", "") or "", mk))
        elif isinstance(m, EditMessageCaption):
            out.append(("photo", m.caption or "", mk))
    return out


async def main():
    M, bot, dp = await setup()
    import uikit, banners
    bot.session.middleware(uikit.UiMiddleware())
    uid = config.OWNER_ID or 1
    seen, queue, bad, nohead, total = set(), [], {}, {}, 0
    for cmd in ("/start", "/menu", "/help", "/admin", "/me", "/panel", "/giveaway", "/gifts", "/emoji", "/plus", "/bots"):
        start = len(SENT)
        try:
            await asyncio.wait_for(dp.feed_update(bot, msg(cmd, uid, uid)), 15)
        except Exception as e:
            print("cmd", cmd, e)
        queue += [(cmd, s) for s in screens(start)]
    i = 0
    while i < len(queue) and len(seen) < 400:
        src, (kind, text, mk) = queue[i]
        i += 1
        if isinstance(mk, InlineKeyboardMarkup) and mk.inline_keyboard:
            total += 1
            head = banners.auto_for_text(text) or banners.for_text(text)
            first = text.split("\n")[0][:60]
            if kind != "photo":
                (bad if head else nohead)[first] = src
            for row in mk.inline_keyboard:
                for b in row:
                    d = b.callback_data
                    if not d or d in seen or SKIP.match(d):
                        continue
                    seen.add(d)
                    start = len(SENT)
                    try:
                        await asyncio.wait_for(dp.feed_update(bot, cbq(d, uid, uid, mid=len(SENT) + 100)), 15)
                    except Exception as e:
                        print("cb", d, type(e).__name__, str(e)[:80])
                    queue += [(d, s) for s in screens(start)]
    print(f"\nэкранов с кнопками: {total}, нажато кнопок: {len(seen)}")
    print(f"\nс шапкой, но БЕЗ картинки: {len(bad)}")
    for k, v in bad.items():
        print("  ", v, "→", k)
    print(f"\nбез шапки (картинку не ставлю): {len(nohead)}")
    for k, v in nohead.items():
        print("  ", v, "→", k)
    await db.close()


asyncio.run(main())
