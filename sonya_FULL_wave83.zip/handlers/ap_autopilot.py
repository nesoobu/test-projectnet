"""Волна 78: экран «🤖 Автопилот» канала — тема, рубрики, свои источники, режим, запуск, пробный пост, итоги."""
import logging
from html import escape

from aiogram import Router, F, Bot
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import CallbackQuery, Message

import ui
from autopost import autopilot as AP, store, sources
from handlers.ap_common import show, kb_rows

router = Router()
log = logging.getLogger("ap_autopilot")
DAYS = "пн вт ср чт пт сб вс".split()


class APL(StatesGroup):
    theme = State()
    src = State()


async def _own(cb: CallbackQuery) -> int | None:
    cid = int(cb.data.rsplit(":", 1)[1])
    if not await store.channel(cid, cb.from_user.id):
        await cb.answer("канал не найден", show_alert=True)
        return None
    return cid


def _sched(key: str, p: dict) -> str:
    rb = AP.RUBRICS[key]
    times = (p.get("times") or {}).get(key) or rb["times"]
    days = (p.get("days") or {}).get(key) or rb["days"]
    d = "каждый день" if len(days) == 7 else ",".join(DAYS[i] for i in sorted(days))
    return f"{d} · {' '.join(times)}"


async def view(cid: int) -> tuple[str, object]:
    ch = await store.channel(cid) or {}
    p = await AP.profile(cid)
    lines = [ui.head("🤖", "Автопилот", escape(ch.get("title", ""))[:40])]
    lines.append(ui.quote(
        f"🎯 тема: <b>{escape(p['theme'])}</b>\n"
        f"🛡 {'каждый пост сначала тебе на ✅' if p.get('mode', 'moderate') == 'moderate' else 'сразу в канал'}\n"
        f"{'🟢 <b>веду канал</b>' if p.get('active') else '⏸ <b>выключен</b>'}"))
    tst = p.get("taste") or {}
    learned = []
    if tst.get("artists"):
        learned.append("артисты: " + ", ".join(escape(a) for a in tst["artists"][:5]))
    if tst.get("boards"):
        learned.append("доски: " + ", ".join(escape(b) for b in tst["boards"][:2]))
    if learned:
        lines.append(ui.quote("🧭 <b>учусь на твоём канале</b>\n" + "\n".join(learned)
                              + "\nмузыка — похожая на твою, видео — с твоих досок и похожее, новости — про твоих артистов"))
    elif "music" in p.get("on", []):
        lines.append("⚠️ для музыки нужен твой источник Яндекс Музыки (лайки/плейлист) — по нему подберу похожее")
    rub = []
    for key, rb in AP.RUBRICS.items():
        on = key in p.get("on", [])
        own = len((p.get("sources") or {}).get(key, []))
        extra = f" · своих источников: {own}" if own else ""
        if on:
            rub.append(f"✅ {rb['emoji']} <b>{rb['name']}</b> — {_sched(key, p)}{extra}")
    lines.append("<b>рубрики</b>\n" + ("\n".join(rub) if rub else "ни одной — включи ниже"))
    import config
    if not config.LLM_VISION_MODEL and "meme" in p.get("on", []):
        lines.append("⚠️ <b>нет нейросети, которая видит картинки</b> (LLM_VISION_MODEL в .env) — без неё мемы не "
                     "выкладываю: не смогу проверить, что это мем, а не закат")
    lines.append(ui.hint("мемы проверяю по картинке: не мем или не смешно — не выложу. новости — свежие, по теме, "
                         "без рекламы и дублей. факты/советы пишу сама и рисую картинку"))
    rows, line = [], []
    for key, rb in AP.RUBRICS.items():
        on = key in p.get("on", [])
        line.append((f"{'✅' if on else '⬜'} {rb['emoji']} {rb['name']}", f"apl:t:{key}:{cid}"))
        if len(line) == 2:
            rows.append(line)
            line = []
    if line:
        rows.append(line)
    rows += [[("🎯 Тема", f"apl:th:{cid}"), ("➕ Мой источник", f"apl:src:{cid}")],
             [("🛡 Сначала мне ✅" if p.get("mode", "moderate") == "moderate" else "🛡 Сначала мне ⬜", f"apl:m:{cid}"),
              ("🧪 Пробный пост", f"apl:try:{cid}")],
             [("⏸ Остановить", f"apl:off:{cid}", "danger") if p.get("active") else ("🚀 Запустить", f"apl:go:{cid}", "success")],
             [("📈 Итоги недели", f"apl:rep:{cid}"), ("‹ К каналу", f"ap:ch:{cid}")]]
    return "\n\n".join(lines), kb_rows(*rows)


async def _ensure(cid: int, uid: int) -> dict:
    p = await AP.profile(cid)
    if not p:
        ch = await store.channel(cid) or {}
        p = AP.new_profile(AP.clean_theme(await AP.guess_theme(cid, uid), ch.get("title", "")))
        await AP.save(cid, p)
    if not p.get("v80"):   # волна 80: у музыкального канала включаю музыку и видео
        if AP.is_music(p.get("theme", "")):
            for k in ("music", "video"):
                if k not in p.setdefault("on", []):
                    p["on"].insert(0, k)
        p["v80"] = True
        await AP.save(cid, p)
    if not p.get("v82"):   # волна 82: учусь на канале — тема без названия, источники от твоих
        ch = await store.channel(cid) or {}
        try:
            await AP.refresh_taste(uid, cid, p, force=True)
        except Exception as e:
            log.info("вкус: %s", e)
        p["theme"] = (await AP.theme_from_taste(p.get("taste") or {}, ch.get("title", ""))
                      or AP.clean_theme(p.get("theme", ""), ch.get("title", "")))
        p["v82"] = True
        await AP.save(cid, p)
        if p.get("active"):
            await AP.apply(uid, cid, p)
            await AP.save(cid, p)
    return p


@router.callback_query(F.data.startswith("apl:h:"))
async def cb_home(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    await cb.answer("смотрю канал…")
    await _ensure(cid, cb.from_user.id)
    await show(cb, *await view(cid))


@router.callback_query(F.data.startswith("apl:t:"))
async def cb_toggle(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    key = cb.data.split(":")[2]
    p = await _ensure(cid, cb.from_user.id)
    on = p.setdefault("on", [])
    if key in on:
        on.remove(key)
    else:
        on.append(key)
    await AP.save(cid, p)
    if p.get("active"):
        await AP.apply(cb.from_user.id, cid, p)
        await AP.save(cid, p)
    await cb.answer()
    await show(cb, *await view(cid))


@router.callback_query(F.data.startswith("apl:m:"))
async def cb_mode(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    p = await _ensure(cid, cb.from_user.id)
    p["mode"] = "auto" if p.get("mode", "moderate") == "moderate" else "moderate"
    await AP.save(cid, p)
    if p.get("active"):
        await AP.apply(cb.from_user.id, cid, p)
        await AP.save(cid, p)
    await cb.answer("сразу в канал" if p["mode"] == "auto" else "сначала тебе")
    await show(cb, *await view(cid))


@router.callback_query(F.data.startswith("apl:go:") | F.data.startswith("apl:off:"))
async def cb_go(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    p = await _ensure(cid, cb.from_user.id)
    p["active"] = cb.data.startswith("apl:go:")
    if p["active"] and not p.get("on"):
        return await cb.answer("включи хотя бы одну рубрику", show_alert=True)
    made = await AP.apply(cb.from_user.id, cid, p)
    await AP.save(cid, p)
    await cb.answer(f"🚀 запустила {len(made)} рубрик(и)" if p["active"] else "⏸ остановила", show_alert=p["active"])
    await show(cb, *await view(cid))


@router.callback_query(F.data.startswith("apl:th:"))
async def cb_theme(cb: CallbackQuery, state: FSMContext):
    cid = await _own(cb)
    if not cid:
        return
    await state.set_state(APL.theme)
    await state.update_data(cid=cid)
    await cb.answer()
    await cb.message.answer("🎯 о чём канал? одной фразой, например: <i>рэп и хип-хоп, новости и мемы</i>\n"
                            + ui.hint("/cancel — отмена"))


@router.message(APL.theme)
async def st_theme(m: Message, state: FSMContext):
    d = await state.get_data()
    await state.clear()
    if (m.text or "").startswith("/"):
        return await m.answer("ок, отменила")
    cid = d["cid"]
    p = await _ensure(cid, m.from_user.id)
    p["theme"] = (m.text or "").strip()[:80]
    await AP.save(cid, p)
    if p.get("active"):
        await AP.apply(m.from_user.id, cid, p)
        await AP.save(cid, p)
    text, kb = await view(cid)
    await m.answer(text, reply_markup=kb)


@router.callback_query(F.data.startswith("apl:src:"))
async def cb_src(cb: CallbackQuery, state: FSMContext):
    cid = await _own(cb)
    if not cid:
        return
    await state.set_state(APL.src)
    await state.update_data(cid=cid)
    await cb.answer()
    await cb.message.answer(
        ui.head("➕", "Мой источник", "откуда брать") + "\n" + ui.quote(
            "пришли ссылку:\n• сайт или RSS — для новостей (найду ленту сама)\n• ТГ-канал t.me/… или VK-паблик — "
            "для мемов/новостей/видео\n• reddit.com/r/… или доска Pinterest — для мемов и картинок\n"
            "• YouTube/VK-видео — для рубрики «Видео»\n• Яндекс Музыка (плейлист, альбом, артист) или SoundCloud — "
            "для «Музыки»") + "\n" + ui.hint("/cancel — отмена"))


@router.message(APL.src)
async def st_src(m: Message, state: FSMContext):
    d = await state.get_data()
    if (m.text or "").startswith("/"):
        await state.clear()
        return await m.answer("ок, отменила")
    det = AP.detect_source(m.text or "")
    if not det:
        return await m.answer("😕 не поняла ссылку — пришли адрес сайта, t.me/канал, vk.com/паблик или reddit.com/r/…")
    t, src = det
    if t == "rss":
        st = await m.answer("🔎 ищу ленту на сайте…")
        try:
            src = await AP.find_feed(src)
        except sources.SourceError as e:
            return await st.edit_text(f"😕 {escape(str(e))}")
    try:
        probe = await sources.fetch(t, src, 5) if t not in ("video", "yamusic", "music") else [1]
    except Exception as e:
        return await m.answer(f"😕 источник не открылся: {escape(str(e)[:150])}")
    if not probe:
        return await m.answer("😕 там пусто — пришли другой")
    await state.clear()
    await state.update_data(pending=[t, src])
    fits = {"rss": ["news"], "tg": ["meme", "news", "video", "art"], "vk": ["meme", "news", "art"],
            "reddit": ["meme", "art", "news"], "pinterest": ["meme", "art", "video"], "video": ["video", "music"],
            "yamusic": ["music"], "music": ["music"]}.get(t, ["news"])
    rows = [[(f"{AP.RUBRICS[k]['emoji']} {AP.RUBRICS[k]['name']}", f"apl:sa:{k}:{d['cid']}")] for k in fits]
    await m.answer(f"✅ открыла: <b>{escape(src[:60])}</b>\nв какую рубрику?", reply_markup=kb_rows(*rows))


@router.callback_query(F.data.startswith("apl:sa:"))
async def cb_src_assign(cb: CallbackQuery, state: FSMContext):
    cid = await _own(cb)
    if not cid:
        return
    key = cb.data.split(":")[2]
    pend = (await state.get_data()).get("pending")
    if not pend:
        return await cb.answer("пришли ссылку заново", show_alert=True)
    await state.clear()
    p = await _ensure(cid, cb.from_user.id)
    lst = p.setdefault("sources", {}).setdefault(key, [])
    if pend not in lst:
        lst.append(pend)
    if key not in p.setdefault("on", []):
        p["on"].append(key)
    await AP.save(cid, p)
    if p.get("active"):
        await AP.apply(cb.from_user.id, cid, p)
        await AP.save(cid, p)
    await cb.answer("добавила")
    await show(cb, *await view(cid))


@router.callback_query(F.data.startswith("apl:try:"))
async def cb_try(cb: CallbackQuery, bot: Bot):
    """Пробный пост каждой включённой рубрики — тебе в личку, в канал не уходит."""
    from autopost import publisher, rules as R
    cid = await _own(cb)
    if not cid:
        return
    p = await _ensure(cid, cb.from_user.id)
    await cb.answer("собираю пробные посты — пару минут")
    was = p.get("active")
    p["active"] = True
    await AP.apply(cb.from_user.id, cid, p)
    p["active"] = was
    if not was:
        await AP.apply(cb.from_user.id, cid, p)   # вернуть «выключено», правила останутся на паузе
    await AP.save(cid, p)
    for key in p.get("on", []):
        rid = (p.get("rules") or {}).get(key)
        r = await store.rule(rid) if rid else None
        if not r:
            continue
        cfg = store.cfg_of(r)
        rb = AP.RUBRICS[key]
        try:
            seen = await store.seen_keys(rid)
            cands = await AP.candidates(r, cfg, seen, 1)
            post, why = None, []
            for it in cands[:6]:
                try:
                    post = await AP.materialize(r, cfg, it)
                    break
                except R.SkipItem as e:
                    why.append(str(e))
            if not post:
                await bot.send_message(cb.from_user.id, f"{rb['emoji']} <b>{rb['name']}</b>: не нашла подходящего — "
                                       + escape("; ".join(why[:3]) or "источник пуст"))
                continue
            await bot.send_message(cb.from_user.id, f"🧪 пробный · {rb['emoji']} <b>{rb['name']}</b>")
            await publisher.send(bot, {"text": post["text"], "media": post["media"], "buttons": [],
                                       "reactions": [], "opts": post["opts"]}, cb.from_user.id, preview=True)
        except Exception as e:
            log.info("пробный %s: %s", key, e)
            await bot.send_message(cb.from_user.id, f"{rb['emoji']} <b>{rb['name']}</b>: ошибка — {escape(str(e)[:120])}")


@router.callback_query(F.data.startswith("apl:rep:"))
async def cb_rep(cb: CallbackQuery):
    cid = await _own(cb)
    if not cid:
        return
    await cb.answer()
    await cb.message.answer(ui.head("📈", "Итоги недели", "автопилот") + "\n" + await AP.report(cid),
                            reply_markup=kb_rows([("‹ Автопилот", f"apl:h:{cid}")]))
