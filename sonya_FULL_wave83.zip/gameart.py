"""Волна 66: картинки для игр — виселица, блэкджек, колесо фортуны, гороскоп, топ.
Рисуем PIL за ~50–150 мс, без файлов и сети. Шрифты — те же, что у обложек (Unbounded + Manrope).
Эмодзи на картинке шрифт не нарисует — масти, звёзды и пр. рисуем фигурами."""
import io
import math
import random

from PIL import Image, ImageDraw, ImageFilter

import banners

W, H = 1280, 720
_f = banners._font
HEAD, TEXT, BOLD = banners.HEAD_FONT, banners.TEXT_FONT, banners.TAG_FONT


def _jpg(im: Image.Image) -> bytes:
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=88, optimize=True)
    return buf.getvalue()


def _bg(c1, c2, glow, seed, w=W, h=H) -> Image.Image:
    im = banners._gradient(c1, c2, w, h)
    banners._glow(im, glow, random.Random(seed), 3)
    banners._grain(im)
    return im


def _title(im, text, sub="", accent=(255, 255, 255)):
    banners._shadow_text(im, (64, 92), text, _f(HEAD, 56))
    if sub:
        ImageDraw.Draw(im).text((66, 140), sub, font=_f(TEXT, 30), fill=(235, 230, 245), anchor="ls")
    ImageDraw.Draw(im).rounded_rectangle([66, 160, 66 + 90, 166], radius=3, fill=accent)


# ================= 🔤 виселица =================
def hangman(word: str, got: set, miss: set, state: str = "play") -> bytes:
    """state: play | won | lost. Виселица дорисовывается по числу ошибок (0–6)."""
    lost, won = state == "lost", state == "won"
    im = _bg((14, 18, 40), (60, 30, 90), (255, 120, 120) if lost else (120, 200, 255), "hang")
    d = ImageDraw.Draw(im)
    _title(im, "Виселица", f"ошибок: {len(miss)} из 6", (255, 120, 120) if miss else (120, 200, 255))
    # виселица справа
    wood, rope = (226, 200, 160), (240, 230, 210)
    gx, gy = 900, 640
    d.line([(gx - 120, gy), (gx + 160, gy)], fill=wood, width=14)
    d.line([(gx - 60, gy), (gx - 60, 150)], fill=wood, width=14)
    d.line([(gx - 66, 150), (gx + 110, 150)], fill=wood, width=14)
    d.line([(gx - 60, 220), (gx + 0, 156)], fill=wood, width=10)
    d.line([(gx + 100, 150), (gx + 100, 215)], fill=rope, width=6)
    n = len(miss)
    body = (255, 255, 255) if not lost else (255, 140, 140)
    cx = gx + 100
    if n >= 1:   # голова
        d.ellipse([cx - 42, 215, cx + 42, 299], outline=body, width=9)
        if lost:   # крестики-глаза
            for ex in (-16, 16):
                d.line([(cx + ex - 7, 248), (cx + ex + 7, 262)], fill=body, width=5)
                d.line([(cx + ex + 7, 248), (cx + ex - 7, 262)], fill=body, width=5)
        else:
            for ex in (-16, 16):
                d.ellipse([cx + ex - 5, 248, cx + ex + 5, 258], fill=body)
    if n >= 2:
        d.line([(cx, 299), (cx, 440)], fill=body, width=9)
    if n >= 3:
        d.line([(cx, 330), (cx - 70, 390)], fill=body, width=9)
    if n >= 4:
        d.line([(cx, 330), (cx + 70, 390)], fill=body, width=9)
    if n >= 5:
        d.line([(cx, 440), (cx - 60, 540)], fill=body, width=9)
    if n >= 6:
        d.line([(cx, 440), (cx + 60, 540)], fill=body, width=9)
    # слово плитками
    letters = list(word)
    size = min(74, int(720 / max(1, len(letters))) - 8)
    x = 66
    for c in letters:
        show = c in got or lost or won
        miss_tile = lost and c not in got
        fill = (255, 255, 255, 40)
        banners._glass(im, [x, 470, x + size, 470 + size + 16], 12, 48 if show else 22,
                       (255, 120, 120) if miss_tile else (140, 220, 255) if show else (180, 180, 220))
        if show:
            ImageDraw.Draw(im).text((x + size // 2, 470 + (size + 16) // 2), c.upper(),
                                    font=_f(HEAD, int(size * 0.6)),
                                    fill=(255, 150, 150) if miss_tile else (255, 255, 255), anchor="mm")
        x += size + 8
    d = ImageDraw.Draw(im)
    if miss:
        d.text((66, 620), "мимо: " + " ".join(sorted(m.upper() for m in miss)), font=_f(TEXT, 32),
               fill=(255, 170, 170), anchor="ls")
    if won:
        _confetti(im, "won")
        banners._shadow_text(im, (66, 400), "Угадали!", _f(HEAD, 86), fill=(150, 255, 170))
    elif lost:
        banners._shadow_text(im, (66, 400), "Не угадали", _f(HEAD, 80), fill=(255, 150, 150))
    return _jpg(im)


def _confetti(im, seed):
    rng = random.Random(seed)
    d = ImageDraw.Draw(im)
    for _ in range(90):
        x, y = rng.randint(0, im.width), rng.randint(0, im.height)
        c = rng.choice([(255, 92, 170), (255, 210, 80), (110, 220, 255), (150, 255, 170), (200, 140, 255)])
        a = rng.random() * math.pi
        r = rng.randint(5, 11)
        d.polygon([(x + math.cos(a) * r, y + math.sin(a) * r), (x + math.cos(a + 1.8) * r * 0.5, y + math.sin(a + 1.8) * r * 0.5),
                   (x - math.cos(a) * r, y - math.sin(a) * r), (x - math.cos(a + 1.8) * r * 0.5, y - math.sin(a + 1.8) * r * 0.5)],
                  fill=c)


# ================= 🃏 блэкджек =================
RED = (214, 40, 60)
BLACK = (28, 28, 36)


def _suit(d, s: str, cx, cy, r, col):
    """Масть фигурами: ♥ ♦ ♠ ♣ (шрифт их не рисует)."""
    if s == "♦":
        d.polygon([(cx, cy - r), (cx + r * 0.7, cy), (cx, cy + r), (cx - r * 0.7, cy)], fill=col)
        return
    if s in ("♥", "♠"):
        k = -1 if s == "♠" else 1
        q = r * 0.52
        d.ellipse([cx - r, cy - k * r * 0.45 - q, cx - r + 2 * q, cy - k * r * 0.45 + q], fill=col)
        d.ellipse([cx + r - 2 * q, cy - k * r * 0.45 - q, cx + r, cy - k * r * 0.45 + q], fill=col)
        d.polygon([(cx - r * 0.98, cy - k * r * 0.3), (cx + r * 0.98, cy - k * r * 0.3), (cx, cy + k * r)], fill=col)
        if s == "♠":
            d.polygon([(cx, cy + r * 0.2), (cx - r * 0.35, cy + r * 1.05), (cx + r * 0.35, cy + r * 1.05)], fill=col)
        return
    q = r * 0.42   # ♣
    for dx, dy in ((0, -0.45), (-0.5, 0.1), (0.5, 0.1)):
        d.ellipse([cx + dx * r - q, cy + dy * r - q, cx + dx * r + q, cy + dy * r + q], fill=col)
    d.polygon([(cx, cy), (cx - r * 0.3, cy + r * 1.0), (cx + r * 0.3, cy + r * 1.0)], fill=col)


def _card(im, x, y, card: str | None, w=150, h=210):
    sh = Image.new("RGBA", im.size, (0, 0, 0, 0))
    ImageDraw.Draw(sh).rounded_rectangle([x + 6, y + 10, x + w + 6, y + h + 10], radius=16, fill=(0, 0, 0, 110))
    sh = sh.filter(ImageFilter.GaussianBlur(8))
    im.paste(sh, (0, 0), sh)
    d = ImageDraw.Draw(im)
    if card is None:   # рубашка
        d.rounded_rectangle([x, y, x + w, y + h], radius=16, fill=(120, 40, 160), outline=(255, 255, 255), width=4)
        for i in range(-h, w, 18):
            d.line([(x + max(0, i), y + max(0, -i)), (x + min(w, i + h), y + min(h, w - i))],
                   fill=(160, 80, 200), width=2)
        d.rounded_rectangle([x + 14, y + 14, x + w - 14, y + h - 14], radius=10, outline=(255, 200, 255), width=3)
        banners._shadow_text(im, (x + w // 2, y + h // 2 + 18), "S", _f(HEAD, 64), fill=(255, 220, 255), anchor="ms",
                             blur=3, alpha=90)
        return
    rank, suit = card[:-1], card[-1]
    col = RED if suit in "♥♦" else BLACK
    d.rounded_rectangle([x, y, x + w, y + h], radius=16, fill=(250, 248, 244), outline=(220, 215, 205), width=2)
    d.text((x + 16, y + 50), rank, font=_f(HEAD, 40 if len(rank) == 1 else 32), fill=col, anchor="ls")
    _suit(d, suit, x + 32, y + 78, 14, col)
    _suit(d, suit, x + w // 2, y + h // 2 + 18, 40, col)


def _clean(c: str) -> str:
    """«10♠️» → «10♠» (вариант-селектор эмодзи убираем)."""
    return c.replace("️", "")


def blackjack(dealer: list[str], hand: list[str], final: str = "", d_score="?", p_score=0, bet=0) -> bytes:
    im = _bg((10, 60, 36), (18, 110, 60), (120, 255, 170), "bj")
    d = ImageDraw.Draw(im)
    d.ellipse([-300, 380, W + 300, H + 700], outline=(200, 240, 200), width=3)
    _title(im, "Блэкджек", f"ставка {bet} монет", (255, 210, 80))
    d = ImageDraw.Draw(im)
    for row, (who, cards, sc, y) in enumerate((("Соня", dealer, d_score, 200), ("Ты", hand, p_score, 450))):
        d.text((66, y + 60), who, font=_f(HEAD, 40), fill=(255, 255, 255), anchor="ls")
        d.text((66, y + 110), f"очки: {sc}", font=_f(TEXT, 30), fill=(220, 245, 225), anchor="ls")
        for i, c in enumerate(cards[:7]):
            _card(im, 300 + i * 120, y - 20, None if c == "🂠" else _clean(c), w=140, h=196)
        d = ImageDraw.Draw(im)
    if final:
        good = "выиграл" in final or "блэкджек" in final
        tie = "ничья" in final
        label = "Победа!" if good else "Ничья" if tie else "Проигрыш"
        col = (150, 255, 170) if good else (255, 220, 120) if tie else (255, 150, 150)
        banners._glass(im, [W - 420, 40, W - 50, 140], 24, 40, col)
        banners._shadow_text(im, (W - 235, 106), label, _f(HEAD, 44), fill=col, anchor="ms", blur=6)
        if good:
            _confetti(im, "bjwin")
    return _jpg(im)


# ================= 🎡 колесо фортуны =================
def wheel(labels: list[str], idx: int) -> bytes:
    """Колесо с секторами, стрелка указывает на выпавший idx."""
    im = _bg((40, 12, 60), (120, 30, 90), (255, 200, 90), "wheel")
    n = len(labels)
    cx, cy, r = 880, 380, 300
    cols = [(255, 92, 170), (255, 190, 60), (90, 200, 255), (150, 255, 170), (200, 140, 255), (255, 130, 90),
            (120, 220, 210), (255, 230, 120)]
    # поворачиваем так, чтобы сектор idx был сверху, под стрелкой
    step = 360 / n
    base = -90 - (idx + 0.5) * step
    layer = Image.new("RGBA", im.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    d.ellipse([cx - r - 14, cy - r - 14, cx + r + 14, cy + r + 14], fill=(255, 255, 255, 230))
    for i in range(n):
        a0 = base + i * step
        d.pieslice([cx - r, cy - r, cx + r, cy + r], a0, a0 + step, fill=cols[i % len(cols)] + (255,),
                   outline=(255, 255, 255, 255), width=3)
    im.paste(layer, (0, 0), layer)
    d = ImageDraw.Draw(im)
    for i, lab in enumerate(labels):
        a = math.radians(base + (i + 0.5) * step)
        tx, ty = cx + math.cos(a) * r * 0.62, cy + math.sin(a) * r * 0.62
        t = Image.new("RGBA", (260, 60), (0, 0, 0, 0))
        ImageDraw.Draw(t).text((130, 30), lab, font=_f(BOLD, 26 if len(lab) < 8 else 20), fill=(30, 20, 40), anchor="mm")
        deg = -math.degrees(a)
        if math.cos(a) < 0:   # левая половина — переворачиваем, чтобы не читать вверх ногами
            deg += 180
        t = t.rotate(deg, expand=True, resample=Image.BICUBIC)
        im.paste(t, (int(tx - t.width / 2), int(ty - t.height / 2)), t)
    d = ImageDraw.Draw(im)
    d.ellipse([cx - 46, cy - 46, cx + 46, cy + 46], fill=(255, 255, 255), outline=(255, 200, 90), width=6)
    d.polygon([(cx - 34, cy - r - 46), (cx + 34, cy - r - 46), (cx, cy - r + 22)], fill=(255, 255, 255),
              outline=(255, 200, 90))
    _title(im, "Колесо", "раз в 20 часов", (255, 200, 90))
    banners._shadow_text(im, (66, 420), "выпало:", _f(TEXT, 40), fill=(240, 235, 250))
    banners._shadow_text(im, (66, 500), labels[idx], banners._fit(labels[idx], HEAD, 480, 72, 36), fill=(255, 220, 120))
    return _jpg(im)


# ================= 🔮 гороскоп =================
def horoscope(sign: str, date: str) -> bytes:
    rng = random.Random(sign)
    im = _bg((8, 10, 34), (50, 24, 90), (170, 130, 255), "horo" + sign)
    d = ImageDraw.Draw(im)
    for _ in range(160):   # звёздное небо
        x, y = rng.randint(0, W), rng.randint(0, H)
        s = rng.choice((1, 1, 1, 2, 2, 3))
        d.ellipse([x - s, y - s, x + s, y + s], fill=(255, 255, 255, 255))
    pts = [(rng.randint(760, 1180), rng.randint(140, 600)) for _ in range(7)]   # «созвездие» знака
    pts.sort()
    d.line(pts, fill=(200, 180, 255), width=3)
    for x, y in pts:
        d.ellipse([x - 9, y - 9, x + 9, y + 9], fill=(255, 240, 200))
    _title(im, "Гороскоп", f"на {date}", (170, 130, 255))
    banners._shadow_text(im, (66, 430), sign.capitalize(), banners._fit(sign.capitalize(), HEAD, 640, 120, 60),
                         fill=(255, 240, 210))
    return _jpg(im)


# ================= 🏆 топ =================
def top(title: str, rows: list[tuple[str, str]]) -> bytes:
    """rows: [(имя, значение)] — первые трое на пьедестале, дальше список."""
    im = _sonya_bg("games") or _bg((24, 14, 50), (80, 40, 130), (255, 210, 110), "top")   # волна 76: Соня фоном
    _title(im, title[:22], "кто впереди", (255, 210, 110))
    d = ImageDraw.Draw(im)
    podium = [(0, 640, 300, (255, 210, 80)), (1, 400, 380, (210, 215, 230)), (2, 880, 440, (220, 150, 90))]
    for place, x, y, col in podium:
        if place >= len(rows):
            continue
        name, val = rows[place]
        banners._glass(im, [x - 110, y, x + 110, 690], 18, 34, col)
        d = ImageDraw.Draw(im)
        d.ellipse([x - 52, y - 120, x + 52, y - 16], fill=col)
        d.text((x, y - 68), (name.strip()[:1] or "?").upper(), font=_f(HEAD, 54), fill=(40, 26, 60), anchor="mm")
        d.text((x, y + 50), str(place + 1), font=_f(HEAD, 64), fill=col, anchor="mm")
        d.text((x, y + 112), name[:12], font=banners._fit(name[:12], BOLD, 210, 30, 18), fill=(255, 255, 255), anchor="mm")
        d.text((x, y + 150), str(val), font=_f(TEXT, 28), fill=(235, 230, 245), anchor="mm")
    y = 210
    for i, (name, val) in enumerate(rows[3:10], start=4):
        d.text((1030, y), f"{i}. {name[:12]}", font=_f(TEXT, 28), fill=(240, 235, 250), anchor="ls")
        d.text((1240, y), str(val), font=_f(BOLD, 28), fill=(255, 220, 140), anchor="rs")
        y += 52
    return _jpg(im)


# ================= 🗓 автопостинг: неделя картинкой (волна 69) =================
def week(title: str, posts: list[tuple[int, str, str]], start_ts: int) -> bytes:
    """posts: [(время unix, тип медиа photo|video|audio|animation|text, короткий текст)] — на 7 дней от start_ts (МСК)."""
    import time as _t
    im = _sonya_bg("autopost") or _bg((12, 18, 46), (60, 40, 140), (160, 150, 255), "week")
    _title(im, "Неделя", title[:28], (160, 150, 255))
    d = ImageDraw.Draw(im)
    days = "пн вт ср чт пт сб вс".split()
    x0, top, colw, gap = 40, 200, 166, 8
    by_day: dict[int, list] = {}
    for at, kind, text in posts:
        k = (at + 3 * 3600) // 86400 - (start_ts + 3 * 3600) // 86400
        if 0 <= k < 7:
            by_day.setdefault(k, []).append((at, kind, text))
    icon_col = {"photo": (90, 200, 255), "video": (255, 120, 120), "audio": (150, 255, 170),
                "animation": (255, 210, 80), "text": (200, 190, 230)}
    for i in range(7):
        t = _t.gmtime(start_ts + i * 86400 + 3 * 3600)
        x = x0 + i * (colw + gap)
        today = i == 0
        banners._glass(im, [x, top, x + colw, 690], 18, 40 if today else 22, (160, 150, 255) if today else None)
        d = ImageDraw.Draw(im)
        d.text((x + colw // 2, top + 30), f"{days[t.tm_wday]} {t.tm_mday}", font=_f(BOLD, 28),
               fill=(255, 255, 255) if today else (220, 215, 240), anchor="mm")
        items = sorted(by_day.get(i, []))
        y = top + 64
        for at, kind, text in items[:4]:
            tt = _t.gmtime(at + 3 * 3600)
            banners._glass(im, [x + 8, y, x + colw - 8, y + 80], 12, 30)
            d = ImageDraw.Draw(im)
            d.ellipse([x + 18, y + 14, x + 34, y + 30], fill=icon_col.get(kind, (200, 190, 230)))
            d.text((x + 42, y + 22), f"{tt.tm_hour:02d}:{tt.tm_min:02d}", font=_f(BOLD, 24), fill=(255, 255, 255),
                   anchor="lm")
            short = (text or {"photo": "фото", "video": "видео", "audio": "трек", "animation": "гиф"}.get(kind, "пост"))
            short = short.replace("\n", " ")
            while short and _f(TEXT, 20).getbbox(short)[2] > colw - 34:
                short = short[:-2]
            d.text((x + 18, y + 58), short, font=_f(TEXT, 20), fill=(225, 220, 240), anchor="lm")
            y += 88
        if len(items) > 4:
            d.text((x + colw // 2, y + 18), f"+ ещё {len(items) - 4}", font=_f(TEXT, 22), fill=(200, 195, 230),
                   anchor="mm")
        if not items:
            d.text((x + colw // 2, top + 140), "пусто", font=_f(TEXT, 22), fill=(170, 165, 200), anchor="mm")
    return _jpg(im)


# ================= 📊 статистика чата картинкой (волна 76) =================
_OK_CH = r"[\w\s.,!?@#&+\-—–_'\"()«»:;/]"


def _name_ok(s: str, fallback: str = "участник") -> str:
    """Шрифт не умеет иероглифы и эмодзи — оставляю латиницу/кириллицу, пусто → «участник»."""
    import re
    t = "".join(ch for ch in s if re.match(_OK_CH, ch) and (ord(ch) < 0x2E80 or ch in "«»—–"))
    t = re.sub(r"\s+", " ", t).strip()
    return t or fallback


def _sonya_bg(theme: str, w=W, h=H) -> Image.Image | None:
    """Иллюстрация с Соней (та же, что у обложек разделов), затемнена под цифры. Нет файла — None."""
    p = banners.bg_path(theme)
    if not p.exists():
        return None
    try:
        img = Image.open(p).convert("RGB")
    except Exception:
        return None
    k = max(w / img.width, h / img.height)
    img = img.resize((max(w, round(img.width * k)), max(h, round(img.height * k))), Image.LANCZOS)
    x = img.width - w   # Соня справа — держим правый край
    img = img.crop((x, (img.height - h) // 2, x + w, (img.height - h) // 2 + h))
    shade = Image.new("L", (w, h))
    shade.putdata([int(225 - 120 * min(1.0, max(0.0, (xx - w * 0.45) / (w * 0.5)))) for yy in range(h) for xx in range(w)])
    dark = Image.new("RGB", (w, h), (12, 10, 30))
    img = Image.composite(dark, img.filter(ImageFilter.GaussianBlur(2)), shade)
    banners._grain(img)
    return img


def chat_stats(title: str, day_n: int, week_n: int, active: int, tops: list[tuple[str, int]],
               hours: list[int], word: str = "", word_n: int = 0) -> bytes:
    """Дашборд группы (сетка без наложений): слева — плитки и топ болтунов, справа — часы активности.
    На заднем плане — Соня (иллюстрация раздела «главная»), если фон нарисован."""
    im = _sonya_bg("home") or _bg((14, 16, 44), (54, 36, 120), (120, 150, 255), "stats" + title)
    _title(im, "Статистика", _name_ok(title, "чат")[:34], (120, 190, 255))
    accent, pink, gold = (120, 190, 255), (255, 110, 180), (255, 210, 110)
    L, R = 56, 600            # левая колонка
    PX0, PX1 = 648, 1224      # правая панель
    # --- плитки (3 × 170, зазор 16 → ровно до R)
    tw = (R - L - 32) // 3
    for i, (lab, val, col) in enumerate((("сегодня", day_n, accent), ("за неделю", week_n, pink),
                                         ("активных", active, gold))):
        x = L + i * (tw + 16)
        banners._glass(im, [x, 188, x + tw, 288], 18, 60, col)
        d = ImageDraw.Draw(im)
        d.text((x + 18, 246), str(val), font=banners._fit(str(val), HEAD, tw - 36, 48, 26), fill=(255, 255, 255), anchor="ls")
        d.text((x + 18, 276), lab, font=_f(TEXT, 22), fill=(225, 220, 245), anchor="ls")
    # --- топ болтунов
    d = ImageDraw.Draw(im)
    d.text((L, 344), "болтуны недели", font=_f(BOLD, 28), fill=(255, 255, 255), anchor="ls")
    rows = tops[:5]
    mx = max([n for _, n in rows] or [1])
    medal = [(255, 210, 80), (210, 215, 230), (220, 150, 90)]
    BX0, BX1 = L + 54, R - 120          # полоса; справа место под «38 · 40%»
    for i, (name, n) in enumerate(rows):
        y = 366 + i * 62
        col = medal[i] if i < 3 else (150, 140, 220)
        d.ellipse([L, y, L + 40, y + 40], fill=col)
        d.text((L + 20, y + 21), str(i + 1), font=_f(HEAD, 22), fill=(40, 26, 60), anchor="mm")
        nm = _name_ok(name)[:20]
        fnt = banners._fit(nm, BOLD, BX1 - BX0 - 28, 24, 15)
        bw = min(BX1 - BX0, max(fnt.getbbox(nm)[2] + 30, int((BX1 - BX0) * n / mx)))   # имя всегда внутри полосы
        banners._glass(im, [BX0, y + 2, BX0 + bw, y + 38], 16, 70, col)
        d = ImageDraw.Draw(im)
        d.text((BX0 + 14, y + 28), nm, font=fnt, fill=(255, 255, 255), anchor="ls")
        pct = round(n / max(week_n, 1) * 100)
        d.text((R, y + 28), f"{n} · {pct}%", font=_f(TEXT, 24), fill=(235, 230, 250), anchor="rs")
    # --- часы активности
    banners._glass(im, [PX0, 188, PX1, 610], 22, 34, accent)   # прозрачнее — Соня видна сквозь панель
    d = ImageDraw.Draw(im)
    cx0, cx1, cy0, cy1 = PX0 + 28, PX1 - 28, 260, 548
    peak = max(range(24), key=lambda h: hours[h]) if any(hours) else 12
    d.text((cx0, 232), "когда болтаете", font=_f(BOLD, 28), fill=(255, 255, 255), anchor="ls")
    d.text((cx1, 232), f"пик в {peak}:00", font=_f(TEXT, 24), fill=gold, anchor="rs")
    top_h = max(hours) or 1
    bw = (cx1 - cx0) / 24
    for h, v in enumerate(hours):
        bh = max(4, int((cy1 - cy0) * v / top_h))
        d.rounded_rectangle([cx0 + h * bw + 3, cy1 - bh, cx0 + (h + 1) * bw - 3, cy1], radius=5,
                            fill=(gold if h == peak else accent) if v else (90, 90, 140))
    for h in (0, 6, 12, 18, 23):
        d.text((cx0 + (h + 0.5) * bw, cy1 + 30), str(h), font=_f(TEXT, 22), fill=(220, 215, 240), anchor="mm")
    # --- слово недели (под панелью, в её ширину)
    if word:
        wtxt = f"слово недели: {word} · {word_n}×"
        f = banners._fit(wtxt, BOLD, PX1 - PX0 - 40, 28, 18)
        banners._glass(im, [PX0, 630, PX1, 684], 20, 70, pink)
        ImageDraw.Draw(im).text(((PX0 + PX1) // 2, 666), wtxt, font=f, fill=(255, 255, 255), anchor="ms")
    return _jpg(im)


# ================= 🖼 обложка поста автопилота (волна 79) =================
def _wrap(text: str, font, max_w: int, max_lines: int) -> list[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if font.getbbox(t)[2] <= max_w or not cur:
            cur = t
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    if len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(" ,.;:—") + "…"
    return lines


def post_card(img: bytes, title: str, sub: str = "", accent=(255, 110, 180)) -> bytes:
    """Картинка генератора (без текста) + НАШ заголовок нормальным шрифтом: генератор пишет по-русски кракозябры,
    поэтому буквы кладём сами. Снизу — тёмная дымка, заголовок до 3 строк, подпись (автор цитаты и т.п.)."""
    W2 = H2 = 1080
    src = Image.open(io.BytesIO(img)).convert("RGB")
    k = max(W2 / src.width, H2 / src.height)
    src = src.resize((max(W2, round(src.width * k)), max(H2, round(src.height * k))), Image.LANCZOS)
    x, y = (src.width - W2) // 2, (src.height - H2) // 2
    im = src.crop((x, y, x + W2, y + H2))
    grad = Image.new("L", (1, H2))
    for yy in range(H2):
        grad.putpixel((0, yy), int(215 * max(0.0, (yy - H2 * 0.55) / (H2 * 0.45)) ** 1.4))   # волна 83: легче
    im.paste(Image.new("RGB", (W2, H2), (10, 8, 20)), (0, 0), grad.resize((W2, H2)))
    d = ImageDraw.Draw(im)
    title = " ".join((title or "").split())[:160]
    size = 64
    while size > 38:
        f = _f(HEAD, size)
        lines = _wrap(title, f, W2 - 140, 3)
        if len(lines) <= 3 and all(f.getbbox(ln)[2] <= W2 - 140 for ln in lines):
            break
        size -= 4
    f = _f(HEAD, size)
    lines = _wrap(title, f, W2 - 140, 3)
    lh = int(size * 1.18)
    base = H2 - 90 - (46 if sub else 0) - lh * (len(lines) - 1)
    d.rounded_rectangle([70, base - lh - 34, 70 + 96, base - lh - 26], radius=4, fill=accent)
    for i, ln in enumerate(lines):
        banners._shadow_text(im, (70, base + i * lh - lh // 3), ln, f)
    if sub:
        d = ImageDraw.Draw(im)
        d.text((72, H2 - 70), sub[:60], font=_f(TEXT, 34), fill=(235, 228, 245), anchor="ls")
    return _jpg(im)


# ================= ⏰ расписание источника картинкой (волна 81) =================
def schedule_card(title: str, label: str, next_ts: int, posts: list[tuple[int, int, int]],
                  off: list[tuple[int, int]], now: int, hours: int = 24) -> bytes:
    """Лента ближайших суток: точки — посты, полосы — окно, в которое пост может выйти (разброс),
    серые зоны — нерабочие часы/дни. posts: [(центр, от, до)] unix; off: [(от, до)]."""
    import time as _t
    from datetime import datetime, timedelta, timezone
    msk = timezone(timedelta(hours=3))
    im = _sonya_bg("autopost") or _bg((12, 18, 46), (60, 40, 140), (160, 150, 255), "sched")
    _title(im, "Расписание", title[:34], (160, 150, 255))
    d = ImageDraw.Draw(im)
    accent, gold = (160, 150, 255), (255, 210, 110)
    banners._glass(im, [56, 190, 600, 300], 20, 60, accent)
    d = ImageDraw.Draw(im)
    d.text((80, 240), label, font=banners._fit(label, HEAD, 500, 40, 22), fill=(255, 255, 255), anchor="ls")
    nxt = datetime.fromtimestamp(next_ts, msk).strftime("%H:%M") if next_ts else "—"
    d.text((80, 282), f"следующий пост: {nxt}", font=_f(TEXT, 26), fill=(230, 225, 245), anchor="ls")
    x0, x1, y = 70, W - 70, 470
    span = hours * 3600
    X = lambda ts: x0 + (x1 - x0) * max(0.0, min(1.0, (ts - now) / span))   # noqa: E731
    banners._glass(im, [40, 360, W - 40, 600], 22, 40, accent)
    d = ImageDraw.Draw(im)
    for a, b in off:   # нерабочее время
        if b > now and a < now + span:
            d.rectangle([X(a), y - 60, X(b), y + 40], fill=(40, 36, 60))
    d.line([x0, y, x1, y], fill=(200, 195, 230), width=4)
    start = datetime.fromtimestamp(now, msk)
    for h in range(hours + 1):
        ts = int((start.replace(minute=0, second=0) + timedelta(hours=h)).timestamp())
        if ts < now or ts > now + span:
            continue
        hh = datetime.fromtimestamp(ts, msk).hour
        big = hh % 6 == 0
        d.line([X(ts), y - (14 if big else 7), X(ts), y + (14 if big else 7)], fill=(200, 195, 230), width=3 if big else 2)
        if big:
            d.text((X(ts), y + 44), f"{hh:02d}:00", font=_f(TEXT, 22), fill=(220, 215, 240), anchor="mm")
    for i, (c, a, b) in enumerate(posts):
        if c > now + span:
            break
        if b > a:
            band = Image.new("RGBA", im.size, (0, 0, 0, 0))
            ImageDraw.Draw(band).rounded_rectangle([X(a), y - 22, max(X(b), X(a) + 6), y + 22], radius=12,
                                                   fill=(255, 210, 110, 70 if i else 110))
            im.paste(band, (0, 0), band)
            d = ImageDraw.Draw(im)
        col = gold if i == 0 else (255, 255, 255)
        d.ellipse([X(c) - 11, y - 11, X(c) + 11, y + 11], fill=col, outline=(40, 26, 60), width=3)
        if i < 6:
            lab = datetime.fromtimestamp(c, msk).strftime("%H:%M")
            d.text((X(c), y - 40), ("~" if i else "") + lab, font=_f(BOLD, 22), fill=col, anchor="mm")
    d.text((70, 580), "точка — пост · полоса — окно, где он может выйти · серое — не публикую",
           font=_f(TEXT, 20), fill=(200, 195, 225), anchor="ls")
    return _jpg(im)
