"""Волна 82: автопилот учится на канале — тема без названия, музыка похожая на твою, видео с твоих досок,
новости только про твоих артистов и свежие. python test_w82.py ../sonya"""
import asyncio, json, sys, time
from harness import *  # noqa
import harness as H
import config
config.PROFILE = "full"

CID, UID = -100999, 1


async def main():
    M, bot, dp = await setup()
    import llm
    from autopost import autopilot as AP, store, sources, media_dl as md, rules as R
    await store.add_channel(CID, UID, "H9 музыка/music", "h9")
    check("тема без названия канала («H9» ломало факты)", AP.clean_theme("музыка H9 и эстетика", "H9 музыка/music")
          == "музыка и эстетика")

    ym = await store.add_rule(UID, CID, "yamusic", "likes", "лайки")
    await store.set_cfg(ym, token="TOK")
    for k in ("101:1", "102:1", "103:2"):
        await store.mark_seen(ym, k)
    await store.add_rule(UID, CID, "pinterest", "Nesoobu/h9", "h9")

    async def ym_meta(ids, token):
        return [{"key": i, "artist": "MiyaGi, Эндшпиль" if i != "103:2" else "Скриптонит", "title": "x", "duration": 200}
                for i in ids]

    async def board(src):
        return [{"key": "pin:1", "kw": "vhs aesthetic night", "is_video": True, "image": "https://i.pinimg.com/736x/1.jpg",
                 "video_list": {"V_720P": {"url": "https://v1.pinimg.com/videos/mc/720p/1.mp4"}}},
                {"key": "pin:2", "kw": "vhs aesthetic night", "is_video": False, "image": "https://i.pinimg.com/736x/2.jpg"},
                {"key": "pin:3", "kw": "rose film grain", "is_video": False, "image": "https://i.pinimg.com/736x/3.jpg"}]
    md.ym_meta, sources.pinterest_board = ym_meta, board

    async def ask(msgs, **k):
        if "Опиши тему" in msgs[0]["content"]:
            return "русский рэп и VHS-эстетика H9"
        return "ok"
    llm.ask = ask
    SENT.clear()
    await dp.feed_update(bot, cbq(f"apl:h:{CID}", UID, UID))
    p = await AP.profile(CID)
    t = p["taste"]
    check("учусь на канале: артисты из твоих треков, доски, слова пинов", t["artists"][:2] == ["MiyaGi", "Эндшпиль"]
          and t["boards"] == ["Nesoobu/h9"] and "vhs aesthetic night" in t["kw"] and p["theme"] == "русский рэп и VHS-эстетика")
    check("на экране видно, на чём учусь", "учусь на твоём канале" in "\n".join(H.texts()))

    ms = AP.default_sources("music", p["theme"], "TOK", t)
    check("музыка — похожие на твои треки (не чарт)", ms and all(s.startswith("similar:") for _, s in ms)
          and ["yamusic", "similar:101"] in ms)
    check("без твоей музыки — не гадаю из чарта", AP.default_sources("music", "x", "", {}) == [])
    vs = AP.default_sources("video", p["theme"], "", t)
    check("видео — с твоей доски и похожие по словам её пинов, без YouTube-каши",
          ["pinterest", "Nesoobu/h9"] in vs and ["pinterest", "v:vhs aesthetic night"] in vs and not any(x == "video" for x, _ in vs))
    ns = AP.default_sources("news", p["theme"], "", t)
    check("новости — про твоих артистов, только за 3 дня", "MiyaGi" in ns[0][1] and "when%3A3d" in ns[0][1])

    try:
        await AP.judge_news({"title": "Вышел новый смартфон", "text": "", "ts": int(time.time())}, "рэп", [],
                            artists=["MiyaGi", "Скриптонит"])
        ok = False
    except AP.Reject as e:
        ok = "артистов" in str(e)
    check("новость не про твоих артистов — мимо", ok)

    async def fetch(t_, src, limit=10):
        return await board(src)
    sources.fetch = fetch
    rule = {"id": 999, "source": "video", "type": "auto"}
    c = await AP.candidates(rule, {"rubric": "video", "sources": [["pinterest", "Nesoobu/h9"]]}, set(), 1)
    check("с доски в «Видео» идут только видео-пины", [x["key"] for x in c] == ["pinterest|pin:1"] and c[0]["_board"])

    class FakeClient:
        async def tracks_similar(self, tid):
            class T:
                def __init__(s, i): s.id, s.albums = i, []
            class R_:
                similar_tracks = [T(201), T(202)]
            assert tid == "101"
            return R_()

    async def client(token): return FakeClient()
    md._ym_client = client
    check("Яндекс: «похожие на трек» работает", await md.ym_ids("similar:101", "TOK") == ["201", "202"])
    # факт с названием канала — переписывается
    outs = ["Тайный аккорд H9\nвыдумка про H9", "Первый рэп-баттл\nВ 1979 году вышел трек Rapper's Delight."]

    async def ask2(msgs, **k):
        if "фактчекер" in msgs[0]["content"]:
            return '{"score": 8, "made_up": false}'
        if "English prompt" in msgs[0]["content"] or "short vivid" in msgs[0]["content"]:
            return "vinyl"
        return outs.pop(0) if outs else "x\ny"
    llm.ask = ask2
    from handlers import tools

    async def fimg(url): raise Exception("нет сети")
    tools.fetch_image = fimg
    p = await AP.profile(CID)
    p["on"].append("fact")
    p["active"] = True
    await AP.apply(UID, CID, p)
    await AP.save(CID, p)
    r_ = await store.rule(p["rules"]["fact"])
    post = await AP.materialize(r_, store.cfg_of(r_), {"key": "ai:1", "_ai": True})
    check("факт с «H9» (название канала) — переписан, вышел нормальный", "H9" not in post["text"] and "1979" in post["text"])
    await db.close()
    print("итого провалов:", len(FAILS))


asyncio.run(main())
sys.exit(1 if FAILS else 0)
